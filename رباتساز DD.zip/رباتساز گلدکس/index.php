<?php
/*
سورس رباتساز گلدکس
اوپن شده در دو تیم زیر :
@Cristal_Team
@GoldCreate
*/

// راهنما : در فایل ها چک کنید ادرس دامین + نام پوشه سورس را در قسمت متغییر $URL وارد کنید.
// موفق باشید:)
//@mahdiphp
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("@MAHDIPHP");
//---
define('API_KEY','TOKEN'); // توکن بزار
ini_set("log_errors" , "off");
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

//---Mahdiphp---
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$message_id = $update->message->message_id; 
$message_id = $message->message_id; 
$message_id2 = $update->callback_query->message->message_id; //
$chat_id = $message->chat->id; 
$chatID = $callback_query->message->chat->id;
$forward_chat_username = $update->message->forward_from_chat->username;
$reply = $update->message->reply_to_message;
@mkdir("data");
@mkdir("data/$chat_id");
$from_id = $message->from->id;
$from_id2 = $results->callback_query->from->id;
$text = $message->text;
$text1 = $message1->text1;
$text1 = $message->text;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$username = $update->message->from->username; 
$c_id2 = $message->forward_from_chat->id;
$photo = $message->photo;
$botusername = "BOTNAME"; // ایدی ربات بدون @
$admin = "1390815208"; // ایدی ادمین
$admin1 = "1214486292"; // ایدی ادمین 1
$channel = "@Cristal_Team"; // ایدی کانال با @
$canel = "@CodexTem"; // ایدی کانال با @
$channel1 = "GoldenCreate"; //ایدی کانال 1 با @
$token = API_KEY; // دس نزنید!
$rpto = $update->message->reply_to_message->forward_from->id;
$URL = "db + folder"; // ادرس سورس
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$blocklist = file_get_contents("data/blocklist.txt"); 
$step = file_get_contents("data/$from_id/step.txt");
$step = $user["step"];
@$list = file_get_contents("Member.txt");
$maxcreate = $settings["maxcreate"];
$invite = $user["invite"];
$newinvite = $user["invite"];
$createfree = $user["create"];
$createbot = $user["createbot"];
$createbot = $user["createbot"];
$createbotsaz = $user["createbotsaz"];
$createbotgem = $user["createbotgem"];
$createbotvip = $user["createbotvip"];
$createbotcrs = $user["createbotcrs"];
$createbotfire = $user["createbotfire"];
$createbotgh = $user["createbotgh"];
$createbotble = $user["createbotble"];
$createbotbnz = $user["createbotbnz"];
$type = $user["type"];
$Stoken = $user["Stoken"];
$typegold = $user["typegold"];
$typebnz = $user["typebnz"];
$typecrs = $user["typecrs"];
$typevip = $user["typevip"];
$typegh = $user["typegh"];
$typefire = $user["typefire"];
$typeGolden = $user["typeGolden"];
$typeble = $user["typeble"];
$typegem = $user["typegem"];
$yourbotsaz = $user["yourbotsaz"];
$settings = json_decode(file_get_contents("data/settings.json"),true);
$code_silver = $settings["code_silver"];
$code_bnz = $settings["code_bnz"];
$code_gem = $settings["code_gem"];
$code_gh = $settings["code_gh"];
$code_crs = $settings["code_crs"];
$code_Novin = $settings["code_Novin"];
$code_Goldex3 = $settings["code_Goldex3"];
$code_gold = $settings["code_gold"];
$code_ble = $settings["code_ble"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot1442345680:AAFhej_NGlbsn6VpjDUyjMOJuwQocBFzGxI/getChatMember?chat_id=@Cristal_Team&user_id=".$chat_id));
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot1442345680:AAFhej_NGlbsn6VpjDUyjMOJuwQocBFzGxI/getChatMember?chat_id=@GoldenCreate&user_id=".$chat_id));
$torchannel = json_decode(file_get_contents("https://api.telegram.org/bot1442345680:AAFhej_NGlbsn6VpjDUyjMOJuwQocBFzGxI/getChatMember?chat_id=@CodexTem&user_id=".$chat_id));
$cinvite = "29"; //تعداد زیر مجموعه گیری
$tch = $forchaneel->result->status;
$tch = $truechannel->result->status;
$tch = $torchannel->result->status;
$golden_times = $settings["golden_times"];
$golden_pic = $settings["golden_pic"];
$golden_txt = $settings["golden_txt"];
$chcode = -1001191987781;
$chlog = -1001191987781;
$channel_logs = -1001191987781;
$mode = $settings["mode"];
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
			
				function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 
 //
 if(strpos($text, '$') !== false or strpos($text, '}') !== false or strpos($text, '{') !== false){
SendMessage($chat_id,"⚠️ هشدار : این متن مورد تایید ما نیست تکرار نکنید","html","true");
exit;
}
//----
if(strpos($blocklist, "$from_id") !== false  ) {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
شما به دستور ادمین بلاک شدید.
",
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
])
]);
}
//--امنیت--//
if(strpos($text,"'") !== false or strpos($text,'"') !== false or strpos($text,"}") !== false or strpos($text,"{") !== false or strpos($text,"$") !== false or strpos($text,"=") !== false or strpos($text,",") !== false){
 $addus= $from_id . "\n";
file_put_contents("data/blocklist.txt", $addus);
$title = $getch->result->title;
$userch = $getch->result->username;
$ok = $getch->ok;
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کد داد کــیر شد ⚠️

⚡ - [$from_id](tg://user?id=$from_id)

-  -  -
$text
-  -  -",
 'parse_mode'=>"MarkDown",
  ]); 
 }
//------کریستال تیم--//
if(strpos($textmessage=="/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "free";
$user["type"] = "free";
$user["invite"] = "0";
$user["createbot"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
if($golden_times == "on"){
        $user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 2;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
                    'text'=>"✌️🔥یک نفر از طریق لینک شما به ربات اضافه شد🤓

به دلیل روشن بودن ساعات طلایی دو برابر حساب شد : 2 نفر🌈

شما تا الان $newinvite نفر را به ربات آورده اید و  برای ویژه شدن در رباتساز گلدکس به $cinvite زیرمجموعه نیاز دارید☔️🔫

 اگر زیرمجموعه های شما به $cinvite رسیده به بخش 💎جزئیات رباتساز گلدکس💎 بروید و حساب خود را رایگان ویژه کنید",
                   'parse_mode'=>"HTML",
	                      ]);
					}else{
						        $user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
                    'text'=>"✌️🔥یک نفر از طریق لینک شما به ربات اضافه شد🤓

شما تا الان $newinvite نفر را به ربات آورده اید و  برای ویژه شدن در رباتساز گلدکس به $cinvite زیرمجموعه نیاز دارید☔️🔫

 اگر زیرمجموعه های شما به $cinvite رسیده به بخش 💎جزئیات رباتساز گلدکس💎 بروید و حساب خود را رایگان ویژه کنید",
                   'parse_mode'=>"HTML",
	                      ]);
						
					}
					}
					}
if(!file_exists("data/$from_id.json")) {
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "free";
$user["type"] = "free";
$user["invite"] = "0";
$user["create"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
}
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
		 bot('sendMessage',[
                    'chat_id'=>$chat_id,
'text'=>"🍏 برای حمایت از رباتساز گلدکس در کانال های ما عضو شوید!

💎 @Cristal_Team 
☀️ @GoldenCreate 
🕷 @CodexTem
و سپس بعد از عضویت مجددن /start کنید🛠",
                   'parse_mode'=>"HTML",
]); 
}else{
    function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 1000;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"جهت جلوگیری از اسپم ربات شما به مدت 1000 ثانیه از رباتساز گلدکس بلاک شدید"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
if ($mode == "off"){
   	bot('sendMessage',[
                    'chat_id'=>$chat_id,
                    'text'=>"رباتساز گلدکس در حال اپدیت میباشد ⚙

📌لطفا بعد از اپدیت و اطلاع رسانی در چنل ( @Cristal_Team ) دوباره /start کنید.",
'parse_mode'=>"HTML",
]); 
}

//
elseif($textmessage == "/start"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"🤖 به سرویس رباتساز پیشرفته گلدکس خوش آمدید

🤠 با این رباتساز ربات و رباتساز های با امنیت و بدون باگ خود را بساز !
CH📍= @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"❄️ ورود به پنل ها ❄️"],['text'=>"🖲 جزئیات ساخت"]],
[['text'=>"🎲اسپانسر ما🎲"],['text'=>"☑️ پشتیبانی"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//=cristal_team==//
elseif($textmessage == "❄️ ورود به پنل ها ❄️"){
     $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"⚙ به پنل های #پیشرفته رباتساز #گلدکس خوش آمدید!

🔵🔴 یک #پنل را برای ساخت انتخاب کن!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔵 ورود به پنل آبی 🔵"]],
[['text'=>"🔴 ورود به پنل قرمز 🔴"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
    "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//============================================
elseif($textmessage == "🔴 ورود به پنل قرمز 🔴"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"یک بخش را جهت ساختن ربات انتخاب کن! 🛠 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🌕ساخت ضد لینک ربو ایرانی🌖"],['text'=>"💥 ساخت آی ویو | بازدیدبگیر 💥"]],
[['text'=>"🌤ساخت ضد لینک گپ گرام🌤"],['text'=>"🎳ساخت ربات موزیک استور🎳"]],
[['text'=>"ساخت ممبرگیر شیشه ای🍀"],['text'=>"🏅ساخت روبات اصل بده🏅"]],
[['text'=>"ساخت ربات هاستینگ🥝"],['text'=>"ساخت ربات دانلود از گیت هاب☄️"]],
[['text'=>"🏖ساخت ربات تبادل کانال🏖"]],
[['text'=>"پیامرسان شیشه ای🌹"],['text'=>"پیامرسان دکمه ای🏛"]],
[['text'=>"ساخت پیامرسان ربو ایرانی🔌"]],
[['text'=>"🍏برگشت به پنل ها🍎"]],
],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//===//
elseif($text1 == "📡 وضعیت سرور"){
$load = sys_getloadavg();
$mem = memory_get_usage();
$ver = phpversion();           
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📡 پینگ  : $load[0]
🧭 ورژن پی اچ پی : $ver
🎛 میزان مصرف حافظه : $mem KB",
'parse_mode'=>'HTML',
]);
 }
//==//
elseif($textmessage == "🍏برگشت به پنل ها🍎"){
     $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"⚙ به پنل های #پیشرفته رباتساز #گلدکس خوش آمدید!

🔵🔴 یک #پنل را برای ساخت انتخاب کن!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔵 ورود به پنل آبی 🔵"]],
[['text'=>"🔴 ورود به پنل قرمز 🔴"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
    "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//==//
elseif($textmessage == "🔵 ورود به پنل آبی 🔵"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"یک بخش را جهت ساختن رباتساز انتخاب کن! 🛠",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>" 👇بخش 1👇"]],
[['text'=>"🍉بخش ساخت رباتساز کریت گرام🍉"]],
[['text'=>"💎بخش ساخت رباتساز گلدکس💎"]],
[['text'=>"🌟بخش ساخت رباتساز نوین تاج🌟"]],
[['text'=>"🌱بخش ساخت رباتساز سایبر کریت🌱"]],
[['text'=>"🍇بخش ساخت رباتساز هاجی کریت🍇"]],
[['text'=>"🍖بخش ساخت رباتساز تک (فوق پیشرفته)🍖"]],
[['text'=>"🍳بخش ساخت رباتساز سایبر آلفا🍳"]],
[['text'=>"🍉ساخت رباتساز نوین فایر🍉"]],
[['text'=>"💡ساخت ربات هاجی لایت💡"]],
[['text'=>" 👇بخش 2👇"]],
[['text'=>"ساخت رباتساز گلد"]],
[['text'=>"ساخت رباتساز ساده⏳"]],
[['text'=>"ساخت رباتساز ویژه🍯"]],
[['text'=>"ساخت رباتساز هاجی روبوت🌶"]],
[['text'=>"🍏برگشت به پنل ها🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🎨بخش ساخت رباتساز کریت کاپ🎨"){
     $user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز کریت کاپ خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ساخت رباتساز کریت کاپ(نسخه جدید)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
    "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🍳بخش ساخت رباتساز سایبر آلفا🍳"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتسازسایبر آلفا خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ساخت رباتساز سایبر آلفا (نسخه جدید)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🍖بخش ساخت رباتساز تک (فوق پیشرفته)🍖"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتسازتک خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ساخت رباتساز تک(نسخه جدید)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🎃بخش ساخت رباتساز بت🎃"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز بت خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ساخت رباتساز بت(نسخه جدید)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🍇بخش ساخت رباتساز هاجی کریت🍇"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز هاجی کریت خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"هاجی کریت(نسخه قدیمی)"]],
[['text'=>"هاجی کریت(نسخه جدید)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🍉بخش ساخت رباتساز کریت گرام🍉"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز کریت گرام خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"کریت گرام(نسخه4)"],['text'=>"کریت گرام(نسخه4.1)"]],
[['text'=>"کریت گرام(نسخه6)"],['text'=>"کریت گرام(نسخه6.2)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🌟بخش ساخت رباتساز نوین تاج🌟"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز نوین تاج خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ساخت رباتساز نوین تاج(نسخه جدید)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "💎بخش ساخت رباتساز گلدکس💎"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز گلدکس خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"رباتساز گلدکس(نسخه2)"]],
[['text'=>"رباتساز گلدکس(نسخه2.2)"]],
[['text'=>"ساخت رباتساز گلدکس(نسخه 3.0)"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🌱بخش ساخت رباتساز سایبر کریت🌱"){
    	$user["step"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت رباتساز سایبر کریت خوش آمدید
جهت ساخت یک نسخه را انتخاب نمایید💎💎
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔥ساخت ربات ساز سایبر کریت🔥"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//==//
elseif($textmessage == "🌀 هاستینگ مگاران سرور🌀"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"⚡️  مگاران سرور 

☁️ ارائه دهنده سرویس های میزبانی وب
☁️ ارائه هاست پر سرعت 
☁️ لوکیشن المان
☁️ کنترل پنل سیپنل
☁️ سرعت بالا
☁️ پینگ مناسب به تلگرام
☁️ پشتیبانی از پایتون,میدلاین و ...
🌐 ارائه دامین .ir

👨🏻‍💻 پشتیبانی همه روزه از 8 صبح تا 9 شب
🖊 ضمانت بازگشت وجه
💵 نماد اعتماد ایدی پی
✔️ کیفیتی که انتظار داشتید، قیمتی که انتظار نداشتید 
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
📡 @Megaranserver
🌐 Megaranserver.ir
👨‍💻 @Megaran_support
🤖 @MegaranServerBot",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//
elseif($textmessage == "🎲اسپانسر ما🎲"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش اسپانسر هاست ما خوش آمدید🎯
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🌀 هاستینگ مگاران سرور🌀"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

elseif($textmessage == "راهنمایی ساخت ربات🎈"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش راهنمایی ساخت ربات خوش آمدید🕹
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔻راهنمایی ساخت روبات🔺"]],
[['text'=>"💻راهنمایی دستورات بات فادر💻"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
elseif($textmessage == "🍏برگشت به منوی اصلی🍎"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"💎به منوی اصلی رباتساز گلدکس خوش امدید💎",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"❄️ ورود به پنل ها ❄️"],['text'=>"🖲 جزئیات ساخت"]],
[['text'=>"🎲اسپانسر ما🎲"],['text'=>"☑️ پشتیبانی"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

elseif($textmessage == "🖲 جزئیات ساخت"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش (  🖲 جزئیات ساخت ) خوش آمدید 
🤖 یکی از گزینه های زیر را انتخاب کن !
@Cristal_Team",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"اطلاع از ساعت طلایی🎗"],['text'=>"تعداد زیرمجموعه های من🏆"]],
[['text'=>"💠خرید حساب ویژه💠"],['text'=>"راهنمایی ساخت ربات🎈"]],
[['text'=>"🎁بخش کد هدیه🎁"],['text'=>"📡 وضعیت سرور"]],
[['text'=>"زیرمجموعه گیری👥"],['text'=>"💎 ویژه شدن 💎"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
	//=============================================
elseif($textmessage == "اطلاع از ساعت طلایی🎗"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"وضعیت ساعت طلایی در رباتساز گلدکس🏵👇
$golden_times
جهت ویژه شدن در رباتساز گلدکس به $cinvite زیرمجموعه نیاز دارید تا ویژه بشید🗣🌷",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"اطلاع از ساعت طلایی🎗"],['text'=>"تعداد زیرمجموعه های من🏆"]],
[['text'=>"💠خرید حساب ویژه💠"],['text'=>"راهنمایی ساخت ربات🎈"]],
[['text'=>"🎁بخش کد هدیه🎁"],['text'=>"📡 وضعیت سرور"]],
[['text'=>"زیرمجموعه گیری👥"],['text'=>"💎 ویژه شدن 💎"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//------------------------------------------------
elseif($textmessage == "تعداد زیرمجموعه های من🏆"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>" اطلاع از روشن بودن ساعت طلایی🌾: $golden_times
تعداد زیر مجموعه جهت ویژه شدن🍀: $cinvite
مقدار امتیاز شما از زیرمجموعه گیری برابر : $newinvite
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"اطلاع از ساعت طلایی🎗"],['text'=>"تعداد زیرمجموعه های من🏆"]],
[['text'=>"💠خرید حساب ویژه💠"],['text'=>"راهنمایی ساخت ربات🎈"]],
[['text'=>"🎁بخش کد هدیه🎁"],['text'=>"📡 وضعیت سرور"]],
[['text'=>"زیرمجموعه گیری👥"],['text'=>"💎 ویژه شدن 💎"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 
}
	 
	elseif($textmessage ==
"💠خرید حساب ویژه💠"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"⚙ جهت خرید حساب ویژه بخش 1 و 2 به متی ولف مراجعه کنید !
@Metiym
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"☑️ پشتیبانی"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
           ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	
	 	elseif($textmessage ==
"💻راهنمایی دستورات بات فادر💻"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔻دستورهای مورد نیاز در بات فادر🔺
@Botfather
🔷ساخت ربات جدید⬇️
/newbot 
🔷دریافت توکن ربات های ساخته شده⬇️
/token 
🔷تغییر دادن توکن ربات های ساخته شده⬇️
/revoke 
🔷تغییر نام ربات های شما⬇️
/setname 
🔷اضافه کردن متن توضیحات ربات ها⬇️
/setdescription 
🔷تعیین کردن متن درباره اطلاعات ربات شما⬇️
/setabouttext 
🔷تغییر دادن عکس ربات ها⬇️
/setuserpic 
🔷اضافه کردن اینلاین⬇️
/setinline
🔷درخواست دریافت موقعیت⬇️
/setinlinegeo 
🔷تنظیمات اینلاین⬇️
/setinlinefeedback
🔷تنظیم دستورات ربات که با / شروع میشود⬇️
/setcommands
🔷تنظیم عضویت در گروه که با فعال بودن و غیر فعال بودن کار میکنه⬇️
/setjoingroups 
🔷به پیام ها در گروه دسترسی داشته باشد⬇️
/setprivacy
🔷حذف کردن ربات⬇️
/deletebot 
🔷لغو آخرین عملیات⬇️
/cancel",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
           [['text'=>"🍏برگشت به منوی اصلی🍎"]],
           ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	elseif($textmessage == "🎁بخش کد هدیه🎁"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🗂یک بخش را برای کد هدیه انتخاب کنید🗂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"کد هدیه رباتساز ساده⏳"]],
[['text'=>"کد هدیه رباتساز نوین فایر"]],
[['text'=>"کد هدیه رباتساز گلدکس نسخه 3"]],
[['text'=>"کد هدیه رباتسازهاجی روبوت🍢"]],
[['text'=>"کد هدیه رباتساز ویژه🍶"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>false,
	 ])
	 ]); 
	 }

	
//---
elseif($textmessage == "🔻راهنمایی ساخت روبات🔺"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
🚦برای ساخت ربات اول باید :

 1📲- ربات @BotFather را استارت کنید.
2- 🕹دستور /newbot را به بات فادر ارسال کنید.
3-📽 یک نام برای ربات خودتان به بات فادر ارسال کنید.
4-📟 یک یوزرنیم برای ربات خودتان به بات فادر ارسال کنید.
توجه کنید که آخر یوزرنیم باید عبارت Bot وجود داشته باشد و حتما از نوع لاتین/انگلیسی باشد.
5- 🛢اگر تمام مراحل را درست انجام داده باشید، بات فادر متن طولانی ای به عنوان توکن برای شما ارسال میکند.
6- ⚒آن متن طولانی که توکن نامیده میشود که به صورت 
369762599:AAFeMVVjM8KSYz_-1f-6sm6owsl22-0gGAr36
می باشد و همچین چیزی را در ساخت ربات باید به ربات ساز بدهید تا برایتان ربات مورد نظر را بسازد !🎉🎉
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//---
elseif($textmessage == "ساخت رباتساز گلدکس(نسخه 3.0)"){
         if($typeGolden == "vip"){
             
       $user["step"] = "create-BotSazpro3-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazpro3-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazpro3-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"??برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazpro3-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazpro3&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    //
	 elseif($textmessage == "کد هدیه رباتساز ویژه🍶"){	
	$user["step"] = "free-code_gem";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حالا کد رایگان را برای ربات ارسال کنید😅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "free-code_gem"){	
	if($code_gem != null){
	if($code_gem == $textmessage){
	$user["step"] = "none";
	$user["typegem"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_gem"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد وارد شده صحیح میباشد💯

حساب شما برای ساخت ربات ساز ویژه   ویژه شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"💵کد هدیه رباتسازویژه با موفقیت استفاده شد💵
فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨
فرد با موفقیت در ساختن رباتسازویژه   ویژه شد📦
💎رباتساز گلدکس💎
@Goldexbot
",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متأسفانه کد وارد شده صحیح نمیباشد🙁",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متأسفانه کد رایگان استفاده شده یا با تأخیر وارد شده است🙁",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	//---
	 elseif($textmessage == "کد هدیه رباتساز گلد🎂"){	
	$user["step"] = "free-code_gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حالا کد رایگان را برای ربات ارسال کنید😅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "free-code_gold"){	
	if($code_gold != null){
	if($code_gold == $textmessage){
	$user["step"] = "none";
	$user["typegold"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_gold"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد وارد شده صحیح میباشد💯

حساب شما برای ساخت ربات ساز گلد ویژه شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"💵کد هدیه رباتساز  گلد با موفقیت استفاده شد💵
فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨
فرد با موفقیت در ساختن رباتساز گلد ویژه شد📦
💎رباتساز گلدکس💎
@Goldexbot
",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متأسفانه کد وارد شده صحیح نمیباشد🙁",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متأسفانه کد رایگان استفاده شده یا با تأخیر وارد شده است🙁",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	 //---
	 elseif($textmessage == "کد هدیه رباتسازهاجی روبوت🍢"){	
	$user["step"] = "free-code_ble";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حالا کد رایگان را برای ربات ارسال کنید😅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "free-code_ble"){	
	if($code_ble != null){
	if($code_ble == $textmessage){
	$user["step"] = "none";
	$user["typeble"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_ble"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد وارد شده صحیح میباشد💯

حساب شما برای ساخت ربات ساز هاجی روبوت ویژه شد🏈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"💵کد هدیه رباتساز هاجی روبوت با موفقیت استفاده شد💵
فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨
فرد با موفقیت در ساختن رباتساز هاجی روبوت ویژه شد📦
💎رباتساز گلدکس💎
@Goldexbot
",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متأسفانه کد وارد شده صحیح نمیباشد🙁",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متأسفانه کد رایگان استفاده شده یا با تأخیر وارد شده است🙁",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	//---
	 elseif($textmessage == "ساخت رباتساز هاجی روبوت🌶"){
		 if($typeble == "vip" and $createbotble == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typeble == "vip"){
			if($createbotble != "true"){
			$user["step"] = "createbotble";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotble" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما با موفقیت ساخته شد در ربات ساز خود استارت بزنید😅",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
//---
/* elseif($textmessage == "ساخت رباتساز گلد"){
		 if($typebnz == "vip" and $createbotbnz == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typebnz == "vip"){
			if($createbotbnz != "true"){
			$user["step"] = "createbotbnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotbnz" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotbnz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما با موفقیت ساخته شد در ربات ساز خود استارت بزنید😅",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}*/
//---
 elseif($textmessage == "ساخت رباتساز ویژه🍯"){
		 if($typegold == "vip" and $createbotsaz == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typegold == "vip"){
			if($createbotsaz != "true"){
			$user["step"] = "createbotgold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotgold" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما با موفقیت ساخته شد در ربات ساز خود استارت بزنید😅",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
	 //---
elseif($textmessage == "ساخت رباتساز سایبر آلفا (نسخه جدید)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazcyberalfa-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcyberalfa-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazcyberalfa/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazcyberalfa-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcyberalfa-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazcyberalfa&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
//---
elseif($textmessage == "ساخت رباتساز تک(نسخه جدید)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSaztak-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSaztak-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSaztak/$un/index1.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSaztak-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSaztak-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSaztak&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
//---
elseif($textmessage == "ساخت رباتساز کریت کاپ(نسخه جدید)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazcreatecup-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreatecup-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazcreatecup-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫????",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"??برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreatecup-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazcreatecup&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "ساخت ممبرگیر شیشه ای🍀"){
         if($type == "vip"){
             
       $user["step"] = "create-member-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-member-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/bot.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-member-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-member-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=member&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
//---
elseif($textmessage == "ساخت رباتساز بت(نسخه جدید)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazbet-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazbet-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazbet/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazbet-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazbet-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazbet&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
//---
elseif($textmessage == "هاجی کریت(نسخه قدیمی)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazhaji1-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazhaji1-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazhaji1-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazhaji1-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazhaji1&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
//---
elseif($textmessage == "رباتساز گلدکس(نسخه2.2)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazpro22-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید?? 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید??
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazpro22-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazpro22-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazpro22-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazpro22&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "کریت گرام(نسخه6.2)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazcreategram62-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreategram62-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazcreategram62-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreategram62-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazcreategram62&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "کریت گرام(نسخه6)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazcreategram6-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس??
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreategram6-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazcreategram6-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreategram6-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazcreategram6&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "کریت گرام(نسخه4.1)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazcreategram41-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreategram41-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazcreategram41-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazcreategram41-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazcreategram41&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"??برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "ساخت رباتساز نوین تاج(نسخه جدید)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSaztaj-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس??
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSaztaj-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSaztaj-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSaztaj-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSaztaj&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "هاجی کریت(نسخه جدید)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazhaji-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazhaji-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../kosnane/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazhaji-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazhaji-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=hajicreate&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "رباتساز گلدکس(نسخه2)"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazpro-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazpro-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazpro-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazpro-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazpro&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "🏅ساخت روبات اصل بده🏅"){
         if($type == "vip"){
             
       $user["step"] = "create-AsllBede";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AsllBede"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AsllBede1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AsllBede1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AsllBede&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی??"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
  elseif($textmessage == "ساخت ربات دلیت اکانت" && $step == "none"){
       $user["step"] = "create-AccountDelicatessen-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "??برگشت به منوی اصلی🍎" and $step == "create-AccountDelicatessen-1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AccountDelicatessen-2";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AccountDelicatessen-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AccountDelicatessen&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$usergpgram

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
elseif($textmessage == "🎳ساخت ربات موزیک استور🎳"){
         if($type == "vip"){
             
       $user["step"] = "create-index-MusicYab";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
    
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-index-MusicYab"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/musicyab.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-index-MusicYab1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-index-MusicYab1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=MusicYab&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
elseif($textmessage == "🌤ساخت ضد لینک گپ گرام🌤"){
         if($type == "vip"){
             
       $user["step"] = "create-gp-gram1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
   elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-gp-gram1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
   $user["step"] = "create-gp-gram2";
   $user["gpgramtok"] = $textmessage;
   $user["usergpgram"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
     "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-gp-gram2"){
    settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["gpgramtok"];
$usergpgram = $user["usergpgram"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=gpgram&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد !
آیدی کانال تنظیم شده روی ربات :
@$textmessage
آیدی ربات شما :
@$usergpgram",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["gpgramtok"] = "";
   $user["usergpgram"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AccountDelicatessen-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AccountDelicatessen&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
   	 	elseif($textmessage == "پیام رسان ربوایرانی"){
	     $user["step"] = "create-pyemresan2-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]);
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-pyemresan2-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotGrams/$un/bot.py"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan2&token=$textmessage&account=$type&ads=$URL/Bots/BotGrams/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotGrams/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$un

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}}
	//---
   	 	elseif($textmessage == "پیامرسان شیشه ای🌹"){
	     $user["step"] = "create-pyemresan1-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]);
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-pyemresan1-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotGrams/$un/pyemresan1.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan1&token=$textmessage&account=$type&ads=$URL/Bots/BotGrams/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotGrams/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$un

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}}
	//---
elseif($textmessage == "پیامرسان دکمه ای🏛"){
       $user["step"] = "create-pm-resan";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
  "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-pm-resan"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan2&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔺نوع ربات : پیام رسان
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

همین حالا ربات خود را با بهترین سرعت بسازید➰
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد



 آیدی ربات شما :
@$un

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
  "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }}
  
  //---
elseif($textmessage == "🍉ساخت رباتساز نوین فایر🍉"){
         if($typefire == "vip"){
             
       $user["step"] = "create-BotSazNovin-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazNovin-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazNovin-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-BotSazNovin-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazNovin&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "کریت گرام(نسخه4)"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
 به بخش ساخت ربات ساز کریت گرام خوش آمدید
میخوای ربات رو برای کی درست کنی ؟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"⭐️برای خودم⭐️"]],
[['text'=>"⭐️برای یک  کاربر دیگه⭐️"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],

  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

elseif($textmessage == "⭐️برای یک  کاربر دیگه⭐️"){
     if($type == "vip"){
       $user["step"] = "create-create9964675785785897-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕  یا میتوانید توکن را از کاربر مورد نظر بگیرید و ارسال کنید !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-create9964675785785897-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Goldexbots/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create9964675785785897-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا آیدی عددی کاربر موردنظر را ارسال کنید

برای دریافت آیدی عددی کاربر یک پیام از کاربر موردنظر به ربات @userinfobot فروارد کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-create9964675785785897-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create9964675785785897&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$textmessage
 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "⭐️برای خودم⭐️"){
     if($type == "vip"){
       $user["step"] = "create-create997-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-create997-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Goldexbots/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create997-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-create997-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create997&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
   	    	 //---------botgrams---------//
   	 
elseif($textmessage == "💡ساخت ربات هاجی لایت💡"){
         if($type == "vip"){
             
       $user["step"] = "createbotble45";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:??
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbotble45" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$un

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
//---
elseif($textmessage == "زیرمجموعه گیری👥"){
 $username = $message->from->username;
$pic="$URL/Photo.jpg";
bot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>$pic,
'caption'=>"🏖رباتساز گلدکس

🏝 ساخت 13 نوع رباتساز پیشرفته و چن نوع بات خفن ;)

🌟منتظر چی هستی باتسازتو سریع بساز!
https://t.me/Goldexbot?start=$from_id
کاری از کریستال تیم 🔥",
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🍄 بنر بالا مخصوص شما طراحی شده.
🐚آنرا بردارید و پخش کنید که بقیه با لینک شما وارد ربات شوند و شما امتیاز کسب کنید.

🍿تعداد امتیاز برای ویژه شدن : 40",
]);
}

////===========تیم کریستال==========////
      elseif($textmessage == "/setvip"){
     if($type !== "vip"){
         if($invite >= $cinvite){
             $user["type"] = "vip";
             $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما با موفقیت ویژه شد😱🎉",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
     }else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیر مجموعه های شما کافی نیست☹️🔒",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);   
  }
 }else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما ویژه میباشد 🙂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
     }}
  elseif($textmessage == "💎 ویژه شدن 💎"){
   if($type == "vip"){
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما ویژه میباشد 🙂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
روش های ویژه شدن حساب🤠

😼 برای اینکه شما به صورت رایگان در رباتساز ما ویژه بشید لازم است که از طریق دکمه( زیر مجموعه گیری👥 )لینک زیر مجموعه گیری خود را دریافت کنید و با ارسال اون برای دوستانتون بعد از ورود آنها به رباتساز به شما 1 امتیاز داده میشود 😻👏

🙀با افزایش امتیاز به 40 میتونید با ارسال /setvip خود را ویژه کنید .

یا میتوانید بدون هیچ زحمتی با قیمت مناسب رباتساز خود را بسازی ! 
جهت پرداخت برای ویژع شدن : @Metiym

[ @$botusername ]",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
    
   }
  }
		 //---
		elseif($textmessage == "🏖ساخت ربات تبادل کانال🏖"){
       $user["step"] = "create-Tabadol";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-Tabadol"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/Tabadol.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-Tabadol-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-Tabadol-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=Tabadol&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$usergpgram

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }

	 elseif($textmessage == " ساخت ضدلینگ سوشال 🍿"){
       $user["step"] = "create-AntiSpam-Sohal";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AntiSpam-Sohal"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AntiSpam-Sohal1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AntiSpam-Sohal1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamSohal&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$usergpgram

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    //---
elseif($textmessage == "ساخت ربات دانلود از گیت هاب☄️"){
       $user["step"] = "create-gethob";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
  //-------APIBOT3----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-gethob"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/gethob.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=gethob&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$un

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}
  
  //---
/*elseif($textmessage == "❄️ساخت رباتساز کریستال❄️"){
       $user["step"] = "create-bot-saz-BOTSAZNEW";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:??
جهت دریافت توکن به @botfather مراجعه نمایید✂️👤",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }*/
  
  //-------APIBOT3----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-bot-saz-BOTSAZNEW"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BOTSAZNEW&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$un

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}
//---
elseif($textmessage == "💥 ساخت آی ویو | بازدیدبگیر 💥"){
         if($type == "vip"){
             
       $user["step"] = "create-view-btn1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-view-btn1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-view-btn2";
   $user["viewtok"] = $textmessage;
   $user["viewidbot"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا آدرس کانالی که میخواهید تبلیغات به آن جا ارسال شود را بدون @ ارسال نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-view-btn2"){
    $user["step"] = "create-view-btn3";
   $user["viewch"] = $textmessage;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"کانال تبلیغات ست شد 🙂
حال آیدی پشتیبانی را که کاربران برای خرید بازدید به آن مراجعه کنند را بدون @ ارسال نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-view-btn3"){
    settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$viewtok = $user["viewtok"];
$viewidbot = $user["viewidbot"];
$viewch = $user["viewch"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&sup=$textmessage&type=iViewGeer&type=iViewGeer&token=$viewtok&account=$type&channel=$viewch&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
'text'=>"یک ربات  آی ویو  ساخته شد

🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram
",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
⚙️ آیدی ربات شما :
@$usergpgram

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["gpgramtok"] = "";
   $user["usergpgram"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
elseif($textmessage == "??ساخت ضد لینک ربو ایرانی🌖"){
         if($type == "vip"){
             
       $user["step"] = "create-AntiSpamRoboIRani";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT3----//
  elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-AntiSpamRoboIRani"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/AntiSpamRoboIRani.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamRoboIRani&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد😻

🗂آیدی ربات شما:
@$un

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید??📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}
  //---
elseif($textmessage == "🔥ساخت ربات ساز سایبر کریت🔥"){
         if($type == "vip"){
             
       $user["step"] = "createbot4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"🍏برگشت به منوی اصلی🍎"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نیست 😐🎈
در حساب vip شما میتوانید👌
انواع رباتساز ها و ربات ها را بسازید 🤙🏻
مانند👇🏿
تمام نسخه های رباتساز کریت گرام 💎
و برخی از نسخه های رباتساز گلدکس💎
جهت خرید حساب ویژه این بخش با پشتیبانی در ارتباط باشید🎙
یا میتوانید با زیر مجموعه گیری ویژه بشید💣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbot4" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi1.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"⚡️رباتساز سایبر کریت شما با موفقیت ساخته شد⚡️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
   	 //---
	elseif($textmessage == "ساخت ربات هاستینگ🥝"){
	     $user["step"] = "create-HostVid-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-HostVid-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=HostVid&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد😻

🗂آیدی ربات شما:
@$un

💎 @Goldexbot
🔱 @Cristal_Team
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}}
    //---
	 elseif($textmessage == "کد هدیه رباتساز ساده⏳"){	
	$user["step"] = "free-code_crs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💰کد رایگان را ارسال کنید💰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "free-code_crs"){	
	if($code_crs != null){
	if($code_crs == $textmessage){
	$user["step"] = "none";
	$user["typecrs"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_crs"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎉کد وارد شده صحیح میباشد و حساب شما در ساختن رباتساز پیشرفته ویژه شد🎉",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"💵کد هدیه رباتساز پیشرفته با موفقیت استفاده شد💵
فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨
فرد با موفقیت در ساختن رباتساز پیشرفته ویژه شد📦
💎رباتساز گلدکس💎
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌خطا❌
❕کد وارد شد صحیح نیست❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😓کد با تاخیر وارد شد😢
 😼بار دیگر سریعتر باش😼",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
//
 elseif($textmessage == "کد هدیه رباتساز نوین فایر"){	
	$user["step"] = "free-code_Novin";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💰کد رایگان را ارسال کنید💰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "free-code_Novin"){	
	if($code_Novin != null){
	if($code_Novin == $textmessage){
	$user["step"] = "none";
	$user["typefire"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_Novin"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎉کد وارد شده صحیح میباشد و حساب شما در ساختن رباتساز نوین فایر ویژه شد🎉",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"💵کد هدیه رباتساز نوین فایر با موفقیت استفاده شد.

فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨

فرد با موفقیت در ساختن رباتساز نوین فایر ویژه شد📦

💎رباتساز گلدکس💎
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
      bot('sendMessage',[
 'chat_id'=>$canel,
 'text'=>"💵کد هدیه رباتساز نوین فایر با موفقیت استفاده شد.

فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨

فرد با موفقیت در ساختن رباتساز نوین فایر ویژه شد📦

💎رباتساز گلدکس💎
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌خطا❌
❕کد وارد شد صحیح نیست❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😓کد با تاخیر وارد شد😢
 😼بار دیگر سریعتر باش😼",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	
	//
	 elseif($textmessage == "کد هدیه رباتساز گلدکس نسخه 3"){	
	$user["step"] = "free-code_Goldex3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💰کد رایگان را ارسال کنید💰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "free-code_Goldex3"){	
	if($code_Goldex3 != null){
	if($code_Goldex3 == $textmessage){
	$user["step"] = "none";
	$user["typeGolden"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_Goldex3"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎉کد وارد شده صحیح میباشد و حساب شما در ساختن رباتساز گلدکس نسخه 3 ویژه شد🎉",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"
💵کد هدیه رباتساز گلدکس نسخه 3.0 با موفقیت استفاده شد.

فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨

فرد با موفقیت در ساختن رباتساز گلدکس نسخه 3 ویژه شد📦

💎رباتساز گلدکس💎
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
      bot('sendMessage',[
 'chat_id'=>$canel,
 'text'=>"
💵کد هدیه رباتساز گلدکس نسخه 3.0 با موفقیت استفاده شد.

فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨

فرد با موفقیت در ساختن رباتساز گلدکس نسخه 3 ویژه شد📦

💎رباتساز گلدکس💎
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌خطا❌
❕کد وارد شد صحیح نیست❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😓کد با تاخیر وارد شد😢
 😼بار دیگر سریعتر باش😼",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
 //---
	  if($textmessage == "☑️ پشتیبانی"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لطفاً پیام خود را ارسال کنید📮",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
	   elseif($step == "support" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیامت ارسال شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"پاسخ پیام ارسالی شما
------------------------------
$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما ارسال شد",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	//---
		 elseif($textmessage == "ساخت رباتساز ساده⏳"){
		 if($typecrs == "vip" and $createbotcrs == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈
جهت خرید حساب ویژه با ایدی های زیر در ارتباط باشید🌶
@metiym
@metiym",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typecrs == "vip"){
			if($createbotcrs != "true"){
			$user["step"] = "createbotcrs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نیست 😐🎈
جهت خرید حساب ویژه با ایدی های زیر در ارتباط باشید🌶
@metiym
@metiym",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotcrs" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazCreate/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotcrs"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSaCreateApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😻رباتساز شما ساخته  شد آن را استارت بزنی😻",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫📌📌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
//-----admin-panel----
if($textmessage == "/panel" or $textmessage == "پنل" or $textmessage == "🔙"){
	if($chat_id == $admin or $admin1){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به پنل مدیریت خوش آمدید😸",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"📊آمار ربات📊"]],
[['text'=>"تنظیمات رباتساز گلدکس🌿"],['text'=>"بن کردن🚫"]],
[['text'=>"🌽ویژه کردن بخش2 vip🍅"],['text'=>"انبن کردن✅"]],
[['text'=>"🛍VIP کردن فرد🛍"],['text'=>"غیرvipکردن فرد🖍"]],
[['text'=>"📓پیام همگانی📓"],['text'=>"🎊فوروارد همگانی🎊"]],
[['text'=>"🍏برگشت به منوی اصلی🍎"]],
 ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😐",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
elseif($chat_id == $admin and $textmessage == "تنظیمات رباتساز گلدکس🌿"){	
$user["step"] = "set-golden-times";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به تنظیمات رباتساز گلدکس خوش آمدید🍄☄️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"تنظیم زیرمجموعه🔥"]],
[['text'=>"تنظیم ساعت طلایی💣"]],
[['text'=>"روشن کردن رباتساز🔓"],['text'=>"خاموش کردن رباتساز🔒"]],
[['text'=>"تنظیم ساخت ربات رایگان برای حساب رایگان📦"]],
[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage == "تنظیم ساعت طلایی💣"){	
$user["step"] = "set-golden-times";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"⛱⛱به بخش تنظیم ساعات طلایی خوش آمدید❕
در ساعات طلایی زیرمجموعه گیری در ربات ساز 2 برابر میشود!??
⚒وضعیت ساعات طلایی هم اکنون در ربات ساز شما : $golden_times
برای فعال سازی / غیرفعال سازی و ... این بخش از کیبورد زیر استفاده کنید:🔮",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"روشن کردن ساعت طلایی☀️"],['text'=>"خاموش کردن ساعت طلایی🥈"]],
	[['text'=>"🔖تنظیم کپشن عکس (متن زیر عکس) ارسال به کانال🔖"]],
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}

////
elseif($chat_id == $admin and $textmessage == "انبن کردن✅"){	
$user["step"] = "set-unban-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ایدی عددی فرد را برای انبن کردن ارسال نمایید⚠️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-unban-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["step"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت لغو مسدود شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"شما از رباتساز گلدکس انبن شدید
الان میتوانید از رباتساز گلدکس استفاده کنید",
 'parse_mode'=>"HTML",
]); 
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
elseif($chat_id == $admin and $textmessage == "تنظیم ساخت ربات رایگان برای حساب رایگان📦"){	
$user["step"] = "set-max-create";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"در حال حاظر هر فرد که در ربات ساز شما حساب رایگان دارد قادر به ساخت $maxcreate ربات میباشد♣️
شما میتوانید این عدد را تغییر دهید💎
لطفا عدد جدید را به لاتین ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($step == "set-max-create" and $chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
settype($maxcreate,"integer");
$settings["maxcreate"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد مجاز ساخت ربات برای اعضای رایگان به $textmessage عدد تغییر کرد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}

//

elseif($chat_id == $admin and $textmessage == "بن کردن🚫"){	
$user["step"] = "set-ban-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ایدی عددی فرد را برای بن کردن ارسال نمایید❎:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-ban-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["step"] = "ban";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت مسدود شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"شما از رباتساز گلدکس بلاک شدید توسط مدیریت🔀

اگر اشتباه بلاک شده اید با ما تماس بگیرید🔽🔽
🙂 @metiym
😜 @metiym",
 'parse_mode'=>"HTML",
]); 
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
////
elseif($chat_id == $admin and $textmessage == "روشن کردن رباتساز🔓"){	
$settings["mode"] = "on";
$outjson = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"رباتساز روشن شد/:🌀",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
elseif($chat_id == $admin and $textmessage == "خاموش کردن رباتساز🔒"){	
$settings["mode"] = "off";
$outjson = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"رباتساز خاموش شد:/💤",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
////
elseif($chat_id == $admin and $textmessage == "🔖تنظیم کپشن عکس (متن زیر عکس) ارسال به کانال🔖" and $step == "set-golden-times"){	
$user["step"] = "set-golden-txt";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"⛓🔫لطفا متن ارسال به کانال را ارسال کنید:
این متن هم میتواندبصورت کپشن زیر عکس ارسال شود و هم تنهایی!
برای حذف متن عدد 0 را ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); }
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-golden-txt"){
	if($textmessage == "0"){
		$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["golden_txt"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متن ساعات طلایی با موفقیت حذف شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]);
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["golden_txt"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متن ساعات طلایی با موفقیت تنظیم شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]);
}
}	
elseif($chat_id == $admin and $textmessage == "🗾تنظیم عکس بالای متن برای ارسال به کانال🗾" and $step == "set-golden-times"){	
$user["step"] = "set-golden-pic";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"این عکس هنگامی که ساعات طلایی فعال شود به کانال اطلاع رسانی ارسال میشود!
توجه کنید که تنظیم متن نیز اجباری است😊
برای حذف عکس عدد 0 را ارسال کنید!
لطفا عکس را ارسال کنید :🔨🔨⚙️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); }
elseif($chat_id == $admin and $photo and $step == "set-golden-pic" and $textmessage != "🍏برگشت به منوی اصلی🍎"){
	if($textmessage == "0"){
		$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["golden_pic"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"عکس ساعات طلایی با موفقیت حذف شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]);
	}else{
	    $photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_put_contents("data/code.png",file_get_contents("https://api.telegram.org/file/bot$token/$patch"));
$settings["golden_pic"] = "$URL/Bots/BotSaz/$botusername/data/code.png";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"عکس ساعات طلایی با موفقیت تنظیم شد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]);
}
}	
elseif($chat_id == $admin and $textmessage == "خاموش کردن ساعت طلایی🥈" and $step == "set-golden-times"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["golden_times"] = "off";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ساعات طلایی با موفقیت در ربات ساز شما خاموش شد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); }
elseif($chat_id == $admin and $textmessage == "روشن کردن ساعت طلایی☀️" and $step == "set-golden-times"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["golden_times"] = "on";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حالت ساعات طلایی در ربات ساز شما فعال شد!
ازین پس کاربران ربات ساز شما به ازای هر زیر مجموعه 2 امتیاز دریافت میکنند❕💎
اگر متن و عکس برای این بخش را تنظیم نکرده اید لطفا تنظیم کنید تا به کانال اطلاع رسانی ارسال شود!
عکس الزامی نیست!🛡",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 if($golden_pic == null and $golden_txt != null){
		 bot('sendMessage',[
 'chat_id'=>$chcode,
 'text'=>$golden_txt,
 'parse_mode'=>"HTML",
	 ]); 
	 }
	 if($golden_pic != null and $golden_txt != null){
	 	bot('SendPhoto',[
	'chat_id'=>$chcode,
	'photo'=>$golden_pic,
	'caption'=>$golden_txt
	]);
	 }
	 if($golden_pic == null and $golden_txt == null){
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ادمین گرامی❕
پست مخصوص ساعات طلایی به کانال ارسال نشد!
برای این کار شما باید ابتدا متن و عکس پست را تنظیم کنید
البته عکس اجباری نیست!",
 'parse_mode'=>"HTML",
	 ]); 
	 }
}
elseif($chat_id == $admin and $textmessage == "تنظیم زیرمجموعه🔥"){	
$user["step"] = "set-vip-invite";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"در این بخش میتوانید تنظیم کنید که کاربرانتان با آوردن چند زیرمجموعه میتوانند حساب خود را در ربات ساز شما ویژه کنند😀🕹
تعداد زیرمجموعه فعلی:  $cinvite
تعداد زیرمجموعه جدید را به عدد لاتین وارد نمایید با تشکر❤️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-invite"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["cinvite"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با موفقیت ثبت شد😉
تعداد زیرمجموعه فعلی:  $textmessage",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
if($textmessage == "🌽ویژه کردن بخش2 vip🍅"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"مدیر گرامی یک بخش را انتخاب نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"کریستال تیم 👇"]],
[['text'=>"ویژه کردن رباتساز ساده⏳"]],
[['text'=>"ساخت کد هدیه رباتساز ساده⏳"]],
[['text'=>"🔹ویژه کردن رباتساز ویژه🍸"]],
[['text'=>"🔹باطل کردن حساب رباتساز ویژه🍸"]],
[['text'=>"🌕ساخت کد هدیه رباتساز ویژه☕️"]], 
[['text'=>"🔹ویژه کردن هاجی روبوت🍩"]],
[['text'=>"🔹باطل کردن حساب هاجی روبوت🍺"]],
[['text'=>"🍦ساخت کد هدیه هاجی روبوت🍦"]],
[['text'=>"ساخت کد هدیه رباتساز نوین فایر"]], 
[['text'=>"ویژه کردن رباتساز نوین فایر"]],
[['text'=>"ساخت کد هدیه رباتساز گلدکس 3"]],
[['text'=>"ویژه کردن رباتساز گلدکس 3"]],
[['text'=>"ویژه کردن ساخت رباتساز گلد🍿"]],
[['text'=>"کدکس تیم 👇"]], 
[['text'=>"ساخت کد هدیه رباتساز نوین فایر 1"]], 
[['text'=>"🔙"]],
 ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🍦ساخت کد هدیه هاجی روبوت🍦"){	
$user["step"] = "create-code_ble";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code_ble"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_ble"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"🎉کد هدیه ی جدیدی در بخش ساخت رباتساز هاجی روبوت ساخته شد🎉
🎁کد🎁: ⇦ $textmessage ⇨
🗞روش وارد کردن کد: 🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی کد هدیه رباتسازهاجی روبوت🍢 بزنید و کد را ارسال کنید 
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}
	//---
elseif($chat_id == $admin and $textmessage == "🔹باطل کردن حساب هاجی روبوت🍺"){	
$user["step"] = "off-vip-user-ble";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌برای لغو حساب کاربری آیدی عددی فرد رو وارد نمایید✂️➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "off-vip-user-ble"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typeble"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما در بخش 2 (رباتساز هاجی روبوت) رایگان شد.",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔹ویژه کردن هاجی روبوت🍩"){	
$user["step"] = "set-vip-user-ble";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user-ble"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typeble"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"⚙ حساب شما در بخش 2 ( رباتساز هاجی روبوت🍕 )  ویژه شد.
💡 فقط میتونی یه دونه رباتساز بسازی!!!
👌باتشکر از مدیریت : @Metiym",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}

//---
elseif($chat_id == $admin and $textmessage == "🌕ساخت کد هدیه رباتساز ویژه☕️"){	
$user["step"] = "create-code_gem";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد مورد نظر را وارد کنید🎮",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code_gem"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_gem"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"🎉کد هدیه ی جدیدی در بخش ساخت رباتساز ویژه ساخته شد🎉
🎁کد🎁: ⇦ $textmessage ⇨
🗞روش وارد کردن کد: 🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی کد هدیه رباتساز ویژه🍶 بزنید و کد را ارسال کنید 
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}
elseif($chat_id == $admin and $textmessage == "🔹باطل کردن حساب رباتساز ویژه🍸"){	
$user["step"] = "off-vip-user-gem";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌برای لغو حساب کاربری آیدی عددی فرد رو وارد نمایید✂️➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "off-vip-user-gem"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typegem"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما در بخش 2 ( رباتساز ویژه ) رایگان شد.",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔹ویژه کردن رباتساز ویژه🍸"){	
$user["step"] = "set-vip-user-bnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user-bnz"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typebnz"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"⚙ حساب شما در بخش 2 ( رباتساز ویژه🍸 )  ویژه شد.
💡 فقط میتونی یه دونه رباتساز بسازی!!!
👌باتشکر از مدیریت : @Metiym
",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔥ساخت کد هدیه گلد🔥"){	
$user["step"] = "create-code_gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code_gold"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_gold"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"🎉کد هدیه ی جدیدی در بخش ساخت رباتسازگلدساخته شد🎉
🎁کد🎁: ⇦ $textmessage ⇨
🗞روش وارد کردن کد: 🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی کد هدیه رباتساز گلد🎂 بزنید و کد را ارسال کنید 
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}
	//---
elseif($chat_id == $admin and $textmessage == "باطل کردن حساب رباتساز گلد🍩"){	
$user["step"] = "off-vip-user-gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌برای لغو حساب کاربری آیدی عددی فرد رو وارد نمایید✂️➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "off-vip-user-gold"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typegold"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما در بخش 2 ( رباتساز گلد ) رایگان شد.",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "ویژه کردن ساخت رباتساز گلد🍿"){	
$user["step"] = "set-vip-user-gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🍏برگشت به منوی اصلی🍎"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user-gold"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typegold"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"⚙ حساب شما در بخش 2 ( رباتساز گلد 🍤 )  ویژه شد.
💡 فقط میتونی یه دونه رباتساز بسازی!!!
👌باتشکر از مدیریت : @Metiym",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//
elseif($chat_id == $admin and $textmessage == "ساخت کد هدیه رباتساز نوین فایر"){	
$user["step"] = "create-code_novin";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code_novin"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_Novin"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"😃 آماده باشید تا ثانیه های دیگر کد هدیه در کانال قرار میگیرد ! 

💎 رباتساز گلدکس 
🆔 @Goldexbot",
     'parse_mode'=>'HTML'
 ]);
sleep(20);
 bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"3⃣3⃣3⃣",
     'parse_mode'=>'HTML'
 ]);
 sleep(10);
 bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"2⃣2⃣",
     'parse_mode'=>'HTML'
 ]);
 sleep(8);
 bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"1⃣",
     'parse_mode'=>'HTML'
  ]);
   sleep(5);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"🎉کد هدیه ی جدیدی در بخش ساخت رباتساز نوین فایر ساخته شد.

🎁کد🎁: ⇦ $textmessage ⇨

🗞روش وارد کردن کد: 
🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی (کد هدیه رباتساز نوین فایر ) بزنید و کد را ارسال کنید 
💎 @Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}
//---
elseif($chat_id == $admin and $textmessage == "🛍VIP کردن فرد🛍"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"⚙ حساب شما در (بخش 1 و ربات های vip) ویژه شد.
💡 میتونی فقط در همین بخش رباتساز بسازی!👌باتشکر از مدیریت : @Metiym",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب کاربری شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//-کدکس-//
elseif($chat_id == $admin and $textmessage == "ساخت کد هدیه رباتساز نوین فایر 1"){	
$user["step"] = "create-code_novin1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code_novin1"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_Novin"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

bot('sendMessage',[
     'chat_id'=> $canel,
     'text'=>"😃 آماده باشید تا ثانیه های دیگر کد هدیه در کانال قرار میگیرد ! 

💎 رباتساز گلدکس 
🆔 @Goldexbot",
     'parse_mode'=>'HTML'
 ]);
sleep(20);
 bot('sendMessage',[
     'chat_id'=> $canel,
     'text'=>"3⃣3⃣3⃣",
     'parse_mode'=>'HTML'
 ]);
 sleep(10);
 bot('sendMessage',[
     'chat_id'=> $canel,
     'text'=>"2⃣2⃣",
     'parse_mode'=>'HTML'
 ]);
 sleep(8);
 bot('sendMessage',[
     'chat_id'=> $canel,
     'text'=>"1⃣",
     'parse_mode'=>'HTML'
  ]);
  sleep(5);
	 bot('sendMessage',[
 'chat_id'=>$canel,
 'text'=>"🎉کد هدیه ی جدیدی در بخش ساخت رباتساز نوین فایر ساخته شد.

🎁کد🎁: ⇦ $textmessage ⇨

🗞روش وارد کردن کد: 
🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی (کد هدیه رباتساز نوین فایر ) بزنید و کد را ارسال کنید 
💎 @Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}
	
//
elseif($chat_id == $admin and $textmessage == "ساخت کد هدیه رباتساز گلدکس 3"){	
$user["step"] = "create-code_Goldex3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code_Goldex3"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_Goldex3"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"😃 آماده باشید تا ثانیه های دیگر کد هدیه در کانال قرار میگیرد ! 

💎 رباتساز گلدکس 
🆔 @Goldexbot",
     'parse_mode'=>'HTML'
 ]);
sleep(30);
 bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"3⃣3⃣3⃣",
     'parse_mode'=>'HTML'
 ]);
 sleep(20);
 bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"2⃣2⃣",
     'parse_mode'=>'HTML'
 ]);
 sleep(10);
 bot('sendMessage',[
     'chat_id'=> $channel,
     'text'=>"1⃣",
     'parse_mode'=>'HTML'
  ]);
  sleep(5);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"
🎉کد هدیه ی جدیدی در بخش ساخت رباتساز گلدکس نسخه 3.0 ساخته شد.

🎁کد🎁: ⇦ $textmessage ⇨

🗞روش وارد کردن کد: 
🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی (کد هدیه رباتساز گلدکس نسخه 3 ) بزنید و کد را ارسال کنید


💎 @Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}


//---
elseif($chat_id == $admin and $textmessage == "غیرvipکردن فرد🖍"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌برای غیرvipکردن فرد🖍 آیدی عددی فرد رو وارد نمایید✂️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"حساب شما غیر ویژه شد",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "📊آمار ربات📊"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔹تعداد کل اعضای ربات : $allusers
🔹تعداد ربات های ساخته شده : $vipbots 🔹",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "ویژه کردن رباتساز ساده⏳"){	
$user["step"] = "set-vip-user-crs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user-crs"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typecrs"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"⚙ حساب شما در بخش 2 ( رباتساز ساده⏳ )  ویژه شد.
💡 فقط میتونی یه دونه رباتساز بسازی!!!
👌باتشکر از مدیریت : @Metiym",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//
elseif($chat_id == $admin and $textmessage == "ویژه کردن رباتساز نوین فایر"){	
$user["step"] = "set-vip-user-novin";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user-novin"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typefire"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"⚙ حساب شما در بخش 2 ( رباتساز نوین فایر )  ویژه شد.
💡 فقط میتونی یه دونه رباتساز بسازی!!!
👌باتشکر از مدیریت : @Metiym",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}

//
elseif($chat_id == $admin and $textmessage == "ویژه کردن رباتساز گلدکس 3"){	
$user["step"] = "set-vip-user-Goldex3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "set-vip-user-Goldex3"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typeGolden"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"
⚙ حساب شما در بخش 2 ( رباتساز گلدکس نسخه 3.0 ) ویژه شد.
💡 فقط میتونی یه دونه رباتساز بسازی!!!
👌باتشکر از مدیریت : @Metiym",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//
elseif($chat_id == $admin and $textmessage == "ساخت کد هدیه رباتساز نوین"){ 
$user["step"] = "create-code-novin";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"🔙"]],
 ],
  "resize_keyboard"=>true,
  ])
  ]); 
}
//---
elseif($chat_id == $admin and $textmessage == "ساخت کد هدیه رباتساز ساده⏳"){	
$user["step"] = "create-code_crs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🍏برگشت به منوی اصلی🍎" and $step == "create-code-crs"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_crs"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"??کد هدیه ی جدیدی در بخش ساخت رباتساز پیشرفته ساخته شد🎉
🎁کد🎁: ⇦ $textmessage ⇨
🗞روش وارد کردن کد: 🗞وارد ربات ما شوید سپس بر روی 🎁بخش کد هدیه🎁 بزنید سپس بر روی کد هدیه رباتساز ساده⏳ بزنید و کد را ارسال کنید 
@Goldexbot",
 'parse_mode'=>"HTML",
	 ]); 
	}
//---
elseif($chat_id == $admin and $textmessage == "📓پیام همگانی📓"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"📤پیام که میخواهید همگانی شود را ارسال نمیایید📤",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "🍏برگشت به منوی اصلی🍎"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی به همه ارسال شد🗂",
 'parse_mode'=>"MarkDown",
  ]);
}

//----
elseif($chat_id == $admin and $textmessage == "🎊فوروارد همگانی🎊"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🗳پیام خود را برای فوروارد همگانی فوروارد نمایید🗳",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "🔙" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"⚡️فوروارد همگانی به همه ارسال شد⚡️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
?>
/*
سورس رباتساز گلدکس
اوپن شده در دو تیم زیر :
@Cristal_Team
@GoldCreate
*/
