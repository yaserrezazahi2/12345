<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[*[TOKEN]*]');
ini_set("log_errors" , "off");
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$vipaccs = $settings["vipaccs"];
$profile = "https://telegram.me/$username";
$channel = $settings["channel"];
$chcode = $settings["chcode"];
$admin = "[*[ADMIN]*]";
$channel_logs = "[*[CHANNEL]*]"; 
$rpto = $update->message->reply_to_message->forward_from->id;
$URL = "http://Crystal.megaranhost.ir/Altos"; 
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$createfree = $user["createfree"];
$createbot = $user["createbot"];
$typefire = $user["typefire"];
$type = $user["type"];
$invite = $user["invite"];
$createbotfire = $user["createbotfire"];
$typebnz = $user["typebnz"];
$time = $getchat["FAtime"];
$date = $getchat["FAdate"];
$cinvite = $settings["cinvite"];
$cinvite = $settings["cinvite"];
$yourbotsaz = $user["yourbotsaz"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/getChatMember?chat_id=@[*[CHANNEL]*]&user_id=".$chat_id));
$tch = $forchaneel->result->status;
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
			
				function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
//------
if(strpos($textmessage=="/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "free";
$user["type"] = "free";
$user["invite"] = "0";
$user["createbot"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
'text'=>"یک نفر با لینک شما وارد ربات شد و جهت ویژه شدن نیاز به 77 زیرمجموعه دارید 
تعداد زیرمجموعه های شما: $newinvite
پس از جمع اوری زیر مجموعه بر روی دکمه ویژه شدن بزنید",
                   'parse_mode'=>"HTML",
	                      ]);
						
					}
					}
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"جهت استفاده از ربات لطفا عضو کانال ما شوید جهت ورود به کانال بر روی جوین بزنید سپس ربات را ( /start ) استارت کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [['text'=>"جوین", 'url'=>"https://t.me/[*[CHANNEL]*]"]],
              ]
        ])
	 ]); 
	}else{
    function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 30;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"به دلیل اسپم زدن 30 ثانیه مسدود شدید😹"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
	if($textmessage == "/start" or $textmessage == "/start"){
	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به ربات ساز پیشرفته ما خوش آمدید😃
با استفاده از ما میتوانید برای خود ربات ساز بسازید و کسب درامد کنید😄
هم اکنون ربات سازپیشرفته خودتو بساز😻

Channel: @[*[CHANNEL]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🛠ساخت ربات ساز🛠"]],
 [['text'=>"☎️پشتیبانی☎️"],['text'=>"📍پروفایل📍"]],
[['text'=>""]],
  ],
 	  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	 }
elseif($textmessage == "《برگشت》"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
به منوی قبل بازگشتید.
یک بخش را انتخاب نمایید☑️
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🛠ساخت ربات ساز🛠"]],
 [['text'=>"☎️پشتیبانی☎️"],['text'=>"📍پروفایل📍"]],
[['text'=>""]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
elseif($textmessage == ""){
         if($type == "vip"){
       $user["step"] = "createbot490";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }


elseif($textmessage == "🎖ساخت ربات ساز طلایی🎖"){
         if($type == "vip"){
             
       $user["step"] = "createbot490";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید.
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbot490" and $textmessage != "《برگشت》"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaztal/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "free";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد😄

در ربات ساز خود استارت بزنید🙃",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}


elseif($textmessage == "🛠ساخت ربات ساز🛠"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش ساخت ربات ساز خوش امدید😃
 توجه کنید جهت ساخت ربات ساز حتما باید حساب ویژه خریداری کنید!
نوع ربات ساز خود را انتخاب کنید🇮🇷

channel: @[*[CHANNEL]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🎴ساخت ربات ساز سایبر🎴"],['text'=>"🎖ساخت ربات ساز طلایی🎖"]],
                 [['text'=>"🔺ساخت ربات ساز پیشرفته🔺"],['text'=>"⚡️ساخت ربات ساز هاجی ربوت⚡️"]],
                  [['text'=>"🔥ساخت ربات ساز فایر🔥"]],
 [['text'=>"《برگشت》"]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 
}

   //==============================================================================
elseif($textmessage == ''){
bot('sendphoto', [
'photo'=>$profile,
'chat_id' => $chat_id,
'caption' => "حساب شما:",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'حساب شما:','callback_data'=>'beta'],['text'=>"$type",'callback_data'=>'beta']],
],])
]);
}/*else{
bot('sendphoto', [
'photo'=>"$link_bnr",
'chat_id' => $chat_id,
'caption' => "حساب شما:",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'حساب شما:','callback_data'=>'beta'],['text'=>"$type",'callback_data'=>'beta']],
],])
]);    
}}*/
      //==============================================================================
  
   //---
	  elseif($textmessage == "☎️پشتیبانی☎️"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیام خود را ارسال کنید تا مدیران پاسخ شما را بدهند",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
elseif($step == "support" and $textmessage != "《برگشت》"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیام شما با موفقیت ارسال شد منتظر پاسخ باشید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"پاسخ پیام شما:

$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما به کاربر ارسال شد😄",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	 //---
	 elseif($textmessage == "ویژه شدن"){
      if($type !== "vip"){
          if($invite >= 77){
              $user["type"] = "vip";
              $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅ شما 77 نفر را به ربات اوردید و حسابتان با موفقیت ویژه شد.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 

      }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیرمجموعه های شما کافی نیست جهت دریافت بنر بر روی دریافت بنر بزنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);     
    }
  }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حسابتان ویژه هست لطفا بر روی این دکمه نزنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 
      }}
      
	
	 //---------Megateam97---------//



elseif($textmessage == "🔺ساخت ربات ساز پیشرفته🔺"){
     if($type == "vip"){
       $user["step"] = "create-create997-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------Megateam97----//
  elseif($textmessage != "《برگشت》" and $step == "create-create997-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../kosnanat/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create997-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خوب حالا ایدی چنلتو بدون @ بفرست",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
  
    
  //-------Megateam97----//
elseif($textmessage != "《برگشت》" and $step == "create-create997-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create997&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات ساز شما ساخته شد😄

ایدی ربات ساز: @$usergpgram",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"《برگشت》"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
   	    	 //---------Megateam97---------//
   	 

elseif($textmessage == "🎴ساخت ربات ساز سایبر🎴"){
         if($type == "vip"){
             
       $user["step"] = "createbot4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید.
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbot4" and $textmessage != "《برگشت》"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "free";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi1.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد😄

در ربات ساز خود استارت بزنید🙃",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
   	 
elseif($textmessage == "⚡️ساخت ربات ساز هاجی ربوت⚡️"){
         if($type == "vip"){
             
       $user["step"] = "createbotble45";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbotble45" and $textmessage != "《برگشت》"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "free";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات ساز شما ساخته شد😄

ایدی ربات ساز: @$un",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
   	 

elseif($textmessage == "🔥ساخت ربات ساز فایر🔥"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazNovin-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------Megateam97----//
  elseif($textmessage != "《برگشت》" and $step == "create-BotSazNovin-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazfire/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazNovin-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خوب حالا ایدی چنلتو بدون @ بفرست",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------Megateam97----//
elseif($textmessage != "《برگشت》" and $step == "create-BotSazNovin-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazNovin&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات ساز شما ساخته شد😄

ایدی ربات ساز: @$usergpgram",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  


  elseif($textmessage == "alphasaz"){
         if($type == "vip"){
             
       $user["step"] = "createbotble4523232";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید. 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbotble4523232" and $textmessage != "《برگشت》"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "free";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazApi.php?token=$textmessage&id=$from_id&type=create333223");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات ساز شما ساخته شد😄

ایدی ربات ساز: @$un",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
  
   elseif($textmessage == "alphasaz55"){
         if($type == "vip"){
             
       $user["step"] = "createbotble4523232";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت ربات ساز توکن دریافتی از @BotFather را ارسال نمایید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حسابت ویژه نیست اول حساب ویژه خریداری کن سپس مجدد به این بخش مراجعه کن 😃❣",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  elseif($step == "createbot" and $textmessage != "《برگشت》"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
   $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
    $user["step"] = "free";
    $user["createbot"] = "true";
    $user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  file_get_contents("$URL/BotSazApi.php?token=$textmessage&id=$from_id&type=create");
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد😄

ایدی ربات ساز: @$un",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
   ]);  
   bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز ساخته شد
نوع حساب : ویژه
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
   ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن باطل هست یا قبلا با این توکن ربات ساز ساخته اید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
  }
  
 //---

elseif($textmessage == "📍پروفایل📍"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"به بخش پروفایل خوش آمدید یک بخش را انتخاب کنید;)",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>""]],
[['text'=>"ویژه شدن"],['text'=>"دریافت بنر"]],
  [['text'=>"《برگشت》"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
 

elseif($textmessage == "دریافت بنر"){
$username = $message->from->username;
$pic="https://www.uplooder.net/img/image/23/22950073aaeedf20bb9bee4235045baf/68747470733a2f2f692e696d6775722e636f6d2f7265514d504d442e706e67.png";
bot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>$pic,
'caption'=>"ربات ساز پیشرفته،قابلیت ساخت ربات ساز های پیشرفته و امکانات زیاد میتوانید با ساخت ربات ساز کسب درامد کنید هم اکنون ربات ساز پیشرفته خودتو بساز
https://telegram.me/[*[BOT]*]?start=$from_id",
  'reply_to_message_id'=>$message_id,
]);
}

////===========Megateam97==========////

	 //---

	//---

//-----kosnanat-----
elseif($textmessage == "سعید" or $textmessage == "مگا" or $textmessage == "/panel"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"hi",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"امار ربات"]],
  [['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]],
     [['text'=>"شارژ کردن ربات ساز گلد"]],
  [['text'=>"ویژه کردن فرد"],['text'=>"تنزل حساب ویژه فرد"]],
  [['text'=>"《برگشت》"]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "امار ربات"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"تعداد کل اعضا : $allusers
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "ویژه کردن فرد"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ایدی عددی کسی رو که میخوای حساب ویژه شو بگیری رو بفرس",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "《برگشت》" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
'text'=>"کاربر مورد نظر با موفقیت ویژه شد
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"حساب شما با موفقیت توسط مدیران vip شد",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
'text'=>"
یک حساب ویژه شد
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"خطا!",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "تنزل حساب ویژه فرد"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ایدی عددی کسی رو که میخوای حساب ویژه شو بگیری رو بفرس",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "《برگشت》" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "free";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت گرفته شد
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"حساب شما توسط مدیران ربات رایگان شد",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "پیام همگانی"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال به اعضا ارسال نمایید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "《برگشت》"){ 
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام به اعضا با موفقیت به اعضا ارسال شد",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "فروارد همگانی"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($textmessage != "《برگشت》" && $from_id == $admin && $step == "f2all"){
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضا ربات فروارد شد",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "شارژ کردن ربات ساز گلد"){
$user["step"] = "charge";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
'text'=>"برای شارژ ربات ساز آیدی ربات ساز را بدون @ ارسال کنید",
 'parse_mode'=>"MarkDown",
     'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"《برگشت》"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]);
}
elseif($chat_id == $admin and $textmessage != "《برگشت》" && $step == "charge"){
if(file_exists("Bots/BotSaz/$textmessage/index.php")){
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر برای ساخت 1 عدد ربات  شارژ شد",
 'parse_mode'=>"MarkDown",
]);
$settings = json_decode(file_get_contents("Bots/BotSaz/$textmessage/data/settings.json"),true);
$sellbotsaz = $settings["sellbotsaz"];
$new = $sellbotsaz + 1;
$settings["sellbotsaz"] = $new;
$outjson1 = json_encode($settings,true);
file_put_contents("Bots/BotSaz/$textmessage/data/settings.json",$outjson1);
}else{
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"خطا!",
 'parse_mode'=>"MarkDown",
]);  
}
   }

elseif($textmessage == ""){
         if($type == "vip"){
       $user["step"] = "createbot490";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
elseif($textmessage == ""){
         if($type == "vip"){
       $user["step"] = "createbot490";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"《برگشت》"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
}
unlink('error_log');
?>





