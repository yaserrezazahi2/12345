<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[*[TOKEN]*]');
$API_KEY = '[*[TOKEN]*]'; 
$channel1 = '[*[CHANNEL]*]'; 
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message = $update->message;
$message_id = $message->message_id;
$from_id = $message->from->id;
$forward_chat_username = $update->message->forward_from_chat->username;
$text = $message->text;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$username = $update->message->from->username;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactnum = $contact->phone_number;
$c_id2 = $message->forward_from_chat->id;
$admin = "[*[ADMIN]*]";
$channel = "@[*[CHANNEL]*]";
$rpto = $update->message->reply_to_message->forward_from->id;
$URL = "http://Crystal.megaranhost.ir/Altos";
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$invite = $user["invite"];
$createbot = $user["createbot"];
$createbotsaz = $user["createbotsaz"];
$createbotgem = $user["createbotgem"];
$createbotvip = $user["createbotvip"];
$createbotcrs = $user["createbotcrs"];
$createbotfire = $user["createbotfire"];
$createbotgh = $user["createbotgh"];
$createbotble = $user["createbotble"];
$createbotbnz = $user["createbotbnz"];
$type = $user["type"];
$Stoken = $user["Stoken"];
$typegold = $user["typegold"];
$typebnz = $user["typebnz"];
$typecrs = $user["typecrs"];
$typevip = $user["typevip"];
$typegh = $user["typegh"];
$typefire = $user["typefire"];
$typeble = $user["typeble"];
$typegem = $user["typegem"];
$yourbotsaz = $user["yourbotsaz"];
$settings = json_decode(file_get_contents("data/settings.json"),true);
$code_silver = $settings["code_silver"];
$code_bnz = $settings["code_bnz"];
$code_gem = $settings["code_gem"];
$code_gh = $settings["code_gh"];
$code_crs = $settings["code_crs"];
$code_gold = $settings["code_gold"];
$code_ble = $settings["code_ble"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot$API_KEY/getChatMember?chat_id=@$channel1&user_id=".$chat_id));
$tch = $forchaneel->result->status;
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
			
				function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 //
  if(strpos($text,"'") !== false or strpos($text,'"') !== false or strpos($text,"}") !== false or strpos($text,"{") !== false or strpos($text,"<") !== false or strpos($text,"$") !== false or strpos($text,",") !== false){ 
file_put_contents("data/$from_id/state.txt","none");
file_put_contents("data/$from_id/step.txt","none");
$list = file_get_contents('data/blocklist.txt');
$addus= $from_id . "\n";
file_put_contents("data/blocklist.txt", $addus);
$addus= $from_id . "\n";
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
کد ندع پسرم گاییدمت کون گلابی نبینم بشاخی صیکتیر
 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"
مدیریت گرامی 🌹
سیستم ضد هک هوشمند یک فرد که ضاهرا قسط هک ربات داشته رو دستگیر کرده 🌹
👇🏻 اطلاعات فرد 👇🏻
👤 نام : $first_name
[🗣 نمایش پروفایل](tg://user?id=$from_id)
🆔 ایدی فرد : $username
🆔 آیدی عددی فرد : $from_id
🚫 کد استفاده شده : 🚫
[   $text   ]
",
 'parse_mode'=>"MarkDown",
  ]); 
    exit ();
 }
//------
if(strpos($textmessage=="/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "free";
$user["type"] = "free";
$user["invite"] = "0";
$user["createbot"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
'text'=>"یک نفر از طریق لینک شما به ربات اضافه شد

شما تا الان $newinvite نفر را به ربات آورده اید و برای 🔥ویژه شدن در ربات ساز🔥 نیاز به 15 زیرمجموعه دارید

 اگر زیرمجموعه های شما به 15 رسیده به بخش 💎حساب کاربری💎 بروید و حساب خود را رایگان ویژه کنید",
                   'parse_mode'=>"HTML",
	                      ]);
						
					}
					}
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
		 bot('sendMessage',[
                    'chat_id'=>$chat_id,
'text'=>"
🌀درود لطفا برای حمایت از تیم برنامه نویس این ربات در کانال تیم این ربات عضو شوید ‼️‼️

✅ @$channel1 @$channel1 ✅
و سپس بعد از عضویت مجددن /start بزنید💠",
                   'parse_mode'=>"HTML",
]); 
}else{
    function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 179999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"به دلیل اسپم زدن شما از رباتساز پیشرفته بلاک شدید"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
	if($textmessage == "/start" or $textmessage == "▶️برگشت به منوی اصلی◀️"){
	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
🎊به سرویس رباتساز پیشرفته خوش آمدید🎊
CH📍= @$channel1
BOT🗳= @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"🕹ورود به بخش ساخت ربات🕹"]],
 [['text'=>"⭐️بخش کد هدیه⭐️"]],
 [['text'=>"💎حساب کاربری💎"]],
 [['text'=>"🚥راهنمایی ساخت روبات🚥"]],
[['text'=>"📨پشتیبانی📨"]],
 ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	elseif($textmessage == "⭐️بخش کد هدیه⭐️"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🗂یک بخش را برای کد هدیه انتخاب کنید🗂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔌کد هدیه رباتساز پیشرفته🔌"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }

	elseif($textmessage == "🕹ورود به بخش ساخت ربات🕹"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"یک بخش را جهت ساختن ربات انتخاب نمایید🎈",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"📒بخش ساخت رباتساز📒"],['text'=>"🎗بخش ساخت ربات🎗"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }

//---
	elseif($textmessage == "📒بخش ساخت رباتساز📒"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔌یک بخش را انتخاب نماید🔌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"💎بخش ویژه ساخت رباتساز💎"],['text'=>"🎈بخش رایگان ساخت رباتساز🎈"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }

//---
	elseif($textmessage == "💎بخش ویژه ساخت رباتساز💎"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"یک نوع رباتساز را انتخاب نمایید🎀",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔌ساخت رباتساز پیشرفته🔌"],['text'=>"🔥ساخت ربات ساز سایبر کریت🔥"]],
[['text'=>"💡ساخت ربات هاجی لایت💡"],['text'=>"🍏ساخت رباتساز کریت گرام🍏"]],
[['text'=>"🍉ساخت رباتساز نوین فایر🍉"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
//---
	elseif($textmessage ==
"🎈بخش رایگان ساخت رباتساز🎈"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"این بخش به دلایلی غیر فعال میباشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
           [['text'=>"▶️برگشت به منوی اصلی◀️"]],
           ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	elseif($textmessage == "🎗بخش ساخت ربات🎗"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"یک بخش را برای ساخت ربات انتخاب نمایید🌿⭐️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🌱بخش VIP ساخت ربات🌱"]],	
[['text'=>"❄️بخش رایگان ساخت ربات❄️"]],	
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
//---
	elseif($textmessage == "🌱بخش VIP ساخت ربات🌱"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🕹یک ربات را انتخاب نمایید🕹",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🎯ساخت ضد لینک ربو ایرانی🎯"],['text'=>"👁‍🗨 ساخت آی ویو | بازدیدبگیر 👁‍🗨"]],
[['text'=>"🔱ساخت ضد لینک گپ گرام🔱"],['text'=>"🎵ساخت ربات موزیک استور🎵"]],
[['text'=>"🏅ساخت روبات اصل بده🏅"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	elseif($textmessage == "❄️بخش رایگان ساخت ربات❄️"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🕹یک ربات را انتخاب نمایید🕹",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"💰ساخت ربات هاستینگ💰"],['text'=>"💡ساخت ربات دانلود از گیت هاب💡"]],
[['text'=>"💥ساخت ربات تبادل کانال💥"],['text'=>"🛡 ساخت ضدلینگ سوشال 🛡"]],
[['text'=>"☀️ساخت ربات پیامرسان☀️"],['text'=>"〽️ساخت ربات دلیت اکانت〽️"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
//---
elseif($textmessage == "☀️ساخت ربات پیامرسان☀️"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
یک نوع پیامرسان را انتخاب کنید👇🏿
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"➰پیامرسان شیشه ای➰"],['text'=>"➿پیامرسان دکمه ای➿"]],
[['text'=>"🔘ساخت پیامرسان ربو ایرانی🔘"]],
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,'one_time_keyboard' => true,

  ])
  ]); 

}
//---
elseif($textmessage == "🚥راهنمایی ساخت روبات🚥"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
🚦برای ساخت ربات اول باید :

 1📲- ربات @BotFather را استارت کنید.
2- 🕹دستور /newbot را به بات فادر ارسال کنید.
3-📽 یک نام برای ربات خودتان به بات فادر ارسال کنید.
4-📟 یک یوزرنیم برای ربات خودتان به بات فادر ارسال کنید.
توجه کنید که آخر یوزرنیم باید عبارت Bot وجود داشته باشد و حتما از نوع لاتین/انگلیسی باشد.
5- 🛢اگر تمام مراحل را درست انجام داده باشید، بات فادر متن طولانی ای به عنوان توکن برای شما ارسال میکند.
6- ⚒آن متن طولانی که توکن نامیده میشود که به صورت 
369762599:AAFeMVVjM8KSYz_-1f-6sm6owsl22-0gGAr36
می باشد و همچین چیزی را در ساخت ربات باید به ربات ساز بدهید تا برایتان ربات مورد نظر را بسازد !🎉🎉
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
//---
elseif($textmessage == "🏅ساخت روبات اصل بده🏅"){
         if($type == "vip"){
             
       $user["step"] = "create-AsllBede";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AsllBede"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AsllBede1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AsllBede1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AsllBede&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
  elseif($textmessage == "〽️ساخت ربات دلیت اکانت〽️" && $step == "none"){
       $user["step"] = "create-AccountDelicatessen-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AccountDelicatessen-1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AccountDelicatessen-2";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AccountDelicatessen-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AccountDelicatessen&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$usergpgram

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
elseif($textmessage == "🎵ساخت ربات موزیک استور🎵"){
         if($type == "vip"){
             
       $user["step"] = "create-index-MusicYab";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
    
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-index-MusicYab"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/musicyab.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-index-MusicYab1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-index-MusicYab1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=MusicYab&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
elseif($textmessage == "🔱ساخت ضد لینک گپ گرام🔱"){
         if($type == "vip"){
             
       $user["step"] = "create-gp-gram1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
   elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-gp-gram1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
   $user["step"] = "create-gp-gram2";
   $user["gpgramtok"] = $textmessage;
   $user["usergpgram"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
     "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-gp-gram2"){
    settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["gpgramtok"];
$usergpgram = $user["usergpgram"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=gpgram&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد !
آیدی کانال تنظیم شده روی ربات :
@$textmessage
آیدی ربات شما :
@$usergpgram",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["gpgramtok"] = "";
   $user["usergpgram"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
  elseif($textmessage == "ساخت ربات دلیت اکانت" && $step == "free"){
       $user["step"] = "create-AccountDelicatessen-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AccountDelicatessen-1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AccountDelicatessen-2";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AccountDelicatessen-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AccountDelicatessen&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
   	 	elseif($textmessage == "پیام رسان ربوایرانی"){
	     $user["step"] = "create-pyemresan2-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]);
	}
	elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-pyemresan2-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotGrams/$un/bot.py"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan2&token=$textmessage&account=$type&ads=$URL/Bots/BotGrams/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotGrams/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$un

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}}
	//---
   	 	elseif($textmessage == "➰پیامرسان شیشه ای➰"){
	     $user["step"] = "create-pyemresan1-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]);
	}
	elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-pyemresan1-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotGrams/$un/pyemresan1.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan1&token=$textmessage&account=$type&ads=$URL/Bots/BotGrams/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotGrams/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$un

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}}
	//---
elseif($textmessage == "➿پیامرسان دکمه ای➿"){
       $user["step"] = "create-pm-resan";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
  "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
	elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-pm-resan"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan2&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔺نوع ربات : پیام رسان
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

همین حالا ربات خود را با بهترین سرعت بسازید➰
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد



 آیدی ربات شما :
@$un

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
  "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }}
  
  //---
elseif($textmessage == "🍉ساخت رباتساز نوین فایر🍉"){
         if($type == "vip"){
             
       $user["step"] = "create-BotSazNovin-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-BotSazNovin-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazNovin/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-BotSazNovin-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-BotSazNovin-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazNovin&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //---
elseif($textmessage == "🍏ساخت رباتساز کریت گرام🍏"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
 به بخش ساخت ربات ساز کریت گرام خوش آمدید
میخوای ربات رو برای کی درست کنی ؟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"⭐️برای خودم⭐️"]],
[['text'=>"⭐️برای یک  کاربر دیگه⭐️"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],

  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

elseif($textmessage == "⭐️برای یک  کاربر دیگه⭐️"){
     if($type == "vip"){
       $user["step"] = "create-create9964675785785897-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕  یا میتوانید توکن را از کاربر مورد نظر بگیرید و ارسال کنید !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-create9964675785785897-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../[*[BOT]*]s/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create9964675785785897-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا آیدی عددی کاربر موردنظر را ارسال کنید

برای دریافت آیدی عددی کاربر یک پیام از کاربر موردنظر به ربات @userinfobot فروارد کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-create9964675785785897-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create9964675785785897&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$textmessage
 آیدی ربات شما :
@$usergpgram

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "⭐️برای خودم⭐️"){
     if($type == "vip"){
       $user["step"] = "create-create997-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-create997-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../[*[BOT]*]s/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create997-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-create997-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create997&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد

 آیدی ربات شما :
@$usergpgram

 💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
   	    	 //---------botgrams---------//
   	 
elseif($textmessage == "💡ساخت ربات هاجی لایت💡"){
         if($type == "vip"){
             
       $user["step"] = "createbotble45";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbotble45" and $textmessage != "▶️برگشت به منوی اصلی◀️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$un

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
 //---
elseif($textmessage == "💎حساب کاربری💎"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
به بخش حساب کاربری خوش امدید🗂🗂
برای ویژه کردن حساب کاربری خود از بخش {🔥ویژه شدن در ربات ساز🔥}استفاده کن
⚡️ اما از قبل با بنر خود 15 نفر را دعوت کنید و سپس از این بخش استفاده کنید⚡️
‼️‼️توجه:با زیرمجموعه گیری در رباتساز ما در بخش ساخت رباتساز فقط در بخشی از ساخت رباتساز ویژه خواهد شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"⭐️دریافت بنر زیر مجموعه گیری⭐️"],['text'=>"🔥ویژه شدن در ربات ساز🔥"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
 

elseif($textmessage == "⭐️دریافت بنر زیر مجموعه گیری⭐️"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"رباتساز پیشرفته خود را با ما بسازید😇♥️
https://telegram.me/[*[BOT]*]?start=$from_id",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

////===========aftab==========////
	 elseif($textmessage == "🔥ویژه شدن در ربات ساز🔥"){
      if($type !== "vip"){
          if($invite >= 15){
              $user["type"] = "vip";
              $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎉حساب شما در بخش ساخت رباتساز{ویژه} vip شد شما میتوانید تمامی رباتساز های ویژه را به غیر از رباتساز پیشرفته بسازید🎉",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 

      }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌تعداد زیرمجموعه های شما کافی نمیباشد❌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);     
    }
  }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🙁حساب شما در ربات ساز ویژه است☹️😹",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 
      }}
      
		 //---
	     elseif($textmessage == "💥ساخت ربات تبادل کانال💥" && $step == "none"){
$user["step"] = "create-Tabadol";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
    
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-Tabadol"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/Tabadol.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-Tabadol-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-Tabadol-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=Tabadol&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$usergpgram

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }

	 elseif($textmessage == "🛡 ساخت ضدلینگ سوشال 🛡"){
       $user["step"] = "create-AntiSpam-Sohal";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AntiSpam-Sohal"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AntiSpam-Sohal1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AntiSpam-Sohal1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamSohal&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel1",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$usergpgram

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    //---
elseif($textmessage == "💡ساخت ربات دانلود از گیت هاب💡"){
       $user["step"] = "create-gethob";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
  //-------APIBOT3----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-gethob"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/gethob.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=gethob&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$un

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}
  
  //---
elseif($textmessage == "🏅ساخت رباتساز نیو🏅"){
       $user["step"] = "create-bot-saz-BOTSAZNEW";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
  //-------APIBOT3----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-bot-saz-BOTSAZNEW"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BOTSAZNEW&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅

⚙️ آیدی ربات شما :
@$un

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}
//---
elseif($textmessage == "👁‍🗨 ساخت آی ویو | بازدیدبگیر 👁‍🗨"){
         if($type == "vip"){
             
       $user["step"] = "create-view-btn1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-view-btn1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-view-btn2";
   $user["viewtok"] = $textmessage;
   $user["viewidbot"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا آدرس کانالی که میخواهید تبلیغات به آن جا ارسال شود را بدون @ ارسال نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-view-btn2"){
    $user["step"] = "create-view-btn3";
   $user["viewch"] = $textmessage;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"کانال تبلیغات ست شد 🙂
حال آیدی پشتیبانی را که کاربران برای خرید بازدید به آن مراجعه کنند را بدون @ ارسال نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-view-btn3"){
    settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$viewtok = $user["viewtok"];
$viewidbot = $user["viewidbot"];
$viewch = $user["viewch"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&sup=$textmessage&type=iViewGeer&type=iViewGeer&token=$viewtok&account=$type&channel=$viewch&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
'text'=>"یک ربات  آی ویو  ساخته شد

🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram
",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
⚙️ آیدی ربات شما :
@$usergpgram

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["gpgramtok"] = "";
   $user["usergpgram"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  //---
elseif($textmessage == "🎯ساخت ضد لینک ربو ایرانی🎯"){
         if($type == "vip"){
             
       $user["step"] = "create-AntiSpamRoboIRani";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  
  //-------APIBOT3----//
  elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-AntiSpamRoboIRani"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/AntiSpamRoboIRani.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamRoboIRani&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد😻

🗂آیدی ربات شما:
@$un

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}
  //---
elseif($textmessage == "🔥ساخت ربات ساز سایبر کریت🔥"){
         if($type == "vip"){
             
       $user["step"] = "createbot4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"▶️برگشت به منوی اصلی◀️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbot4" and $textmessage != "▶️برگشت به منوی اصلی◀️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi1.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"⚡️رباتساز سایبر کریت شما با موفقیت ساخته شد⚡️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
   	 //---
	elseif($textmessage == "💰ساخت ربات هاستینگ💰"){
	     $user["step"] = "create-HostVid-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-HostVid-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=HostVid&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد😻

🗂آیدی ربات شما:
@$un

💎 @[*[BOT]*]
🔱 @$channel1
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}}
    //---
	 elseif($textmessage == "🔌کد هدیه رباتساز پیشرفته🔌"){	
	$user["step"] = "free-code_crs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💰کد رایگان را ارسال کنید💰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "free-code_crs"){	
	if($code_crs != null){
	if($code_crs == $textmessage){
	$user["step"] = "none";
	$user["typecrs"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_crs"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎉کد وارد شده صحیح میباشد و حساب شما در ساختن رباتساز پیشرفته ویژه شد🎉",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"💵کد هدیه رباتساز پیشرفته با موفقیت استفاده شد💵
فرد استفاده کننده🎁= ⇦ @$username ⇨
کد🎉= ⇦ $textmessage ⇨
فرد با موفقیت در ساختن رباتساز پیشرفته ویژه شد📦
💎رباتساز ما💎
@[*[BOT]*]",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❌خطا❌
❕کد وارد شد صحیح نیست❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😓کد با تاخیر وارد شد😢
 😼بار دیگر سریعتر باش😼",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
 //---
	  elseif($textmessage == "📨پشتیبانی📨"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لطفاً پیام خود را ارسال کنید📮",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
	   elseif($step == "support" and $textmessage != "▶️برگشت به منوی اصلی◀️"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیامت ارسال شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"پاسخ پیام ارسالی شما
------------------------------
$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما ارسال شد",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	//---
		 elseif($textmessage == "🔌ساخت رباتساز پیشرفته🔌"){
		 if($typecrs == "vip" and $createbotcrs == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typecrs == "vip"){
			if($createbotcrs != "true"){
			$user["step"] = "createbotcrs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن را وارد نمایید:🗳
جهت دریافت توکن به @botfather مراجعه نمایید📕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما vip نمیباشد🖌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotcrs" and $textmessage != "▶️برگشت به منوی اصلی◀️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazCreate/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotcrs"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSaCreateApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😻رباتساز شما ساخته  شد آن را استارت بزنی😻",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن نامعتبر است یا قبلا با این توکن ربات ساخته اید🚫",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
//-----admin-panel-----
if($textmessage == "/panel" or $textmessage == "پنل" or $textmessage == "مدیریت"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به پنل مدیریت خوش آمدید😸",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"📊آمار ربات📊"]],
[['text'=>"🔌ویژه کردن رباتساز پیشرفته🔌"],['text'=>"🔌ساخت کد هدیه رباتساز پیشرفته🔌"]],
  [['text'=>"ویژه کردن حساب کاربری"],['text'=>"لغو حساب کاربری"]],
[['text'=>"📓پیام همگانی📓"],['text'=>"🎊فوروارد همگانی🎊"]],
[['text'=>"▶️برگشت به منوی اصلی◀️"]],
 ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "ویژه کردن حساب کاربری"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"🎊حساب شما vip شد و شما میتوانید تمام رباتساز های vip به غیر از رباتساز پیشرفته و تمام ربات های vip  را بسازید🗂🎊",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب کاربری شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "لغو حساب کاربری"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌برای لغو حساب کاربری آیدی عددی فرد رو وارد نمایید✂️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"حساب شما غیر ویژه شد",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "📊آمار ربات📊"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔹تعداد کل اعضای ربات : $allusers
🔹تعداد ربات های ساخته شده : $vipbots 🔹",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "🔌ویژه کردن رباتساز پیشرفته🔌"){	
$user["step"] = "set-vip-user-crs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✂️آیدی عددی فرد رو وارد کن✂️:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "set-vip-user-crs"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typecrs"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"🎉حساب شما vip  شد🎉
🎁همین الان میتوانید رباتساز پیشرفته خود را بسازید🎁",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌کاربر وجود ندارد❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔌ساخت کد هدیه رباتساز پیشرفته🔌"){	
$user["step"] = "create-code_crs";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎁کد مورد نظر را وارد کنید🎁️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "▶️برگشت به منوی اصلی◀️" and $step == "create-code_crs"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_crs"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"🎉کد هدیه ی جدیدی در بخش ساخت رباتساز پیشرفته ساخته شد🎉
🎁کد🎁: ⇦ $textmessage ⇨
🗞روش وارد کردن کد: 🗞وارد ربات ما شوید سپس بر روی ⭐️بخش کد هدیه⭐️ بزنید سپس بر روی 🔌کد هدیه رباتساز پیشرفته🔌 بزنید و کد را ارسال کنید 
@[*[BOT]*]",
 'parse_mode'=>"HTML",
	 ]); 
	}
//---
elseif($chat_id == $admin and $textmessage == "📓پیام همگانی📓"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"📤پیام که میخواهید همگانی شود را ارسال نمیایید📤",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "▶️برگشت به منوی اصلی◀️"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی به همه ارسال شد🗂",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "🎊فوروارد همگانی🎊"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🗳پیام خود را برای فوروارد همگانی فوروارد نمایید🗳",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"▶️برگشت به منوی اصلی◀️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "▶️برگشت به منوی اصلی◀️" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"⚡️فوروارد همگانی به همه ارسال شد⚡️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
?>

>

