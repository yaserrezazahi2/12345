<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[*[TOKEN]*]');
ini_set("log_errors" , "on");
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$vipaccs = $settings["vipaccs"];
$channel = $settings["channel"];
$chcode = $settings["chcode"];
$admin = "[*[ADMIN]*]";
$channel_logs = "@[*[CHANNEL]*]"; 
$rpto = $update->message->reply_to_message->forward_from->id;
$URL = "http://Crystal.megaranhost.ir/Altos"; 
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$createfree = $user["createfree"];
$createbot = $user["createbot"];
$typefire = $user["typefire"];
$type = $user["type"];
$invite = $user["invite"];
$createbotfire = $user["createbotfire"];
$typebnz = $user["typebnz"];
$time = $getchat["FAtime"];
$date = $getchat["FAdate"];
$cinvite = $settings["cinvite"];
$cinvite = $settings["cinvite"];

$yourbotsaz = $user["yourbotsaz"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/getChatMember?chat_id=@[*[CHANNEL]*]&user_id=".$chat_id));
$tch = $forchaneel->result->status;
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
			
				function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
//------
if(strpos($textmessage=="/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "none";
$user["type"] = "free";
$user["invite"] = "0";
$user["createbot"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
'text'=>"🎈یک نفر از طریق لینک شما به ربات اضافه شد
شما تا الان $newinvite نفر را به ربات آورده اید و برای ویژه شدن در ربات ساز نیاز به 15 زیرمجموعه دارید

📌 و اگر هم زیرمجموعه های شما به 15 رسیده به بخش حساب کاربری بروید و حساب خود را رایگان ویژه کنید",
                   'parse_mode'=>"HTML",
	                      ]);
						
					}
					}
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
		 bot('sendMessage',[
                    'chat_id'=>$chat_id,
                    'text'=>"💠 درود به ربات  خوش آمدید برای استفاده از امکانات این ربات و همچون حمایت از تیم برنامه نویسی ربات باید در کانال رسمی ربات عضو شوید

🚀 @[*[CHANNEL]*]
🚀 @[*[CHANNEL]*] 

🎯 سپس بعد از عضویت در کانال مجددن / start بزنید",
                   'parse_mode'=>"HTML",
]); 
}else{
if($textmessage == "/start" or $textmessage == "↪️"){
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
if($golden_times == "on"){
        $user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
           bot('sendMessage',[
                    'chat_id'=>$id,
                    'text'=>"خطا دیگر با این نوع لینگ وارد ربات نشوید در غیر این صورت بلاک خواهید شد❗️",
                   'parse_mode'=>"HTML",
                        ]);
 }else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"❄️درود عضویت شما را به ربات پیشرفته  تبریک میگوییم .
جهت کار با امکانات ربات از دکمه های زیر استفاده کنید !
@[*[CHANNEL]*] 🌹",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"💎 ورود 🤠"]],
 [['text'=>"🎙پشتیبانی 📫"],['text'=>"‼️ ویژگی های ربات 🤔"]],
[['text'=>"⛪️ بایگانی ⛪️"],['text'=>"👤 حساب کاربری 💰"]],
  ],
  "resize_keyboard"=>true,
  ])
  ]); 

}
    }

//============aftab============//

elseif($textmessage == "⚙️بخش ساخت ربات🍃"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"🏀 به بخش ساخت ربات خوش آمدید 
🔻 یک ربات را برای ساخت انتخاب کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
               [['text'=>"🛶 ساخت ربات ساز گلد 🛶"]],
[['text'=>"📣ساخت ضدلینک سه زبانه⚙️"],['text'=>"🎯ساخت ربات ادیت پیکسل🎲"]],
[['text'=>"🛡ساخت ربات ساز نیو🔮"],['text'=>"✏️ساخت ربات اصل بده📋"]],
[['text'=>"📡 ساخت ضدلینگ سوشال 🔰"],['text'=>"🚀 ساخت موزیک استور 🎵"]],
[['text'=>"📢 ساخت تبادل کانال 📣"],['text'=>"🚠 ساخت ضدلینگ ربوایرانی 🛰"]],
[['text'=>"🕹دانلود از گیت هاب🚚"],['text'=>"👁‍🗨 ساخت آی ویو | بازدیدبگیر 🛒"]],
[['text'=>"🎠ساخت ربات هاستینگ🎠"],['text'=>"🗑ساخت ربات دلیت اکانت🛠"]],
[['text'=>"↪️"]],
  ],
		"resize_keyboard"=>true,

  ])
  ]); 
}
elseif($textmessage == "💎 ورود 🤠"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
🔻یک بخش را انتخاب کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🛠بخش طلایی💎"],['text'=>"⚙️بخش ساخت ربات🍃"]],
  [['text'=>"↪️"]],
  ],
		"resize_keyboard"=>true,

  ])
  ]); 

}

//============aftab============//
  
elseif($textmessage == "🛠بخش طلایی💎"){
         if($type == "vip"){
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
🔆 به بخش طلایی ربات #کریت_گرام خوش آمدید
🔻یک بخش را انتخاب کنید
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
                 [['text'=>"😎ساخت ربات ساز کریت گرام⚙️"]],
                 [['text'=>"💥ساخت ربات ساز سایبر کریت🎗"]],
[['text'=>"🌹ساخت هاجی ربات لایت🌳"]],
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
⚠️ حساب شما ویژه نمی باشد
لطفا از بخش 👤 حساب کاربری 💰اقدام به ویژه کردن حساب خود کنید !
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
   
   
elseif($textmessage == "‼️ ویژگی های ربات 🤔"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"1️⃣ ساخت ربات بدون تبلیغ و با سرعت بالا
2️⃣ دارای بخش زیرمجموعه گیری هوشمند
3️⃣ ساخت ربات ساز گلد با سرعت فوق العاده بالا 
4️⃣ برترین ربات مخصوص ایرانیان بدون باگ 
5️⃣ پاسخ دهی پشتیبانی برای همه اعضا
6️⃣ ساخت ربات بدون باگ و بدون تبلیغ
7️⃣ دارای بخش ویژه برای اعضای طلایی

➖ ➖ ➖ ➖ ➖ 
🏘 @[*[CHANNEL]*]
🗣 @AftabSupportBot
🛠 @[*[BOT]*]",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  ],
		"resize_keyboard"=>true,

  ])
  ]); 

}
elseif($textmessage == "🌐 اسپانسران 🔋"){  

  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔮 اسپانسران قدرتمند ربات ساز #کریت_گرام",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [['text'=>"الیت هاست", 'url'=>"https://elithost.ir"]],
                      [['text'=>"تله هاست", 'url'=>"https://tel-host.ir"]],
 [['text'=>"کاپ هاست", 'url'=>"https://cuphost.ir"]],
[['text'=>"مکس وب", 'url'=>"https://Max-web.ir"]],
              ]
        ])
   ]); 
  }


	 elseif($textmessage == "⛪️ بایگانی ⛪️"){
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"📬 به بخش بایگانی بات خوش آمدید
🔻یک بخش را انتخاب کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
               [['text'=>"حذف ربات ساز گلد"]],
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
   //---
	  elseif($textmessage == "🎙پشتیبانی 📫"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🚠 از این پس هر پیامی ارسال کنید به پشتیبانی ارسال خواهد شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
elseif($step == "support" and $textmessage != "↪️"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیام شما به پشتیبانی ارسال شد !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"دوست عزیز شما یک پیام از طرف پشتیبانی ربات دریافت کردید
--------------------
$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما به فرد ارسال شد✔️",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	 //---
	 elseif($textmessage == "ویژه شدن در ربات ساز"){
      if($type !== "vip"){
          if($invite >= 15){
              $user["type"] = "vip";
              $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 

      }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیرمجموعه های شما کافی نمیباشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);     
    }
  }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه است",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 
      }}
      
      elseif($textmessage == "حذف ربات سیستمی"){

$user["step"] = "delete-bot";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توکن بدید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($step == "delete-bot" and $textmessage != "↪️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("../../BotGrams/$un/index.php"))){
		$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
settype($createfree,"integer");
                   
                  
                       $outjson1 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson1);
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات شما با موفقیت از سرور های ما حذف شد✅
آیدی ربات :
@$un",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
file_get_contents("$URL/BotSazApi.php?token=$textmessage&id=123&type=delete1&account=123");
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"مشکلی پیش اومد📛
ممکن است توکن نادرست یا رباتدر سرور ما ثبت نشده باشد❗️
دوباره امتحان کنید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
	}
	
	 //---------[*[CHANNEL]*]---------//
	 
	
elseif($textmessage == "😎ساخت ربات ساز کریت گرام⚙️"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
😉 به بخش ساخت ربات ساز مانند کریت گرام خوش آمدید
❓میخوای ربات رو برای کی درست کنی ؟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"😋 برای خودم"]],
[['text'=>"😌 برای کاربر دیگه"]],
[['text'=>"↪️"]],

  ],
    "resize_keyboard"=>true,

  ])
  ]); 

}

elseif($textmessage == "😌 برای کاربر دیگه"){
     if($type == "vip"){
       $user["step"] = "create-create9964675785785897-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇 یا میتوانید توکن را از کاربر مورد نظر بگیرید و ارسال کنید !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-create9964675785785897-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../[*[BOT]*]s/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create9964675785785897-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا آیدی عددی کاربر موردنظر را ارسال کنید

برای دریافت آیدی عددی کاربر یک پیام از کاربر موردنظر به ربات @userinfobot فروارد کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-create9964675785785897-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create9964675785785897&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$textmessage
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"💎 ورود 🤠"]],
 [['text'=>"🎙پشتیبانی 📫"],['text'=>"‼️ ویژگی های ربات 🤔"]],
[['text'=>"⛪️ بایگانی ⛪️"],['text'=>"👤 حساب کاربری 💰"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "😋 برای خودم"){
     if($type == "vip"){
       $user["step"] = "create-create997-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-create997-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../[*[BOT]*]s/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create997-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-create997-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create997&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"💎 ورود 🤠"]],
 [['text'=>"🎙پشتیبانی 📫"],['text'=>"‼️ ویژگی های ربات 🤔"]],
[['text'=>"⛪️ بایگانی ⛪️"],['text'=>"👤 حساب کاربری 💰"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
   	    	 //---------botgrams---------//
   	 
elseif($textmessage == "💥ساخت ربات ساز سایبر کریت🎗"){
         if($type == "vip"){
             
       $user["step"] = "createbot4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbot4" and $textmessage != "↪️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi1.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما با موفقیت ساخته شد در ربات ساز خود استارت بزنید😅",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متاسفانه توکن ارسال شده نامعتبر هست یا قبلا ربات با این توکن ساخته اید☹️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
   	 
elseif($textmessage == "🌹ساخت هاجی ربات لایت🌳"){
         if($type == "vip"){
             
       $user["step"] = "createbotble45";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbotble45" and $textmessage != "↪️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
   	 
	elseif($textmessage == "🎠ساخت ربات هاستینگ🎠"){
	     $user["step"] = "create-HostVid-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	elseif($textmessage != "↪️" and $step == "create-HostVid-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=HostVid&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}}

elseif($textmessage == "📣ساخت ضدلینک سه زبانه⚙️"){
         if($type == "vip"){
             
       $user["step"] = "create-anti-spam-antisoam3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  
  //-------APIBOT1----//
  elseif($textmessage != "↪️" and $step =="create-anti-spam-antisoam3"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=antisoam3&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}

elseif($textmessage == "🎯ساخت ربات ادیت پیکسل🎲"){
       $user["step"] = "create-edit-bot-ultra";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
  //-------APIBOT2----//
  elseif($textmessage != "↪️" and $step == "create-edit-bot-ultra"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=EditPixel&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }}

elseif($textmessage == "🛡ساخت ربات ساز نیو🔮"){
       $user["step"] = "create-bot-saz-BOTSAZNEW";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
  //-------APIBOT3----//
  elseif($textmessage != "↪️" and $step == "create-bot-saz-BOTSAZNEW"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BOTSAZNEW&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'teل نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  elseif($textmessage != "↪️" and $step == "create-view-lov2"){
    $user["step"] = "create-view-lov3";
   $user["viewch"] = $textmessage;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"کانال تبلیغات ست شد 🙂
حال آیدی پشتیبانی را که کاربران برای خرید بازدید به آن مراجعه کنند را بدون @ ارسال نمایید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  elseif($textmessage != "↪️" and $step == "create-view-lov3"){
    settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$viewtok = $user["viewtok"];
$viewidbot = $user["viewidbot"];
$viewch = $user["viewch"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&sup=$textmessage&type=ViewGeerLov&type=ViewGeerLov&token=$viewtok&account=$type&channel=$viewch&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
'text'=>"یک ربات  آی ویو  ساخته شد

🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram
",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["gpgramtok"] = "";
   $user["usergpgram"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "✏️ساخت ربات اصل بده📋"){
         if($type == "vip"){
             
       $user["step"] = "create-AsllBede";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-AsllBede"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AsllBede1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-AsllBede1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AsllBede&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
  elseif($textmessage == "🗑ساخت ربات دلیت اکانت🛠" && $step == "none"){
       $user["step"] = "create-AccountDelicatessen-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-AccountDelicatessen-1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AccountDelicatessen-2";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-AccountDelicatessen-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AccountDelicatessen&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "📡 ساخت ضدلینگ سوشال 🔰"){
       $user["step"] = "create-AntiSpam-Sohal";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-AntiSpam-Sohal"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AntiSpam-Sohal1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-AntiSpam-Sohal1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamSohal&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-HajiRobotNew-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=HajiRobotNew&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],],"resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
    elseif($textmessage == "📢 ساخت تبادل کانال 📣" && $step == "none"){
$user["step"] = "create-Tabadol";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);
  }
  
    
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-Tabadol"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/Tabadol.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-Tabadol-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-Tabadol-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=Tabadol&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }

  
elseif($textmessage == "🚀 ساخت موزیک استور 🎵"){
         if($type == "vip"){
             
       $user["step"] = "create-index-MusicYab";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 😇
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
    
  //-------APIBOT4----//
  elseif($textmessage != "↪️" and $step == "create-index-MusicYab"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/musicyab.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-index-MusicYab1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 🙂
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا ⚠️
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "↪️" and $step == "create-index-MusicYab1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=MusicYab&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد✅
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$usergpgram

🚀 @[*[CHANNEL]*]
⛵️ @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  
  ],
    "resize_keyboard"=>true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
 elseif($textmessage == "🛶 ساخت ربات ساز گلد🛶"){
if($type== "vip" and $createbot == "true"){
       $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر گرامی هر کاربر ویژه می تواند فقط یک ربات گلد بسازد به دلیل فشار نیامدن در سرور اصلی ربات 🙏❤️❤️
آیدی ربات ساز گلد شما : @$yourbotsaz",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
     }
    if($type == "vip"){
      if($createbot != "true"){
      $user["step"] = "createbot";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"کاربر گرامی برای ساخت ربات ساز پیشرفته گلد توکن خود را از @BotFather بگیرید و ارسال کنید
توجه در ساخت این ربات بسیار دقت نمایید به دلیل اینکه فقط میتوانید یک ربات ساز گلد بسازید ❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"↪️"]],
  ],
    "resize_keyboard"=>true,
   ])
   ]);  
    }
  }else{
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما ویژه نمی باشد
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
    }
  }     
     
     
  elseif($step == "createbot" and $textmessage != "↪️"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
   $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
    $user["step"] = "none";
    $user["createbot"] = "true";
    $user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  file_get_contents("$URL/BotSazSazApi.php?token=$textmessage&id=$from_id&type=create");
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد
آیدی ربات ساز شما :
@$un
مدیر ربات ساز :
[$from_id](tg://user?id=$from_id)
چنل ما :
@[*[CHANNEL]*]",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
   ]);  
   bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز ساخته شد❗️
نوع حساب : ویژه
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
   ]);  
}else{
   $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا توکن خراب است و یا با این توکن قبلا ربات ثبت کرده اید !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
  }
  
 //---

elseif($textmessage == "👤 حساب کاربری 💰"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"👤 به بخش حساب کاربری ربات   خوش آمدید

💯برای ویژه کردن حساب کاربری خود از بخش {ویژه شدن در ربات ساز} استفاده کنید اما از قبل با بنر خود 15 نفر را دعوت کنید و سپس از این بخش استفاده کنید 

🔻یک بخش را انتخاب کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"بنر زیرمجموعه گیری"],['text'=>"ویژه شدن در ربات ساز "]],
  [['text'=>"↪️"]],
  ],
    "resize_keyboard"=>true,

  ])
  ]); 

}
 

elseif($textmessage == "بنر زیرمجموعه گیری"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"🤠 یه ربات ساز فوق پیشرفته میخوای که ربات های جذابو سرگرم کننده بسازه حتی ربات ساز پیشرفته گلد رو بسازه زود بیا تو  لذت ببر😃♥️
https://telegram.me/[*[BOT]*]?start=$from_id",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"↪️"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

////===========aftab==========////
elseif($textmessage == "حذف ربات ساز گلد"){
		 if($type == "vip"){
			  $user["step"] = "deletebotsaz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"برای حذف ربات ساز گلد خود توکن آن را ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	 }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
حساب شما ویژه نمی باشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);   
	 }
	 }
		 elseif($step == "deletebotsaz" and $textmessage != "↪️"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("Bots/BotSaz/$un/index.php")) && $un == $yourbotsaz){
	file_get_contents("$URL/https://wolfis.adrinaserver.site/Altos?token=$textmessage&id=$from_id&type=delete");
		bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات مورد نظر با آیدی  @$un  از سیستم ربات  حذف شد !",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 
      bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز گلد کاربر موردنظر حذف شد
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots - 1;
                       file_put_contents("data/vipbots.txt",$newbots);
	 $user["step"] = "none";
	 $user["createbot"] = "none";
	 $user["yourbotsaz"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا
توکن نادرست می باشد و یا با ربات  ساخته نشده است ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
}
}
	 //---

	//---

//-----admin-panel-----
elseif($textmessage == "مدیریت" or $textmessage == "پنل" or $textmessage == "/panel"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"🤠 سلام بابایی به پنل مدیریتم خوش اومدی",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"آمار"]],
  [['text'=>"ارسال پیام همگانی"],['text'=>"فروارد همگانی"]],
     [['text'=>"شارژ ربات ساز گلد برای ساخت ربات ساز"]],
  [['text'=>"ویژه کردن حساب کاربری"],['text'=>"لغو حساب کاربری"]],
    [['text'=>"حذف ربات ساز گلد"]],
  [['text'=>"↪️"]],
  ],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما مدیر این ربات نمی باشید ! و دسترسی به این بخش را ندارید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "آمار"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"تعداد کل اعضای ربات : $allusers
تعداد ربات های ویژه ربات ساز گلد: $vipbots
 @[*[CHANNEL]*]",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "ویژه کردن حساب کاربری"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "↪️" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"💎 حساب کاربری شما توسط مدیریت ویژه شد",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب کاربری شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "لغو حساب کاربری"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "↪️" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"حساب شما توسط مدیران ربات رایگان شد⚙️",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "ارسال پیام همگانی"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال به تمامی اعضا ارسال نمایید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "↪️"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام به تمامی اعضا با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "فروارد همگانی"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "↪️" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "شارژ ربات ساز گلد برای ساخت ربات ساز"){
$user["step"] = "charge";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
'text'=>"برای شارژ ربات ساز گلد آیدی ربات ساز رو بدون @ ارسال کنید🎇",
 'parse_mode'=>"MarkDown",
     'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"↪️"]],
	],
		"resize_keyboard"=>true,
	 ])
]);
}
elseif($chat_id == $admin and $textmessage != "↪️" && $step == "charge"){
if(file_exists("Bots/BotSaz/$textmessage/index.php")){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر برای ساخت 1 عدد ربات ساز شارژ شد!",
 'parse_mode'=>"MarkDown",
]);
$settings = json_decode(file_get_contents("Bots/BotSaz/$textmessage/data/settings.json"),true);
$sellbotsaz = $settings["sellbotsaz"];
$new = $sellbotsaz + 1;
$settings["sellbotsaz"] = $new;
$outjson1 = json_encode($settings,true);
file_put_contents("Bots/BotSaz/$textmessage/data/settings.json",$outjson1);
}else{
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر یافت نشد!",
 'parse_mode'=>"MarkDown",
]);  
}
   }



  //-----------
/*
این سورس توسط تیم آفتاب نوشته شده است هر گونه کپی بدون ذکر منبع حرام می باشد
@[*[CHANNEL]*]
*/
}
unlink('error_log');
?>
?>