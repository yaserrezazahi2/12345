<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[*[TOKEN]*]');
$API_KEY = '[*[TOKEN]*]'; 
$bot_id = "[*[BOT]*]"; 
$channel = "[*[CHANNEL]*]"; 
ini_set("log_errors" , "off");
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$vipaccs = $settings["vipaccs"];
$profile = "https://telegram.me/$username";
$channel = $settings["channel"];
$chcode = $settings["chcode"];
$admin = "[*[ADMIN]*]";
$channel_logs = "@[*[CHANNEL]*]"; 
$URL1 = "http://Crystal.megaranhost.ir/Altos";
$URL = "http://Crystal.megaranhost.ir/Altos"; 
$NAMEBOT = "[*[BOT]*]"; 
$CHANNEL = "[*[CHANNEL]*]"; 
$USEERBOT = "[*[BOT]*]"; 
$SUDO_USEER = "#SUDO_USEER"; 
$TOKEN = "[*[TOKEN]*]"; 
$rpto = $update->message->reply_to_message->forward_from->id;
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$createfree = $user["createfree"];
$createbot = $user["createbot"];
$typefire = $user["typefire"];
$type = $user["type"];
$invite = $user["invite"];
$createbotfire = $user["createbotfire"];
$typebnz = $user["typebnz"];
$cinvite = $settings["cinvite"];
$cinvite = $settings["cinvite"];
$yourbotsaz = $user["yourbotsaz"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot$TOKEN/getChatMember?chat_id=@$CHANNEL&user_id=".$chat_id));
$tch = $forchaneel->result->status;
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
			
				function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
//------
if(strpos($textmessage=="/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "free";
$user["type"] = "free";
$user["invite"] = "0";
$user["createbot"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
'text'=>"یک نفر از طریق لینک شما به ربات اضافه شد

شما تا الان $newinvite نفر را به ربات آورده اید و برای ویژه شدن در ربات ساز نیاز به 18 زیرمجموعه دارید

 اگر زیرمجموعه های شما به 18 رسیده به بخش #داشبورد بروید و حساب خود را رایگان ویژه کنید",
                   'parse_mode'=>"HTML",
	                      ]);
						
					}
					}
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
		 bot('sendMessage',[
                    'chat_id'=>$chat_id,
'text'=>"
🏔 درود لطفا برای #حمایت از تیم برنامه نویس این ربات در #کانال تیم این ربات #عضو شوید 

🕍  @$CHANNEL
🕍  @$CHANNEL

و سپس بعد از #عضویت مجددن /start بزنید 🚀",
                   'parse_mode'=>"HTML",
                     'reply_to_message_id'=>$message_id,
]); 
}else{
    function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 7){
$time = time() + 176626263636363636363535363663636373829182376464647373737374747373737747447737272281871636363000;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"
  به دلیل  اسپم زدن به ربات ؛ شما برای همیشه از ربات بلاک شدید ‼️ "
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
	if($textmessage == "/start" or $textmessage == "/start"){
	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
با سلام :
به ربات ساز پیشرفته $NAMEBOT خوش آمدید 🦋

- با $NAMEBOT به شیوه مدرن #ربات بسازید!
 
- ورژن ربات : 6.2
 برای شروع از دکمه [ایجاد ربات جدید🚀] استفاده کنید 🛵
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ایجاد ربات جدید🚀"]],
 [['text'=>"پشتیبانی🚚"],['text'=>"داشبورد 🌔"]],
[['text'=>"🛢راهنمایی ساخت ربات"]],

  ],
 	  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	 }
elseif($textmessage == "منوی اصلی"){
    	$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
- به منوی اصلی خوش آمدید
- لطفا یک بخش را انتخاب کنید 🍃
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ایجاد ربات جدید🚀"]],
 [['text'=>"پشتیبانی🚚"],['text'=>"داشبورد 🌔"]],
[['text'=>"🛢راهنمایی ساخت ربات"]],

  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}


   

elseif($textmessage == "ایجاد ربات جدید🚀"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
♦️به بخش ساخت ربات خوش آمدید :)

<code>در این بخش میتوانید ربات های کاربردی بسازید که هر نوع به بهترین نوع نوشته شده اند و به راحتی و بدون مشکل میتوانید ربات خود را بسازید ! و یا ربات ساز های بسیار شیکی بسازید و کسب و درآمد کنید !</code>

🍃لطفا یک بخش را انتخاب کنید !
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ساخت ربات ساز"]],
               [['text'=>"ساخت ربات اصل بده"],['text'=>"ساخت ربات پیام رسان"]],
[['text'=>"ساخت ضدلینک سه زبانه"],['text'=>"ساخت ربات ادیت پیکسل"]],
[['text'=>" ساخت ضدلینگ سوشال "],['text'=>" ساخت موزیک استور "]],
[['text'=>" ساخت تبادل کانال "],['text'=>" ساخت ضدلینگ ربوایرانی "]],
[['text'=>"ساخت ربات هاستینگ"],['text'=>"ساخت ربات دلیت اکانت"]],
  [['text'=>"منوی اصلی"]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}


elseif($textmessage == "🛢راهنمایی ساخت ربات"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
🍂برای ساخت ربات اول باید :

<code> 1- ربات @BotFather را استارت کنید.
2- دستور /newbot را به بات فادر ارسال کنید.
3- یک نام برای ربات خودتان به بات فادر ارسال کنید.
4- یک یوزرنیم برای ربات خودتان به بات فادر ارسال کنید.
توجه کنید که آخر یوزرنیم باید عبارت Bot وجود داشته باشد و حتما از نوع لاتین/انگلیسی باشد.
5- اگر تمام مراحل را درست انجام داده باشید، بات فادر متن طولانی ای به عنوان توکن برای شما ارسال میکند.
6- آن متن طولانی که توکن نامیده میشود که به صورت </code>
369762599:AAFeMVVjM8KSYz_-1f-6nowsl22-0gGAr36
<code>می باشد و همچین چیزی را در ساخت ربات باید به ربات ساز بدهید تا برایتان ربات مورد نظر را بسازد !</code>

موفق باشید💐
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ایجاد ربات جدید🚀"]],
 [['text'=>"پشتیبانی🚚"],['text'=>"داشبورد 🌔"]],
[['text'=>"🛢راهنمایی ساخت ربات"]],

  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

elseif($textmessage == "پشتیبانی🚚"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
👤برای رفع #مشکل خود به آدرس @SUDO_USEER مراجعه نمایید تا در اسرع وقت مشکلتان ارجاع شود !
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"ایجاد ربات جدید🚀"]],
 [['text'=>"پشتیبانی🚚"],['text'=>"داشبورد 🌔"]],
[['text'=>"🛢راهنمایی ساخت ربات"]],

  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}



   //==============================================================================
  

   //---
  
elseif($textmessage == '📜اطلاعات حساب من'){
bot('sendphoto', [
'chat_id' => $chat_id,
'photo'=>$profile,
'caption' => " اطلاعات حساب شما ",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'➡️نام شما','callback_data'=>'beta'],['text'=>"$first_name",'callback_data'=>'beta']],
[['text'=>'➡️آیدی عددی شما','callback_data'=>'beta'],['text'=>"$chat_id",'callback_data'=>'beta']],
[['text'=>'➡️یوزرنیم شما','callback_data'=>'beta'],['text'=>"@$username",'callback_data'=>'beta']],
[['text'=>'➡️نوع حساب شما','callback_data'=>'beta'],['text'=>"$type",'callback_data'=>'beta']],
],])
]);
}/*else{
bot('sendphoto', [
'chat_id' => $chat_id,
'photo'=>"$link_bnr",
'caption' => "اطلاعات شما",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'👉اسم شما㊗️','callback_data'=>'beta'],['text'=>"$first_name",'callback_data'=>'beta']],
[['text'=>'👉ایدی عددی شما☯','callback_data'=>'beta'],['text'=>"$chat_id",'callback_data'=>'beta']],
[['text'=>'👉نام کاربری شما🆔','callback_data'=>'beta'],['text'=>"@$username",'callback_data'=>'beta']],
[['text'=>'نوع حساب🌿','callback_data'=>'beta'],['text'=>"$type",'callback_data'=>'beta']],
],])
]);    
}}*/
      //==============================================================================

	 //---
	 elseif($textmessage == "🥇ویژه شدن در ربات ساز"){
      if($type !== "vip"){
          if($invite >= 18){
              $user["type"] = "vip";
              $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه شد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 

      }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیرمجموعه های شما کافی نمیباشد",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);     
    }
  }else{
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه است",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]); 
      }}
      
	
	 //---------$CHANNEL---------//

elseif($textmessage == "ساخت ربات ساز"){
     if($type == "vip"){
       $user["step"] = "create-create997-0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
}else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "منوی اصلی" and $step == "create-create997-0"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../$USEERBOTs/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-create997-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متاسفانه توکن ارسال شده نامعتبر هست یا قبلا ربات با این توکن ساخته اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-create997-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=create997&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"منوی اصلی"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
   	    	 //---------botgrams---------//
   	    elseif($textmessage == "گلد تست"){
         if($type == "vip"){
             
       $user["step"] = "create-gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  
  //-------APIBOT3----//
  elseif($textmessage != "منوی اصلی" and $step == "create-gold"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSazGold/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazSazApi.php?id=$from_id&type=create554422&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un


",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
     "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }}
  
   	elseif($textmessage == "ساخت ضدلینگ ربوایرانی"){
         if($type == "vip"){
             
       $user["step"] = "create-AntiSpamRoboIRani";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  
  //-------APIBOT3----//
  elseif($textmessage != "منوی اصلی" and $step == "create-AntiSpamRoboIRani"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/AntiSpamRoboIRani.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamRoboIRani&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد🎉
🔻مدیر ربات : $from_id
🔸آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
🛡مدیر ربات :
$from_id
⚙️ آیدی ربات شما :
@$un


",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
     "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }}
   	 	elseif($textmessage == "ساخت ربات پیام رسان"){
	     $user["step"] = "create-pyemresan1-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]);
	}
	elseif($textmessage != "منوی اصلی" and $step == "create-pyemresan1-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotGrams/$un/pyemresan44.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=pyemresan44&token=$textmessage&account=$type&ads=$URL/Bots/BotGrams/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotGrams/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$un

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}}
 
elseif($textmessage == ""){
         if($type == "vip"){
             
       $user["step"] = "createbot4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbot4" and $textmessage != "منوی اصلی"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "free";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazApi1.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما با موفقیت ساخته شد در ربات ساز خود استارت بزنید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
   $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متاسفانه توکن ارسال شده نامعتبر هست یا قبلا ربات با این توکن ساخته اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
}
}
   	 
elseif($textmessage == ""){
         if($type == "vip"){
             
       $user["step"] = "createbotble45";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
	elseif($step == "createbotble45" and $textmessage != "منوی اصلی"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "free";
		$user["createbotble"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$un

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متاسفانه توکن ارسال شده نامعتبر هست یا قبلا ربات با این توکن ساخته اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
   	 
	elseif($textmessage == "ساخت ربات هاستینگ"){
	     $user["step"] = "create-HostVid-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]);
	}
	elseif($textmessage != "منوی اصلی" and $step == "create-HostVid-1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
	 settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
					  $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
	 settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

	    file_get_contents("$URL/BotSazApi.php?id=$from_id&type=HostVid&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
		if($chlog != null){
			 bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
	 ]); 
		}
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$un

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}else{
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
	}}

elseif($textmessage == "ساخت ضدلینک سه زبانه"){
         if($type == "vip"){
             
       $user["step"] = "create-anti-spam-antisoam3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  
  //-------APIBOT1----//
  elseif($textmessage != "منوی اصلی" and $step =="create-anti-spam-antisoam3"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=antisoam3&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$un

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }}

elseif($textmessage == "ساخت ربات ادیت پیکسل"){
       $user["step"] = "create-edit-bot-ultra";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
  
  //-------APIBOT2----//
  elseif($textmessage != "منوی اصلی" and $step == "create-edit-bot-ultra"){
    $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "free";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);

      file_get_contents("$URL/BotSazApi.php?id=$from_id&type=EditPixel&token=$textmessage&account=$type&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/Bot/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$un

",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$un

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }}
elseif($textmessage == "ساخت ربات اصل بده"){
         if($type == "vip"){
             
       $user["step"] = "create-AsllBede";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
  //-------APIBOT4----//
  elseif($textmessage != "منوی اصلی" and $step == "create-AsllBede"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AsllBede1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-AsllBede1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AsllBede&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
  elseif($textmessage == "ساخت ربات دلیت اکانت" && $step == "free"){
       $user["step"] = "create-AccountDelicatessen-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "منوی اصلی" and $step == "create-AccountDelicatessen-1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AccountDelicatessen-2";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-AccountDelicatessen-2"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AccountDelicatessen&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "ساخت ضدلینگ سوشال"){
       $user["step"] = "create-AntiSpam-Sohal";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
  //-------APIBOT4----//
  elseif($textmessage != "منوی اصلی" and $step == "create-AntiSpam-Sohal"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-AntiSpam-Sohal1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-AntiSpam-Sohal1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=AntiSpamSohal&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-BotSazNovin-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=BotSazNovin&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSazNovin/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
    
  
    elseif($textmessage == "ساخت تبادل کانال" && $step == "free"){
$user["step"] = "create-Tabadol";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);
  }
  
    
  //-------APIBOT4----//
  elseif($textmessage != "منوی اصلی" and $step == "create-Tabadol"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/Tabadol.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-Tabadol-1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-Tabadol-1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=Tabadol&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }

elseif($textmessage == ""){
         if($type == "vip"){
             
       $user["step"] = "create-gp-gram1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
   elseif($textmessage != "منوی اصلی" and $step == "create-gp-gram1"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/index.php"))){
   $user["step"] = "create-gp-gram2";
   $user["gpgramtok"] = $textmessage;
   $user["usergpgram"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
     "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
   "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  elseif($textmessage != "منوی اصلی" and $step == "create-gp-gram2"){
    settype($createfree,"integer");
                      $newcreate = $createfree + 1;
                      $user["create"] = $newcreate;
            $user["step"] = "none";
                       $outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
                      $newbots = $freeallbots + 1;
                      $settings["freeallbots"] = $newbots;
                       $outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["gpgramtok"];
$usergpgram = $user["usergpgram"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=gpgram&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"",
 'parse_mode'=>"MarkDown",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد !
مدیر ربات :
[$from_id](tg://user?id=$from_id)
آیدی کانال تنظیم شده روی ربات :
@$textmessage
آیدی ربات شما :
@$usergpgram",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
    "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["gpgramtok"] = "";
   $user["usergpgram"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  
elseif($textmessage == "ساخت موزیک استور"){
         if($type == "vip"){
             
       $user["step"] = "create-index-MusicYab";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"جهت ساخت این ربات توکن دریافتی از @BotFather را ارسال کنید 
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]);  
   }else{
    bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"حساب کاربری شما VIP نمی باشد!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);   
   }
   }
    
  //-------APIBOT4----//
  elseif($textmessage != "منوی اصلی" and $step == "create-index-MusicYab"){
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
  $resultb = objectToArrays($userbot);
  $un = $resultb["result"]["username"];
  $ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../Bot/$un/musicyab.php"))){
  $myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
   $user["step"] = "create-index-MusicYab1";
   $user["esmtok"] = $textmessage;
   $user["useresm"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$myfile2 = fopen("data/ids.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$un\n");
fclose($myfile2);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"توکن ست شد 
حالا برای ست کردن کانال خود بر روی ربات آدرس کانال خود را بدون @ ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }else{
     bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"خطا 
دوست عزیز توکن شما خراب است و یا با این توکن قبلا ربات ثبت کرده اید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
  }
  }
  
    
  //-------APIBOT5----//
elseif($textmessage != "منوی اصلی" and $step == "create-index-MusicYab1"){
settype($createfree,"integer");
$newcreate = $createfree + 1;
$user["create"] = $newcreate;
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
   settype($freeallbots,"integer");
$newbots = $freeallbots + 1;
$settings["freeallbots"] = $newbots;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
$gpgramtok = $user["esmtok"];
$usergpgram = $user["useresm"];
file_get_contents("$URL/BotSazApi.php?id=$from_id&type=MusicYab&token=$gpgramtok&account=$type&channel=$textmessage&ads=$URL/Bots/BotSaz/$botusername/data/ads.txt&creator_cmd=$URL/Bots/BotSaz/$botusername/data/creator-cmd.txt");
    if($chlog != null){
       bot('sendMessage',[
 'chat_id'=>$chlog,
 'text'=>"یک ربات ساخته شد
مدیر ربات : $from_id
آیدی ربات : @$usergpgram

همین حالا ربات خود را با بهترین سرعت بسازید
@$botusername
$channel",
 'parse_mode'=>"HTML",
   ]); 
    }
 bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"ربات شما با موفقیت ساخته شد
مدیر ربات :
$from_id
 آیدی ربات شما :
@$usergpgram

 @$CHANNEL
 @$USEERBOT
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
  [['text'=>"منوی اصلی"]],
  
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,
   ])
   ]); 
   $user["esmtok"] = "";
   $user["useresm"] = "";
     $outjson3 = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson3);
  }
  

  
  
  
 //---

elseif($textmessage == "داشبورد 🌔"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
به بخش #داشبورد خوش آمدید ⚙

 <code>برای ویژه کردن حساب کاربری خود از بخش {ویژه شدن در ربات ساز} استفاده کنید اما از قبل با بنر خود 18 نفر را دعوت کنید و سپس از این بخش استفاده کنید</code>

یک بخش را انتخاب کنید ♻️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"📜اطلاعات حساب من"]],
[['text'=>"بنر زیرمجموعه گیری📊"],['text'=>"🥇ویژه شدن در ربات ساز"]],
  [['text'=>"منوی اصلی"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}
 

elseif($textmessage == "بنر زیرمجموعه گیری📊"){
       bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"یک ربات ساز فوق پیشرفته میخوای که ربات های جذابو سرگرم کننده بسازه حتی ربات ساز های پیشرفته  رو بسازه زود بیا تو کریت گرام حالشو ببر😘
https://telegram.me/$USEERBOT?start=$from_id",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"منوی اصلی"]],
  ],
      "resize_keyboard"=>true,'one_time_keyboard' => true,

  ])
  ]); 

}

//-----admin-panel-----
elseif($textmessage == "مدیریت" or $textmessage == "پنل" or $textmessage == "/panel"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>" سلام بابایی به پنل مدیریتم خوش اومدی",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"آمار"]],
  [['text'=>"ارسال پیام همگانی"],['text'=>"فروارد همگانی"]],
  [['text'=>"ویژه کردن حساب کاربری"],['text'=>"لغو حساب کاربری"]],
  [['text'=>"منوی اصلی"]],
  ],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما مدیر این ربات نمی باشید ! و دسترسی به این بخش را ندارید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "آمار"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"تعداد کل اعضای ربات : $allusers
تعداد ربات های ویژه ربات ساز گلد: $vipbots
 @$CHANNEL",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "ویژه کردن حساب کاربری"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "منوی اصلی" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
'text'=>"کاربر مورد نظر با موفقیت ویژه شد
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>" حساب کاربری شما توسط مدیریت ویژه شد",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
'text'=>"
یک حساب ویژه شد
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "لغو حساب کاربری"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "منوی اصلی" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "free";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
'text'=>"حساب شما توسط مدیران ربات رایگان شد",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "ارسال پیام همگانی"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال به تمامی اعضا ارسال نمایید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "منوی اصلی"){ 
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام به تمامی اعضا با موفقیت به همه اعضا ارسال شد",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "فروارد همگانی"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]); 
}
elseif($textmessage != "منوی اصلی" && $from_id == $admin && $step == "f2all"){
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "شارژ ربات ساز گلد برای ساخت ربات ساز"){
$user["step"] = "charge";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
'text'=>"برای شارژ ربات ساز گلد آیدی ربات ساز رو بدون @ ارسال کنید🎇",
 'parse_mode'=>"MarkDown",
     'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"منوی اصلی"]],
	],
		  "resize_keyboard"=>true,'one_time_keyboard' => true,
	 ])
]);
}
elseif($chat_id == $admin and $textmessage != "منوی اصلی" && $step == "charge"){
if(file_exists("Bots/BotSaz/$textmessage/index.php")){
$user["step"] = "free";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر برای ساخت 1 عدد ربات ساز شارژ شد!",
 'parse_mode'=>"MarkDown",
]);
$settings = json_decode(file_get_contents("Bots/BotSaz/$textmessage/data/settings.json"),true);
$sellbotsaz = $settings["sellbotsaz"];
$new = $sellbotsaz + 1;
$settings["sellbotsaz"] = $new;
$outjson1 = json_encode($settings,true);
file_put_contents("Bots/BotSaz/$textmessage/data/settings.json",$outjson1);
}else{
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر یافت نشد!",
 'parse_mode'=>"MarkDown",
]);  
}
   }

  //-----------
/*
این سورس توسط تیم آفتاب نوشته شده است هر گونه کپی بدون ذکر منبع حرام می باشد
@$CHANNEL
*/
}
unlink('error_log');
?>
);
?>