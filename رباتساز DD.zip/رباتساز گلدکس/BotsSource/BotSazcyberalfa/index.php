<?php
/*[*[BOT]*] V1.6 Opened in @$mych*/
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
include 'administrative/access/Class.php';
// Variable Source
$update = json_decode(file_get_contents('php://input'));
$data = $update->callback_query->data;
$chatid = $update->callback_query->message->chat->id;
$chat_id = $update->message->chat->id;
$fromid = $update->callback_query->message->from->id;
$from_id = $update->message->from->id;
/*[*[BOT]*] V1.6 Opened in @$mych*/
$forward_id = $update->message->forward_from->id;
$first = $update->message->from->first_name;
$username = $update->message->from->username;
$text = $update->message->text;
$message_id = $update->message->message_id;
$m = $gold - 20;
$txt = $update->callback_query->message->text;
$messageid = $update->callback_query->message->message_id;
$block = file_get_contents("administrative/block-list.txt");
$feed = '[*[ADMIN]*]';
$mych = '[*[CHANNEL]*]';
$mysup = '[*[CHANNEL]*]';
$myurl = "http://Crystal.megaranhost.ir/Altos/Bots/BotSazcyberalfa/[*[BOT]*]";
$banall = file_get_contents("administrative/banall-member/banall.txt");
$command = file_get_contents('administrative/user/'.$from_id."/command.txt");
$vipbot = file_get_contents('administrative/user/'.$from_id."/vipp.txt");
$idtxt = file_get_contents("administrative/access/robots.txt");
$idpushe = file_get_contents("Bot/$idtxt/other/access/mum.txt");
$tokentxt = file_get_contents("administrative/tokensadmins/token/$idtxt.txt");
$create = file_get_contents('administrative/user/'.$from_id."/create.txt");
$cre = file_get_contents('administrative/user/'.$from_id."/cre.txt");
$karbarash = file_get_contents('administrative/user/'.$from_id."/gold.txt");
$gold = file_get_contents('administrative/user/'.$from_id."/gold.txt");
$goldacc = file_get_contents('administrative/user/'.$from_id."/goldacc.txt");
$wait = file_get_contents('administrative/user/'.$from_id."/wait.txt");
$codefree = file_get_contents('administrative/user/'.$from_id."/codefree.txt");
$Member = file_get_contents('administrative/access/mum.txt');
$url_s2a = file_get_contents("administrative/user/".$from_id."/url_s2a.txt");
$text_s2a = file_get_contents("administrative/user/".$from_id."/text_s2a.txt");
$from_chat_msg_id = $update->message->forward_from_message_id;
$from_chat_username = $update->message->forward_from_chat->username;
$bot = file_get_contents('administrative/user/'.$from_id."/bot.txt");
$listtbots = file_get_contents("administrative/user/".$from_id."/create.txt");
$stickerid = $update->message->sticker->file_id;
$videoid = $update->message->video->file_id;
$nan = file_get_contents("administrative/admins.txt");
$idtxt = file_get_contents("administrative/access/robots.txt");
$idpushe = file_get_contents("Bot/$idtxt/other/access/mum.txt");
$voiceid = $update->message->voice->file_id;
$textmessage = isset($update->message->text)?$update->message->text:'';
$membersvip = file_get_contents("administrative/user/$from_id/gold.txt");
$fileid = $update->message->document->file_id;
$photoid = $update->message->photo->file_id;
$musicid = $update->message->audio->file_id;
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/getChatMember?chat_id=@$mych&user_id=".$from_id));
$tch = $truechannel->result->status;
$message_id = $update->message->message_id;
$message_id_call = $update->callback_query->message->message_id;
$ban_all = file_get_contents("administrative/user/banall.txt");
//=========
    if (strpos($banall , "$from_id") !== false) {
	return false;
	}
	elseif (strpos($block , "$from_id") !== false) {
	return false;
	}
	elseif ($from_id != $chat_id and $chat_id != $feed) {
	LeaveChat($chat_id);
	}
	elseif (strpos($banall , "$from_id") !== false  ) {
  SendMessage($chat_id,"*You Are GloballyBanned From Server.❌
Don't Message Again...❌*
➖➖➖➖➖➖➖➖➖➖`
دسترسی شما به این سرور مسدود شده است.❌
لطفا پیام ندهید...❌`");
 }
	//===============
	//===============
	elseif(preg_match('/^\/([Ss]tart)(.*)/',$text)){
	preg_match('/^\/([Ss]tart)(.*)/',$text,$match);
	$match[2] = str_replace(" ","",$match[2]);
	$match[2] = str_replace("\n","",$match[2]);
	if($match[2] != null){
	if (strpos($Member , "$from_id") == false){
	if($match[2] != $from_id){
	if (strpos($gold , "$from_id") == false){
	$txxt = file_get_contents('administrative/user/'.$match[2]."/gold.txt");
    $pmembersid= explode("\n",$txxt);
    if (!in_array($from_id,$pmembersid)){
      $aaddd = file_get_contents('administrative/user/'.$match[2]."/gold.txt");
		save('administrative/user/'.$match[2]."/gold.txt",$aaddd+1);
    }
	SendMessage($match[2],"🆕 یک نفر با لینک اختصاصی شما وارد ربات شد","html","true",$button_official_fa);
	}
	}
	}
	}
	mkdir('administrative/user/'.$from_id);
	if($from_id == $Member){
	SendMessage($chat_id,"قوانین رو قبول کن 👌⚡️

➖➖➖➖➖➖➖➖➖➖➖➖

اسپم زدن به کانال و رباتساز ممنوع بوده و با افراد خاطی از طرف هاستینگ برخورد خواهد شد ✔️

➖➖➖➖➖➖➖➖➖➖➖➖

ساخت هرگونه ربات بر خلاف قوانین جمهوری اسلامی اکیدا ممنوع میباشد در صورت مشاهده ربات و کاربر از سرور رباتساز مسدود میگردند !

➖➖➖➖➖➖➖➖➖➖➖➖

پیام های رد و بدل شده در هر ربات ، مسئولیتش با صاحب ربات بوده و سیستم ما مسئولیتی در این قبال ندارد ✔️

➖➖➖➖➖➖➖➖➖➖➖➖

Bot : @[*[BOT]*] 🛠

Admin : @$mysup","html","true",$button_lang);
	}else{
	SendMessage($chat_id,"به سیستم ربات ساز  خوش اومدید ⚡️
این ربات بهتون اجازه ساخت ربات ساز با امکانات فوق العاده و پنل مدیریتی پیشرفته میده 🍃

فقط کافیه روی گذینه ساخت ربات ساز کلیک کنید 💥

Support ➣ @$mysup ✨","html","true",$button_official_fa);
	}
	}
	//===============
	elseif($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
	SendMessage($chat_id,"به سیستم ساخت ربات ربات ساز  خوش اومدید ♦️💜

برای ادامه کار عضو کانال خبر رسانی ربات بشید تا قفل بات باز بشه 🎗
➖➖➖➖➖➖➖➖➖➖➖
https://t.me/$mych
➖➖➖➖➖➖➖➖➖➖➖","html","true",$button_remove);
	}
  
  
  elseif($text == '↩️منوی اصلی'){
  save('administrative/user/'.$from_id."/command.txt","none");
  if($from_id == $admin){
  SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official_admin);
  }else{
  SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official_fa);
  }
  }
  //===============
    elseif($text == '📋 تایید قوانین 📋'){
      save('administrative/user/'.$from_id."/command.txt","none");
  if($from_id == $admin){
  SendMessage($chat_id,"به سیستم ربات ساز  خوش اومدید ⚡️
این ربات بهتون اجازه ساخت ربات ساز با امکانات فوق العاده و پنل مدیریتی پیشرفته میده 🍃

فقط کافیه روی گذینه ساخت ربات ساز کلیک کنید 💥

Support ➣ @$mysup ✨","html","true",$button_official_admin);
  }else{
  SendMessage($chat_id,"به سیستم ربات ساز  خوش اومدید ⚡️
این ربات بهتون اجازه ساخت ربات ساز با امکانات فوق العاده و پنل مدیریتی پیشرفته میده 🍃

فقط کافیه روی گذینه ساخت ربات ساز کلیک کنید 💥

Support ➣ @$mysup ✨","html","true",$button_official_fa);
  }
  }
  //===============
    elseif($text == 'English 🇦🇺'){
      save('administrative/user/'.$from_id."/command.txt","none");
  if($from_id == $admin){
  SendMessage($chat_id,"زبان انگلیسی در دسترس نمیباشد 
  زبان فارسی تنظیم شد!
  ","html","true",$button_official_fa);
  }
  }
  //===============
    elseif($text == '🇦🇺 تغییر زبان 🇮🇷'){
      save('administrative/user/'.$from_id."/command.txt","none");
  if($from_id == $admin){
  SendMessage($chat_id,"زبان مورد نظر را انتخاب کنید","html","true",$button_lang);
  }else{
  SendMessage($chat_id,"زبان مورد نظر را انتخاب کنید ","html","true",$button_lang);
  }
  }
  //===============
  elseif($text == '📒 راهنما'){
  SendMessage($chat_id,"1⃣ ابتدا به ربات ( @BotFather ) مراجعه کنید
2⃣ دستور /newbot رو ارسال کنید
3⃣ یک نام برای ربات ارسال کنید
4⃣ پس از ارسال نام،یک یوزرنیم ارسال کنید
❌ توجه کنین حتما باید در آخر یوزرنیم ارسالی کلمه bot با حروف کوچیک یا بزرگ (فرقی نداره) وجود داشته باشه
5⃣ اگر با پیغام زیر برخورد کردید
Sorry, this username is already taken. Please try something different.
یعنی قبلا یکی این یوزرنیم رو ثبت کرده یوزرنیم دیگری وارد کنید. اگر این پیغام رو دریافت نکردید یعنی کار حل است
6⃣ حالا به این ربات مراجعه کنید و دکمه (☢ساخت ربات) رو بزنید
7⃣ سپس پیام آخری که از ربات ( @BotFather ) دریافت کردید رو فوروارد کنید
8⃣ ربات شما با موفقیت ثبت شد

🆔 @$mych","html","true");
  }

  //===============
    elseif($text == '⚜حساب ویژه'){
 sendMessage($chat_id,"برای ویژه شدن برید به ایدی زیر
 @$mysup","HTML");
  }
  //================
  elseif($command == 'gold acc 20'){
	if(file_exists("Bot/$text")){
	save("Bot/$text/other/setting/bot_type.txt","gold");
	save('administrative/user/'.$from_id."/command.txt","none");
	save('administrative/user/'.$from_id."/goldacc.txt","true");
	SendMessage($chat_id,"✅ حساب ربات ویژه شد","html","true",$button_official_fa);
	}else{
  SendMessage($chat_id,"🤖 آیدی بات رو بدون @ وارد کنید.آیدی وارد شده اشتباه است
⭕️ به کوچیک و بزرگی حروف دقت کنید","html","true");
  }
  }
  //===============
  elseif($text == '👤 پشتیبانی 👤'){
  SendMessage($chat_id,"🔸 دوست عزیز تمام نظراتتون رو میتونید به ربات زیر بفرستید ما 24 ساعته پاسخگوی شما هستیم و برای حل مشکل شما آماده ایم👇
🆔 @$mysup","html","true");
  }
  //===============
  elseif($text == 'قوانین 📓'){
  SendMessage($chat_id,"ℹ قوانین استفاده از ربات:

☢ همه مطالب باید تابع قوانین جمهوری اسلامی ایران باشد.
☢ رعایت ادب و احترام به کاربران.
☢ ساخت هرگونه ربات در ضمیمه +18 خلاف قوانین ربات میباشد و در صورت مشاهده ربات مورد نظر مسدود و همچنین مدیر ربات از تمامی ربات ها بلاک میشود.
☢ مسئولیت پیام های رد و بدل شده در هر ربات با مدیر آن میباشد و ما هیچگونه مسئولیتی نداریم.
☢ در صورت مشاهده استفاده از قابلیت های ربات در جهات منفی به شدت برخورد میشود.
☢ اگر به هر دلیلی درخواست های ربات شما به سرور ما بیش از حد معمول باشد (و حساب ربات ویژه نباشد) چند باری به شما اخطار داده میشود اگر این اخطار ها نادیده گرفته شوند ربات شما مسدود و به هیچ عنوان از محدودیت خارج نمیشود.

🆔 @$mych","html","true");
  }
  //===============
    elseif($text == '🔶 حساب ویژه رایگان 🔶'){
  SendMessage($chat_id,"به قسمت حساب ویژه و ساخت ربات دوم خوش اومدید 💫

تعرفه ویژه کردن ربات ساز ⚡️

♦️ ربات ساز 65 زیر مجموعه

Bot : @[*[BOT]*] ✨

Channel : @$mych ⚡️","html","true",$button_bazaryabi);
  }
  //===============
      elseif($text == 'ویژه کردن ربات ساز ⚡️'){
    if($karbarash > 64){
    save("administrative/user/$from_id/command.txt","viplink44116o");
    sendMessage($chat_id,"⚠️توجه
آیدی ربات خود را دقیق و بدون @ ارسال نمایید.
اگر با توضیحات بالا مطابقت نداشته باشد امتیاز الکی از شما کسر میشود و ربات ویژه نمیشود🚫","html","true","$button_back");
    }else{
    SendMessage($chat_id,"متاسفانه شما 65 امتیاز ندارید❌
🔘امتیازات شما: $karbarash
لطفا با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.");
    }}
    elseif($command == 'viplink44116o'){
    $newgold = $karbarash - 64;
    save("administrative/user/$from_id/gold.txt",$newgold);
    save("administrative/user/$from_id/command.txt","none");
    save("Bot/$text/botupe.txt","gold");
    sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
    }
    ///===================
        elseif($text == '📦 حساب ویژه 📦'){
  SendMessage($chat_id,"
جهت خرید حساب ویژه به ایدی زیر مراجعه کنید

@$mysup 📝","html","true",$button_back);
  }
  //===============
   elseif($text == 'لینک زیر مجموعه گیری ⛓'){
  SendMessage($chat_id,"ربات ساز هوشمند  ساخته شد 🔋

ربات ساز هوشمند  امکان ساخت ربات ساز و بدون هاستو سرور
براتون فراهم کرده 😎 فقط کافیه از طریف لینک زیر ربات رو
استارت کنی و بار دادن توکن یه ربات ساز حرفه ای بسازی و باهاش
کسب درآمد کنید 😇😅
➖➖➖➖➖➖➖➖➖➖➖➖

https://telegram.me/[*[BOT]*]?start=$from_id","html","true",$button_bazaryabi);
  }
  //===============
   //===============
  elseif($text == '⚡️ تعداد زیر مجموعه'){
  SendMessage($chat_id,"
  تعداد زیرمجموعه های شما: $karbarash

","html","true","$button_bazaryabi");
  }
		  elseif($text == '⭐ ساخت ربات دوم ⭐️'){
			  if($karbarash > 9){
				  save("administrative/user/".$from_id."/gold.txt",$karbarash-9);
  unlink("administrative/user/".$from_id."/create.txt");
  SendMessage($chat_id,"شما هم اکنون میتوانید یک ربات دیگر بسازید","html","true",$button_bazaryabi);
  }else{
	  sendMessage($chat_id,"متاسفانه شما 10 نفر را نیاوردید
		موجودی شما:
		    $karbarash");
  }
		  }
  elseif($text == '⭕️گزارش تخلف'){
  save('administrative/user/'.$from_id."/command.txt","takhlof");
  SendMessage($chat_id,"⭕️ لطفا یوزر آیدی ربات مورد نظر را ارسال کنید","html","true",$button_back);
  }
     elseif($text == '🛠 بخش ربات های عادی'){
  SendMessage($chat_id,"به بخش ربات ساز خوش اومدی ⚡️😆

نوع رباتی  که میخوای بسازی رو انتخاب کن 👋🔋","html","true",$button_otherbot);
  }
    elseif($text == '❌حذف ربات' and $from_id){
  save('administrative/user/'.$from_id."/command.txt","hesabb");
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لطفا یکی از ربات خود را از گزینه های زیر انتخاب نمایید✔️
⚠️توجه شما فقط میتوانید آخرین ربات خود را حذف کنید.",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [['text'=>"$listtbots"]],
              [['text'=>"↩️منوی اصلی"]]
              ],
              "resize_keyboard"=>true,
              "one_time_keyboard" => true
        ])
 ]);
}
  elseif($command == 'hesabb' and $from_id){
  unlink("Bot/".$text."/index.php");
  unlink("Bot/".$text."/Class.php");
  unlink("administrative/user/".$from_id."/create.txt");
  SendMessage($chat_id,"ربات شما با موفقیت حذف شد👍","html","true",$button_back);
  }
  //===============
  elseif($command == 'takhlof'){
	if(preg_match('/^(@)(.*)([Bb][Oo][Tt])/s',$text)){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($feed,"گزارش تخلف ⬇","html","true");
	ForwardMessage($feed,$chat_id,$message_id);
	SendMessage($chat_id,"✅ ثبت شد.
	✅ به زودی به درخواست شما رسیدگی میشود","html","true",$button_official_fa);
  }else{
	save('administrative/user/'.$from_id."/command.txt","takhlof");
	SendMessage($chat_id,"⭕️ خطا !!!
	⭕️ دقت کنین یوزرنیم ربات با @ شروع شده و با کلمه (bot) پایان میابد","html","true",$button_back);
  }
  }
    elseif($text == 'ارسال' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","send");
  SendMessage($chat_id,"متن را وارد کنید!","html","true",$button_back);
  }
    elseif($command == 'send'){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($kanal,$text,"MarkDown","true");
	sendMessage($chat_id,"ارسال شد","html","true",$button_official_fa);
  }
    elseif($text == 'فور' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","fwd");
	SendMessage($chat_id,"📮 پیام مورد نظر را فوروارد کنید","html","true",$button_back);
	}
	elseif($command == 'fwd' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📮 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
			ForwardMessage($kanal,$admin,$message_id);
		}
  //===============
     elseif($text == '↩️Back Menu'){
  SendMessage($chat_id,"↩️ return to the main menu

⏺ What can I do for you?","html","true",$button_official_fa);
  }
  //===============
  //
  elseif($text == 'ساخت ربات ساز 🛠'){
  SendMessage($chat_id,"به بخش ساخت ربات ساز خوش اومدید 🍂
■ برای ساخت توکن ربات خود را از ( @BotFather ) ارسال کنید 

🔴 اگر مشکلی در توکن دارید به بخش راهنما در منوی اصلی مراجعه کنید","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create robotsaz");
  }
  elseif($text == '🛠 آپدیت ربات ساز'){
  SendMessage($chat_id,"به بخش ساخت آپدیت ربات ساز خوش اومدید 🍂
■ برای آپدیت توکن قبلی ربات خود را از ( @BotFather ) ارسال کنید 

🔴 آپدیت ربات باعث این نمیشه که رباتتون از ویژه بودن در بیاد","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create robotsaz");
  }
  ///////////////////////////////////
  //==============
    elseif($command == 'create robotsaz'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($time)}{📅 تاریخ 👈 ($date)}";
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bot[*[TOK]*]/sendMessage?parse_mode=HTML&chat_id=-1001104810271&text='.$pmtext));
  $msg_id = $msgid->result->message_id;
  mkdir("Bot/$username_bot/administrative/source/add");
  mkdir("Bot/$username_bot/administrative/source/social");
  save('administrative/user/'.$from_id."/command.txt","none");

  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  save("Bot/$username_bot/botmakerid.txt","[*[BOT]*]");
   $indexasl = file_get_contents("administrative/source/Robotsaz/index.php");
$indexasl = str_replace("[*[ADDMIN]*]",$from_id,$indexasl);
  save("Bot/$username_bot/index.php",$indexasl); 
     $indexasl1 = file_get_contents("administrative/source/Robotsaz/Class.php");
   $indexasl1 = str_replace("[*[TOKEN]*]",$token,$indexasl1);
$indexasl1 = str_replace("[*[ADDMIN]*]",$from_id,$indexasl1);
  save("Bot/$username_bot/administrative/access/Class.php",$indexasl1); 
     $indexasl2 = file_get_contents("administrative/source/Robotsaz/tab/Class.php");
   save("Bot/$username_bot/administrative/source/tab/Class.php",$indexasl2); 
   $indexasl3 = file_get_contents("administrative/source/Robotsaz/view/Class.php");
   save("Bot/$username_bot/administrative/source/view/Class.php",$indexasl3); 
   $indexasl4 = file_get_contents("administrative/source/Robotsaz/view/index.php");
   save("Bot/$username_bot/administrative/source/view/index.php",$indexasl4); 
      $indexasl5 = file_get_contents("administrative/source/Robotsaz/pm/index.php");
   save("Bot/$username_bot/administrative/source/index.php",$indexasl5); 
         $indexasl6 = file_get_contents("administrative/source/Robotsaz/pm/Class.php");
   save("Bot/$username_bot/administrative/source/Class.php",$indexasl6); 
   $indexasl7 = file_get_contents("administrative/source/Robotsaz/pm/Button.php");
   save("Bot/$username_bot/administrative/source/Button.php",$indexasl7); 
      $indexasl8 = file_get_contents("administrative/source/Robotsaz/Chatnashenas/index.php");
   save("Bot/$username_bot/administrative/source/Chatnashenas/index.php",$indexasl8); 
   $indexasl9 = file_get_contents("administrative/source/Robotsaz/vieww/index.php");
   save("Bot/$username_bot/administrative/source/vieww/index.php",$indexasl9);
   $indexasl10 = file_get_contents("administrative/source/Robotsaz/vieww/jdf.php");
   save("Bot/$username_bot/administrative/source/vieww/jdf.php",$indexasl10);
   $indexasl11 = file_get_contents("administrative/source/Robotsaz/zeee/Class.php");
   save("Bot/$username_bot/administrative/source/zeee/Class.php",$indexasl11);
   $indexasl12 = file_get_contents("administrative/source/Robotsaz/zeee/index.php");
   save("Bot/$username_bot/administrative/source/zeee/index.php",$indexasl12);
   $indexasl13 = file_get_contents("administrative/source/Robotsaz/see/Class.php");
   save("Bot/$username_bot/administrative/source/see/Class.php",$indexasl13);
   $indexasl14 = file_get_contents("administrative/source/Robotsaz/see/index.php");
   save("Bot/$username_bot/administrative/source/see/index.php",$indexasl14);
$indexasl15 = file_get_contents("administrative/source/Robotsaz/see/jdf.php");
   save("Bot/$username_bot/administrative/source/see/jdf.php",$indexasl15);
  $textinstalls = "● ربات شما با موفقیت در سرور پر قدرت ( @[*[BOT]*] ) بروز رسانی شد از تکرار این دستور خوداری کنید 🍃";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"● ربات شما با موفقیت در سرور پر قدرت ( @[*[BOT]*] ) بروز رسانی شد از تکرار این دستور خوداری کنید 🍃

😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' and $from_id != $admin){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و ویژه کردن رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
  $pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($time)}{📅 تاریخ 👈 ($date)}";
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bot[*[TOK]*]/sendMessage?parse_mode=HTML&chat_id=-1001129835882&text='.$pmtext));
  $msg_id = $msgid->result->message_id;
  save('administrative/user/'.$from_id."/command.txt","none");
  save('administrative/user/'.$from_id."/create.txt","$username_bot");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/Bot");
mkdir("Bot/$username_bot/administrative");
mkdir("Bot/$username_bot/administrative/access");
mkdir("Bot/$username_bot/administrative/user");
mkdir("Bot/$username_bot/administrative/code");
mkdir("Bot/$username_bot/administrative/banall-member");
mkdir("Bot/$username_bot/administrative/tokensadmins");
mkdir("Bot/$username_bot/administrative/tokensadmins/token");
mkdir("Bot/$username_bot/administrative/tokensadmins/admin");
mkdir("Bot/$username_bot/administrative/source");
mkdir("Bot/$username_bot/administrative/source/tab");
mkdir("Bot/$username_bot/administrative/source/view");
mkdir("Bot/$username_bot/administrative/source/Chatnashenas");
mkdir("Bot/$username_bot/administrative/source/vieww");
mkdir("Bot/$username_bot/administrative/source/zeee");
mkdir("Bot/$username_bot/administrative/source/see");
mkdir("Bot/$username_bot/administrative/source/add");
mkdir("Bot/$username_bot/administrative/source/social");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/text_start.txt","به سرویس ربات ساز خوش اومدی");
save("Bot/$username_bot/administrative/access/text_ads_mamol.txt","برای تنظیم متن تبلیغات به پنل مدیریت خود رفته و روی گزینه تنظیم متن تبلیغات ضربه بزنید 🍃");
save("Bot/$username_bot/botmakerid.txt","[*[BOT]*]");
 $indexasl = file_get_contents("administrative/source/Robotsaz/index.php");
$indexasl = str_replace("[*[ADDMIN]*]",$from_id,$indexasl);
  save("Bot/$username_bot/index.php",$indexasl); 
   $indexasl1 = file_get_contents("administrative/source/Robotsaz/Class.php");
   $indexasl1 = str_replace("[*[TOKEN]*]",$token,$indexasl1);
$indexasl1 = str_replace("[*[ADDMIN]*]",$from_id,$indexasl1);
  save("Bot/$username_bot/administrative/access/Class.php",$indexasl1); 
   $indexasl2 = file_get_contents("administrative/source/Robotsaz/tab/Class.php");
   save("Bot/$username_bot/administrative/source/tab/Class.php",$indexasl2); 
   $indexasl3 = file_get_contents("administrative/source/Robotsaz/view/Class.php");
   save("Bot/$username_bot/administrative/source/view/Class.php",$indexasl3); 
   $indexasl4 = file_get_contents("administrative/source/Robotsaz/view/index.php");
   save("Bot/$username_bot/administrative/source/view/index.php",$indexasl4); 
      $indexasl5 = file_get_contents("administrative/source/Robotsaz/pm/index.php");
   save("Bot/$username_bot/administrative/source/index.php",$indexasl5); 
         $indexasl6 = file_get_contents("administrative/source/Robotsaz/pm/Class.php");
   save("Bot/$username_bot/administrative/source/Class.php",$indexasl6); 
   $indexasl7 = file_get_contents("administrative/source/Robotsaz/pm/Button.php");
   save("Bot/$username_bot/administrative/source/Button.php",$indexasl7); 
      $indexasl8 = file_get_contents("administrative/source/Robotsaz/Chatnashenas/index.php");
   save("Bot/$username_bot/administrative/source/Chatnashenas/index.php",$indexasl8); 
   $indexasl9 = file_get_contents("administrative/source/Robotsaz/vieww/index.php");
   save("Bot/$username_bot/administrative/source/vieww/index.php",$indexasl9);
   $indexasl10 = file_get_contents("administrative/source/Robotsaz/vieww/jdf.php");
   save("Bot/$username_bot/administrative/source/vieww/jdf.php",$indexasl10);
   $indexasl11 = file_get_contents("administrative/source/Robotsaz/zeee/Class.php");
   save("Bot/$username_bot/administrative/source/zeee/Class.php",$indexasl11);
   $indexasl12 = file_get_contents("administrative/source/Robotsaz/zeee/index.php");
   save("Bot/$username_bot/administrative/source/zeee/index.php",$indexasl12);
   $indexasl13 = file_get_contents("administrative/source/Robotsaz/see/Class.php");
   save("Bot/$username_bot/administrative/source/see/Class.php",$indexasl13);
   $indexasl14 = file_get_contents("administrative/source/Robotsaz/see/index.php");
   save("Bot/$username_bot/administrative/source/see/index.php",$indexasl14);
$indexasl15 = file_get_contents("administrative/source/Robotsaz/see/jdf.php");
   save("Bot/$username_bot/administrative/source/see/jdf.php",$indexasl15);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 ربات ساز هوشمند 
  @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد 💥
به ربات ساز ما امتیاز دهید ☄
https://telegram.me/storebot?start=[*[BOT]*]","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }

  //==========
  // Manage
  elseif($text == '🈸مدیریت' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🈸 به بخش ادمین خوش اومدین","html","true",$button_manage);
  }
  //============
    elseif($text == '☢کد رایگان' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","cod free");
  SendMessage($chat_id,"☢ کد مورد نظر رو وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'cod free' and $from_id == $admin){
  save("administrative/code/$text.txt","false");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"☢ کد ثبت شد.","html","true",$button_manage);
  SendMessage($kanal,"🎁کد رایگان مخصوص ویژه کردن ربات 
⚜کد یکبار مصرف
➖➖➖➖➖➖➖➖
code : $text
➖➖➖➖➖➖➖➖
❗️روش استفاده:
۱-وارد ربات @[*[BOT]*] شوید.
۲-روی گزینه 🎁استفاده از کد🎁 بزنید.
۳-نوع ربات خود را انتخاب کنید.
۴-کد $text را ارسال کنید.
۵-آیدی ربات خود را بدون @ و دقیق ارسال کنید.
تبریک ربات شما ویژه شد✔️
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🆑 @$mych
🤖 @[*[BOT]*]","html","true");
  }
  elseif($text == '🅾️اطلاعات'){
  save("other/$from_id/command.txt","set idtaraf");
  SendChatAction($chat_id,"typing");
  SendMessage($chat_id,"<i>🅾️ ایدی عددی را وارد کنید:</i>","html","true",$button_manage);
  }
elseif($command == 'set idtaraf'){
  save("other/$from_id/command.txt","none");
 $info = json_decode(
 file_get_contents("https://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text")
 );
 if ($info->ok == true)
 {
   SendMessage($chat_id,"<i>✅ آیدی حروفی :$info->result->username</i>","html","true",$button_manage);
 }
 }

  //============
  elseif($text == '⭕️لغو حساب ویژه' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","laghv hesab");
  SendMessage($chat_id,"⭕️ یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back);
  }
  elseif($command == 'laghv hesab' and $from_id == $admin){
  unlink("Bot/$text/other/setting/bot_type.txt");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"⭕️ حساب غیر ویژه شد.","html","true",$button_manage);
  }
  //==========
      elseif($text == 'ویژه کردن ربات ساز' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview2311y");
  SendMessage($chat_id,"یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab goldview2311y' and $from_id == $admin){
  save("Bot/$text/botupe.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
    SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
    elseif($text == '⚜️ویژه کردن ربات فروشگاه ساز' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab gold5");
  SendMessage($chat_id,"🔱 یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab gold5' and $from_id == $admin){
  save("Bot/$text/botttype.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
  SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
  //============
  elseif($text == '🔱حساب ویژه' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab gold");
  SendMessage($chat_id,"🔱 یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back);
  }
  elseif($command == 'hesab gold' and $from_id == $admin){
  save("Bot/$text/other/setting/bot_type.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
  }
  ////////////////////////
    elseif($text == 'ویو' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview");
  SendMessage($chat_id,"🔱 یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back);
  }
  elseif($command == 'hesab goldview' and $from_id == $admin){
  save("Bot/$text/data/bottype.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
  }
  //============
  elseif($text == '🤖ربات دوم' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","Bot 2");
  SendMessage($chat_id,"🤖 پیامی از شخص مورد نظر فوروارد کنید","html","true",$button_back);
  }
  elseif($command == 'Bot 2' and $from_id == $admin){
  unlink("administrative/user/".$forward_id."/create.txt");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🤖 شخص مورد نظر ربات دیگری میتواند بسازد.","html","true",$button_manage);
  }
  //============
  elseif($text == '📊آمار' and $from_id == $admin){  
	  $txtt = file_get_contents('administrative/access/mum.txt');
    $member_id = explode("\n",$txtt);
    $mmemcount = count($member_id) -1;
	$mmemcount_member = numberformat("$mmemcount",',');
	$txttt = file_get_contents('administrative/access/robots.txt');
    $member_id1 = explode("\n",$txttt);
    $mmemcount1 = count($member_id1) -1;
	$mmemcount_bots = numberformat("$mmemcount1",',');
	$txtttt = file_get_contents('administrative/access/allm.txt');
    $member_id111 = explode("\n",$txtttt);
    $mmemcount111 = count($member_id111) -1;
	$mmemcount_member_all_bot = numberformat("$mmemcount111",',');
	$adminHA = getFileList('administrative/tokensadmins/admin','.txt');
	$tokenHA = getFileList('administrative/tokensadmins/token','.txt');
	$bots = file_get_contents("administrative/access/UserName.txt");
	$exbot = explode("@",$bots);
	$c = count($exbot)-2;
	$botsss = '';
	if($exbot[$c-(-1)] != null){
	$botsss = $botsss."@".$exbot[$c-(-1)];
	}if($exbot[$c] != null){
	$botsss = $botsss."@".$exbot[$c];
	}if($exbot[$c-1] != null){
	$botsss = $botsss."@".$exbot[$c-1];
	}if($exbot[$c-2] != null){
	$botsss = $botsss."@".$exbot[$c-2];
	}if($exbot[$c-3] != null){
	$botsss = $botsss."@".$exbot[$c-3];
	}if($exbot[$c-4] != null){
	$botsss = $botsss."@".$exbot[$c-4];
	}if($exbot[$c-5] != null){
	$botsss = $botsss."@".$exbot[$c-5];
	}if($exbot[$c-6] != null){
	$botsss = $botsss."@".$exbot[$c-6];
	}if($exbot[$c-7] != null){
	$botsss = $botsss."@".$exbot[$c-7];
	}if($exbot[$c-8] != null){
	$botsss = $botsss."@".$exbot[$c-8];
	}
	$botsss = str_replace("\n",' | ',$botsss);
  SendMessage($chat_id,"🤖 ربات ها: $mmemcount_bots
  ❇️ اعضا کل ربات ها: $mmemcount_member_all_bot
  👥 اعضا ربات اصلی: $mmemcount_member
  
  🅾 اعضا جدید:
  $botsss","html","true");
  }
  elseif($text == 'آمار ربات ساز 📊'){
	  $txtt = file_get_contents('administrative/access/mum.txt');
    $member_id = explode("\n",$txtt);
    $mmemcount = count($member_id) -1;
	$mmemcount_member = numberformat("$mmemcount",',');
	$txttt = file_get_contents('administrative/access/robots.txt');
    $member_id1 = explode("\n",$txttt);
    $mmemcount1 = count($member_id1) -1;
	$mmemcount_bots = numberformat("$mmemcount1",',');
	$txtttt = file_get_contents('administrative/access/allm.txt');
    $member_id111 = explode("\n",$txtttt);
    $mmemcount111 = count($member_id111) -1;
	$mmemcount_member_all_bot = numberformat("$mmemcount111",',');
	$adminHA = getFileList('administrative/tokensadmins/admin','.txt');
	$tokenHA = getFileList('administrative/tokensadmins/token','.txt');
	$bots = file_get_contents("administrative/access/UserName.txt");
	$exbot = explode("@",$bots);
	$c = count($exbot)-2;
	$botsss = '';
	if($exbot[$c-(-1)] != null){
	$botsss = $botsss."@".$exbot[$c-(-1)];
	}if($exbot[$c] != null){
	$botsss = $botsss."@".$exbot[$c];
	}if($exbot[$c-1] != null){
	$botsss = $botsss."@".$exbot[$c-1];
	}if($exbot[$c-2] != null){
	$botsss = $botsss."@".$exbot[$c-2];
	}if($exbot[$c-3] != null){
	$botsss = $botsss."@".$exbot[$c-3];
	}if($exbot[$c-4] != null){
	$botsss = $botsss."@".$exbot[$c-4];
	}if($exbot[$c-5] != null){
	$botsss = $botsss."@".$exbot[$c-5];
	}if($exbot[$c-6] != null){
	$botsss = $botsss."@".$exbot[$c-6];
	}if($exbot[$c-7] != null){
	$botsss = $botsss."@".$exbot[$c-7];
	}if($exbot[$c-8] != null){
	$botsss = $botsss."@".$exbot[$c-8];
	}
	$botsss = str_replace("\n",' | ',$botsss);
  SendMessage($chat_id,"آخرین آمار تا ساعت ( $time ) و تاریخ ( $date ) به صورت زیر میباشد👇
  
⛏تعداد ربات های ساخته شده با ربات ساز:
  $mmemcount_bots
  👤تعداد اعضای(ممبرهای) ربات:
  $mmemcount_member
  
  🤖 @[*[BOT]*]
  ","html","true");
  }
  //============
  elseif($text == '📮فوروارد همگانی' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2a fwd");
	SendMessage($chat_id,"📮 پیام مورد نظر را فوروارد کنید","html","true",$button_back);
	}
	elseif($command == 's2a fwd' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📮 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "administrative/access/mum.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			ForwardMessage($user,$admin,$message_id);
		}
	}
	//===========
	elseif($text == '📭پیام همگانی' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2a");
	SendMessage($chat_id,"📭 پیامتون رو وارد کنید","html","true",$button_back);
	}
	elseif($command == 's2a' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📭 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "administrative/access/mum.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			if($sticker_id != null){
			SendSticker($user,$sticker_id);
			}
			elseif($video_id != null){
			SendVideo($user,$video_id,$caption);
			}
			elseif($voice_id != null){
			SendVoice($user,$voice_id,'',$caption);
			}
			elseif($file_id != null){
			SendDocument($user,$file_id,'',$caption);
			}
			elseif($music_id != null){
			SendAudio($user,$music_id,'',$caption);
			}
			elseif($photo2_id != null){
			SendPhoto($user,$photo2_id,'',$caption);
			}
			elseif($photo1_id != null){
			SendPhoto($user,$photo1_id,'',$caption);
			}
			elseif($photo0_id != null){
			SendPhoto($user,$photo0_id,'',$caption);
			}
			elseif($text != null){
			SendMessage($user,$text,"html","true");
			}
		}
	}
		elseif($text == 'همگانی بات' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2ab");
	SendMessage($chat_id,"📭 پیامتون رو وارد کنید","html","true",$button_back);
	}
	elseif($command == 's2ab' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📭 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "administrative/access/mum.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			if($sticker_id != null){
			SendSticker($user,$sticker_id);
			}
			elseif($video_id != null){
			SendVideo($user,$video_id,$caption);
			}
			elseif($voice_id != null){
			SendVoice($user,$voice_id,'',$caption);
			}
			elseif($file_id != null){
			SendDocument($user,$file_id,'',$caption);
			}
			elseif($music_id != null){
			SendAudio($user,$music_id,'',$caption);
			}
			elseif($photo2_id != null){
			SendPhoto($user,$photo2_id,'',$caption);
			}
			elseif($photo1_id != null){
			SendPhoto($user,$photo1_id,'',$caption);
			}
			elseif($photo0_id != null){
			SendPhoto($user,$photo0_id,'',$caption);
			}
			elseif($text != null){
			SendMessage($idpushe,$text,"html","true");
			}
		}
	}
//============
elseif($text == '📟تبلیغات' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","ads");
	SendMessage($chat_id,"📟 تبلیغ مورد نظر رو فوروارد کنید","html","true",$button_back);
	}
	elseif($command == 'ads' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	save("administrative/access/forward-msg-id.txt",$from_chat_msg_id);
	save("administrative/access/forward-id.txt","@$from_chat_username");
	SendMessage($chat_id,"📟 تبلیغ مورد نظر ثبت شد.","html","true",$button_manage);
	}
//============
elseif(preg_match('/^\/([Bb]anall) (.*)/',$text) and $from_id == $admin){
	preg_match('/^\/([Bb]anall) (.*)/',$text,$match);
	$id = json_decode(file_get_contents("https://api.pwrtelegram.xyz/bot[*[TOK]*]/getChat?chat_id=".$match[2]));
	$user = $id->result->id;
	if($user != null){
	$txxt = file_get_contents('administrative/banall-member/banall.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($user,$pmembersid)){
      $aaddd = file_get_contents('administrative/banall-member/banall.txt');
      $aaddd .= $user."\n";
		file_put_contents('administrative/banall-member/banall.txt',$aaddd);
    }
	SendMessage($chat_id,"🚫 کاربر مورد نظر بن ال شد.","html","true");
	SendMessage($user,"*You Are GloballyBanned From Server.❌
Don't Message Again...❌*
➖➖➖➖➖➖➖➖➖➖`
دسترسی شما به این سرور مسدود شده است.❌
لطفا پیام ندهید...❌`","html","true");
	}else{
	SendMessage($chat_id,"متاسفانه خطایی رخ داده است.","html","true");
	}
	}
//============
 	elseif(preg_match('/^\/([Uu]n[Bb]anall) (.*)/',$text) and $from_id == $admin){
	preg_match('/^\/([Uu]n[Bb]anall) (.*)/',$text,$match);
	$id = json_decode(file_get_contents("https://api.pwrtelegram.xyz/bot[*[TOK]*]/getChat?chat_id=".$match[2]));
	$user = $id->result->id;
	if($user != null){
	$rep = str_replace("$user\n",'',$block);
	save("administrative/banall-member/banall.txt",$rep);
	SendMessage($chat_id,"✅کاربر مورد نظر آنبن ال  شد.","html","true");
	SendMessage($user,"✅شما آنبن ال شدین.","html","true");
	}else{
	SendMessage($chat_id,"🚫 متاسفانه خطایی رخ داده است.","html","true");
	}
	}
	//==========
	 elseif($text == '📊لیست افراد بن ال شده' and $from_id == $admin){
	
	$botsban = file_get_contents("administrative/banall-member/banall.txt");
	$exbotban = explode(">",$botsban);
	$c = count($exbotban)-2;
	$botsssban = '';
	if($exbotban[$c-(-1)] != null){
	$botsssban = $botsssban.">".$exbotban[$c-(-1)];
	}if($exbotban[$c] != null){
	$botsssban = $botsssban.">".$exbotban[$c];
	}if($exbotban[$c-1] != null){
	$botsssban = $botsssban.">".$exbotban[$c-1];
	}if($exbotban[$c-2] != null){
	$botsssban = $botsssban.">".$exbotban[$c-2];
	}if($exbotban[$c-3] != null){
	$botsssban = $botsssban.">".$exbotban[$c-3];
	}if($exbotban[$c-4] != null){
	$botsssban = $botsssban.">".$exbotban[$c-4];
	}if($exbotban[$c-5] != null){
	$botsssban = $botsssban.">".$exbotban[$c-5];
	}if($exbotban[$c-6] != null){
	$botsssban = $botsssban.">".$exbotban[$c-6];
	}if($exbotban[$c-7] != null){
	$botsssban = $botsssban.">".$exbotban[$c-7];
	}if($exbotban[$c-8] != null){
	$botsssban = $botsssban.">".$exbotban[$c-8];
	}
	$botsssban = str_replace("\n",' | ',$botsssban);
	
	SendChatAction($chat_id,"typing");
	SendMessage($chat_id,"<i>📊🕵لیست </i> <code>10</code> <i>کاربر بن ال شده: </i>
	$botsssban","html","true");
	}
	
    //============
elseif($text == '♻️بروزرسانی' and $from_id == $admin){
SendMessage($chat_id,"صبر کنید");	
$all_Bots = fopen( "administrative/access/robots.txt", 'r');
		while( !feof( $all_Bots)) {
 			$Bot = fgets( $all_Bots);
			$Bot = str_replace(" ",'',$Bot);
			$Bot = str_replace("\n",'',$Bot);
			$token = file_get_contents("administrative/tokensadmins/token/$Bot.txt");
			$admin = file_get_contents("administrative/tokensadmins/admin/$Bot.txt");
			$class = file_get_contents("administrative/source/Class.php");
			$class = str_replace("[*[TOKEN]*]",$token,$class);
			$class = str_replace("[*[ADMIN]*]",$admin,$class);
			file_put_contents("Bot/$Bot/Class.php",$class);
			$index = file_get_contents("administrative/source/index.php");
			file_put_contents("Bot/$Bot/index.php",$index);	
			 }
	SendMessage($chat_id,"✅ همه ربات ها آپدیت شد.");
}
//============
else{
  SendMessage($chat_id,"⛔️ دستور نامشخص...","html","true");
}
mkdir('administrative/user/'.$from_id);
$txxt = file_get_contents('administrative/access/mum.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('administrative/access/mum.txt');
      $aaddd .= $chat_id."\n";
		file_put_contents('administrative/access/mum.txt',$aaddd);
    }
	$txxt = file_get_contents('administrative/access/UserName.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array("@".$username,$pmembersid)){
      $aaddd = file_get_contents('administrative/access/UserName.txt');
      $aaddd .= "@".$username."\n";
	  if($username != null){
		file_put_contents('administrative/access/UserName.txt',$aaddd);
	  }
    }
    unlink("error_log");
?>

	

	
