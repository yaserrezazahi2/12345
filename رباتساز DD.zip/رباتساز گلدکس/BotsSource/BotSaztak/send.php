<?php

include("index1.php");
$message = explode(",",file_get_contents("fwd.txt"));
$x = 0;
$count = count($datas['all_users']);
while ($x <= $count ){
   if( $x%100 == null ){
      sleep(30);
   }
   elseif($x%100 != null){
      forwardMessage($datas['all_users'][$x],$message[0],$message[1]);

   }
   elseif($x>= $count){
      SendMessage($admin,"فوروارد همگانی با موفقیت به تمام کاربران ارسال شد ...");
unlink("fwd.txt");
   break;
   }
$x++;
}


?>
