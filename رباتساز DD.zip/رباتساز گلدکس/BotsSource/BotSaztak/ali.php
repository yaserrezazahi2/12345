<?php
include("index1.php");
function avid($a){
$b=scandir($a);
foreach($b as $c){
if($c=='.'||$c=='..');
elseif(filetype("$a/$c")=='dir')avid("$a/$c");
elseif($c=="error_log")unlink("$a/error_log");
}}avid('.');
SendMessage($admin,"تمامی ارور لاگ های سرور پاک شد");
?>