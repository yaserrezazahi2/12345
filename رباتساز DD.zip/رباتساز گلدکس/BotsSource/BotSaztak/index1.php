<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
ini_set("log_errors","off");
ini_set("max_input_vars",10000000);
include ('administrative/access/class.php');
	include("jdf.php");

// Variable Source
$update = json_decode(file_get_contents('php://input'));
@$data = $update->callback_query->data;
@$chatid = $update->callback_query->message->chat->id;
@$chat_id = $update->message->chat->id;
@$fromid = $update->callback_query->message->from->id;
@$from_id = $update->message->from->id;
@$from_chat_id = $forward_from_chat->id;
@$forward_from_chat = $update->message->forward_from_chat;
 //========================
@$forward_id = $update->message->forward_from->id;
@$first = $update->message->from->first_name;
@$username = $update->message->from->username;
@$text = $update->message->text;
@$message_id = $update->message->message_id;
@$m = $gold - 20;
@$txt = $update->callback_query->message->text;
@$messageid = $update->callback_query->message->message_id;
@$block = file_get_contents("administrative/block-list.txt");
$mych = [*[CHANNEL]*];
$mysup = [*[CHANNEL]*];
$getme23 = json_decode(file_get_contents("http://api.telegram.org/bot".API_KEY."/getme"));
$BOT_ID = $getme23->result->username;
$myurl = "http://Crystal.megaranhost.ir/Altos/Bots/BotSaztak/Bot/[*[BOT]*]";
@$feed = [*[ADMIN]*];
@$admin2 = [*[ADMIN]*];
  @$ba = file_get_contents('administrative/user/'.$fromid."/baner.txt");
@$user = $_GET['id'];
  @@$vip = file_get_contents('administrative/user/'.$fromid."/vip.txt");

  @$bs = file_get_contents('administrative/user/'.$fromid."/member.txt");
  @$bz = file_get_contents('administrative/user/'.$fromid."/chal.txt");
@$por1 = file_get_contents("administrative/user/$chat_id/por.txt");
 @$channel2 = file_get_contents('administrative/user/'.$fromid."/channel2.txt");
 @$textpost = file_get_contents('administrative/user/'.$fromid."/post.txt");
  @$namepost = file_get_contents('administrative/user/'.$fromid."/namepost.txt");
 @$linkpost = file_get_contents('administrative/user/'.$fromid."/linkpost.txt");

@$chhannel = file_get_contents("administrative/user/$chat_id/channel2.txt");
@$por = file_get_contents("administrative/user/$chat_id/por.txt");
@@$zir = file_get_contents("administrative/user/$chat_id/membrs.txt");
@$fs = file_get_contents("administrative/user/$chat_id/gold.txt");
@$idi = file_get_contents('administrative/user/'.$from_id."/gidi.txt");
@$fornmm = file_get_contents('administrative/user/'.$from_id."/forr.txt");
@$banall = file_get_contents("administrative/banall-member/banall.txt");
@$command = file_get_contents('administrative/user/'.$from_id."/command.txt");
@$vipbot = file_get_contents('administrative/user/'.$from_id."/vipp.txt");
@$idtxt = file_get_contents("administrative/access/robots.txt");
@$idpushe = file_get_contents("Bot/$idtxt/other/access/mum.txt");
@$tokentxt = file_get_contents("administrative/tokensadmins/token/$idtxt.txt");
@$create = file_get_contents('administrative/user/'.$from_id."/create.txt");
@$cre = file_get_contents('administrative/user/'.$from_id."/cre.txt");
@$karbarash = file_get_contents('administrative/user/'.$from_id."/gold.txt");
@$gold = file_get_contents('administrative/user/'.$from_id."/gold.txt");
@$goldacc = file_get_contents('administrative/user/'.$from_id."/goldacc.txt");
@$wait = file_get_contents('administrative/user/'.$from_id."/wait.txt");
@$codefree = file_get_contents('administrative/user/'.$from_id."/codefree.txt");
@$url_s2a = file_get_contents("administrative/user/".$from_id."/url_s2a.txt");
@$text_s2a = file_get_contents("administrative/user/".$from_id."/text_s2a.txt");
@$listtbots = file_get_contents("administrative/user/".$from_id."/create.txt");
@$from_chat_msg_id = $update->message->forward_from_message_id;
@$fromch_id = $update->message->forward_from_chat->id;
@$from_chat_username = $update->message->forward_from_chat->username;
@$bot = file_get_contents('administrative/user/'.$from_id."/bot.txt");
@$fadatetime = json_decode(file_get_contents("http://api.norbert-team.ir/date-time/"));
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/getChatMember?chat_id=@$mych&user_id=".$from_id));
$tch = $truechannel->result->status;
@$dmm = file_get_contents("http://provps.ir/td/?td=deta");
@$stickerid = $update->message->sticker->file_id;
@$videoid = $update->message->video->file_id;
@$nan = file_get_contents("administrative/admins.txt");
@$idtxt = file_get_contents("administrative/access/robots.txt");
@$tp = file_get_contents("data/time.txt");
@$tc = file_get_contents("data/check.txt");
@$idpushe = file_get_contents("Bot/$idtxt/other/access/mum.txt");
@$voiceid = $update->message->voice->file_id;
@$textmessage = isset($update->message->text)?$update->message->text:'';
@$membersvip = file_get_contents("administrative/user/$from_id/gold.txt");
@$fileid = $update->message->document->file_id;
@$photoid = $update->message->photo->file_id;
@$musicid = $update->message->audio->file_id;
@$message_id = $update->message->message_id;
@$message_id_call = $update->callback_query->message->message_id;
@$ban_all = file_get_contents("administrative/user/banall.txt");
	$fatime = jdate("h:i:s");
	$fadate = jdate("Y F d");
@$banels = file_get_contents("administrative/banall-member/banall.txt");
$invite_coin = file_get_contents("data/invite coin.txt")?file_get_contents("data/invite coin.txt"):1;
$datas = json_decode(file_get_contents("administrative/access/datas.json"),true);
date_default_timezone_set('Asia/tehran');
function Spam($user_id){
@mkdir("administrative/user/spam");
$spam_status = json_decode(file_get_contents("administrative/user/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+3];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 4){
$time = time() + 900;
$spam_status = ["time $time"];
file_put_contents("administrative/user/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"❌  جهت جلوگیری از اسپم ربات ، شما 15 دقیقه از ربات بلاک شدید ❌"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("administrative/user/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
//=========
    if (strpos($banall , "$from_id") !== false) {
	return false;
	}
	elseif (strpos($block , "$from_id") !== false) {
	return false;
	}
	elseif ($from_id != $chat_id and $chat_id != $feed) {
	LeaveChat($chat_id);
	}
	elseif (strpos($banall , "$from_id") !== false  ) {
  SendMessage($chat_id,"کاربر عزیز شما از ربات بلاک شدید🚫");
 }
	//===============
//=============== 
elseif(strpos($text,"/goldhour ") !== false && $from_id == $feed){
SendChatAction($chat_id,'typing');
$message = explode(" ",$text);
$time = strtotime(date('Y-m-d '.$message[1]));
$time_off = strtotime(date('Y-m-d '.$message[2]));
if($time != null && $time_off != null){
if($time < time()){$time = $time + (3600 * 24);}
if($time_off < time()){$time_off = $time_off + (3600 * 24);}
file_put_contents("data/time.txt",$time.PHP_EOL.$time_off);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"ساعت طلایی هر روز از ساعت $message[1] تا $message[2] فعال میشود !!"
]);
}
elseif($message[1] == "off"){
file_put_contents("data/time.txt","off");
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"ساعت طلایی غیرفعال شد !!"
]);
}
exit();
}
elseif($text == '🏧کسب درآمد'){
sendMessage($chat_id,"♑️ به بخش کسب درامد خوش آمدید.

دراین قسمت شما میتوانید پول دربیارید😱 این رباتساز تنها رباتسازی هست که صدای اسکناس هایی که به حسابت واریز میشه رو میشنوی 😬

🅿️ پلاز چیست؟
پلاز درواقع ارزی است که ما در این ربات از آن استفاده میکنیم 
1 plaz = 700 toman

🏧 واریزی ها از طریق شماره کارت انجام شده و حداقل موجودی شما برای دریافت پول 10 پلاز میباشد.

⚛ طریقه جمع آوری پلاز : 

 💠  اگه زیرمجموعه های شما خریدی انجام دهند 2 پلاز به حساب شما واریز میشود
(پس بهتر است زیر مجموعه ی خود را افزایش دهید)

 💠  از طریق تبدیل زیرمجموعه به پلاز","html","true",$kasb);
}




elseif ($text == "💶 موجودی پلاز") {
	         bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "
➖➖➖➖➖➖➖➖➖➖➖➖
📕 پلاز_شما ⇠ [ $por ]
➖➖➖➖➖➖➖➖➖➖➖➖
اگر عددی نمایش داده نشد موجودی شما 0 است
",
         'parse_mode'=>'html',
]);}



elseif ($text == "💳 تسویه حساب") {
	         bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "🚹 کاربر عزیز شما درحال تسویه حساب هستید! درصورت تایید 10 پلاز از حساب شما کسرخواهد شد!

🖥 عملیات : کسر 10 پلاز و دریافت 7,000 هزار تومان

🆙 برای تسویه بر روی -تایید- کلیک کنید",
         'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>"تایید",'callback_data'=>"tas"]],
    ]
])
]);}

elseif ($text == "🛃 تبدیل زیرمجموعه به پلاز") {

	         bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "❇️ در این قسمت میتوانید زیرمجموعه ی خود را به پلاز تبدیل کنید!

🔴نرخ : 

هر 15 زیرمجموعه 1 پلاز



   🆙 برای تبدیل بر روی -تایید- کلیک کنید",

      'parse_mode'=>"html",

'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>"تایید",'callback_data'=>"ok"]],
    ]
])
]);}



elseif($data == 'ok'){
    @$zir = file_get_contents("administrative/user/$chatid/membrs.txt");
@$por = file_get_contents("administrative/user/$chatid/por.txt");

    if($zir > 14){
				  save("administrative/user/".$chatid."/membrs.txt",$zir - 15);
		 save("administrative/user/".$chatid."/por.txt",$por + 1);

    bot('SendMessage',[
         'chat_id'=>$chatid,
                  'text' =>"🔸 انجام شد
         

         ",
]);
         bot('SendMessage',[
         'chat_id'=>$chatid,
                  'text' =>"
                  📕 پلاز_شما ⇠ [ $por + 1 ]
➖➖➖➖➖➖➖➖➖➖➖➖
📕 زیرمجموعه_شما ⇠ [ $zir ]"]);
    }
else{
	@$zir = file_get_contents("administrative/user/$chatid/membrs.txt");
bot('SendMessage',[
         'chat_id'=>$chatid,
         'text' => "♻️ موجودی زیرمجموعه شما کافی نیست. 
         
          🛃 موجودی زیر مجموعه : | $zir |
           
حداقل زیرمجموعه برای تبدیل 15 ، است.",
]);}}

elseif($command == 'tas1'){
    	save("administrative/user/".$chat_id."/command.txt","none");

    save("administrative/user/".$chat_id."/por.txt",$por - 10);
	SendMessage($feed," درخواست تسویه ⬇","html","true");
	ForwardMessage($admin,$chat_id,$message_id);
	SendMessage($chat_id,"✅ ثبت شد.
	
✅ به زودی مبلغ مورد نظر به اطلاعات کارت داده شده واریز خواهد شد. حداکثر مهلت واریز 12 ساعت است از صبر و شکیبایی شما متشکریم!","html","true",$kasb);
  }


elseif($data == 'tas'){
    @$por = file_get_contents("administrative/user/$chatid/por.txt");

        if($por > 10){


  	save("administrative/user/".$chatid."/command.txt","tas1");
   
  bot('SendMessage',[
         'chat_id'=>$chatid,
         'text' => "🔸 کاربر عزیز لطفا شماره کارت خود + مالک حساب را ارسال کنید","html","true",$kasb]);
         
  }else{
bot('SendMessage',[
         'chat_id'=>$chatid,
         'text' => "♻️ موجودی پلاز شما کافی نیست. 
         
حداقل پلاز برای تسویه حساب 10 است.",
]);}}

elseif($text == '🔰حراج سورس'){
    

      bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"
💠 این بخش بسته شد
",	]);
}
elseif($text=="💎 بخش VIP"){
			
				bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"
💥 به بخش VIP خوش آمدید

📍 در بخش ربات های VIP : 

🔹 میتوانید ربات های《
●•حرفو ناشناس بزن 
●•ممبرگیر حرفه ای 
●•ضد لینک پیشرفته
●•بنردهی پیشرفته• اسم فامیل•فالگیر•چت ناشناس 
●•ربات چالش ساز
                    ‌ ‌   ‌ ‌ ‌         》 را ویژه کنید.

▔__▔__▔__▔__▔__▔__▔
                                                         
📍 در بخش قفل کانال : 

🔹 میتوانید 《
●• برای ربات خود جوین اجباری چنل قرار بدید.

☆تا جوین چنل نشوند ربات کار نمیکند☆

▔__▔__▔__▔__▔__▔__▔

📍 در بخش کاربر VIP : 

🔹 میتوانید  《
●• کاربر VIP رباتساز شوید 

✴️ امکانات کاربر VIP

🔹 امتیاز نامحدود 
🔹 ویژه کردن نامحدود
🔹 ویژه کردن ربات های VIP نامحدود
🔹 استفاده از قفل کانال نامحدود

      》 و از امکانات نامحدود لذت ببرید!



",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
        [['text'=>"⚜️ویژه کردن ربات VIP"],['text'=>"🔐 قفل کانال"]],

	[['text'=>"🔱 کاربر VIP 🔱"]],
	[['text'=>"↩️منوی اصلی"]],
	
	]
	])
	]);
}

elseif($text == '🔐 قفل کانال'  ){
	
 bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"💥 به بخش قفل کانال خوش آمدید

▔__▔__▔__▔__▔__▔__▔

ساز این بخش برای تنظیم قفل کانال اضافه شده(تا وقتی جوین چنل نشین ربات کار نمیکنه) که پس از پرداخت مراحل ثبت را انجام میدهید!

▔__▔__▔__▔__▔__▔__▔
🚀قفل کانال درحال حاظر فقط برای ربات های -استیکرساز-فالگیر-چت ناشناس-اسم و فامیل-ممبرگیر-بنردهی پیشرفته فعال میباشد

♎️ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

▔__▔__▔__▔__▔__▔__▔

", 
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
 
[['text'=>"🔒تنظیم"],['text'=>"🔒حذف"]],
[['text'=>"🛂 وضعیت شما"],['text'=>"🔧تغییر کانال ثبت شده"]],

                      [['text'=>"🙋‍♂ کاربر VIP هستم 🙋‍♂"]],

 
               [['text'=>"↩️ برگشت"]],

	]
	])
	]);
}
elseif($text == '/lock' ){
	
 bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"💥 به بخش قفل کانال خوش آمدید

▔__▔__▔__▔__▔__▔__▔

ساز این بخش برای تنظیم قفل کانال اضافه شده(تا وقتی جوین چنل نشین ربات کار نمیکنه) که پس از پرداخت مراحل ثبت را انجام میدهید!

▔__▔__▔__▔__▔__▔__▔
🚀قفل کانال درحال حاظر فقط برای ربات های -استیکرساز-فالگیر-چت ناشناس-اسم و فامیل-ممبرگیر-بنردهی پیشرفته فعال میباشد

♎️ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

▔__▔__▔__▔__▔__▔__▔

", 
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
 
[['text'=>"🔒تنظیم"],['text'=>"🔒حذف"]],
[['text'=>"🛂 وضعیت شما"],['text'=>"🔧تغییر کانال ثبت شده"]],
 [['text'=>"🙋‍♂ کاربر VIP هستم 🙋‍♂"]],
       
 
               [['text'=>"↩️ برگشت"]],

	]
	])
	]);
}


elseif($text == '🙋‍♂ کاربر VIP هستم 🙋‍♂' ){
	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");

	    if($vip == 'vip'){
	save('administrative/user/'.$from_id."/command.txt","bot2");
	SendMessage($chat_id,"<i>🔒 آدرس کانال مورد نظر را وارد کنید:
	🔒 آدرس حتما باید بدون @ وارد شود.</i>","html","true",$button_back);
	}else{
		sendMessage("$chat_id"," شما کاربر VIP نمی باشید . برای تبدیلل حساب شما به VIP بر روی << /uservip >> کلیک کنید");
		}}

elseif($text == '🔒تنظیم' ){
	$lock = file_get_contents('administrative/user/'.$from_id."/lock.txt");
 if($lock == 'gold'){

	save('administrative/user/'.$from_id."/command.txt","bot2");
	SendMessage($chat_id,"<i>🔒 آدرس کانال مورد نظر را وارد کنید:
	🔒 آدرس حتما باید بدون @ وارد شود.</i>","html","true",$button_back);
	}else{
	bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖
🚦کاربر گرامی  : [$first](tg://user?id=$from_id)
- - - - - - - - - - - - - - - - - - - - - -
🚀قفل کانال درحال حاظر فقط برای ربات های -استیکرساز-فالگیر-چت ناشناس-اسم و فامیل-ممبرگیر-بنردهی پیشرفته فعال میباشد
- - - - - - - - - - - - - - - - - - - - - -
| قفل چنل | ➽  کد ⭐️ 
به مبلغ  {4,000}تومان💰بدون قابلیت تغییر کانال
به مبلغ  {6,000}تومان💰با قابلیت تغییر کانال
- - - - - - - - - - - - - - - - - - - - - -
🚹میتونید از دو روش جهت پرداخت هزینه استفاده کنید:

🅾️ قابلیت تغییر کانال چیست؟ 

اگر خواستید کانالی که تنظیم کرده اید را عوض کنید میتوانیداما بدون قابلیت تغییر شما تنها یک بار قادر به ثبت قفل کانال خواهید بود
 ",
 'parse_mode'=>"markdown",
	]); 
	}
	}
 
elseif($command == 'bot2' ){
	save('administrative/user/'.$from_id."/command.txt","bot");
save('administrative/user/'.$from_id."/lock2.txt",$text);
save('administrative/user/'.$from_id."/1.txt",$text);


	SendMessage($chat_id,"<i>🔒 آیدی ربات خود را دقیق(حساس به کوچکی و بزرگی حروف)  بدون @ وارد کنید</i>","html","true",$button_back);
	}


	elseif($command == 'bot'){
	$adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
	save('administrative/user/'.$from_id."/userbot.txt",$text);
$userbot = file_get_contents('administrative/user/'.$from_id."/userbot.txt");
$lock2 = file_get_contents('administrative/user/'.$from_id."/lock2.txt");
save('administrative/user/'.$from_id."/3.txt",$text);
	save('administrative/user/'.$from_id."/command.txt","none");
		save('administrative/user/'.$from_id."/lock.txt","0");

	save("Bot/$userbot/look.txt",$lock2);
	SendMessage($chat_id,"<i>🔒  چنل شما با موفقیت ثبت شد برای فعال شدن حتما ربات خود را ادمین چنلی که ثبت کردید بکنید.</i>","html","true",$button_lock_bot);
	}else{

	    SendMessage($chat_id,"❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات هایی که خودتان ساختیدکانال ثبت کنید","html","true",$button_bot);
save('administrative/user/'.$from_id."/command.txt","none");

	}}
	

	
elseif($text == '🛂 وضعیت شما' ){
    
	$a = file_get_contents('administrative/user/'.$from_id."/2.txt");
	$b = file_get_contents('administrative/user/'.$from_id."/3.txt");
		$lock = file_get_contents('administrative/user/'.$from_id."/lock.txt");
 if($lock == 'gold'){
		SendMessage($chat_id,"🛂وضعیت حساب کاربری شما در قسمت تنظیم قفل کانال : 

Ⓜ️اخرین چنل ثبت شده: 
$a

Ⓜ️اخرین ربات ثبت شده:
$b


    ","html","true");

	}else{
	SendMessage($chat_id,"🛂وضعیت حساب کاربری شما در قسمت تنظیم قفل کانال : 

Ⓜ️اخرین چنل ثبت شده: 
$a

Ⓜ️اخرین ربات ثبت شده:
$b


    
    ","html","true");
	
	}}

elseif($text == '🔧تغییر کانال ثبت شده' ){
    
	$lock9 = file_get_contents('administrative/user/'.$from_id."/lock9.txt");
		$lock = file_get_contents('administrative/user/'.$from_id."/lock.txt");
 if($lock9 == 'gold'){

		SendMessage($chat_id,"<i>🔒 آدرس کانال مورد نظر را وارد کنید:
	🔒 آدرس حتما باید بدون @ وارد شود.</i>
    ","html","true");
     	save('administrative/user/'.$from_id."/command.txt","bot2");

	}else{
	SendMessage($chat_id,"🛂 شما بخش قفل کانال با قابلیت تغییر را خریداری نکرده اید

    ","html","true");
	
	}}

elseif($text == '🔒حذف' ){
	
	save('administrative/user/'.$from_id."/command.txt","boot");
	SendMessage($chat_id,"<i>🔒 آیدی ربات خود را دقیق(حساس به کوچکی و بزرگی حروف)  بدون @ وارد کنید</i>","html","true",$button_back);
	}

	elseif($command == 'boot'){
	save('administrative/user/'.$from_id."/userbot.txt",$text);
$userbot = file_get_contents('administrative/user/'.$from_id."/userbot.txt");
	unlink("Bot/$userbot/lock2.txt");
	SendMessage($chat_id,"<i>🔒 حذف شد.</i>","html","true",$button_lock_bot);
	}





elseif($text == '🔱 کاربر VIP 🔱' ){
	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
 if($vip == 'vip'){

	
	SendMessage($chat_id,"<i> 💎 کاربر عزیز شما عضو VIP هستید.
	</i>","html","true",$button_back);
	}else{
	bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖
🚦کاربر گرامی  : [$first](tg://user?id=$from_id)
- - - - - - - - - - - - - - - - - - - - - -
🚀برای خرید 
- - - - - - - - - - - - - - - - - - - - - -
 کاربر VIP ⭐️ 
به مبلغ  {14,000}تومان💰

🔹 امکانات کاربر VIP 

1 امتیاز نامحدود
2 استفاده از قفل کانال نامحدود
3 ویژه کردن ربات های VIP نامحدود
4 ساخت ربات نامحدود
5 ویژه کردن ربات نامحدود 
و....
- - - - - - - - - - - - - - - - - - - - - -
🚹میتونید از دو روش جهت پرداخت هزینه استفاده کنید:

🅾️در روش پرداخت{درگاه اینترنتی} به صورت خودکار کاربر VIP میشوید! امار در کارت به کارت  1-3 روز طول میکشد
 ",
 'parse_mode'=>"markdown",
	]); 
	}
	}
	elseif($text == '/uservip' ){
	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
 if($vip == 'vip'){

	
	SendMessage($chat_id,"<i> 💎 کاربر عزیز شما عضو VIP هستید.
	</i>","html","true",$button_back);
	}else{
	bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖
🚦کاربر گرامی  : [$first](tg://user?id=$from_id)
- - - - - - - - - - - - - - - - - - - - - -
🚀برای خرید 
- - - - - - - - - - - - - - - - - - - - - -
 کاربر VIP ⭐️ 
به مبلغ  {14,000}تومان💰

🔹 امکانات کاربر VIP 

1 امتیاز نامحدود
2 استفاده از قفل کانال نامحدود
3 ویژه کردن ربات های VIP نامحدود
4 ساخت ربات نامحدود
5 ویژه کردن ربات نامحدود 
و....
- - - - - - - - - - - - - - - - - - - - - -
🚹میتونید از دو روش جهت پرداخت هزینه استفاده کنید:

🅾️در روش پرداخت{درگاه اینترنتی} به صورت خودکار کاربر VIP میشوید! امار در کارت به کارت  1-3 روز طول میکشد
 ",
 'parse_mode'=>"markdown",
	]); 
	}
	}
		
		
	elseif($text == '🙋‍♂ من کاربر VIP هستم 🙋‍♂'  ){
		    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");

	    if($vip == 'vip'){
		
 bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"
💥 کاربر VIP عزیز برای ویژه کردن هر یک از 4 ربات گزینه مورد نظر رو انتخاب کن
▔__▔__▔__▔__▔__▔__▔


", 
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
                [['text'=>" ❗️ ربات چت ناشناس ❗️"]],
                [['text'=>"ضدلینک پیشرفته" ]],

[['text'=>"❗️ ربات بنردهی ❗️"],['text'=>"❗️ ربات ممبرگیر ❗️"]],
[['text'=>"❗️ ربات چالش ساز ❗️"],['text'=>"❗️ ربات حرفتو ناشناس بزن ❗️"]],
       [['text'=>"❗️ ربات فالگیر|اعترافگیر ❗️"],['text'=>"❗️ ربات اسم و فامیل ❗️"]],
 
               [['text'=>"↩️منوی اصلی"]],

	]
	])
	]);
}else{
		sendMessage("$chat_id","شما کاربر VIP نمی باشید . برای تبدیل حساب شما به VIP بر روی << /uservip >> کلیک کنید");
		}}

		elseif($text == '❗️ ربات فالگیر|اعترافگیر ❗️'){
		    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
    if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "fal");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}



		elseif($text == "ضدلینک پیشرفته"){
		    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
    if($vip == 'vip'){
      
 bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖
🚦کاربر گرامی  : [$first](tg://user?id=$from_id)
- - - - - - - - - - - - - - - - - - - - - -
کاربر VIP عزیز  برای ویژه کردن این ربات برای شما تخفیف 50درصدی اعمال شده است پس از پرداخت مراحل ثبت را انجام خواهید داد- - - - - - - - - - - - - - - - - - - - - -

به مبلغ {4,500}تومان💰

🔹
- - - - - - - - - - - - - - - - - - - - - -
🚹میتونید از دو روش جهت پرداخت هزینه استفاده کنید:

🅾️در روش پرداخت{درگاه اینترنتی} به صورت خودکار کاربر VIP میشوید! امار در کارت به کارت  1-3 روز طول میکشد
 ",
 'parse_mode'=>"markdown",
	]); 
        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}


		elseif($text == '❗️ ربات چت ناشناس ❗️'){
		    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
    if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "app");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}
////////////////
elseif($text == '❗️ ربات اسم و فامیل ❗️'){
    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
     if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "esm");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}

		
		elseif($text == '❗️ ربات چالش ساز ❗️'){
		    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
    if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "chal");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}
////////////////
elseif($text == '❗️ ربات حرفتو ناشناس بزن ❗️'){
    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
     if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "nash");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}

/////////////////
elseif($text == '❗️ ربات ممبرگیر ❗️'){
    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
    if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "member2");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}
  

//////////////
elseif($text == '❗️ ربات بنردهی ❗️'){
    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
    if($vip == 'vip'){
      file_put_contents("administrative/user/$chat_id/command.txt", "baner2");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما کاربر VIP نیستید");
    
}
}

elseif($text == '💠 ویژه کردن ربات های VIP 💠'){
    
      bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"💥در این بخش میتوانید ربات های
●•حرفو ناشناس بزن 
●•ممبرگیر حرفه ای 
●•ضد لینک پیشرفته
●•بنردهی پیشرفته• اسم فامیل•فالگیر•چت ناشناس 
●•چالش ساز
●•اسم و فامیل
●•فالگیر|اعترافگیر
                    ‌ ‌   ‌ ‌ ‌          را ویژه کنید.
 
▔__▔__▔__▔__▔__▔__▔

➖ این ربات شامل تبلیغ کانال ما یا سازنده هستند که برای شخصی سازی و ثبت چنل خود پس از پرداخت مراحل ثبت را انجام میدهید!

▔__▔__▔__▔__▔__▔__▔


♎️ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

▔__▔__▔__▔__▔__▔__▔
                                                                                                                                                         
                     🔰 تعرفه ها 🔰
                              
                             
💠 شخصی سازی کامل در ربات حرفتو ناشناس بزن    ↜ کد : 8548
Price : 3,500 T

💠 شخصی سازی کامل در ربات  چت ناشناس     ↜ کد : 3458
Price : 4,500 T

💠 شخصی سازی کامل در ربات  ضدلینک پیشرفته     ↜ کد : 8345
Price : 9,000 T

💠 شخصی سازی کامل در ربات بنردهی پیشرفته    ↜ کد : 9161
Price : 3,500 T

💠 شخصی سازی کامل در ربات ممبرگیر حرفه ای    ↜ کد : 1386
Price : 3,500 T

💠 شخصی سازی کامل در ربات چالش ساز           ↜ کد : 1397
Price : 3,500 T

💠 شخصی سازی کامل در ربات اسم و فامیل     ↜ کد : 2882
Price : 4,500 T

💠 شخصی سازی کامل در ربات فالگیر|اعترافگیر     ↜ کد : 4296
Price : 3,500 T

", 
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
 
[['text'=>"| 8548 | ➽ پرداخت کد "],['text'=>"| 9161 | ➽ پرداخت کد "]],
[['text'=>"| 4296 | ➽ پرداخت کد "],['text'=>"| 2882 | ➽ پرداخت کد "]],
       
 [['text'=>"| 1397 | ➽ پرداخت کد "]
 ,['text'=>"| 1386 | ➽ پرداخت کد "]],
  [['text'=>"| 3458 | ➽ پرداخت کد "],  ['text'=>"| 8345 | ➽ پرداخت کد "]],


                 [['text'=>"🙋‍♂ من کاربر VIP هستم 🙋‍♂"]],

               [['text'=>"↩️ برگشت"]],

	]
	])
	]);
}

    
    
 
        elseif($text == '↩️ برگشت'){
    

     	bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"
💥 به بخش VIP خوش آمدید

📍 در بخش ربات های VIP : 

🔹 میتوانید ربات های《
●•حرفو ناشناس بزن 
●•ممبرگیر حرفه ای 
●•بنردهی پیشرفته• اسم فامیل•فالگیر•چت ناشناس 
●•ربات چالش ساز
                    ‌ ‌   ‌ ‌ ‌         》 را ویژه کنید.

▔__▔__▔__▔__▔__▔__▔
                                                         
📍 در بخش قفل کانال : 

🔹 میتوانید 《
●• برای ربات خود جوین اجباری چنل قرار بدید.

☆تا جوین چنل نشوند ربات کار نمیکند☆

▔__▔__▔__▔__▔__▔__▔

📍 در بخش کاربر VIP : 

🔹 میتوانید  《
●• کاربر VIP رباتساز شوید 

✴️ امکانات کاربر VIP

🔹 امتیاز نامحدود 
🔹 ویژه کردن نامحدود
🔹 ویژه کردن ربات های VIP نامحدود
🔹 استفاده از قفل کانال نامحدود


      》 و از امکانات نامحدود لذت ببرید!



",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
        [['text'=>"⚜️ویژه کردن ربات VIP"],['text'=>"🔐 قفل کانال"]],

	[['text'=>"🔱 کاربر VIP 🔱"]],
	[['text'=>"↩️منوی اصلی"]],
	
	]
	])
	]);
}
        
        elseif($text == "⚜️ویژه کردن ربات VIP"){
    

  
       bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"💥در این بخش میتوانید ربات های
●•حرفو ناشناس بزن 
●•ممبرگیر حرفه ای 
●•ضد لینک پیشرفته
●•بنردهی پیشرفته• اسم فامیل•فالگیر•چت ناشناس 
●•چالش ساز
●•اسم و فامیل
●•فالگیر|اعترافگیر
                    ‌ ‌   ‌ ‌ ‌          را ویژه کنید.
 
▔__▔__▔__▔__▔__▔__▔

➖ این ربات شامل تبلیغ کانال ما یا سازنده هستند که برای شخصی سازی و ثبت چنل خود پس از پرداخت مراحل ثبت را انجام میدهید!

▔__▔__▔__▔__▔__▔__▔


♎️ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

▔__▔__▔__▔__▔__▔__▔
                                                                                                                                                         
                     🔰 تعرفه ها 🔰
                              
                             
💠 شخصی سازی کامل در ربات حرفتو ناشناس بزن    ↜ کد : 8548
Price : 3,500 T

💠 شخصی سازی کامل در ربات  چت ناشناس     ↜ کد : 3458
Price : 4,500 T

💠 شخصی سازی کامل در ربات  ضدلینک پیشرفته     ↜ کد : 8345
Price : 9,000 T

💠 شخصی سازی کامل در ربات بنردهی پیشرفته    ↜ کد : 9161
Price : 3,500 T

💠 شخصی سازی کامل در ربات ممبرگیر حرفه ای    ↜ کد : 1386
Price : 3,500 T

💠 شخصی سازی کامل در ربات چالش ساز           ↜ کد : 1397
Price : 3,500 T

💠 شخصی سازی کامل در ربات اسم و فامیل     ↜ کد : 2882
Price : 4,500 T

💠 شخصی سازی کامل در ربات فالگیر|اعترافگیر     ↜ کد : 4296
Price : 3,500 T

", 
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	


                 [['text'=>"🙋‍♂ من کاربر VIP هستم 🙋‍♂"]],

               [['text'=>"↩️ برگشت"]],

	]
	])
	]);
}



elseif($text == '/vip'){
    

       
      bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"💥در این بخش میتوانید ربات های
●•حرفو ناشناس بزن 
●•ممبرگیر حرفه ای 
●•ضد لینک پیشرفته
●•بنردهی پیشرفته• اسم فامیل•فالگیر•چت ناشناس 
●•چالش ساز
●•اسم و فامیل
●•فالگیر|اعترافگیر
                    ‌ ‌   ‌ ‌ ‌          را ویژه کنید.
 
▔__▔__▔__▔__▔__▔__▔

➖ این ربات شامل تبلیغ کانال ما یا سازنده هستند که برای شخصی سازی و ثبت چنل خود پس از پرداخت مراحل ثبت را انجام میدهید!

▔__▔__▔__▔__▔__▔__▔


♎️ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

▔__▔__▔__▔__▔__▔__▔
                                                                                                                                                         
                     🔰 تعرفه ها 🔰
                              
                             
💠 شخصی سازی کامل در ربات حرفتو ناشناس بزن    ↜ کد : 8548
Price : 3,500 T

💠 شخصی سازی کامل در ربات  چت ناشناس     ↜ کد : 3458
Price : 4,500 T

💠 شخصی سازی کامل در ربات  ضدلینک پیشرفته     ↜ کد : 8345
Price : 9,000 T

💠 شخصی سازی کامل در ربات بنردهی پیشرفته    ↜ کد : 9161
Price : 3,500 T

💠 شخصی سازی کامل در ربات ممبرگیر حرفه ای    ↜ کد : 1386
Price : 3,500 T

💠 شخصی سازی کامل در ربات چالش ساز           ↜ کد : 1397
Price : 3,500 T

💠 شخصی سازی کامل در ربات اسم و فامیل     ↜ کد : 2882
Price : 4,500 T

💠 شخصی سازی کامل در ربات فالگیر|اعترافگیر     ↜ کد : 4296
Price : 3,500 T

", 
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[



                 [['text'=>"🙋‍♂ من کاربر VIP هستم 🙋‍♂"]],

               [['text'=>"↩️ برگشت"]],

	]
	])
	]);
}


 elseif($text == '🎖 استفاده از کد 🎖'){
	bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"❇️ انتخاب کنید
",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
[['text'=>'📄 کد امتیاز'],['text'=>'کد ویژه 📄']],
[['text'=>'↩️منوی اصلی']],

	]
	])
	]);
}
elseif($text=="🔹 ایجاد متن با فرمت های مارک دان 🔹"){
			save('administrative/user/'.$from_id."/command.txt","mark");
				bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"❇️ متن خود را بفرستید دقت کنید برای هرمتن باید گزینه ♊️ متن دیگر ♊️ را بزنید 

♦️فرمول های مارک دون :

➖درشت کردن : 
*TEXT*

➖کج کردن :
_TEXT_ 

➖کد کردن : 
TEXT 

➖هایپر لینک : 
[TEXT](LINK)

➖هایپر لینک پیشرفته :
[text](tg://user?id=ID)
ID : ایدی عددی ربات یا شخص یا کانال

    ",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[
	['text'=>"✝ ارسال هایپر پیشرفته به کانال ✝"]
	],
	[
	['text'=>"♊️ متن دیگر ♊️"]
	],
	[
	['text'=>"↩️منوی اصلی"]
	],
	]
	])
	]);
}
elseif($text=="♊️ متن دیگر ♊️"){
			save('administrative/user/'.$from_id."/command.txt","mark");
				bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"❇️ متن خود را بفرستید دقت کنید برای هرمتن باید گزینه ♊️ متن دیگر ♊️ را بزنید 

♦️فرمول های مارک دون :

➖درشت کردن : 
*TEXT*

➖کج کردن :
_TEXT_ 

➖کد کردن : 
TEXT 

➖هایپر لینک : 
[TEXT](LINK)

➖هایپر لینک پیشرفته :
[text](tg://user?id=ID)
ID : ایدی عددی ربات یا شخص یا کانال
    ",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[
	['text'=>"✝ ارسال هایپر پیشرفته به کانال ✝"]
	],
	[
	['text'=>"♊️ متن دیگر ♊️"]
	],
	[
	['text'=>"↩️منوی اصلی"]
	],
	]
	])
	]);
}


elseif($command=="mark"){
			save('administrative/user/'.$from_id."/command.txt","none");
			bot('SendMessage',[
			'chat_id'=>$chat_id,
			'text'=>"$text",
      'parse_mode'=>'MarkDown',
	
	]);
	}

elseif($text=="/marko"  &&  $from_id == $admin){
			save('administrative/user/'.$from_id."/command.txt","marko");
				bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"❇️ متن خود را بفرستید  هایپر لینک پیشرفته چنل 


    ",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[
	['text'=>"♊️ متن دیگر ♊️"]
	],
	[
	['text'=>"↩️منوی اصلی"]
	],
	]
	])
	]);
}
elseif($command=="marko"  &&  $from_id == $admin){
			save('administrative/user/'.$from_id."/command.txt","none");
			bot('SendMessage',[
			'chat_id'=>$kanal,
			'text'=>"[$text](tg://user?id=534942826)",
      'parse_mode'=>'MarkDown',
	
	]);
	}
 
elseif($text=="✝ ارسال هایپر پیشرفته به کانال ✝"  &&  $from_id == $admin){
			save('administrative/user/'.$from_id."/command.txt","markio");
				bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"❇️ ایدی کانال را همراه با @ وارد کنید

    ",
    'parse_mode'=>'html',
				'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	
	[
	['text'=>"↩️منوی اصلی"]
	],
	]
	])
	]);
}

elseif($command=="markio" ){
			save('administrative/user/'.$from_id."/command.txt","markioo");
			save('administrative/user/'.$from_id."/marki.txt",$text);
				bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"❇️ متن خود را بفرستید  هایپر لینک پیشرفته چنل 
بعد از ارسال متن مستقیما به چنل شما ارسال خواهد شد

    ",
   ]);
   }
elseif($command=="markioo" ){
	$ch = file_get_contents('administrative/user/'.$from_id."/marki.txt");
			save('administrative/user/'.$from_id."/command.txt","none");
			bot('SendMessage',[
			'chat_id'=>$ch,
			'text'=>"[$text](tg://user?id=534942826)",
		
      'parse_mode'=>'MarkDown',
	
	]);
	}

elseif ($text == "/start" && $from_id!= $feed) {

        if(file_exists('administrative/user/'.$chat_id."/gold.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/membrs.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/membrs.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/por.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/gold.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/membrs.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/membrs", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/por.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
        if (!in_array($from_id,$datas['all_users'])) { 
            $datas['all_users'][] = $from_id;
            file_put_contents("administrative/access/datas.json",json_encode($datas));
        }
        SendChatAction($chat_id, 'typing');
        bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => " 💎 خوش آمدید
🔻لطفا یکی از گزینه های زیر انتخاب‌کنید:",
      'reply_markup' => $button_official_fa
            ]);
    }
    elseif($text=="✨ساعت طلایی️️" && $tc == "40"){
    $time = explode(PHP_EOL,file_get_contents("data/time.txt"));

$time_off = jdate("H:i:s, Y F d",$time[1]);
$time_on = jdate("H:i:s, Y F d",$time[0]);

  bot('SendMessage',[
'chat_id'=>"$chat_id",
'text'=>"➖➖➖➖➖➖<code>
✅ به بخش ساعت طلایی خوش آمدید
➖➖➖
  ↜توضیحات:
        
⌬ساعت طلایی چیست؟
✝ زمانی محدود است که اگر در آن بازه شما از طریق لینک اختصاصیتان افرادی را وارد  رباتساز کنید به جای 1 امتیاز 2 امتیاز دریافت میکنید!</code>
➖➖➖
",
 'parse_mode'=>"html",

'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>": وضعیت بخش 🛅",'callback_data'=>"none"],['text'=>"| ✅ فعال ✅ |",'callback_data'=>"none"]],
[['text'=>"☟تاریخ و ساعت فعال شدن ☟",'callback_data'=>"none"]],
[['text'=>"⌚️ $time_on ⌚",'callback_data'=>"none"]],
[['text'=>"☟تاریخ و ساعت غیر فعال شدن ☟",'callback_data'=>"none"]],
[['text'=>"⌚️ $time_off ⌚",'callback_data'=>"none"]],
]
])
]);
}
elseif($text=="✨ساعت طلایی️️" && $tc == "50"){
    $time = explode(PHP_EOL,file_get_contents("data/time.txt"));

$time_off = jdate("H:i:s, Y F d",$time[1]);
$time_on = jdate("H:i:s, Y F d",$time[0]);

  bot('SendMessage',[
'chat_id'=>"$chat_id",
'text'=>"➖➖➖➖➖➖<code>
✅ به بخش ساعت طلایی خوش آمدید
➖➖➖
  ↜توضیحات:
        
⌬ساعت طلایی چیست؟
✝ زمانی محدود است که اگر در آن بازه شما از طریق لینک اختصاصیتان افرادی را وارد  رباتساز کنید به جای 1 امتیاز 2 امتیاز دریافت میکنید!</code>
➖➖➖
",
 'parse_mode'=>"html",

'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>": وضعیت بخش 🛅",'callback_data'=>"none"],['text'=>"| ❌غیر فعال ❌ |",'callback_data'=>"none"]],
[['text'=>"☟تاریخ و ساعت فعال شدن ☟",'callback_data'=>"none"]],
[['text'=>"⌚️ $time_on ⌚",'callback_data'=>"none"]],
[['text'=>"☟تاریخ و ساعت غیر فعال شدن ☟",'callback_data'=>"none"]],
[['text'=>"⌚️ $time_off ⌚",'callback_data'=>"none"]],
]
])
]);
}
elseif($text=="✨ساعت طلایی️️" && $tp == "off"){

  $time_on = jdate("H:i:s, Y F d",$time[0]);

  bot('SendMessage',[
'chat_id'=>"$chat_id",
'text'=>"➖➖➖➖➖➖
❌ ساعت طلایی غیر فعال است
—---------—
👥با دعوت هر 1 نفر میتونید ⭐️{1}امتیاز دریافت کنید
—---------—
",

]);
}
  elseif($text == "/start" && $from_id== $feed)
  {
      if(file_exists('administrative/user/'.$chat_id."/por.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/gold.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/membrs.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/membrs.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/gold.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/membrs.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/membrs", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/por.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
    SendChatAction($chat_id, 'typing');
        bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "💎 خوش آمدید
🔻لطفا یکی از گزینه های زیر انتخاب‌کنید:",
      'reply_markup' => $button_official_admin
            ]);
  }

    elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
     
        $newid = str_replace("/start ", "", $text);
        if ($from_id == $newid) {
      
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "💎 خوش آمدید",
                      'reply_markup' => $button_official_fa
            ]);
        } elseif (in_array($from_id,$datas['all_users'])) {
            bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💎 خوش آمدید", 
  
 'parse_mode'=>"MarkDown",
        'reply_markup' => $button_official_fa
 ]);  
        } else {

            SendChatAction($chat_id, 'typing');
            @$sho = file_get_contents('administrative/user/'.$newid."/gold.txt");
            $getsho = $sho + $invite_coin;
            file_put_contents('administrative/user/'.$newid."/gold.txt", $getsho);
            @$sea = file_get_contents('administrative/user/'.$newid."/membrs.txt");
            $getsea = $sea + 1;
            file_put_contents('administrative/user/'.$newid."/membrs.txt", $getsea);
            file_put_contents("administrative/user/$from_id/inviter.txt",$newid);
            file_put_contents("administrative/user/$chat_id/gold.txt", "0");
                file_put_contents("administrative/user/$chat_id/por.txt", "0");
            file_put_contents("administrative/user/$chat_id/membrs.txt", "0");

            if (!in_array($from_id,$datas['all_users'])) {
                $datas['all_users'][] = $from_id;
                file_put_contents("administrative/access/datas.json",json_encode($datas));
            }
            SendMessage($chat_id, "تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️");
      bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => " 💥به ربات ساز هوشمند 》[PHP ] 》 خوش امدید.
⚒ساخت انواع ربات های:
💬ربات پیام رسان
👁‍🗨ربات ویو گیر
⛏ربات فروشگاه ساز🛍
📝ربات تغییر نام فایلها📌
➕ربات ادداجباری➕
💬ربات چت ناشناس🗣
🛡ربات های انلاینی{cli}🛡
》°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•《
💰به صورت رایگان و به اسانی اب‌ خوردن ربات های خودتون بسازید💎
📱سرعت بالا ps23

》°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°《
🆔 @$mych
🤖 @[*[BOT]*]
🗣 @$mysup
تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️

🔻لطفا یکی از گزینه های زیر انتخاب‌کنید:",
      'reply_markup' => $button_official_fa
            ]);
            SendMessage($newid, "تبریک یکی با لینک عضویت شما عضو ربات شد😊

و شما $invite_coin سکه گرفتید.😱");
        }
    }
	//===============
elseif($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
	SendMessage($chat_id,"به سیستم ساخت ربات ما خوش اومدید ♦️💜

برای ادامه کار عضو کانال خبر رسانی ربات بشید تا قفل بات باز بشه 🎗
➖➖➖➖➖➖➖➖➖➖➖
https://t.me/$mych
➖➖➖➖➖➖➖➖➖➖➖","html","true",$button_remove);
	}
/*	elseif($text == "مقدار حذف همگانی" and $chat_id == $admin){
  file_put_contents("administrative/user/$chat_id/command.txt", "hazf");
  sendmessage($chat_id,"مقدار امتیاز را بفرستید");
}
elseif($command == "hazf"){
  file_put_contents("data/a.txt",$text);
  sendmessage($chat_id,"تعیین شد");
}*/
///////////////////////////
	/*elseif ($text == "/omg2") {
	$glob = glob("administrative/user/*");
$count = 0;
foreach ($glob as $value){
    $get = file_get_contents("$value/gold.txt");
    if ($get == 125){
        $count += 1;
    }
}
 bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "تعداد : $count",
         'parse_mode'=>'markdown',
]);
}
		if ($text == "/omg") {

  $glob = glob("administrative/user/*");
foreach ($glob as $value){
     $get = file_get_contents("$value/gold.txt");
    if ($get == 125){
        file_put_contents("$value/gold.txt",0);
         bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "انجام شد",
         'parse_mode'=>'markdown',
]);
    }
}}*/
/*	elseif ($text == "⚜ برترین امتیاز گیر ⚜") {
	         bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "<code>♻️ درحال پردازش...
         
         لطفا صبر کنید</code>",
         'parse_mode'=>'html',
]);
     $kandom1 = ttoopp(0);
     $kandom2 = ttoopp(1);
     $kandom3 = ttoopp(2);
     //////////////////////
    
     //////////////////////
     $kandom11 = file_get_contents("administrative/user/$kandom1/gold.txt");
     $kandom22 = file_get_contents("administrative/user/$kandom2/gold.txt");
     $kandom33 = file_get_contents("administrative/user/$kandom3/gold.txt");
     bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "نفرات برتر در جمع آوری امتیاز 💰:
 
🏅نفر اول: [$kandom1](tg://user?id=$kandom1) 
🚀 تعداد امتیاز : $kandom11
 

🏅نفر دوم: [$kandom2](tg://user?id=$kandom2)
🚀 تعداد امتیاز : $kandom22


🏅نفر سوم: [$kandom3](tg://user?id=$kandom3)
🚀 تعداد امتیاز : $kandom33
 

ایدی عددی شما : $chat_id 👨‍💻",
         'parse_mode'=>'MarkDown',
     ]);
 }*/
 elseif($text == '🎉 کاربران برتر 🎉'){
sendMessage($chat_id,"👤 این قسمت به دلیل فشار آوردن به سرور بسته شد  ","html","true");
}

 /*elseif($text == '⚜ برترین زیر مجموعه گیر ⚜'){
    bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "<code>♻️ درحال پردازش...
         
         لطفا صبر کنید</code>",
         'parse_mode'=>'html',
]);
     
     $member1 = top_sea(0);
     $member2 = top_sea(1);
     $member3 = top_sea(2);
     //////////////////////
     $mosak1 = file_get_contents("administrative/user/$member1/membrs.txt");
     $mosak2 = file_get_contents("administrative/user/$member2/membrs.txt");
     $mosak3 = file_get_contents("administrative/user/$member3/membrs.txt");
     
     bot('SendMessage',[
         'chat_id'=>$chat_id,
         'text' => "🏆نفرات برتر  در جمع آوری زیرمجموعه :
 
🏅نفر اول: [$member1](tg://user?id=$member1) 
🏛تعداد دعوت :  $mosak1
 

🏅نفر دوم: [$member2](tg://user?id=$member2)
🏛تعداد دعوت :  $mosak2


🏅نفر سوم: [$member3](tg://user?id=$member3)
🏛تعداد دعوت :  $mosak3

ایدی عددی شما : $chat_id 👨‍💻",
         'parse_mode'=>'MarkDown',
     ]);
 }*/
 
	//===============
	 elseif (strpos($text, 'عضوشدم') !== false ) {
        if(file_exists('administrative/user/'.$chat_id."/por.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/gold.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/membrs.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/membrs.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/gold.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/membrs.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/membrs", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/por.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
        $newid = str_replace("/start ", "", $text);
        if ($from_id == $newid) {
      
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "💎 خوش آمدید",
                      'reply_markup' => $button_official_fa
            ]);
        } elseif (in_array($from_id,$datas['all_users'])) {
            bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💎 خوش آمدید", 
  
 'parse_mode'=>"MarkDown",
        'reply_markup' => $button_official_fa
 ]);  
        } else {
        	       if(file_exists('administrative/user/'.$chat_id."/por.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/gold.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_exists('administrative/user/'.$chat_id."/membrs.txt")==false){
      file_put_contents('administrative/user/'.$chat_id."/membrs.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/gold.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/gold.txt", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/membrs.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/membrs", "0");
    }
    if(file_get_contents('administrative/user/'.$chat_id."/por.txt") == null){
      file_put_contents('administrative/user/'.$chat_id."/por.txt", "0");
    } 
            SendChatAction($chat_id, 'typing');
            @$sho = file_get_contents('administrative/user/'.$newid."/gold.txt");
            $getsho = $sho + $invite_coin;
            file_put_contents('administrative/user/'.$newid."/gold.txt", $getsho);
            @$sea = file_get_contents('administrative/user/'.$newid."/membrs.txt");
            $getsea = $sea + 1;
            file_put_contents('administrative/user/'.$newid."/membrs.txt", $getsea);
            file_put_contents("administrative/user/$from_id/inviter.txt",$newid);
            if (!in_array($from_id,$datas['all_users'])) {
                $datas['all_users'][] = $from_id;
                file_put_contents("administrative/access/datas.json",json_encode($datas));
            }
            SendMessage($chat_id, "تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️");
      bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => " 💎 خوش آمدید
تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️

🔻لطفا یکی از گزینه های زیر انتخاب‌کنید:",
      'reply_markup' => $button_official_fa
            ]);
            SendMessage($newid, "تبریک یکی با لینک عضویت شما عضو ربات شد😊

و شما $invite_coin سکه گرفتید.😱");
        }
    }
	elseif($text == '↩️منوی اصلی'){
  save('administrative/user/'.$from_id."/command.txt","none");
  if($from_id == $admin){
  SendMessage($chat_id,"<pre>🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.</pre>","html","true",$button_official_admin);
  }else{
  SendMessage($chat_id,"<pre>🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.
</pre>","html","true",$button_official_fa);
  }
  }
  
  elseif($text == '/restart'){
  save('administrative/user/'.$from_id."/command.txt","none");
  mkdir('administrative/user/'.$from_id);
    if (!in_array($chat_id,$datas['all_users'])){
      $datas['all_users'][] = $from_id;
      file_put_contents("administrative/access/datas.json",json_encode($datas));
    }
  SendMessage($chat_id,"<pre>🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.
</pre>","html","true",$button_official_fa);
  }
  
  //===============
	elseif($text == '/panel'){


  SendMessage($chat_id,"<pre> ⚠️ دستور /panel را باید در رباتی که ساخته اید ارسال کنید‌
 ش</pre>","html","true",$button_official_admin);
  }
  
	
		elseif($text == '↩️برگشت به منوی ادمین'){
  save('administrative/user/'.$from_id."/command.txt","none");
  if($from_id == $admin){
  SendMessage($chat_id,"به منوی ادمین خوش امدید ","html","true",$button_manage);
  }else{
  SendMessage($chat_id,"کاربر عزیز شما ادمین نیستید","html","true",$button_official_fa);
  }
  }
  //===============
    elseif($text == 'کد ویژه 📄'){
  SendMessage($chat_id,"💎📱کدی که در کاناله{ @$mych } برای ویژه شدن ربات ارسال شده رو بفرستید:","html","true",$button_back);
   save('administrative/user/'.$from_id."/command.txt","code pv 123");
  }
  //===============

  //===============
 elseif ($text == '📇 مشخصات ربات')
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"

✨اطلات سرور:
⬛️ram: 4hf
⬛️cpi: 5Hf
⬛️hard: 1000k.b

💥اطلاعات سورس ربات:

⬛️زبان: php
⬛️نویسنده: DEVADVANCED

🏅  Information : 
⛓تاریخ ساخت{ربات}: 1396/10/01
⛓تاریخ فعلی: $fadate

⚙اطلاعات ورژن ربات:",
'reply_to_message_id' => $message_id,
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>":ورژن ربات✨",'callback_data'=>"Slm"],['text'=>"°•{V5.0}•°",'callback_data'=>"Slm"]]
,
[
['text'=>":اسم ربات📍",'callback_data'=>"Slm"],
['text'=>"...{ساخت ربات پیشرفته}.....",'callback_data'=>"Slm"],
],
[
['text'=>":ایدی ربات📎",'callback_data'=>"Slm"],
['text'=>"@#[*[BOT]*]",'url'=>"https://t.me/[*[BOT]*]"],
],
[
['text'=>":قدرت‌ ربات📎",'callback_data'=>"fal"],
['text'=>"{98.S}",'callback_data'=>"Slm"]],

[['text'=>":سرعت ربات⏱",'callback_data'=>"Slm"],
['text'=>"{85.S}",'callback_data'=>"mmm"]
],
[
['text'=>"📮کانال اخبار و اطلاعات ربات📮",'url'=>"http://t.me/$mych"]
],
]
])
]);
  ////////////////
 /* elseif ($data == "mh") {
bot('SendMessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📲اطلاعات حساب کاربری شما:️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
[
['text'=>": < وضیعت شما⚙️",'callback_data'=>"fal"],
['text'=>"|✅فعال✅|",'callback_data'=>"Slm"]],

[
['text'=>"⌚️》ساعت > {$fatime}",'callback_data'=>"Slm"]],

[['text'=>"📆》تاریخ > {$fadate}",'callback_data'=>"Slm"]
],
[
['text'=>"🔍》بروز رسانی《🔍",'callback_data'=>"mmm"]
],
]
            ])
        ]);
}*/
  ///////////
  
   elseif($command == 'code pv 123'){
  if(file_exists("administrative/code/$text.txt")){
  @$code = file_get_contents("administrative/code/$text.txt");
  if($code == 'true'){
  SendMessage($chat_id,"🕎 کد ارسالی استفاده شده است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true");
  }else{
  save('administrative/user/'.$from_id."/command.txt","code free");
  save('administrative/user/'.$from_id."/wait.txt",$text);
  SendMessage($chat_id,"الا آیدی رباتتان را بدون @ بفرست.
لطفا به حروف کوچک و بزرگ آیدی دقت کنید🤗","html","true",$button_back);
  }
  }else{
  SendMessage($chat_id,"🕎 کد ارسالی نامعتبر است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true");
  }
  }
  
	//===============
	elseif($command == 'code free'){
	@$code = file_get_contents("administrative/code/$wait.txt");
	if($code == 'true'){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($chat_id,"🕎 کد ارسالی استفاده شده است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true",$button_official_fa);
	}else{
	$text = str_replace("@",'',$text);
	if(file_exists("Bot/$text")){
	@$vip = file_get_contents("Bot/$text/data/bottype.txt");
	if($vip == 'gold'){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($chat_id,"رباتی که آیدیشو فرستادی قبلا هم ویژه بوده.","html","true",$button_official_fa);
	}else{
	save("administrative/code/$wait.txt","true");
	save('administrative/user/'.$from_id."/command.txt","none");
	save('administrative/user/'.$from_id."/codefree.txt","true");
	save("Bot/$text/data/bottype.txt","gold");
	SendMessage($chat_id,"😍تبریک میگم رباتت ویژه شد.","html","true",$button_official_fa);
	SendMessage($admin,"کاربری از کد رایگان استفاده کرد مشخصاتش👇
	$first $from_id $wait","html","true");
	SendMessage($kanal,"***************
😎اطلاعات استفاده کننده از کد👇
👤نام : $first
🆔 آیدی عددی : $from_id
🎁کد استفاده شده : $wait
🤖آیدی ربات : @$text
⏰زمان استفاده از کد : $fatime
📆تاریخ استفاده از کد : $fadate
***************
🆑 @$mych
🤖 @[*[BOT]*]","html","true");
	}
	}else{
	save('administrative/user/'.$from_id."/command.txt","code free");
	SendMessage($chat_id,"⭕️ ربات وجود ندارد.
	✳️ به حروف کوچیک و بزرگ آیدی دقت کنید.","html","true",$button_back);
	}
	}
	}
	//===============
	elseif($command == 'code free'){
	@$code = file_get_contents("administrative/code/$wait.txt");
	if($code == 'true'){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($chat_id,"🕎 کد ارسالی استفاده شده است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true",$button_official_fa);
	}else{
	$text = str_replace("@",'',$text);
	if(file_exists("Bot/$text")){
	@$vip = file_get_contents("Bot/$text/data/bottype.txt");
	if($vip == 'gold'){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($chat_id,"رباتی که آیدیشو فرستادی قبلا هم ویژه بوده.","html","true",$button_official_fa);
	}else{
	save("administrative/code/$wait.txt","true");
	save('administrative/user/'.$from_id."/command.txt","none");
	save('administrative/user/'.$from_id."/codefree.txt","true");
	save("Bot/$text/data/bottype.txt","gold");
	SendMessage($chat_id,"😍تبریک میگم رباتت ویژه شد.","html","true",$button_official_fa);
	SendMessage($admin,"کاربری از کد رایگان استفاده کرد مشخصاتش👇
	$first $from_id $wait","html","true");
	SendMessage($kanal,"***************
😎اطلاعات استفاده کننده از کد👇

👤نام : $first
🆔 آیدی عددی : $from_id
🎁کد استفاده شده : $wait
🤖آیدی ربات : @$text
⏰زمان استفاده از کد : $fatime
📆تاریخ استفاده از کد : $fadate
***************
🆑 @$mych
🤖 @[*[BOT]*]","html","true");
	}
	}else{
	save('administrative/user/'.$from_id."/command.txt","code free");
	SendMessage($chat_id,"⭕️ ربات وجود ندارد.
	✳️ به حروف کوچیک و بزرگ آیدی دقت کنید.","html","true",$button_back);
	}
	}
	}
  //===============
  elseif($text == 'حذف ربات 🗑' and $from_id){
  save('administrative/user/'.$from_id."/command.txt","hesabb");
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>" لطفا ایدی ربات خود را بدون @ ارسال کنید✔️
⚠️ توجه کنید ایدی خود را دقیق وارد کنید حساس به کوچک و بزرگ بودن حروف.",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [['text'=>"↩️منوی اصلی"]]
              ],
              "resize_keyboard"=>true,
              "one_time_keyboard" => true
        ])
 ]);
}
elseif($command == 'hesabb'){
    if (file_exists("Bot/$text")) {

@$adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
unlink("Bot/".$text."/index.php");
  unlink("Bot/".$text."/Class.php");
   rrmdir("Bot/$text");
  unlink("administrative/user/".$from_id."/create.txt");
  SendMessage($chat_id,"ربات شما با موفقیت حذف شد👍","html","true",$button_back);
    }
    else
      SendMessage($chat_id,"⭕️ شما ادمین این ربات نمی باشید!","html","true",$button_back);
    }else{
         SendMessage($chat_id,"⭕️   ایدی ربات وارد شده وجود ندارد","html","true",$button_back);
    }
  }
  
  //===============
elseif ($text == '🎥 فیلم اموزش ساخت ربات🎞')
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"⬇️📱اموزش ‌ویدو ساخت ربات📱⬇️

✨لطفا خوب فیلم تماشا کنید و دقیق مثل فیلم عمل کنید.

✨ایدی پشتیبانی ربات:
@$mysup",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"⬛️ فیلم اموزش ساخت ربات⬛️",'url'=>"https://t.me/$mych/430"]
],
]

])
]);
//===============
/*elseif ($text == 'اطلاعت ربات📲')
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"📱⬇️اطلاعت کاربردی‌ ربات ساز⬇️

<i>✨اطلات سرور{هاست}:
⬛️ram: 4hf
⬛️cpi: 5Hf
⬛️hard: 1000k.b
<pre>💥اطلاعات سورس ربات:
⬛️نام: رباتساز
⬛️زبان: php
🏅اطلاعات ساخت:
⛓تاریخ ساخت{ربات}: 2018/01/1
⛓تاریخ فعلی: $fadate
⛓اتصال به:  $mych
⚙️اطلاعت ورژن ربات:",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>":ورژن ربات✨",'callback_data'=>"Slm"],['text'=>"°•{V3.1}•°",'callback_data'=>"Slm"]]
,
[
['text'=>":اسم ربات📍",'callback_data'=>"Slm"],
['text'=>"{ساخت ربات پیشرفته}",'callback_data'=>"Slm"],
],
[
['text'=>":ایدی ربات📎",'callback_data'=>"Slm"],
['text'=>"@#[*[BOT]*]",'url'=>"https://t.me/[*[BOT]*]"],
],
[
['text'=>":قدرت‌ ربات📎",'callback_data'=>"fal"],
['text'=>"{98.S}",'callback_data'=>"Slm"]],

[['text'=>":سرعت ربات⏱",'callback_data'=>"Slm"],
['text'=>"{85.S}",'callback_data'=>"mmm"]
],
[
['text'=>"📮کانال اخبار و اطلاعت ربات📮",'url'=>"http://t.me/$mych"]
],
[
['text'=>"🔄وضیعت حساب شما🔄",'callback_data'=>"mh"],
],
]
])
]);*/
//////////////////////////
elseif ($text == '🔷 مشخصات کاربری'  && $tc == "40"){
    @$time = explode(PHP_EOL,file_get_contents("data/time.txt"));

$time_off = jdate("H:i:s",$time[1]);
$time_on = jdate("H:i:s",$time[0]);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"[🚦اطلاعات حساب کاربری شما:](tg://user?id=$from_id)",
'reply_to_message_id' => $message_id,
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>" : نام شما 👤 ",'callback_data'=>"Slm"],['text'=>"$first",'callback_data'=>"31"]
],
[
['text'=>"  : آیدی شما  🆔",'callback_data'=>"Sl3m"],['text'=>"@$username",'callback_data'=>"231"]
],
 



[
['text'=>"  : نوع پنل شما  🚦",'callback_data'=>"2Slm"],['text'=>"...........🥉برنزی🥉..................",'callback_data'=>"2431"]
],

[
['text'=>":  شناسه شما 📱",'callback_data'=>"2Slfm"],['text'=>"$from_id",'callback_data'=>"2d431"]
],

[
['text'=>": امتیاز شما🌟 ",'callback_data'=>"f2g"],['text'=>"$karbarash",'callback_data'=>"23d431"]
],

[
['text'=>" : زیرمجموعه شما 🚸 ",'callback_data'=>"f22g"],['text'=>"$zir",'callback_data'=>"23rd431"]
],
[
['text'=>" : پلاز شما ⚜  ",'callback_data'=>"f22dg"],['text'=>"$por",'callback_data'=>"23rd3431"]
],
[['text'=>"☟وضعیت ساعت طلایی ☟",'callback_data'=>"none"]],
 [['text'=>": وضعیت بخش 🛅",'callback_data'=>"none"],['text'=>"| ✅ فعال ✅ |",'callback_data'=>"none"]],
[['text'=>"  : ساعت فعال شدن ",'callback_data'=>"none"],['text'=>"⌚️ $time_on ⌚",'callback_data'=>"none"]],
[['text'=>" : ساعت غیر فعال شدن ",'callback_data'=>"none"],['text'=>"⌚️ $time_off ⌚",'callback_data'=>"none"]],
[
['text'=>": ساعت ⌚️ ",'callback_data'=>"Sl3m"],['text'=>"$fatime",'callback_data'=>"233d431"]
],

[['text'=>": تاریخ 📆 ",'callback_data'=>"Slfm"],['text'=>"$fadate",'callback_data'=>"23d6431"]
],
[['text'=>"🎉کانال ربات🎉",'url'=>"https://t.me/$mych"],['text'=>"🚀پشتیبانی🚀",'url'=>"https://t.me/$mysup"]]]])]);
}

elseif ($text == '🔷 مشخصات کاربری'  && $tc == "50"){
    @$time = explode(PHP_EOL,file_get_contents("data/time.txt"));

$time_off = jdate("H:i:s",$time[1]);
$time_on = jdate("H:i:s",$time[0]);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"[🚦اطلاعات حساب کاربری شما:](tg://user?id=$from_id)",
'reply_to_message_id' => $message_id,
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>" : نام شما 👤 ",'callback_data'=>"Slm"],['text'=>"$first",'callback_data'=>"31"]
],
[
['text'=>"  : آیدی شما  🆔",'callback_data'=>"Sl3m"],['text'=>"@$username",'callback_data'=>"231"]
],
 



[
['text'=>"  : نوع پنل شما  🚦",'callback_data'=>"2Slm"],['text'=>"...........🥉برنزی🥉..................",'callback_data'=>"2431"]
],

[
['text'=>":  شناسه شما 📱",'callback_data'=>"2Slfm"],['text'=>"$from_id",'callback_data'=>"2d431"]
],

[
['text'=>": امتیاز شما🌟 ",'callback_data'=>"f2g"],['text'=>"$karbarash",'callback_data'=>"23d431"]
],

[
['text'=>" : زیرمجموعه شما 🚸 ",'callback_data'=>"f22g"],['text'=>"$zir",'callback_data'=>"23rd431"]
],
[
['text'=>" : پلاز شما ⚜  ",'callback_data'=>"f22dg"],['text'=>"$por",'callback_data'=>"23rd3431"]
],
[['text'=>"☟وضعیت ساعت طلایی ☟",'callback_data'=>"none"]],
 [['text'=>": وضعیت بخش 🛅",'callback_data'=>"none"],['text'=>"| ❌  غیر فعال ❌ |",'callback_data'=>"none"]],
[['text'=>"  : ساعت فعال شدن ",'callback_data'=>"none"],['text'=>"⌚️ $time_on ⌚",'callback_data'=>"none"]],
[['text'=>" : ساعت غیر فعال شدن ",'callback_data'=>"none"],['text'=>"⌚️ $time_off ⌚",'callback_data'=>"none"]],
[
['text'=>": ساعت ⌚️ ",'callback_data'=>"Sl3m"],['text'=>"$fatime",'callback_data'=>"233d431"]
],

[['text'=>": تاریخ 📆 ",'callback_data'=>"Slfm"],['text'=>"$fadate",'callback_data'=>"23d6431"]
],
[['text'=>"🎉کانال ربات🎉",'url'=>"https://t.me/$mych"],['text'=>"🚀پشتیبانی🚀",'url'=>"https://t.me/$mysup"]]]])]);
}
////////////==/
/*elseif ($data == "mmm") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "درحال بروز رسانی...",
            'show_alert' => false
        ]);
bot('editMessageText', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📲اطلاعات حساب کاربری شما:️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
[
['text'=>"👤》نام شما > {$first}",'callback_data'=>"Slm"]
],
[
['text'=>"👤》ایدی شما > {@$username}",'url'=>"http://t.me/$username"]
],
[
['text'=>"📱》شناسه شما > {$from_id}",'callback_data'=>"Slm"]
],
[
['text'=>"📡》ربات شما > {$listtbots}",'url'=>"http://t.me/$listtbots"]
],
[
['text'=>"💫》امتیاز شما > {$karbarash}",'callback_data'=>"fg"],
],
[
['text'=>"⚙️》وضیعت شما > { ✅فعال✅}",'callback_data'=>"fal"]
],
[
['text'=>"⌚️》ساعت > {$fatime}",'callback_data'=>"Slm"]],

[['text'=>"📆》تاریخ > {$fadate}",'callback_data'=>"Slm"]
],
[
['text'=>"🔍》بروز رسانی《🔍",'callback_data'=>"mmm"]
],
]
            ])
        ]);
}*/
////////////
   elseif ($text == '📣کانال اخبار ربات🔊')
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"⬇️اخبار و اطلاعات ثانیه به ثانیه در‌ کانال رسمی ⬇️

✨هر روز ۷ کد ویژه کردن‌رایگان گذاشته میشه
✨اخبار اپدیت ربات‌ ساز
✨برنامه های کاربردی عالی
✅برای عضو شودن کافیه گزینه زیر انتخاب کنید:",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"✔️عضویت در کانال✔️",'url'=>"https://t.me/$mych"]
],
]
])
]);

////////////////

  //=======



elseif($text == '❓چطوری رباتم رو ویژه کنم❓'){
  bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
🔴 بخش اول:
➖برای ویژه کردن برخی ربات ها 30 امتیاز نیاز است
️ با زدن بر روی >> /kharid << لیست قیمت امتیاز هارا مشاهده میکنید .💰
 سپس امتیاز مورد نیاز را خریداری کرده و در قسمت [حساب ویژه]  ربات خود را ویژه کنید
لازم به ذکر است امتیاز ها بعد از پرداخت به صورت خودکار به حساب شما واریز میشود
➖ یا 💎گزینه حساب ویژه رایگان را انتخاب کنید و  30 نفر با لینک یا بنر خصوصیتون به ربات بیارید و ربات خودتون ویژه کنید.
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
🔴 بخش دوم:
برای ویژه کردن ربات های

 ❗️اسم و فامیل-❗️چت ناشناس-❗️فالگیر|اعترافگیر-❗️ممبرگیرحرفه ای-❗️چالش ساز-❗️بنردهی پیشرفته-❗️حرفتو ناشناس بزن

 میتوانید در بخش << /vip >> اقدام به ویژه کردن آنها کنید.
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
🔴 بخش سوم:
برای اضافه کردن قفل کانال هم میتوانید در بخش VIPاقدام کنید.
💎 ربات هایی که از قفل چنل پشتیبانی می کنند درقسمت زیر نام برده شده اند.

 ❗️اسم و فامیل-❗️چت ناشناس-❗️فالگیر|اعترافگیر-❗️ممبرگیرحرفه ای-❗️بنردهی پیشرفته-❗️استیکرساز


 میتوانید در بخش << /vip >> اقدام به ویژه کردن آنها کنید.
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
 
",
'parse_mode'=>'MarkDown',
]);
}
  //===============
  elseif($command == 'gold acc 20'){
	if(file_exists("Bot/$text")){
	save("Bot/$text/other/setting/bot_type.txt","gold");
	save('administrative/user/'.$from_id."/command.txt","none");
	save('administrative/user/'.$from_id."/goldacc.txt","true");
	SendMessage($chat_id,"✅ حساب ربات ویژه شد","html","true",$button_official_fa);
	}else{
  SendMessage($chat_id,"🤖 آیدی بات رو بدون @ وارد کنید.آیدی وارد شده اشتباه است
⭕️ به کوچیک و بزرگی حروف دقت کنید","html","true");
  }
  }
  //===============
  elseif($text == '🤖پشتیبانی'){
  SendMessage($chat_id,"🔸دوست عزیز تمام نظراتتون رو میتونید به ربات زیر بفرستید.
ما 24 ساعته پاسخگوی شما هستیم و برای حل مشکل شما آماده ایم👇
🆔 @$mysup","html","true");
  }
  //===============
  elseif($text == '🔹قوانین'){
  SendMessage($chat_id,"
  💯قوانین ساخت ربات:
🔹  استفاده از این رباتساز به منزله تایید و قبول کردن قوانین میباشد
🔹 همه مطالب باید تابع قوانین جمهوری اسلامی ایران باشد.
🔹 رعایت ادب و احترام به کاربران.
🔹 ساخت هرگونه ربات در ضمیمه +18 خلاف قوانین ربات میباشد و در صورت مشاهده ربات مورد نظر مسدود و همچنین مدیر ربات از تمامی ربات ها بلاک میشود.
🔹 مسئولیت پیام های رد و بدل شده در هر ربات با مدیر آن میباشد و ما هیچگونه مسئولیتی نداریم.
🔹 در صورت مشاهده استفاده از قابلیت های ربات در جهات منفی به شدت برخورد میشود.
🔹 اگر به هر دلیلی درخواست های ربات شما به سرور ما بیش از حد معمول باشد (و حساب ربات ویژه نباشد) چند باری به شما اخطار داده میشود اگر این اخطار ها نادیده گرفته شوند ربات شما مسدود و به هیچ عنوان از محدودیت خارج نمیشود.
🔹 بعد از پرداخت مبلغ جهت ویژه کردن رباتتان وجه به هیچ عنوان باز نمیگردد.
🔹 ما هیچ مسِولیتی درقبال آموزش استفاده از ربات ها نداریم لذا استفاده کنندگان باید در این مورداشناییتی با ربات ها و طریقه استفاده انها داشته باشند!
🔹  لطفا پس از اطمینان از کارکرد صحیح ربات ویژه خریداری کنید! درغیراینصورت امکان ارجاع وجه وجود نخواهد داشت.
🔹 تمامی ربات هایی که ساخته میشوند به سورس کد فلودینگ مجهز هستند لذا ارسال دستورات پشت سرهم(رگباری)باعت میشود ربات ۱۵ دقیقه شما را بلاک کند.
****************
🤖Create Bot : @[*[BOT]*]
📢Channel : @$mych
🗣Support : @$mysup

","html","true");
  }
  //===============
   elseif($text == 'حساب ویژه رایگان 🎉'){
 SendMessage($chat_id,"🏅شما میتونید ربات های خودتون رو به صورت رایگان ویژه بکنید و تمام تبلیغات ربات شما حذف بشه↓
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
🥇<code>برای ویژه کردن رباتتون باید { 30 } امتیاز داشته باشید 
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🥈برای اینکه بیشتر از یک ربات در ربات ساز پیشرفته بسازید باید { 20 } امتیاز داشته باشید
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🏆برای جمع کردن امتیاز گزینه[دریافت بنر] انتخاب کنید و از طریق لینک مخصوص شما امتیاز های خود را افزایش دهید</code>
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
⇓لطفا یکی از گزینه های زیر انتخاب کنید:","html","true",$button_bazaryabi);
  } 
  //===============
  elseif($text == '♻️ویژگی ها'){
   sendMessage($chat_id,"🔸ویژگی ربات های ساخته شده با ربات ساز ما:
1-بدون هیچ گونه تبلیغات🚫
2-سرعت بالا🚀
3-پشتیبانی حرفه ای و 24 ساعته💪
4-بدون قطعی و کندی🤝
5-📮امکان ارسال پیام همگانی
6-📊امکان آمار لحظه ای
🆔 @$mych");  
   }
   
elseif($text == '⭐️حساب ویژه✨'){
    

      sendMessage($chat_id,"
💥امکانات ربات های ویژه:
1⃣.سرعت بالا 
2⃣.پشتیبانی خوب
3⃣.بدون باگ
4⃣.بدون تبلیغات
5⃣.خصوصی سازی
6⃣.تنظیمات پنل خوب
 📌برای ویژه کردن رباتتو 3 راه هست:
  ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
🔴 روش اول:
️ با زدن بر روی >> /kharid << لیست قیمت امتیاز هارا مشاهده میکنید .💰
لازم به ذکر است امتیاز پس از پرداخت به صورت خودکار به حساب شما واریز میشود
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
🔴 2.روش دوم:
✨ هر چند روز کد رایگانی در چنل @$mych قرار میگیرد که میتوانید با استفاده از آن رباتتان را ویژه کنید
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖
🔴 3.روش سوم:
💎گزینه 🤖 حساب ویژه رایگان را انتخاب کنید و  30 نفر با لینک یا بنر خصوصیتون به ربات بیارید و ربات خودتون ویژه کنید.
 ➖➖ ➖➖ ➖➖ ➖➖ ➖➖ ➖➖","markdown","true",$v1ip);
        }


   elseif($text == '💥دریافت بنر💥'){

 bot('SendMessage', [
	'chat_id'=>$chat_id,
'text'=>"ربات های خود را بسازید 📩
سرعت بالا ✈️
تنظیمات حرفه ای ⚙️
کاملا رایگان 🎖
پیام رسان 🗣
ویو گیر 👁‍🗨
ممبرگیر حرفه ای 📛
فروشگاه وغیر...
https://telegram.me/[*[BOT]*]?start=$from_id",
 
sendMessage($chat_id,"
👤کاربر گرامی :  $first 

📝متن پایین بنر شما هست به دوستان خودتون فوروارد کنید

⭐️ هرکس با لینک مخصوص شما که در اخر بنر هست وارد ربات ساز بشه به شما {1}امتیاز اضافه میشه

💰جهت خرید امتیاز به قیمت مناسب و ارزون گزینه [  /kharid  ] انتخاب کنید

✅ موفق_باشید ")
 ]);
 }
 
 elseif ($text == "🌟امتیاز روزانه") {
        date_default_timezone_set('Asia/Tehran');
        $dattee = date('Ymd');
        @$gettime = file_get_contents("administrative/user/$from_id/dates.txt");
        if ($gettime == $dattee) {
            bot('SendMessage', [
                'chat_id'=>$chat_id,
                 'text' => "🔥کاربر گرامی شما امتیاز امروز گرفتید لطفا 24 ساعت دیگر اقدام کنید️",
                ]);
        } else {
            file_put_contents("administrative/user/$from_id/dates.txt", $dattee);
            @$sho = file_get_contents("administrative/user/$from_id/gold.txt");
            $newgold = $sho + 2;
            file_put_contents("administrative/user/$from_id/gold.txt", $newgold);
            @$sho2 = file_get_contents("administrative/user/$from_id/gold.txt");
            bot('SendMessage', [
                'chat_id'=>$chat_id,
                
            'text' => "➖➖➖➖➖➖➖
⭐️تبریک
کاربر گرامی 2 امتیاز به شما داده شد
⏰تاریخ و ساعت زمان دریافت امتیاز: { $fatime,$fadate }
➖➖➖➖➖➖➖",
 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
        [['text'=>"| $sho2 | امتیاز شما   ",'callback_data'=>"tagirch01"]]
           ]  
        ])
            
            ]);
        }
  }
 
  //===============
 elseif($text == '📌تغییر پروفایل ربات🔰'){
  sendMessage($chat_id,"📱تغیر اسم ربات📱
📱🔻برای عوض کردن اسم ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور    /setname  تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》نام جدید رباتتون ارسال کنید.
📱 
°•°•°•°•°•°•°•°•°•°•°•°°•°•°•
📱تغیر عکس ربات📱
📱🔻برای عوض کردن عکس ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور   setuserpic/  تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》عکس جدید رباتتون ارسال کنید.
📱 
°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•
📱تغیر اطلاعات ربات📱
📱🔻برای عوض کردن اطلاعت  ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور  setabouttext/  تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》اطلاعات جدید رباتتون ارسال کنید.
📱 
°•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°
📱تغیر توضیحات ربات📱
📱??برای عوض کردن توضیحات ربات خودتون مراحله زیر را انجام بدید:
1》به ربات @BotFather وارد بشید
2》دستور  setdescription/ تایب کنید یا انتخاب کنید
3》ربات خودتون انتخاب کنید
4》توضیحات جدید رباتتون ارسال کنید.
📱 ","html","true");
}
 elseif ($text == '💎ویژه کردن به{مناسبت}⌚️'){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"💎به بخش 》|ویژه کردن ربات به مناسبت| خوش امدید❤️

⚠️توضیحات:
<code>
بخش ویژه کردن به مناسبت یک بخشی هست که شما ربات هاتون رایگان ویژه میکنید و بدون کسر حتی 1 امتیاز ربات خودتون ویژه میشه

🔆این بخش محدودیتی داره یعنی یک از زمانی مشخص تا زمان مشخص فقط میتونید رباتتون رایگان ویژه کنید
مثلا امروز تو کاناله ربات ساز @ $mych اطلاعه میدن که بخش ویژه کردن به مناسبت عید،محرم،و‌.‌‌... تا ساعت و تاریخ ......

 فعال شود
🔰یعنی شما میتونید ربات خودتون تا تاریخ مشخص شوده به صورت رایگان ویژه کنید
</code>
🎁جهت ویژه کردن رباتتون به صورت رایگان گزینه زیر انتخاب کنید:

 /viphastbot

📥اطلاعات زمان فعال بودن یا غیر فعال بودن بخش حساب ویژه رایگان مناسبت:",
'reply_to_message_id' => $message_id,
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"《 وضیعت بخش⚙️",'callback_data'=>"Slm"],['text'=>"|✖️غیرفعال✖️️|",'callback_data'=>"Slm"]],
[
['text'=>"🔻تاریخ و ساعت تا اتمام بخش🔻",'callback_data'=>"Slm"]],
[
['text'=>"**end**",'callback_data'=>"Slm"]],
[
['text'=>"🔻تاریخ و ساعت فعلی🔻",'callback_data'=>"fal"]],
[
['text'=>"$fatime,$fadate",'callback_data'=>"Slm"]],
]
            ])
        ]);
}



///////////////////
elseif($text == "مناسبت فعال" && $from_id == $admin){
	save("data/buy.txt", "on");
		bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"ویژه کردن مناسبت فعال شد",
		'parse_mode'=>'MarkDown'
		]);
}
elseif($text == "مناسبت غیر فعال" && $from_id == $admin){
	save("data/buy.txt", "off");
		bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"ویژه کردن مناسبت غیرفعال شد",
		'parse_mode'=>'MarkDown'
		]);
}
/////////////
elseif($text == '/viphastbot'){
    if(file_get_contents("data/buy.txt") == "on"){
    
  SendMessage($chat_id,"لطفا نوع ربات خود را جهت ویژه کردن انتخاب نمایید✔️","html","true",$button_vipp);
}
    elseif(file_get_contents("data/buy.txt") == "off"){
    
  SendMessage($chat_id,"ویژه کردن مناسبت غیر فعال است","html","true");
}
}
 elseif($text == '🔃اموزش اپدیت ربات🔃'){
  SendMessage($chat_id,"⬇️اموزش اپدیت ربات ها⬇️


⚠️توجه:
مراحل زیر به ترتیب انجام بدید انگار ربات دارید میسازید

<pre>1》وارد @BotFather بشید

2》گزینه /token انتخاب یا‌تایب کنید و بفرستید

3》ربات  خودتون رو انتخاب کنید

4》توکن دریافتی کپی کنید 

5》وارد ربات سازه @[*[BOT]*] بشید

6》گزینه‌ساخت ربات انتخاب کنید

7》نوع رباتتون انتخاب کنید

8》توکن رباتتون بفرستید

9》 چند ثانیه صبر کنید...

10》ربات شما با موفقیت اپدیت شد.</pre>



🆑 》@$mych","html","true");
  }
///////////////////

 elseif($text == '⚠️راهنما'){
  SendMessage($chat_id,"⬇️لطفا نوع اموزش ساخت ربات انتخاب کنید:","html","true",$bu);
  }

   elseif($text == '👤 مدیریت امتیاز 💰'){
sendMessage($chat_id,"👤برای مدیریت حساب کاربریتون تو ربات ساز یکی از گزینه های زیر انتخاب کنید:","html","true",$modbot);
}
////////////////////
    elseif($text == '💰تبدیل امتیاز به کارت شارژ💳'){

  SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
*This section is currently disabled ...
----------------
*در حال حاضر این بخش غیرفعال هست...
➖➖➖➖➖➖➖➖➖➖➖➖","html","true");
  }
  elseif($text == '🗺تبدیل امتیاز به شماره مجازی'){

  SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
*This section is currently disabled ...
----------------
*در حال حاضر این بخش غیرفعال هست...
➖➖➖➖➖➖➖➖➖➖➖➖","html","true");
  }
  elseif($text == '💶اعلام موجودی'){
              @$zir = file_get_contents("administrative/user/$chat_id/membrs.txt");

  SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
📕 امتیاز_شما ⇠ [ $gold ]
➖➖➖➖➖➖➖➖➖➖➖➖
📕 زیرمجموعه_شما ⇠ [ $zir ]
➖➖➖➖➖➖➖➖➖➖➖➖

","html","true"
);}
  elseif($text == '💰خرید امتیاز🔮'){
  bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖➖➖➖
🅾️ به بخش خرید امتیاز خوش آمدید .  تعرفه ها به صورت زیر میباشد! پس از پرداخت امتیاز به صورت خودکار وآنی به حساب شما واریز میشود.

                                                                                                                  
           ‌‌‌‌            🔰 تعرفه ها 🔰

💠 خرید 70 امتیاز 
Price : 8,500 T

💠 خرید 50 امتیاز 
Price : 6,500 T

💠 خرید 30 امتیاز
Price : 3,500 T

💠 خرید 15 امتیاز
Price : 2,000 T

✝ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

✝ در پرداخت از طریق USSD  پس از ورود به صفحه مورد نظر بر روی Continue کلیک کنید

➖➖➖➖➖➖➖➖➖➖➖➖",
            ]);
        }
  
  elseif($text == '/kharid'){
  bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖➖➖➖
🅾️ به بخش خرید امتیاز خوش آمدید .  تعرفه ها به صورت زیر میباشد! پس از پرداخت امتیاز به صورت خودکار وآنی به حساب شما واریز میشود.

                                                                                                                  
           ‌‌‌‌            🔰 تعرفه ها 🔰

💠 خرید 70 امتیاز 
Price : 8,500 T

💠 خرید 50 امتیاز 
Price : 6,500 T

💠 خرید 30 امتیاز
Price : 3,500 T

💠 خرید 15 امتیاز
Price : 2,000 T

✝ پرداخت فقط از طریق درگاه پرداخت(زرین پال)  انجام میشود!

✝ در پرداخت از طریق USSD  پس از ورود به صفحه مورد نظر بر روی Continue کلیک کنید

➖➖➖➖➖➖➖➖➖➖➖➖",
            ]);
        }
  
  	elseif ($text == '🏧انتقال امتیاز💰') {
  	    	@$vip = file_get_contents('administrative/user/'.$from_id."/vip.txt");
  	         if($vip == null){

  	    if($fs > 5){
        file_put_contents("administrative/user/$from_id/command.txt","for");
    bot('SendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id' => $message_id,
            'text' => "🚀لطفا یک پیام از کاربری که میخواید براش  امتیاز انتقال بدید فوروارد کنید:",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [['text'=>"↩️منوی اصلی"]]
              ],
            
        ])
 ]);
}else {
            SendMessage($chat_id, "⭕️ امتیاز شما جهت انتقال حداقل باید 5 باشد
            ");
        }}else{
            SendMessage($chat_id, "
         ⭕️  شما کاربر VIP هستید نمیتوانید امتیاز انتقال دهید    
            ");
        }}
        
     elseif ($command == "for") {
        if ($from_id == $forward_id) {
           SendMessage($chat_id, "⚠️پیام خودتون برام فوروارد نکنید پیام کاربری که میخواید براش امتیاز انتقال بدید فوروارد کنید:️️");
        } else {
            if (in_array($forward_id,$datas['all_users'])) {
                file_put_contents("administrative/user/$from_id/command.txt","fore");
                 file_put_contents("administrative/user/$from_id/forr.txt",$fornam);
                file_put_contents("administrative/user/$from_id/for.txt", $forward_id);
                bot('SendMessage', [
                    'chat_id' => $chat_id,
                    'reply_to_message_id' => $message_id,
                    'text' => "➖➖➖
💰لطفا تعداد امتیاز های که میخواید به کاربر 
---------------------
📝 #$fornam
👤 $forward_id
------------------
💎انتقال بدید ارسال کنید:", ]);
            } else {
                SendMessage($chat_id, "❌این کاربر در ربات ما عضو نیست نمیتوانید بهشون امتیاز انتقال بدید️");
            }
        }
    } elseif ($command == "fore") {
        if (preg_match('/^([0-9])/', $text)) {
            if ($karbarash > $text) {
                @$fr = file_get_contents("administrative/user/$chat_id/for.txt");
                @$fle = file_get_contents("administrative/user/$fr/gold.txt");
                @$fl = file_get_contents("administrative/user/$chat_id/gold.txt");
                $s = $text;
                $getsh = $fl - $s;
                file_put_contents("administrative/user/$chat_id/gold.txt", $getsh);
                SendMessage($chat_id, "➖➖➖➖➖➖
✅ عملیات_موفق
------------------

📝نام دریافت کننده:$fornmm

👤شناسه دریافت کننده: $fr

⭐️تعداد امتیاز ها ارسال شده: $text
------------------
🌟تعداد امتیاز های باقی مانده شما: $gold
-----------------
⏰تاریخ و ساعت زمان انتقال: [ $fatime,$fadate ]
➖➖➖➖➖➖");
                $getshe = $fle + $s;
                file_put_contents("administrative/user/$fr/gold.txt", $getshe);
                SendMessage($fr, "➖➖➖➖➖➖➖➖➖
⭐️تبریک 
🔮از طرف کاربر 
----------------
📝  $first
??  $chat_id
----------------
💰به شما امتیاز انتقال یافت
➖➖➖➖➖➖➖➖➖
🌟تعداد امتیاز های که ارسال کردن: $text
------------
⏰تاریخ و ساعت زمان دریافت : [ $fatime,$fadate ]
➖➖➖➖➖➖➖➖➖");
            } else {
                SendMessage($chat_id, "❌ عملیات_ناموفق❌
🅾️امتیاز های شما جهت ارسال $text امتیاز به کاربر کافی نیست");
            }
        } else {
            SendMessage($chat_id, "⭕️یک عدد لاتینی جهت انتقال امتیاز ارسال کنید:");
        }
        
    }
  
  
  
  elseif($text == '🎉  اعتماد به درگاه های پرداخت 🎉'){
  SendMessage($chat_id,"🔴 سلام کاربر گرامی

🔹 تیم تلگرام بات با فعالیت گسترده در زمینه رباتسازی، بدون هیچ اختلالی افتخار دارد که بیش از از 2k ربات ساخته شده را بدون اُفت سرعت پشتیبانی کند. 

🔹 ما برای راحتی شما عزیزان در خرید امتیاز و ویژه کردن ربات ها درگاه های پرداخت قرار دادیم که به صورت خودکار عمل میکند و از تلف شدن وقت برای ارسال رسید پرداخت و... جلوگیری میکند تا پس از پرداخت عملیات مورد نطر اتوماتیک انجام شود.

🔹 درگاه های موجود از سایت زرین پال است و شما میتوانید با خیال راحت خرید انجام دهید! ضمن اینکه ما پرداخت از طریق USSD هم برای شما قرار دادیم که دیگه خیالتان کاملا راحت شود. 

🔹 ما باز هم جهت اطمینان شما از واقعی بودن درگاه ها ویدیو ای ضبط کرده برای شما اماده کردیم تا باز هم شما  راه مطمئن سازیم!

🅾 ULR : 
 https://t.me/$mych/50","html","true",$button_back);
  }
  
  
  elseif($text == 'کدامتیاز' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","cod freee");
  SendMessage($chat_id,"☢ کد مورد نظر رو وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'cod freee' and $from_id == $admin){
  save("administrative/code1/$text.txt","false");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"☢ کد ثبت شد.","html","true",$button_manage);
  SendMessage($kanal,"🎁 کدرایگان مخصوص دریافت 20 امتیاز
⚜کد یکبار مصرف
➖➖➖➖➖➖➖➖
code : $text
➖➖➖➖➖➖➖➖
❗️روش استفاده:
1-وارد ربات @[*[BOT]*] شوید.
2- روی گزینه ی کد امتیاز بزنید 
3-کد $text را ارسال کنید.
تبریک شما 20 امتیاز دریافت کردید✔️
*******************
🆑 @$mych
🤖 @[*[BOT]*]","html","true");
  }
  
  
  
  
  
  
  
  
  
  
  elseif($text == '📄 کد امتیاز'){
 SendMessage($chat_id,"💎📱کدی که در کاناله{ @$mych } برای امتیاز  ارسال شده رو بفرستید:","html","true",$button_back);
   save('administrative/user/'.$from_id."/command.txt","code123");
  }
  
  
  
  


   elseif($command == 'code123'){
  if(file_exists("administrative/code1/$text.txt")){
  @$code = file_get_contents("administrative/code1/$text.txt");
  if($code == 'true'){
  SendMessage($chat_id,"🕎 کد ارسالی استفاده شده است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true");
  }else{
        @$imp = file_get_contents("administrative/code1/$text.txt");
          file_put_contents("administrative/code1/$text.txt","true");


  @$mp = file_get_contents('administrative/user/'.$from_id."/gold.txt");
	$mo = 20;
	$mi = $mp + $mo;
          file_put_contents('administrative/user/'.$from_id."/gold.txt","$mi");
  SendMessage($chat_id," تبریک 20 امتیاز به شما اضافه شد🤗","html","true",$button_back);
  SendMessage($kanal,"🎁 کدرایگان مخصوص دریافت 20 امتیاز
⚜کد یکبار مصرف
➖➖➖➖➖➖➖➖
code : $text
➖➖➖➖➖➖➖➖
❗ استفاده شد
*******************
?? @$mych
🤖 @[*[BOT]*]","html","true");
  
  }
  }else{
  SendMessage($chat_id,"🕎 کد ارسالی نامعتبر است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true");
  }
  }
  
	//===============
	elseif($command == 'code freee'){
	@$code = file_get_contents("administrative/code1/$wait.txt");
	if($code == 'true'){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($chat_id,"🕎 کد ارسالی استفاده شده است. برای مشاهده دستورات روی /restart کلیک کنید.","html","true",$button_official_fa);
	}
	else{
	save("administrative/code1/$wait.txt","true");
	save('administrative/user/'.$from_id."/command.txt","none");
	save('administrative/user/'.$from_id."/codefree.txt","true");
	@$mp = file_get_contents('administrative/user/'.$from_id."/gold.txt");
	$mo = 20;
	$mi = $mp + $mo;
          file_put_contents('administrative/user/'.$from_id."/gold.txt","$mi");
SendMessage($chat_id,"تبریک. 20 امتیاز به شما تعلق گرفت","html","true",$button_official_fa);

	SendMessage($kanal,"🎁 کدرایگان مخصوص دریافت 20 امتیاز
⚜کد یکبار مصرف
➖➖➖➖➖➖➖➖
code : $text
➖➖➖➖➖➖➖➖
❗ استفاده شد
*******************
?? @$mych
🤖 @[*[BOT]*]","html","true");
  
  
	}
	}
	
	
	//===============
	
  
  
  
  
  
     elseif($text == '/vizhe'){
  SendMessage($chat_id,"لطفا نوع ربات خود را جهت ویژه کردن انتخاب نمایید✔️","html","true",$button_vipp);
  }
  
   elseif($text == '🔝ویژه کردن ربات🔝'){
  SendMessage($chat_id,"لطفا نوع ربات خود را جهت ویژه کردن انتخاب نمایید✔️","html","true",$button_vipp);
  }
  //
  elseif($text == '🔆موجودی امتیازات'){
                @$zir = file_get_contents("administrative/user/$chat_id/membrs.txt");

  SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
📕 امتیاز_شما ⇠ [ $gold ]
➖➖➖➖➖➖➖➖➖➖➖➖
📕 زیرمجموعه_شما ⇠ [ $zir ]
➖➖➖➖➖➖➖➖➖➖➖➖
","html","true","$button_bazaryabi");
  }
  		elseif($text == '⛏ویژه کردن پیام رسان💬'){
		if($karbarash > 29){
		save("administrative/user/$from_id/command.txt","viplink");
		sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
		}else{
		SendMessage($chat_id,"🔴امتیاز شما کافی نیست.

💠توجه: برای اینکه رباتتون ویژه کنید باید 30 امتیاز داشته باشید

💠توجه: برای اینکه بیشتر‌از یک ربات بسازید باید 5 امتیاز داشته باشید
🔘امتیازات شما: $karbarash
لطفا با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.");
		}}
		elseif($command == 'viplink'){
		$newgold = $karbarash - 30;
		save("administrative/user/$from_id/gold.txt",$newgold);
		save("administrative/user/$from_id/command.txt","none");
		save("Bot/$text/data/bottype.txt","gold");
		sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
		}
		
		elseif($text == '⛏ویژه کردن ویوگیر👁‍🗨'){
		if($karbarash > 29){
  save("administrative/user/$from_id/command.txt","viplin");
  sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
  }else{
  SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
‼️خطا: امتیاز شما کافی نیست
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
⚠️برای اینکه ربات خودتون ویژه کنید باید [ 30 ] امتیاز داشته باشید
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🚦امتیاز_شما > [ $karbarash ]
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🔖با انتخاب گزینه[  /kharid  ]امتیاز خود را افزایش بدید
➖➖➖➖➖➖➖➖➖➖➖");
  }}
  elseif($command == 'viplin'){
  $newgold = $karbarash - 30;
  save("Bot/$text/data/bottype.txt","gold");
  save("administrative/user/$from_id/command.txt","none");
  sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
  }
  elseif($text == '⛏ویژه کردن ویوگیر پیشرفته👁‍🗨'){
  if($karbarash > 29){
		save("administrative/user/$from_id/command.txt","viplink3");
		sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
		}else{
		SendMessage($chat_id,"🔴امتیاز شما کافی نیست.

💠توجه: برای اینکه رباتتون ویژه کنید باید 30 امتیاز داشته باشید

🔘امتیازات شما: $karbarash
لطفا با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.");
		}}
		elseif($command == 'viplink3'){
		$newgold = $karbarash - 30;
		save("administrative/user/$from_id/gold.txt",$newgold);
		save("administrative/user/$from_id/command.txt","none");
		save("Bot/$text/data/bottype.txt","gold");
		sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
		}
		elseif($text == '⛏ویژه کردن فروشگاه ساز🛍'){
    if($karbarash > 29){
    save("administrative/user/$from_id/command.txt","viplink4");
    sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
    }else{
    SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
‼️خطا: امتیاز شما کافی نیست
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
⚠️برای اینکه ربات خودتون ویژه کنید باید [ 30 ] امتیاز داشته باشید
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🚦امتیاز_شما > [ $karbarash ]
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🔖با انتخاب گزینه[  /kharid  ]امتیاز خود را افزایش بدید
➖➖➖➖➖➖➖➖➖➖➖");
    }}
    elseif($command == 'viplink4'){
    $newgold = $karbarash - 30;
    save("administrative/user/$from_id/gold.txt",$newgold);
    save("administrative/user/$from_id/command.txt","none");
    save("Bot/$text/botttype.txt","gold");
    sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
    }
    elseif($text == '✉️ویژه کردن تبچی🎈'){
    if($karbarash > 29){
    save("administrative/user/$from_id/command.txt","viplink4411");
    sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
    }else{
    SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
‼️خطا: امتیاز شما کافی نیست
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
⚠️برای اینکه ربات خودتون ویژه کنید باید [ 30 ] امتیاز داشته باشید
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🚦امتیاز_شما > [ $karbarash ]
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🔖با انتخاب گزینه[  /kharid  ]امتیاز خود را افزایش بدید
➖➖➖➖➖➖➖➖➖➖➖");
    }}
    elseif($command == 'viplink4411'){
    $newgold = $karbarash - 30;
    save("administrative/user/$from_id/gold.txt",$newgold);
    save("administrative/user/$from_id/command.txt","none");
    save("Bot/$text/bot_type_ads.txt","gold");
    sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
    }
    
    
    
    elseif($text == '🔑ویژه کردن ضد لینک📟'){
        $link = file_get_contents("administrative/user/$chat_id/link.txt");
            if($link > 1){
save("administrative/user/$from_id/command.txt","viplink44116");
    sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
  
        
        
    }else{
        $vip = file_get_contents("administrative/user/$chat_id/vip.txt");
            if($vip == "vip"){
save("administrative/user/$from_id/command.txt","viplink44116");
    sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
            }
        
    
            else{
    
    bot('SendMessage',[
'chat_id'=>$chat_id,
'text' =>"➖➖➖➖➖➖➖➖➖
🚦کاربر گرامی  : [$first](tg://user?id=$from_id)
- - - - - - - - - - - - - - - - - - - - - -
 🚀   برای ویژه کردن ربات ضد لینک
 
- - - - - - - - - - - - - - - - - - - - - -
به مبلغ  {3,500}تومان💰
- - - - - - - - - - - - - - - - - - - - - -
🚹میتونید از دو روش جهت پرداخت هزینه استفاده کنید:

🅾در روش پرداخت{درگاه اینترنتی} به صورت خودکار بعد از پرداخت فایل سورس اتوماتیک برای شما فرستاده میشود! امار در کارت به کارت  1-3 روز طول میکشد.
 ",
 'parse_mode'=>"markdown",

	]); 
            }
    }}
    elseif($command == 'viplink44116'){
    $newgold = $karbarash - 30;
    save("administrative/user/$from_id/gold.txt",$newgold);
    save("administrative/user/$from_id/command.txt","none");
    save("Bot/$text/bot_type_ads.txt","gold");
        save("administrative/user/$from_id/link.txt","0");
    sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
    }
    elseif($text == '⛏ویژه کردن بنردهی📥'){
  if($karbarash > 29){
  save("administrative/user/$from_id/command.txt","viplink38");
  sendMessage($chat_id,"⚠️توجه
ایدی ربات خود را بدون @ برای ربات ارسال کنید اگر با @ بفرستید جواب نمیدهد و امتیاز الکی از شما کم میشود.","html","true","$button_back");
  }else{
  SendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
‼️خطا: امتیاز شما کافی نیست
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
⚠️برای اینکه ربات خودتون ویژه کنید باید [ 30 ] امتیاز داشته باشید
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🚦امتیاز_شما > [ $karbarash ]
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🔖با انتخاب گزینه[  /kharid  ]امتیاز خود را افزایش بدید
➖➖➖➖➖➖➖➖➖➖➖");
  }}
  elseif($command == 'viplink38'){
  $newgold = $karbarash - 30;
  save("administrative/user/$from_id/gold.txt",$newgold);
  save("administrative/user/$from_id/command.txt","none");
  save("Bot/$text/bot_type_ads.txt","gold");
  sendMessage($chat_id,"🎊تبریک ربات @$text شما ویژه شد.");
  }

		  elseif($text == 'ساخت ربات |دوم|➕'){
			 	if($create == "" ){  
				SendMessage($chat_id,"
🚦ساخت ربات دوم برای شما فعال بوده است. شما میتوانید ربات بسازید وامتیازی از شما کسر نشد.");

}else{ 
			  if($karbarash > 19){
				  save("administrative/user/".$from_id."/gold.txt",$karbarash-5);
  unlink("administrative/user/".$from_id."/create.txt");
  SendMessage($chat_id,"
🚦ساخت ربات دوم برای شما فعال  و [5] امتیاز از شما کسر شد
🚀میتونید گزینه { 🛠ساخت ربات🛠 } از منوی اصلی انتخاب کنید و ربات برای خودتون بسازید","html","true",$button_bazaryabi);
  }else{
  sendMessage($chat_id,"➖➖➖➖➖➖➖➖➖➖➖➖
‼️امتیاز شما کافی نیست
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
⚠️برای اینکه ربات دوم برای خودتون بسازید باید { 20 } امتیاز داشته باشید
(امتیاز کم نمی شود)
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🚦امتیاز_شما > [ $karbarash ]
﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
🔖با انتخاب گزینه[  /kharid  ]امتیاز خود را افزایش بدید
➖➖➖➖➖➖➖➖➖➖➖➖");}
		  }    }
  elseif($text == '🚩گزارش متخلف🚩'){
  save('administrative/user/'.$from_id."/command.txt","takhlof");
  SendMessage($chat_id,"🔸لطفا آیدی رباتی که با ربات ساز ما ساخته شده و تخلف کرده است را ارسال کنید.","html","true",$button_back);
  }
   
  elseif($text == '💥شماره مجازی'){
  SendMessage($chat_id,"⚜️ ساخت ربات های جدید💥✨
➖➖➖➖➖➖➖➖➖➖➖

☎️ ربات فروش شماره مجازی
    
🏳️‍🌈 شماره از 23 کشور مختلف
💵 ارزان ترین قیمت
☑️ کاملا اتوماتیک
💎 امکان زیرمجموعه گیری و دریافت رایگان شماره مجازی

","html","true",json_encode(['inline_keyboard'=>[[['text'=>"✨??  فروشگاه شماره مجازی📱💥",'url'=>"https://telegram.me/your_number_bot"]],]]));
  }
  
  elseif($command == 'takhlof'){
	if(preg_match('/^(@)(.*)([Bb][Oo][Tt])/s',$text)){
	save('administrative/user/'.$from_id."/command.txt","none");
	SendMessage($feed,"گزارش تخلف ⬇","html","true");
	ForwardMessage($feed,$chat_id,$message_id);
	SendMessage($chat_id,"✅ ثبت شد.
	✅ به زودی به درخواست شما رسیدگی میشود","html","true",$button_official_fa);
  }else{
	save('administrative/user/'.$from_id."/command.txt","takhlof");
	SendMessage($chat_id,"⭕️ خطا !!!
	⭕️ دقت کنین یوزرنیم ربات با @ شروع شده و با کلمه (bot) پایان میابد","html","true",$button_back);
  }
  }
   elseif($text == '✒️ متن اموزش ساخت ربات✒️'){
  SendMessage($chat_id,"مراحل زیر با دقت انجام بدید:
  
1⃣ ابتدا به ربات ( @BotFather ) مراجعه کنید
2⃣ دستور /newbot رو ارسال کنید
3⃣ یک نام برای ربات ارسال کنید
4⃣ پس از ارسال نام،یک یوزرنیم ارسال کنید
❌ توجه کنین حتما باید در آخر یوزرنیم ارسالی کلمه bot با حروف کوچیک یا بزرگ (فرقی نداره) وجود داشته باشه
5⃣ اگر با پیغام زیر برخورد کردید
Sorry, this username is already taken. Please try something different.
یعنی قبلا یکی این یوزرنیم رو ثبت کرده یوزرنیم دیگری وارد کنید. اگر این پیغام رو دریافت نکردید یعنی کار حل است
6⃣ حالا به ربات ساز مراجعه کنید و دکمه (🛠ساخت ربات🛠) رو بزنید و نوع ربات را برای ساخت انتخاب کنید
7⃣ سپس به پیام آخری که از ربات ( @BotFather ) دریافت کردید بروید سپس زیر جمله Use this token to access the HTTP API: توکنی میبینید روی اون بزنید تا کپی شه
8⃣ سپس توکنی که کپی کردید را برای ربات ساز ارسال کنید⬅️
9⃣ ربات شما با موفقیت ساخته شد✔️

🆔 @$mych
","html","true");
  }
  ////////////////////
  elseif($text == '💠 ساخت ربات 💠'){

	SendMessage($chat_id,"
		😎حالا نوع ربات رو برای ساخت انتخاب کن. 		
قبل از ساخت ربات حتما قوانین را مطالعه کنید

🔴 ربات های دارای علامت قرمز : 
در بخش << /vip >> ویژه میشوند.

🔵 ربات های دارای علامت آبی : 
در بخش << /vizhe >> ویژه میشوند.

⚫️ ربات های دارای علامت مشکی : 
قابلیت افزودن قفل کانال را در بخش << /lock >> دارند.

","markdown","true",$button_create);
  
  }
  elseif($text == '💬ساخت ربات پیام رسان🔵'){
     
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create botpv");
  }
  
  elseif($text == '💫 ربات اسم و فامیل 💫🔴⚫️'){
      
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create esm");
  }

elseif($text == '🙊 اعترافگیر | فالگیر 🙊🔴⚫️'){
     
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create fal");
  }
  
  
  elseif($text == "📡ساخت ربات ویوگیر پیشرفته😎🔵"){
     
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create tst");
  }
  elseif($text == '🚀ساخت ربات ضدلینک📡'){
     
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create zedelink");
  }
  elseif($text == '📥ساخت ربات بنردهی📥🔵'){
     
  SendMessage($chat_id,"توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید
پس از ساخت ربات وارد /panel شوید و حتما متن استارت رو تنظیم کنید تا ربات جواب بدهد","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","#[*[BOT]*]");
  }
  elseif($text == '📥ساخت بنردهی پیشرفته📥🔴⚫️'){
   	

  SendMessage($chat_id,"توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید
نمونه  
T.me/$mych/1021

🔴برای اینکه ربات جواب بدهد حتما متن استارت را تنظیم کنید ","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","banner");
  }
 
  elseif($text == '🌇ساخت ربات عکس نوشته ساز😎'){
     
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create aksnevesh");
  }
  elseif($text == '⛏ساخت ربات فروشگاه ساز🛍'){
     
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create botshop");
  }
  
 elseif($text == '🚀 ساخت ربات ضدلینک📡پیشرفته🔴'){


 SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.
","html","true",$button_back);
        save('administrative/user/'.$from_id."/command.txt","zedpish");

  }

   elseif($text == '👁‍🗨ساخت ربات ویو گیر🔵'){
       
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create botview");
  } 
  elseif($text == '🗞ساخت ربات تبچی💸'){
  	
  if($karbarash > 49){
				  save("administrative/user/".$from_id."/gold.txt",$karbarash - 50);
  SendMessage($chat_id,"توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create tbligcho");
  }else{
  SendMessage($chat_id,"🔴امتیاز شما کافی نیست.

نمونه  
T.me/$mych/1022
💠توجه : برای ساختن این ربات به 50 امتیاز نیازمندید
🔘امتیازات شما: $karbarash
لطفا با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.

با پرداخت در بخش << /kharid >>  صاحب این ربات بی نظیر شوید

");
  }}
  elseif($text == '🛎 چت ناشناس | WhatsApp 🗯🔴⚫️'){
    
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create chatnashenas");
  }
elseif($text == '💠ساخت ربات ممبرگیر حرفه ای💠🔴⚫️'){
	
       
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید
","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create mem");
  }
  
  elseif($text == '🎖ساخت ربات حرفاتو ناشناس بزن🎖🔴'){
  	
  
  SendMessage($chat_id,"توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید ","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","ali");
 
  }
  

   elseif($text == '📱ساخت ربات چالش ساز📱🔴'){
   
           
  SendMessage($chat_id,"توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create chalesh");
  }
  elseif($text == '➕ساخت ربات ادداجباری➕'){
  	 
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","create add");
  }
  elseif($text == 'ساخت بات ساز'){
  SendMessage($chat_id,"✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (⚠️راهنما) را مطالعه کنید.","html","true",$button_back);
  save('administrative/user/'.$from_id."/command.txt","ساخت بات ساز");
  } 
  //==============
  elseif($command == '#[*[BOT]*]'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  
  save('administrative/user/'.$from_id."/command.txt","none");

mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/baner/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
   
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
  
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/baner/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
   
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  //////////////////
    elseif($command == 'banner'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
 mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot??
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  $class = file_get_contents("administrative/source/baner2/b.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/b.php",$class); 
  $class9 = file_get_contents("administrative/source/baner2/jdf.php");
   save("Bot/$username_bot/jdf.php",$class9); 
   $class98 = file_get_contents("administrative/source/baner2/channel.txt");
   save("Bot/$username_bot/channel.txt",$class98); 
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/b.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot??
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/baner2/b.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/b.php",$class); 
   $class9 = file_get_contents("administrative/source/baner2/jdf.php");
   save("Bot/$username_bot/jdf.php",$class9); 
    $class98 = file_get_contents("administrative/source/baner2/channel.txt");
   save("Bot/$username_bot/channel.txt",$class98); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/b.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  //////////////////////
   elseif($command == 'create botview'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
	  
	 if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
	  
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  
  mkdir("Bot/$username_bot/admin");
  mkdir("Bot/$username_bot/ads");
  mkdir("Bot/$username_bot/user");
  mkdir("Bot/$username_bot/admin/code");
  mkdir("Bot/$username_bot/ads/ads admin");
  mkdir("Bot/$username_bot/ads/ads msg id");
  mkdir("Bot/$username_bot/ads/ads tally");
  mkdir("Bot/$username_bot/ads/ads tedad");
  mkdir("Bot/$username_bot/ads/ads username");
  mkdir("Bot/$username_bot/ads/ads time");
  mkdir("Bot/$username_bot/ads/ads date");
  mkdir("Bot/$username_bot/data");
  save("Bot/$username_bot/data/start.txt","Hi!✋ 
  Welcome To My Bot");
  save("Bot/$username_bot/data/help.txt","راهنمایی تنظیم نشده است");
  save("Bot/$username_bot/data/channel.txt","تنظیم نشده");
  save("Bot/$username_bot/data/shop.txt","متن فروشگاه ثبت نشده است.");
  save("Bot/$username_bot/data/zir.txt","متن زیر مجموعه گیری ثبت نشده است");
  save("Bot/$username_bot/data/seen.txt","1");
  save("Bot/$username_bot/data/coinlink.txt","5");
  save("Bot/$username_bot/data/bottype.txt","free");
  save('administrative/user/'.$from_id."/command.txt","none");
  $class = file_get_contents("administrative/source/view/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class);
  $index = file_get_contents("administrative/source/view/index.php");
  save("Bot/$username_bot/index.php",$index);	
  
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
	  
	   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
	  
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
  mkdir("Bot/$username_bot/admin");
  mkdir("Bot/$username_bot/ads");
  mkdir("Bot/$username_bot/user");
  mkdir("Bot/$username_bot/admin/code");
  mkdir("Bot/$username_bot/ads/ads admin");
  mkdir("Bot/$username_bot/ads/ads msg id");
  mkdir("Bot/$username_bot/ads/ads tally");
  mkdir("Bot/$username_bot/ads/ads tedad");
  mkdir("Bot/$username_bot/ads/ads username");
  mkdir("Bot/$username_bot/ads/ads time");
  mkdir("Bot/$username_bot/ads/ads date");
  mkdir("Bot/$username_bot/data");
  save("Bot/$username_bot/data/start.txt","Hi!✋ 
  Welcome To My Bot");
  save("Bot/$username_bot/data/help.txt","راهنمایی تنظیم نشده است");
  save("Bot/$username_bot/data/channel.txt","تنظیم نشده");
  save("Bot/$username_bot/data/shop.txt","متن فروشگاه ثبت نشده است.");
  save("Bot/$username_bot/data/zir.txt","متن زیر مجموعه گیری ثبت نشده است");
  save("Bot/$username_bot/data/seen.txt","1");
  save("Bot/$username_bot/data/coinlink.txt","5");
  save("Bot/$username_bot/data/bottype.txt","free");
  
  $class = file_get_contents("administrative/source/view/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class);
  $index = file_get_contents("administrative/source/view/index.php");
  save("Bot/$username_bot/index.php",$index);	
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
     elseif($command == 'create zedelink'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ ?? ($fadate)}";
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  mkdir("Bot/$username_bot/data");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  $class = file_get_contents("administrative/source/zeee/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/zeee/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
$claaas = file_get_contents("administrative/source/zeee/index.php");
save("Bot/$username_bot/index.php",$claaas); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
  elseif($command == 'zedpish'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ ?? ($fadate)}";
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  mkdir("Bot/$username_bot/data");
    mkdir("Bot/$username_bot/flood");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  $class = file_get_contents("administrative/source/zed/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[first_bot]*]",$first_bot,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    save("Bot/$username_bot/users.txt"); 
        save("Bot/$username_bot/supergroups.txt"); 
        save("Bot/$username_bot/step.txt"); 
        save("Bot/$username_bot/groups.txt"); 
                save("Bot/$username_bot/channel.txt","#[*[BOT]*]"); 

    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
      mkdir("Bot/$username_bot");
 mkdir("Bot/$username_bot/data");
    mkdir("Bot/$username_bot/flood");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  $class = file_get_contents("administrative/source/zed/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[first_bot]*]",$first_bot,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    save("Bot/$username_bot/users.txt"); 
        save("Bot/$username_bot/supergroups.txt"); 
        save("Bot/$username_bot/step.txt"); 
        save("Bot/$username_bot/groups.txt"); 
                        save("Bot/$username_bot/channel.txt","#[*[BOT]*]"); 
 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  
  
  
///////////////
    elseif($command == 'stik'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ ?? ($fadate)}";
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  mkdir("Bot/$username_bot/data");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  $class = file_get_contents("administrative/source/stik/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[id]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    $stik = file_get_contents("administrative/source/stik/lock.php");
    $stik = str_replace("[*[id]*]",$username_bot,$stik);
  save("Bot/$from_id.php",$stik); 

    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
 mkdir("Bot/$username_bot/data");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  $class = file_get_contents("administrative/source/stik/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[id]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    $stik = file_get_contents("administrative/source/stik/lock.php");
    $stik = str_replace("[*[id]*]",$username_bot,$class);
  save("Bot/$from_id.php",$stik); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
   elseif($command == 'create zed'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  $class = file_get_contents("administrative/source/zed/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[idbot]*]",$username_bot,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/index.php",$class); 
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
  if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/zed/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[idbot]*]",$username_bot,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/index.php",$class); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
??🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  /////////////////////////////
  elseif($command == 'create add'){
  	 
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  $class = file_get_contents("administrative/source/add/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/index.php",$class); 
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/add/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/index.php",$class); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟????🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  
  /////////////////
  elseif($command == 'create anti'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ ?? ($fadate)}";
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
  save('administrative/user/'.$from_id."/command.txt","none");
  
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
$class = file_get_contents("administrative/source/anti/base.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/base.php",$class); 
  $saeed = file_get_contents("administrative/source/anti/jdf.php");
  save("Bot/$username_bot/jdf.php",$saeed);
  $saeed1 = file_get_contents("administrative/source/anti/index.php");
  save("Bot/$username_bot/index.php",$saeed1); 
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/anti/base.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/base.php",$class); 
  $saeed = file_get_contents("administrative/source/anti/jdf.php");
  save("Bot/$username_bot/jdf.php",$saeed);
  $saeed1 = file_get_contents("administrative/source/anti/index.php");
  save("Bot/$username_bot/index.php",$saeed1);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ///////////////////////
  elseif($command == 'create mem'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/

  save('administrative/user/'.$from_id."/command.txt","none");
     mkdir("Bot/$username_bot/data");
	  mkdir("Bot/$username_bot/data/$chat_id");
	  mkdir("Bot/$username_bot/cod");
	   mkdir("Bot/$username_bot/ads");
	   mkdir("Bot/$username_bot/ads/user");
mkdir("Bot/$username_bot/ads/cont");
mkdir("Bot/$username_bot/ads/date");
mkdir("Bot/$username_bot/ads/seen");
mkdir("Bot/$username_bot/ads/time");
mkdir("Bot/$username_bot/ads/user");
mkdir("Bot/$username_bot/ads/admin");
	   save("Bot/$username_bot/data/shop.txt","متنی تنظیم نشده");
	   save("Bot/$username_bot/data/channel.txt","تنظیم نشده");
	   save("Bot/$username_bot/data/pen.txt");
	   save("Bot/$username_bot/data/frosh.txt");
	   	   save("Bot/$username_bot/data/name.txt","ساخت ربات ویوگیر");
		   	   save("Bot/$username_bot/data/link.txt","botmakerse7en_bot");
  
   $index = file_get_contents("administrative/source/mem/bot.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$from_id,$index);
    $index = str_replace("[*[username]*]",$username,$index);
	$index = str_replace("[*[botid]*]",$username_bot,$index);
  save("Bot/$username_bot/bot.php",$index);	
    	
  $saeed = file_get_contents("administrative/source/mem/jdf.php");
  save("Bot/$username_bot/jdf.php",$saeed);
  $saeed99 = file_get_contents("administrative/source/mem/channel23.txt");
   save("Bot/$username_bot/channel23.txt",$saeed99);
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/bot.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  
  save('administrative/user/'.$from_id."/command.txt","none");
  save('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
     mkdir("Bot/$username_bot/data");
	  mkdir("Bot/$username_bot/data/$chat_id");
	  mkdir("Bot/$username_bot/cod");
	   mkdir("Bot/$username_bot/ads");
	   mkdir("Bot/$username_bot/ads/user");
mkdir("Bot/$username_bot/ads/cont");
mkdir("Bot/$username_bot/ads/date");
mkdir("Bot/$username_bot/ads/seen");
mkdir("Bot/$username_bot/ads/time");
mkdir("Bot/$username_bot/ads/user");
mkdir("Bot/$username_bot/ads/admin");
	   save("Bot/$username_bot/data/shop.txt","متنی تنظیم نشده");
	   save("Bot/$username_bot/data/channel.txt","تنظیم نشده");
	   save("Bot/$username_bot/data/pen.txt");
	   save("Bot/$username_bot/data/frosh.txt");
	   	   save("Bot/$username_bot/data/name.txt","ساخت ربات ویوگیر");
		   	   save("Bot/$username_bot/data/link.txt","botmakerse7en_bot");
	   
  $index = file_get_contents("administrative/source/mem/bot.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$from_id,$index);
    $index = str_replace("[*[username]*]",$username,$index);
	$index = str_replace("[*[botid]*]",$username_bot,$index);
  save("Bot/$username_bot/bot.php",$index);	
   $saeed = file_get_contents("administrative/source/mem/jdf.php");
   save("Bot/$username_bot/jdf.php",$saeed);
   $saeed99 = file_get_contents("administrative/source/mem/channel23.txt");
   save("Bot/$username_bot/channel23.txt",$saeed99);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/bot.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات??",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  //////////////
  elseif($command == 'create esm'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  mkdir("Bot/$username_bot/data");
  save("administrative/tokensadmins/admin/$username_bot.txt",$from_id);
  $class = file_get_contents("administrative/source/esm/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    $saeed909 = file_get_contents("administrative/source/chalesh/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed909);
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
      save('administrative/user/'.$from_id."/create.txt","true");
        save('administrative/user/'.$from_id."/uzrbot.txt","$username_bot");
            file_put_contents('administrative/user/'.$from_id."/create.txt","true");

        unlink('administrative/user/'.$from_id."/pv1.txt");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
  save("Bot/$username_bot/VP.txt","🏅معمولی🏅");
save("Bot/$username_bot/textvip.txt","🤖Create Your Robot Create😃
🤖ربات ساز خود را بسازید😃👇
🆔 @[*[BOT]*]
✊با سرور قوی و پرسرعت💪
✌و پنلی بسیار پیشرفته😎
---------
📍برای حذف تبلیغات ربات خودتون ویژه کنید");
  save("administrative/tokensadmins/admin/$username_bot.txt",$from_id);
 $class = file_get_contents("administrative/source/esm/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
   $cl = file_get_contents("administrative/source/esm/wordlist.json");
  save("Bot/$username_bot/data/wordlist.json",$cl); 
  $saeed909 = file_get_contents("administrative/source/chalesh/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed909);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @Create_mxbot
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }


  elseif($command == 'create fal'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  save("administrative/tokensadmins/admin/$username_bot.txt",$from_id);
  mkdir("Bot/$username_bot/data");
  $class = file_get_contents("administrative/source/fal/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class); 
    $saeed909 = file_get_contents("administrative/source/chalesh/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed909);
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @Create_mxbot
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات??",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
      save('administrative/user/'.$from_id."/create.txt","true");
        save('administrative/user/'.$from_id."/uzrbot.txt","$username_bot");
        unlink('administrative/user/'.$from_id."/pv1.txt");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
save("Bot/$username_bot/textvip.txt","🤖Create Your Robot Create😃
🤖ربات ساز خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪
✌️و پنلی بسیار پیشرفته😎
-------------------
📍برای حذف تبلیغات ربات خودتون ویژه کنید");
  save("Bot/$username_bot/VP.txt","🏅معمولی🏅");
    save("Bot/$username_bot/data/chanel11.txt","کانالی تنظیم نشده");
        save("Bot/$username_bot/data/b.txt","b");
save("Bot/$username_bot/data/baner.txt","🔮 عجیب ترین ربات فال 😳😰
با چند تا سوال ساده تمام آیندت رو بهت میگه!
من شخصا به فال و پیش‌بینی اعتقادی نداشتم ولی این ربات حتی زمان مرگم رو هم گفت😩😱خودت امتحانش کن 👇");
  save("administrative/tokensadmins/admin/$username_bot.txt",$from_id);
 $class = file_get_contents("administrative/source/fal/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[idbot]*]",$username_bot,$class);
  save("Bot/$username_bot/Class.php",$class);
  $saeed909 = file_get_contents("administrative/source/chalesh/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed909);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/Create_mxbot?start=Create_mxbot
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات??",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }


/////////////////
  elseif($command == 'create chalesh'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
  
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  $class = file_get_contents("administrative/source/chalesh/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[ID]*]",$username_bot,$class);
  save("Bot/$username_bot/index.php",$class); 
  $saeed909 = file_get_contents("administrative/source/chalesh/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed909);
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/chalesh/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[ID]*]",$username_bot,$class);
  save("Bot/$username_bot/index.php",$class); 
  $saeed909 = file_get_contents("administrative/source/chalesh/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed909);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید??","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  //////////////
  elseif($command == 'ali'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  
  mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  $class = file_get_contents("administrative/source/ali/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[ID]*]",$username_bot,$class);
  save("Bot/$username_bot/index.php",$class);
  $saeed979 = file_get_contents("administrative/source/ali/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed979);
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
    if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
 $class = file_get_contents("administrative/source/ali/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[*[ID]*]",$username_bot,$class);
  save("Bot/$username_bot/index.php",$class); 
  $saeed979 = file_get_contents("administrative/source/ali/channel.txt");
   save("Bot/$username_bot/channel.txt",$saeed979);
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  /////////////////////////
  elseif($command == 'create chatnashenas'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  
  save("Bot/$username_bot/uzerbot.txt","$username_bot");
  mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
  $class = file_get_contents("administrative/source/Chatnashenas/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[(*BOT*)]",$username_bot,$class);
  $class7 = file_get_contents("administrative/source/Chatnashenas/vip.jpg");
save("Bot/$username_bot/vip.jpg",$class7); 
  save("Bot/$username_bot/index.php",$class); 
    save("Bot/$username_bot/type.txt","free"); 
        save("Bot/$username_bot/channel.txt","#[*[BOT]*]"); 

  save("Bot/$username_bot/ads.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");

    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/user");
save("Bot/$username_bot/uzerbot.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
✊️با سرور قوی و پرسرعت💪");
  
$class = file_get_contents("administrative/source/Chatnashenas/index.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
$class = str_replace("[(*BOT*)]",$username_bot,$class);
  $class7 = file_get_contents("administrative/source/Chatnashenas/vip.jpg");
save("Bot/$username_bot/vip.jpg",$class7); 
  save("Bot/$username_bot/index.php",$class); 
    save("Bot/$username_bot/type.txt","free"); 
        save("Bot/$username_bot/channel.txt","#[*[BOT]*]"); 
  save("Bot/$username_bot/ads.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");

  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
 elseif($command == 'create botshop'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the 
  API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"‼️دوست عزیز توکن مورد نظر نامعتبر است.

⭕️لطفا با دقت بیشتر یک توکن صحیح بفرستید:","html","true",$button_back);
  }else{
	  
	 if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
	  
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001109877538&text='.$pmtext));
  /*  $msg_id = $msgid->result->message_id;*/
  ForwardMessage($channel,$chat_id,"$admin",$msg_id);
  save('administrative/user/'.$from_id."/command.txt","none");
  


  mkdir("Bot/$username_bot/data");
  mkdir("Bot/$username_bot/data/btn");
  mkdir("Bot/$username_bot/data/words");
  mkdir("Bot/$username_bot/data/setting");
  mkdir("Bot/$username_bot/data/admin");
  mkdir("Bot/$username_bot/data/codes");
  mkdir("Bot/$username_bot/data/products");
  mkdir("Bot/$username_bot/data/products/new.txt");
  mkdir("Bot/$username_bot/data/userss");
  mkdir("Bot/$username_bot/data/users");
  save("Bot/$username_bot/data/blocklist.txt","");
  save("Bot/$username_bot/data/last_word.txt","");
  save("Bot/$username_bot/data/pmsend_txt.txt","Message Sent!");
  save("Bot/$username_bot/data/start_txt.txt","Hello World!");
  save("Bot/$username_bot/data/forward_id.txt","");
  save("Bot/$username_bot/data/userss.txt","$from_id\n");
  mkdir("Bot/$username_bot/data/$from_id");
  save("Bot/$username_bot/data/$from_id/type.txt","admin");
  save("Bot/$username_bot/data/$from_id/step.txt","none");
  save("Bot/$username_bot/data/btn/btn1_name","");
  save("Bot/$username_bot/data/btn/btn2_name","");
  save("Bot/$username_bot/data/btn/btn3_name","");
  save("Bot/$username_bot/data/btn/btn4_name","");
    save("Bot/$username_bot/data/ads.text","ساخته شده توسط ربات ساز
	=========
	@[*[BOT]*]");
  save("Bot/$username_bot/data/btn/btn1_post","");
  save("Bot/$username_bot/data/btn/btn2_post","");
  save("Bot/$username_bot/data/btn/btn3_post","");
  save("Bot/$username_bot/data/btn/btn4_post","");
 
  save("Bot/$username_bot/data/setting/sticker.txt","✅");
  save("Bot/$username_bot/data/setting/video.txt","✅");
  save("Bot/$username_bot/data/setting/voice.txt","✅");
  save("Bot/$username_bot/data/setting/file.txt","✅");
  save("Bot/$username_bot/data/setting/photo.txt","✅");
  save("Bot/$username_bot/data/setting/music.txt","✅");
  save("Bot/$username_bot/data/setting/forward.txt","✅");
    $textinstalls = "ربات شما با موفقیت در سرور  بCLICK3روزرسانی شد✅
برای مشاهده خدمات لطفا /start را ارسال بکنید🗳";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  
  SendMessage($chat_id,"✅ ربات شما با موفقیت آپدیت شد.


🤖 برای ورود به ربات خود کلیک کنید😀👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🔯 @$username_bot",'url'=>"https://telegram.me/$username_bot"]],]]));
  
    SendMessage($$channel,"✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🔯@[*[BOT]*]",'url'=>"https://telegram.me/[*[BOT]*]"]],]]));
  SendMessage($chat_id,"↩️ به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official_fa);
  }else{
	  
	  if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
	  
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001109877538&text='.$pmtext));
  /*  $msg_id = $msgid->result->message_id;*/
  ForwardMessage($channel,$chat_id,"$admin",$msg_id);
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");

  mkdir("Bot/$username_bot/data");
  mkdir("Bot/$username_bot/data/btn");
  mkdir("Bot/$username_bot/data/words");
  mkdir("Bot/$username_bot/data/setting");
  mkdir("Bot/$username_bot/data/admin");
  mkdir("Bot/$username_bot/data/codes");
  mkdir("Bot/$username_bot/data/products");
  mkdir("Bot/$username_bot/data/products/new.txt");
  mkdir("Bot/$username_bot/data/userss");
  mkdir("Bot/$username_bot/data/users");
  save("Bot/$username_bot/data/blocklist.txt","");
  save("Bot/$username_bot/data/last_word.txt","");
  save("Bot/$username_bot/data/pmsend_txt.txt","Message Sent!");
  save("Bot/$username_bot/data/start_txt.txt","Hello World!");
  save("Bot/$username_bot/data/forward_id.txt","");
  save("Bot/$username_bot/data/userss.txt","$from_id\n");
  mkdir("Bot/$username_bot/data/$from_id");
  save("Bot/$username_bot/data/$from_id/type.txt","admin");
  save("Bot/$username_bot/data/$from_id/step.txt","none");
  save("Bot/$username_bot/data/btn/btn1_name","");
  save("Bot/$username_bot/data/btn/btn2_name","");
  save("Bot/$username_bot/data/btn/btn3_name","");
  save("Bot/$username_bot/data/btn/btn4_name","");
    save("Bot/$username_bot/data/ads.text","ساخته شده توسط ربات ساز
	=========
	@[*[BOT]*]");
  save("Bot/$username_bot/data/btn/btn1_post","");
  save("Bot/$username_bot/data/btn/btn2_post","");
  save("Bot/$username_bot/data/btn/btn3_post","");
  save("Bot/$username_bot/data/btn/btn4_post","");
 
  save("Bot/$username_bot/data/setting/sticker.txt","✅");
  save("Bot/$username_bot/data/setting/video.txt","✅");
  save("Bot/$username_bot/data/setting/voice.txt","✅");
  save("Bot/$username_bot/data/setting/file.txt","✅");
  save("Bot/$username_bot/data/setting/photo.txt","✅");
  save("Bot/$username_bot/data/setting/music.txt","✅");
  save("Bot/$username_bot/data/setting/forward.txt","✅");
	   
  $index = file_get_contents("administrative/source/gard/index.php");
  $index = str_replace("*TOKEN*",$token,$index);
  $index = str_replace("*ADMIN*",$from_id,$index);
    $index = str_replace("*username*",$username,$index);
	$index = str_replace("*botid*",$username_bot,$index);
  save("Bot/$username_bot/index.php",$index);	
  $textinstalls = "ربات شما با موفقیت به سرور [*[BOT]*] متصل شد✅
برای مشاهده خدمات لطفا /start را ارسال بکنید🗳";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/index.php");
  SendMessage($chat_id,"✅ ربات شما با موفقیت ساخته شد.
  

🤖 برای ورود به ربات خود کلیک کنید😀👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🔯 @$username_bot",'url'=>"https://telegram.me/$username_bot"]],]]));

SendMessage($channel,"✅ ربات ساخته شد  توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)","html","true",json_encode(['inline_keyboard'=>[[['text'=>"@#[*[BOT]*]",'url'=>"https://telegram.me/[*[BOT]*]"]],]]));

SendMessage($channel,"","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🔯 @$username_bot",'url'=>"https://telegram.me/Botcrfree_bot"]],]]));
  SendMessage($chat_id,"↩️ به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/Bots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/Bots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/Bots.txt',$aaddd);
  }
  }
  }
  }
  }
  
  ///////////////////////////////
  
  ////////////////////////////////////
  elseif($command == 'create aksnevesh'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
  if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
save("Bot/$username_bot/data/txvvip.txt","??Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
save("Bot/$username_bot/starttxt.txt","سلام خوش اومدی");
  
 $class = file_get_contents("administrative/source/aksneveshte/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
$claaas = file_get_contents("administrative/source/aksneveshte/index.php");
save("Bot/$username_bot/index.php",$claaas); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
??جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
  elseif($command == 'create editename'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
save("Bot/$username_bot/data/start.txt","سلام خوش اومدی");
  
 $class = file_get_contents("administrative/source/editename/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
$claaas = file_get_contents("administrative/source/editename/index.php");
save("Bot/$username_bot/index.php",$claaas); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
  elseif($command == 'create tbligcho'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  /*$pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
  
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/data/admin");
mkdir("Bot/$username_bot/user");
mkdir("Bot/$username_bot/admin");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
save("Bot/$username_bot/admin/start.txt","سلام خوش اومدی");
  
 $class = file_get_contents("administrative/source/tab/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
$class3 = file_get_contents("jdf.php");
save("Bot/$username_bot/jdf.php",$class3); 
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
    /*$pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";*/
  /*  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));*/
  /*  $msg_id = $msgid->result->message_id;*/
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/data/admin");
mkdir("Bot/$username_bot/user");
mkdir("Bot/$username_bot/admin");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
save("Bot/$username_bot/admin/start.txt","سلام خوش اومدی");
  
 $class = file_get_contents("administrative/source/tab/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
$class3 = file_get_contents("jdf.php");
save("Bot/$username_bot/jdf.php",$class3); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  ////////////////////////////////////
  elseif($command == 'create tst'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
   
  if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
   
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));
  $msg_id = $msgid->result->message_id;
  save('administrative/user/'.$from_id."/command.txt","none");
  mkdir("Bot/$username_bot/ads");
mkdir("Bot/$username_bot/cod");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/ads/admin");
mkdir("Bot/$username_bot/ads/cont");
mkdir("Bot/$username_bot/ads/date");
mkdir("Bot/$username_bot/ads/seen");
mkdir("Bot/$username_bot/ads/time");
mkdir("Bot/$username_bot/ads/user");
save("Bot/$username_bot/data/bottype.txt","o");
save("Bot/$username_bot/data/buy.txt","$from_id");
save("Bot/$username_bot/data/starttx.txt","سلام خوش اومدی");
save("Bot/$username_bot/data/setcoin2.txt","10");
save("Bot/$username_bot/data/setcoin.txt","1");
save("Bot/$username_bot/data/uzernamo.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
save("Bot/$username_bot/data/coinruz.txt","10");
  
  $clslass = file_get_contents("administrative/source/see/Class.php");
  $clslass = str_replace("[*[TOKEN]*]",$token,$clslass);
$clslass = str_replace("[*[ADMIN]*]",$from_id,$clslass);
  save("Bot/$username_bot/Class.php",$clslass);
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
   
   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
   
  $pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));
  $msg_id = $msgid->result->message_id;
  save('administrative/user/'.$from_id."/command.txt","none");
    file_put_contents('administrative/user/'.$from_id."/create.txt","true");
  mkdir("Bot/$username_bot");
mkdir("Bot/$username_bot/ads");
mkdir("Bot/$username_bot/cod");
mkdir("Bot/$username_bot/data");
mkdir("Bot/$username_bot/ads/admin");
mkdir("Bot/$username_bot/ads/cont");
mkdir("Bot/$username_bot/ads/date");
mkdir("Bot/$username_bot/ads/seen");
mkdir("Bot/$username_bot/ads/time");
mkdir("Bot/$username_bot/ads/user");
save("Bot/$username_bot/data/bottype.txt","o");
save("Bot/$username_bot/data/buy.txt","$from_id");
save("Bot/$username_bot/data/starttx.txt","سلام خوش اومدی");
save("Bot/$username_bot/data/setcoin2.txt","10");
save("Bot/$username_bot/data/setcoin.txt","1");
save("Bot/$username_bot/data/uzernamo.txt","$username_bot");
save("Bot/$username_bot/data/txvvip.txt","🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @[*[BOT]*]
✊️با سرور قوی و پرسرعت💪");
save("Bot/$username_bot/data/coinruz.txt","10");
  
 $class = file_get_contents("administrative/source/see/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
$class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class); 
$claaas = file_get_contents("administrative/source/see/index.php");
save("Bot/$username_bot/index.php",$claaas); 
$claaass = file_get_contents("administrative/source/see/jdf.php");
save("Bot/$username_bot/jdf.php",$claaass); 
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/Class.php");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
برای رفتن به پنل مدیریت در ربات دستور /panel را ارسال کنید✔️
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  
  ////////////////////////////////////
  

/*elseif($text == "دریافت جایزه"){
require_once 'gold.php';
$test = hedie($from_id);
if($test != true){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"متاسفم فقط یک بار میتوانید!",
'parse_mode'=>'HTML',
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"25 سکه دریافت کردی",
]);
}}*/
//////////////////////
elseif($text == '/sabtzed'){
      $baz = file_get_contents("administrative/user/$chat_id/baz.txt");

    if($baz > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "baz");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  ضدلینک پیشرفته اقدام نکرده اید.");
    
}
}
    elseif($command == "baz"){
$adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad03.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","baz1");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}
elseif($command == "baz1"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/baz.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad03.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}
///////////////////
elseif($text == '/sabtchalesh'){
    if($bz > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "chal");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  چالش اقدام نکرده اید.");
    
}
}
    elseif($command == "chal"){
$adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad203.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","chal1");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}
elseif($command == "chal1"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/chal.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad203.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}
////////////////
elseif($command == "saeed"){
  file_put_contents("administrative/user/$chat_id/command.txt","chal21");
  sendmessage($chat_id,"📍   ایدی ربات خود را بدون @ وارد کنید حساس به کوچک و بزرگ بودن ایدی");
}
elseif($command == "chal21"){
  sendmessage($chat_id,"📍    تبریک ربات شما ویژه شد");

  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("Bot/$text/type.txt","4");

}




elseif($text == '/sabtesm'){
	$esm = file_get_contents('administrative/user/'.$from_id."/esm.txt");
    if($esm > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "esm");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  چالش اقدام نکرده اید.");
    
}
}
    elseif($command == "esm"){
        $adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad20.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","esm1");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}

elseif($command == "esm1"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/esm.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad20.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}





elseif($text == '/sabtfal'){
	$fal = file_get_contents('administrative/user/'.$from_id."/fal.txt");
    if($fal > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "fal");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  چالش اقدام نکرده اید.");
    
}
}
    elseif($command == "fal"){
  file_put_contents("administrative/user/$chat_id/tedad0.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","fal1");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}
  
elseif($command == "fal1"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/fal.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad0.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}



elseif($text == '/sabtchat'){
    $tz = file_get_contents('administrative/user/'.$fromid."/app.txt");
    if($tz > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "app");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  حرفتو ناشناس بزن اقدام نکرده اید.");
    
}
}
    elseif($command == "app"){
        $adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad213.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","app1");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}
 
elseif($command == "app1"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/app.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad213.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}

elseif($text == '/sabtnashenas'){
    $tz = file_get_contents('administrative/user/'.$fromid."/nash.txt");
    if($tz > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "nash");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  حرفتو ناشناس بزن اقدام نکرده اید.");
    
}
}
    elseif($command == "nash"){
        $adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad213.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","nash1");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}
elseif($command == "nash1"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/nash.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad213.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}
/////////////////
elseif($text == '/sabtmember'){
    if($bs > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "member2");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات  ممبرگیر اقدام نکرده اید.");
    
}
}
    elseif($command == "member2"){
        $adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad23.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","member3");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}
 
elseif($command == "member3"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/member.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad23.txt");
  file_put_contents("Bot/$bbb/channel23.txt",$text); //محل مقدار امتیاز های کاربر
}

//////////////
elseif($text == '/sabtbaner'){
    if($ba > 4){
      file_put_contents("administrative/user/$chat_id/command.txt", "baner2");
  sendmessage($chat_id,"📍 ایدی ربات خود را بدون @ ارسال کنید 
  
 🚩  دقت داشته باشید کوچکی و بزرگی ایدی ربات شما حساس است  پس دقیق وارد کنید در غیر اینصورت مسئولیتی نداریم");

        
    }else{
    sendMessage("$chat_id","📍شما برای خرید  ثبت چنل در ربات بنر دهی اقدام  نکرده اید.");
    
}
}
    elseif($command == "baner2"){
        $adminnn=file_get_contents("administrative/tokensadmins/admin/".$text.".txt");
    if($chat_id==$adminnn)
    {
  file_put_contents("administrative/user/$chat_id/tedad2.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","baner3");
  sendmessage($chat_id,"📍 ایدی خود یا چنل خود را بدون @ وارد کنید");
}else{
      sendmessage($chat_id,"
      ❌ خطا
	    علت یکی از موارد زیر است : 
	        1-ایدی ربات را دقیق یا بدون @ وارد نکردید 
	        2- شما فقط میتوانید برای ربات های خودتان آیدی ثبت کنیدلطفا مراحل را دوباره طی کنید
      
      
      ");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
}
}
  
elseif($command == "baner3"){
  sendmessage($chat_id,"📍 تبریک ایدی شما در رباتتان ثبت شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
    file_put_contents("administrative/user/$chat_id/baner.txt","4");

  $bbb = file_get_contents("administrative/user/$chat_id/tedad2.txt");
  file_put_contents("Bot/$bbb/channel.txt",$text); //محل مقدار امتیاز های کاربر
}

//////////
  elseif($text == "امتیاز به کاربر" and $chat_id == $admin){
  file_put_contents("administrative/user/$chat_id/command.txt", "emtiaz");
  sendmessage($chat_id,"مقدار امتیاز را بفرستید");
}
elseif($command == "emtiaz"){
  file_put_contents("administrative/user/tedad.txt",$text);
  file_put_contents("administrative/user/$chat_id/command.txt","emtiaz2");
  sendmessage($chat_id,"ایدی عددی فرد را بفرستید");
}
elseif($command == "emtiaz2"){
  sendmessage($chat_id,"اضافه شد");
  file_put_contents("administrative/user/$chat_id/command.txt","none");
  $bb = file_get_contents("administrative/user/tedad.txt");
  $aa = file_get_contents("administrative/user/$text/gold.txt"); //محل مقدار امتیاز های کاربر
  $cc = $aa + $bb;
  file_put_contents("administrative/user/$text/gold.txt",$cc);
}
//////////////////
  elseif($command == 'create botpv'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
	  
	 if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
	  
  if(file_exists("Bot/$username_bot")){
  $pmtext = "{✅ ربات آپدیت شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));
  $msg_id = $msgid->result->message_id;
  save('administrative/user/'.$from_id."/command.txt","none");
  
    $textinstalls = "🤖ربات شما با موفقیت در سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 بروز رسانی شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/");
  
  SendMessage($chat_id,"ربات شما با موفقیت آپدیت شد♻️
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  }else{
	  
	   if($create == 'true' ){
    save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🌹دوست عزیز متاسفانه شما قبلا یک ربات ساخته اید و نمیتوانید بیشتر از یک ربات بسازید❌
جهت ساخت ربات بیشتر روی دکمه (🤖ربات دوم و حساب ویژه رایگان🔱) کلیک کنید.","html","true",$button_official_fa);
  }else{
	  
  $pmtext = "{✅ ربات ساخته شد توسط 👈 ($username)}{🤖 ربات مربوطه 👈 (@$username_bot)}{⏰ زمان 👈 ($fatime)}{📅 تاریخ 👈 ($fadate)}";
  $msgid = json_decode(file_get_contents('https://api.telegram.org/bottoken/sendMessage?parse_mode=HTML&chat_id=-1001133375986&text='.$pmtext));
  $msg_id = $msgid->result->message_id;
  save('administrative/user/'.$from_id."/command.txt","none");
  save('administrative/user/'.$from_id."/create.txt","$username_bot");
  mkdir("Bot/$username_bot");
  mkdir("Bot/$username_bot/other");
  mkdir("Bot/$username_bot/data");
  mkdir("Bot/$username_bot/other/$from_id");
  mkdir("Bot/$username_bot/other/access");
  mkdir("Bot/$username_bot/other/button");
  mkdir("Bot/$username_bot/other/profile");
  mkdir("Bot/$username_bot/other/setting");
  mkdir("Bot/$username_bot/other/wordlist");
  mkdir("Bot/$username_bot/other/button/caption");
  mkdir("Bot/$username_bot/other/button/file");
  mkdir("Bot/$username_bot/other/button/forward");
  mkdir("Bot/$username_bot/other/button/music");
  mkdir("Bot/$username_bot/other/button/photo");
  mkdir("Bot/$username_bot/other/button/feed");
  mkdir("Bot/$username_bot/other/button/sticker");
  mkdir("Bot/$username_bot/other/button/text");
  mkdir("Bot/$username_bot/other/button/video");
  mkdir("Bot/$username_bot/other/button/voice");
  save("Bot/$username_bot/other/setting/start.txt","Hi!✋ 
  <b>Welcome To My Bot</b>");
  save("Bot/$username_bot/other/setting/send.txt","<b>Sent To My Admin!</b>");
  save("Bot/$username_bot/other/setting/sticker.txt","✅");
  save("Bot/$username_bot/other/setting/file.txt","✅");
  save("Bot/$username_bot/other/setting/aks.txt","✅");
  save("Bot/$username_bot/other/setting/music.txt","✅");
  save("Bot/$username_bot/other/setting/film.txt","✅");
  save("Bot/$username_bot/other/setting/voice.txt","✅");
  save("Bot/$username_bot/other/setting/join.txt","✅");
  save("Bot/$username_bot/other/setting/link.txt","✅");
  save("Bot/$username_bot/other/setting/forward.txt","✅");
  save("Bot/$username_bot/other/setting/pm_forward.txt","⛔️");
  save("Bot/$username_bot/other/setting/pm_resani.txt","✅");
  save("Bot/$username_bot/other/setting/on-off.txt","true");
  save("Bot/$username_bot/other/setting/profile.txt","✅");
  save("Bot/$username_bot/other/setting/contact.txt","⛔️");
  save("Bot/$username_bot/other/setting/location.txt","⛔️");
  
  $class = file_get_contents("administrative/source/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$from_id,$class);
  save("Bot/$username_bot/Class.php",$class);
  $index = file_get_contents("administrative/source/index.php");
  save("Bot/$username_bot/index.php",$index);	
  $butt = file_get_contents("administrative/source/Button.php");
  save("Bot/$username_bot/other/Button.php",$butt);	
  $textinstalls = "🤖ربات شما با موفقیت به سرور پرسرعت🚀 FUNP
 @[*[BOT]*]
 متصل شد♻️
جهت شروع ربات /start را ارسال کنید.";
  file_get_contents("http://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=$textinstalls");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=$myurl/$username_bot/");
  SendMessage($chat_id,"ربات شما با موفقیت ساخته شد💎
🌟🌟🌟🌟🌟به ربات ما امتیاز بدید👇
https://telegram.me/storebot?start=[*[BOT]*]
😎جهت ورود به ربات خود کلیک کنید👇","html","true",json_encode(['inline_keyboard'=>[[['text'=>"🚀ورود به ربات🚀",'url'=>"https://telegram.me/$username_bot"]],]]));
  SendMessage($chat_id,"🏠به صفحه اصلی برگشتیم.
🙏لطفا یکی از گزینه های زیر را انتخاب نمایید.","html","true",$button_official_fa);
  
  $txxt = file_get_contents('administrative/access/robots.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($username_bot,$pmembersid)){
  $aaddd = file_get_contents('administrative/access/robots.txt');
  $aaddd .= $username_bot."\n";
  file_put_contents('administrative/access/robots.txt',$aaddd);
  }
  }
  }
  }
  }
  //////////////////////////
  
  /////////////////////
  /*
  elseif ($text == '☢ حذف ربات') {
if (file_exists("administrative/user/".$from_id.'/command.txt')) {

}
$botname = file_get_contents("administrative/user/".$from_id.'/create.txt');
if ($botname == "") {
SendMessage($chat_id,"لطفا ایدی ربات خود را بدون @ ارسال کنید✔️
⚠️ توجه کنید ایدی خود را دقیق وارد کنید حساس به کوچک و بزرگ بودن حروف.");

}
else {
save("administrative/user/".$from_id.'/command.txt',"delete");


 	var_dump(bot('sendMessage',[
	'chat_id'=>$update->message->chat->id,
	'text'=>"یکی از ربات های خود را انتخاب کنید : ",
	'parse_mode'=>'MarkDown',
	
	]));


}
}
elseif ($command == 'delete') {
$botun = $txtmsg ;
if (file_exists("Bot/$botun")) {

$src = file_get_contents("Bot/$botun");

if (strpos($src , $from_id) !== false ) {
save("administrative/user/'.$from_id.'/command.txt","none");
unlink("Bot/$botun");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت پاک شده است 
یک ربات جدید بسازید 😄",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔄 ساخت ربات"],['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
else {
SendMessage($chat_id,"خطا!
شما نمی توانید این ربات را پاک کنید ! ");
}
}
else {
SendMessage($chat_id,"یافت نشد.");
}
}
    $data = $update->callback_query->data;
    if (strpos($data, "del") !== false ) {
    $botun = str_replace("del ","",$data);
    unlink("Bot/$botun");
    save("administrative/user/'.$from_id.'/create.txt","");
    var_dump(
        makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"ربات شما با موفقیت حذف شد !",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"به کانال ما بپیوندید",'url'=>"https://telegram.me/$mych"]
                    ]
                ]
            ])
        ])
    );
    exit();
}*/
  //==========
  // Manage
  elseif($text == '👤مدیریت' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"🈸 به بخش ادمین خوش اومدین","html","true",$button_manage);
  }
 /* elseif ($text == 'افزودن ادمین' and $from_id == $admin){
	  $s = file_get_contents("administrative/admin.txt");
	 save('administrative/user/'.$from_id."/command.txt","addadmin");
	 sendMessage($chat_id,"سلام
	 لطفا ایدی ادمین را بصورت آرایه
	 ,id
	 در فایل 
	 administrative/admin.txt
	 اضافه کنید.
	 و ایدی فرد را اینجا وارد کنید تا من خبر ادمین شدنشو بهش بدم","html","true",$button_back);
  }
  elseif($command == 'addadmin' and $from_id == $admin){
	save('administrative/user/'.$from_id."/command.txt","none");
	save('administrative/admin.txt',"$text");
	sendMessage($chat_id,"فرد موردنظر ادمین شد!");
	sendMessage($text,"تبریک شما ادمین شدید
	لطفا قوانین را رعایت کنید");
  }*/
  //============
  elseif($text == '☢کد رایگان' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","cod free");
  SendMessage($chat_id,"☢ کد مورد نظر رو وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'cod free' and $from_id == $admin){
  save("administrative/code/$text.txt","false");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"☢ کد ثبت شد.","html","true",$button_manage);
  SendMessage($kanal,"🎁کد رایگان مخصوص ویژه کردن ربات 
⚜کد یکبار مصرف
➖➖➖➖➖➖➖➖
code : $text
➖➖➖➖➖➖➖➖
❗️روش استفاده:
1-وارد ربات @[*[BOT]*] شوید.
2-روی گزینه 🎁استفاده از کد🎁 بزنید.
3-کد $text را ارسال کنید.
4-آیدی ربات خود را بدون @ و دقیق ارسال کنید.
تبریک ربات شما ویژه شد✔️
*******************
🆑 @$mych
🤖 @[*[BOT]*]","html","true");
  }
  //============
 /* elseif($text == '🅾️اطلاعات'){
  save("other/$from_id/command.txt","set idtaraf");
  SendChatAction($chat_id,"typing");
  SendMessage($chat_id,"<i>🅾️ ایدی عددی را وارد کنید:</i>","html","true",$button_manage);
  }
elseif($command == 'set idtaraf'){
  save("other/$from_id/command.txt","none");
 $info = json_decode(
 file_get_contents("https://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text")
 );
 if ($info->ok == true)
 {
   SendMessage($chat_id,"<i>✅ آیدی حروفی :$info->result->username</i>","html","true",$button_manage);
 }
 }*/

  //============
  elseif($text == '⭕️لغو حساب ویژه' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","laghv hesab");
  SendMessage($chat_id,"⭕️ یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'laghv hesab' and $from_id == $admin){
  unlink("Bot/$text/data/bottype.txt");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"⭕️ حساب غیر ویژه شد.","html","true",$button_manage);
  SendMessage($admin,"از طرف آدمین ربات رباتی غیر ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
  //============
  elseif($text == '⚜️ویژه کردن ربات فروشگاه ساز' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab gold5");
  SendMessage($chat_id,"🔱 یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab gold5' and $from_id == $admin){
  save("Bot/$text/botttype.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
  SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
  ////////////////////////
  elseif($text == '⚜️ویژه کردن ربات پیام رسان' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab gold");
  SendMessage($chat_id,"🔱 یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab gold' and $from_id == $admin){
  save("Bot/$text/data/bottype.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
  SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
  ////////////////////////
    elseif($text == '⚜️ویژه کردن ربات ویوگیر️' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview");
  SendMessage($chat_id,"🔱 یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab goldview' and $from_id == $admin){
  save("Bot/$text/data/bottype.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
    SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
  //============
  ////////////////////////
    elseif($text == 'ویژه کردن بنردهی' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview23");
  SendMessage($chat_id,"یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab goldview23' and $from_id == $admin){
  save("Bot/$text/bot_type_ads.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
    SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }

////////////////////////
    elseif($text == '✉️ویژه کردن تبچی' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview2311");
  SendMessage($chat_id,"یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab goldview2311' and $from_id == $admin){
  save("Bot/$text/bot_type_ads.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
    SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
  ////////////////////////
  elseif($text == '🔑ویژه کردن ضد لینک' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview2311");
  SendMessage($chat_id,"یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab goldview2311' and $from_id == $admin){
  save("Bot/$text/bot_type_ads.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
    SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
    ////////////////////////
    elseif($text == '⚜ویژه کردن چت ناشناس🔱' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","hesab goldview23112");
  SendMessage($chat_id,"یوزرنیم بات رو بدون @ وارد کنید","html","true",$button_back2);
  }
  elseif($command == 'hesab goldview23112' and $from_id == $admin){
  save("Bot/$text/type.txt","gold");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🔱 حساب ویژه شد.","html","true",$button_manage);
    SendMessage($admin,"از طرف آدمین ربات رباتی ویژه شد.
آیدی آدمین:
@$username
آیدی ربات
@$text","html","true",$button_back2);
  }
    ////////////////////////
  elseif($text == '🤖ربات دوم' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","Bot 2");
  SendMessage($chat_id,"🤖 پیامی از شخص مورد نظر فوروارد کنید","html","true",$button_back2);
  }
  elseif($command == 'Bot 2' and $from_id == $admin){
  unlink("administrative/user/".$forward_id."/create.txt");
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"🤖 شخص مورد نظر ربات دیگری میتواند بسازد.","html","true",$button_manage);
  SendMessage($admin,"از طرف آدمین ربات فردی ربات دومش فعال شد.
آیدی آدمین:
@$username
آیدی فرد
$text","html","true",$button_back2);
  }
  //============
  elseif($text == 'آمار ربات 📊'){
    $mmemcount = count($datas['all_users']);
	$mmemcount_member = numberformat("$mmemcount",',');
	$txttt = file_get_contents('administrative/access/robots.txt');
    $member_id1 = explode("\n",$txttt);
    $mmemcount1 = count($member_id1) -1;
	$mmemcount_bots = numberformat("$mmemcount1",',');
	$txtttt = file_get_contents('administrative/access/allm.txt');
    $member_id111 = explode("\n",$txtttt);
    $mmemcount111 = count($member_id111) -1;
	$mmemcount_member_all_bot = numberformat("$mmemcount111",',');
	$adminHA = getFileList('administrative/tokensadmins/admin','.txt');
	$tokenHA = getFileList('administrative/tokensadmins/token','.txt');
	$bots = file_get_contents("administrative/access/UserName.txt");
	$exbot = explode("@",$bots);
	$c = count($exbot)-2;
	$botsss = '';
	if($exbot[$c-(-1)] != null){
	$botsss = $botsss."@".$exbot[$c-(-1)];
	}if($exbot[$c] != null){
	$botsss = $botsss."@".$exbot[$c];
	}if($exbot[$c-1] != null){
	$botsss = $botsss."@".$exbot[$c-1];
	}if($exbot[$c-2] != null){
	$botsss = $botsss."@".$exbot[$c-2];
	}if($exbot[$c-3] != null){
	$botsss = $botsss."@".$exbot[$c-3];
	}if($exbot[$c-4] != null){
	$botsss = $botsss."@".$exbot[$c-4];
	}if($exbot[$c-5] != null){
	$botsss = $botsss."@".$exbot[$c-5];
	}if($exbot[$c-6] != null){
	$botsss = $botsss."@".$exbot[$c-6];
	}if($exbot[$c-7] != null){
	$botsss = $botsss."@".$exbot[$c-7];
	}if($exbot[$c-8] != null){
	$botsss = $botsss."@".$exbot[$c-8];
	}
	$botsss = str_replace("\n",' | ',$botsss);
  SendMessage($chat_id,"آخرین آمار تا ساعت ( $fatime ) و تاریخ ( $fadate ) به صورت زیر میباشد👇
  
⛏تعداد ربات های ساخته شده با ربات ساز:
  $mmemcount_bots
  
  🤖 @[*[BOT]*]
  ","html","true");
  }
  //============
  elseif($text == 'امار' and $from_id == CLICK2){
	$mmemcount = count($datas['all_users']);
	$mmemcount_member = numberformat("$mmemcount",',');
	$txttt = file_get_contents('administrative/access/robots.txt');
    $member_id1 = explode("\n",$txttt);
    $mmemcount1 = count($member_id1) -1;
	$mmemcount_bots = numberformat("$mmemcount1",',');
	$txtttt = file_get_contents('administrative/access/allm.txt');
    $member_id111 = explode("\n",$txtttt);
    $mmemcount111 = count($member_id111) -1;
	$mmemcount_member_all_bot = numberformat("$mmemcount111",',');
	$adminHA = getFileList('administrative/tokensadmins/admin','.txt');
	$tokenHA = getFileList('administrative/tokensadmins/token','.txt');
	$bots = file_get_contents("administrative/access/UserName.txt");
	$exbot = explode("@",$bots);
	$c = count($exbot)-2;
	$botsss = '';
	if($exbot[$c-(-1)] != null){
	$botsss = $botsss."@".$exbot[$c-(-1)];
	}if($exbot[$c] != null){
	$botsss = $botsss."@".$exbot[$c];
	}if($exbot[$c-1] != null){
	$botsss = $botsss."@".$exbot[$c-1];
	}if($exbot[$c-2] != null){
	$botsss = $botsss."@".$exbot[$c-2];
	}if($exbot[$c-3] != null){
	$botsss = $botsss."@".$exbot[$c-3];
	}if($exbot[$c-4] != null){
	$botsss = $botsss."@".$exbot[$c-4];
	}if($exbot[$c-5] != null){
	$botsss = $botsss."@".$exbot[$c-5];
	}if($exbot[$c-6] != null){
	$botsss = $botsss."@".$exbot[$c-6];
	}if($exbot[$c-7] != null){
	$botsss = $botsss."@".$exbot[$c-7];
	}if($exbot[$c-8] != null){
	$botsss = $botsss."@".$exbot[$c-8];
	}
	$botsss = str_replace("\n",' | ',$botsss);
  SendMessage($chat_id,"آخرین آمار تا ساعت ( $fatime ) و تاریخ ( $fadate ) به صورت زیر میباشد👇
  
⛏تعداد ربات های ساخته شده با ربات ساز:
  $mmemcount_bots
  👤تعداد اعضای(ممبرهای) ربات:
  $mmemcount_member
  
  🤖 @[*[BOT]*]
  ","html","true");
  }
	///////////////
	 elseif($text == '📮فوروارد همگانی' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2a fwd");
	SendMessage($chat_id,"📮 پیام مورد نظر را فوروارد کنید","html","true",$button_back2);
	}
	elseif($command == 's2a fwd' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📮 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	file_put_contents("fwd.txt","$chat_id,$message_id");
	file_get_contents(str_replace('index1','send',"http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"));
		}
		
			 elseif($text == 'تبدیل به vip' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2");
	SendMessage($chat_id,"ایدی کاربر را وارد کنید","html","true",$button_back2);
	}
	elseif($command == 's2' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"کاربر $text وی ای پی شد","html","true",$button_manage);
	SendMessage($text,"تبریک شما کاربر VIP شدید","html","true");
	file_put_contents("administrative/user/$text/vip.txt","vip");
file_put_contents("administrative/user/$text/gold.txt","10000");
		}
		
		 elseif($text == 'لغو vip' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s3");
	SendMessage($chat_id,"ایدی کاربر را وارد کنید","html","true",$button_back2);
	}
	elseif($command == 's3' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"VIP کاربر $text لغو شد","html","true",$button_manage);
	SendMessage($text,"حساب VIP شما لغو شد","html","true");
	unlink("administrative/user/$text/vip.txt");
file_put_contents("administrative/user/$text/gold.txt","0");
		}
/*elseif($text == '📮فوروارد همگانی' and $from_id == $admin){
 save("administrative/user/".$from_id."/command.txt","s2a fwd");
 SendMessage($chat_id,"📮 پیام مورد نظر را فوروارد کنید","html","true",$button_back2);
 }
 elseif($command == 's2a fwd' and $from_id == $admin){
 save("administrative/user/".$from_id."/command.txt","none");
 SendMessage($chat_id,"📮 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
 $x = 0;
$count = count($datas['all_users']);
while ($x <= $count ){
   if( $x%100 == 0 ){
      sleep(30);
   }
   if($x%100 != 0){
      forwardMessage($datas['all_users'][$x],$message[0],$message[1]);

   }
   if($x>= $count){
      SendMessage($admin,"فوروارد همگانی با موفقیت به تمام کاربران ارسال شد ...");

   break;
   }
  } 
  }*/
 /*  elseif($text == 'ارسال همگانی'){

        save("administrative/user/".$from_id."/command.txt","msg");

        $msg = 'برای ارسال پیام به تمامی کاربران پیام خود را در قالب متن ، عکس ، فیلم و ... ارسال نمایید ';
        sendMessage($chat_id,$msg);
}
elseif ($command == 'msg') {
    foreach($datas['all_users'] as $user=>$value){
        forwardMessage($user , $chat_id, $message_id);
    }
    $msg = 'پیام با موفقیت به تمامی کاربران ربات ارسال شد !';
   
    sendMessage($chat_id,$message_id, $msg );
}*/

	//===========
	elseif($text == '📭پیام همگانی' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2a");
	SendMessage($chat_id,"📭 پیامتون رو وارد کنید","html","true",$button_back2);
	}
	elseif($command == 's2a' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📭 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "administrative/access/mum.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			if($sticker_id != null){
			SendSticker($user,$sticker_id);
			}
			elseif($video_id != null){
			SendVideo($user,$video_id,$caption);
			}
			elseif($voice_id != null){
			SendVoice($user,$voice_id,'',$caption);
			}
			elseif($file_id != null){
			SendDocument($user,$file_id,'',$caption);
			}
			elseif($music_id != null){
			SendAudio($user,$music_id,'',$caption);
			}
			elseif($photo2_id != null){
			SendPhoto($user,$photo2_id,'',$caption);
			}
			elseif($photo1_id != null){
			SendPhoto($user,$photo1_id,'',$caption);
			}
			elseif($photo0_id != null){
			SendPhoto($user,$photo0_id,'',$caption);
			}
			elseif($text != null){
			SendMessage($user,$text,"html","true");
			}
		}
	}
		elseif($text == 'همگانی بات' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","s2ab");
	SendMessage($chat_id,"📭 پیامتون رو وارد کنید","html","true",$button_back2);
	}
	elseif($command == 's2ab' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📭 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "administrative/access/mum.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			if($sticker_id != null){
			SendSticker($user,$sticker_id);
			}
			elseif($video_id != null){
			SendVideo($user,$video_id,$caption);
			}
			elseif($voice_id != null){
			SendVoice($user,$voice_id,'',$caption);
			}
			elseif($file_id != null){
			SendDocument($user,$file_id,'',$caption);
			}
			elseif($music_id != null){
			SendAudio($user,$music_id,'',$caption);
			}
			elseif($photo2_id != null){
			SendPhoto($user,$photo2_id,'',$caption);
			}
			elseif($photo1_id != null){
			SendPhoto($user,$photo1_id,'',$caption);
			}
			elseif($photo0_id != null){
			SendPhoto($user,$photo0_id,'',$caption);
			}
			elseif($text != null){
			SendMessage($idpushe,$text,"html","true");
			}
		}
	}
//============
elseif($text == '👤زیرمجموعه کاربر👥'and $from_id == $admin or$from_id == $admi){
  save("administrative/user/$from_id/command.txt","am00");
  sendMessage($chat_id,"لطفا ایدی عددی کاربر بفرستید:","html","true,$button_back2");
 }
  elseif($command == 'am00'){
  save("administrative/user/$from_id/gidi.txt","$text");
  $infooo = file_get_contents("administrative/user/$text/membrs.txt");
  sendMessage($chat_id,"➖➖➖➖➖
🅾️تعداد زیرمجموعه های کاربر [ $text ] :
🌟 { $infooo }
");
  }
  
  
elseif($text == '👤مدیریت امتیاز کاربر👥'and $from_id == $admin or$from_id == $admi){
  save("administrative/user/$from_id/command.txt","m00");
  sendMessage($chat_id,"لطفا ایدی عددی کاربر بفرستید:","html","true,$button_back2");
 }
  elseif($command == 'm00'){
  save("administrative/user/$from_id/gidi.txt","$text");
  $infoo = file_get_contents("administrative/user/$text/gold.txt");
  save("administrative/user/$from_id/command.txt","m000");
  sendMessage($chat_id,"➖➖➖➖➖
🅾️تعداد امتیاز های کاربر [ $text ] :
🌟 { $infoo }
🔖لطفا امتیاز جدید ارسال کنید:");
  }
   elseif($command == 'm000'){
 save("administrative/user/$idi/gold.txt","$text");
  save("administrative/user/$from_id/command.txt","none");
  sendMessage($chat_id,"🗄تعداد کل امتیازهای جدید کاربر { $text } عملیات موفق امیز بود💚","html","true",$button_manage);
  sendMessage($idi,"🌟تبریک 
👤کاربر گرامی از طرف پشتیبانی به شما امتیاز داده شد
🔖جمع امتیاز جدید شما : [ $text ]");
  }
  
  ///////////////
elseif($text == '📟تبلیغات' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","ads");
	SendMessage($chat_id,"📟 تبلیغ مورد نظر رو فوروارد کنید","html","true",$button_back2);
	}
	elseif($command == 'ads' and $from_id == $admin){
	save("administrative/user/".$from_id."/command.txt","none");
	save("administrative/access/forward-msg-id.txt",$from_chat_msg_id);
	save("administrative/access/forward-id.txt","@$from_chat_username");
	SendMessage($chat_id,"📟 تبلیغ مورد نظر ثبت شد.","html","true",$button_manage);
	}
	//============
	elseif($text == 'banels'){
  SendMessage($chat_id,"کل اعضا بن شده👇
$banels","html","true");
  }
  //===============
/*  elseif($text == '/bannn' and $from_id == $admin){
  save('administrative/user/'.$from_id."/command.txt","cod ban");
  SendMessage($chat_id,"ایدیشو بفرس","html","true",$button_back2);
  }
  elseif($command == 'cod ban' and $from_id == $admin){
  save("administrative/user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"بلاک شد🚫","html","true",$button_manage);
  SendMessage($text,"شما از ربات بلاک شده اید🚫📛
🚷اگر اشتباه بلاک شده اید به ما خبر دهید👇
@mwolverin","html","true");
$txxt = file_get_contents('administrative/banall-member/banall.txt');
  $pmembersid= explode("\n",$txxt);
  if (!in_array($text,$pmembersid)){
  $aaddddd = file_get_contents('administrative/banall-member/banall.txt');
  $aaddddd .= $text."\n";
  file_put_contents('administrative/banall-member/banall.txt',$aaddddd);
  }
  }
    //===============
//============
elseif(preg_match('/^\/([Bbanall) (.*)/',$text) and $from_id == $admin){
	preg_match('/^\/([Bb]anall) (.*)/',$text,$match);
	$id = json_decode(file_get_contents("https://api.pwrtelegram.xyz/bottoken/getChat?chat_id=".$match[2]));
	$user = $id->result->id;
	if($user != null){
	$txxt = file_get_contents('administrative/banall-member/banall.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($user,$pmembersid)){
      $aaddd = file_get_contents('administrative/banall-member/banall.txt');
      $aaddd .= $user."\n";
		file_put_contents('administrative/banall-member/banall.txt',$aaddd);
    }
	SendMessage($chat_id,"🚫 کاربر مورد نظر بن ال شد.","html","true");
	SendMessage($user,"*You Are GloballyBanned From Server.❌
Don't Message Again...❌*
➖➖➖➖➖➖➖➖➖➖`
دسترسی شما به این سرور مسدود شده است.❌
لطفا پیام ندهید...❌`","html","true");
	}else{
	SendMessage($chat_id,"متاسفانه خطایی رخ داده است.","html","true");
	}
	}
//============
 	elseif(preg_match('/^\/([Uu]n[Bb]anall) (.*)/',$text) and $from_id == $admin){
	preg_match('/^\/([Uu]n[Bb]anall) (.*)/',$text,$match);
	$id = json_decode(file_get_contents("https://api.pwrtelegram.xyz/bottoken/getChat?chat_id=".$match[2]));
	$user = $id->result->id;
	if($user != null){
	$rep = str_replace("$user\n",'',$block);
	save("administrative/banall-member/banall.txt",$rep);
	SendMessage($chat_id,"✅کاربر مورد نظر آنبن ال  شد.","html","true");
	SendMessage($user,"✅شما آنبن ال شدین.","html","true");
	}else{
	SendMessage($chat_id,"🚫 متاسفانه خطایی رخ داده است.","html","true");
	}
	}*/
	//==========
	 elseif($text == '📡لیست افراد بلاک شده' and $from_id == $admin){
	
	$botsban = file_get_contents("administrative/banall-member/banall.txt");
	$exbotban = explode(">",$botsban);
	$c = count($exbotban)-2;
	$botsssban = '';
	if($exbotban[$c-(-1)] != null){
	$botsssban = $botsssban.">".$exbotban[$c-(-1)];
	}if($exbotban[$c] != null){
	$botsssban = $botsssban.">".$exbotban[$c];
	}if($exbotban[$c-1] != null){
	$botsssban = $botsssban.">".$exbotban[$c-1];
	}if($exbotban[$c-2] != null){
	$botsssban = $botsssban.">".$exbotban[$c-2];
	}if($exbotban[$c-3] != null){
	$botsssban = $botsssban.">".$exbotban[$c-3];
	}if($exbotban[$c-4] != null){
	$botsssban = $botsssban.">".$exbotban[$c-4];
	}if($exbotban[$c-5] != null){
	$botsssban = $botsssban.">".$exbotban[$c-5];
	}if($exbotban[$c-6] != null){
	$botsssban = $botsssban.">".$exbotban[$c-6];
	}if($exbotban[$c-7] != null){
	$botsssban = $botsssban.">".$exbotban[$c-7];
	}if($exbotban[$c-8] != null){
	$botsssban = $botsssban.">".$exbotban[$c-8];
	}
	$botsssban = str_replace("\n",' | ',$botsssban);
	
	SendChatAction($chat_id,"typing");
	SendMessage($chat_id,"<i>📊🕵لیست </i> <code>10</code> <i>کاربر بلاک شده: </i>
	$botsssban","html","true");
	}
	
    //============
else{
  SendMessage($chat_id,"
✨کاربر عزیز برای مشاهده دستورات روی /restart ضربه بزنید
","html","true");

 
  SendMessage($admin2,"دستور نامشخص زد👇
نام کاربر : $first
یوزرنیم : @$username
آیدی عددی : $from_id
متن نامشخص : $text","html","true");
}
mkdir('administrative/user/'.$from_id);
    if (!in_array($chat_id,$datas['all_users'])){
      $datas['all_users'][] = $from_id;
      file_put_contents("administrative/access/datas.json",json_encode($datas));
    }
	$txxt = file_get_contents('administrative/access/UserName.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array("@".$username,$pmembersid)){
      $aaddd = file_get_contents('administrative/access/UserName.txt');
      $aaddd .= "@".$username."\n";
	  if($username != null){
		file_put_contents('administrative/access/UserName.txt',$aaddd);
	  }
    }
    
    unlink("error_log");
  
?>
?>
