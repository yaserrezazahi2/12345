<?php


define('API_KEY', '[*[TOKEN]*]');

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function sendmessage($chat_id, $text){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>"MarkDown"
 ]);
 } 
 

function deleteFolder($path){
    if (is_dir($path) === true) {
        $files = array_diff(scandir($path), array('.', '..'));
        foreach ($files as $file)
            deleteFolder(realpath($path) . '/' . $file);
            
        return rmdir($path);
    } else if (is_file($path) === true)
        return unlink($path);
 
    return false;
}
//-//////
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$name = $message->from->first_name;
$username = $message->from->username;
$from_id = $message->from->id;
$text = $message->text;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$admin = [*[ADMIN]*];
$bi = @[*[ID]*];
$channel = file_get_contents("channel.txt");
$message_id = $update->callback_query->message->message_id;
$ali = file_get_contents("data/".$chat_id."/ali.txt");
mkdir("data/$chat_id");
mkdir("ch");
//---------------//
  function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 900;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"❌  جهت جلوگیری از اسپم ربات ، شما 15 دقیقه از ربات بلاک شدید ❌"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
if($text == '/start'){
 if (!file_exists("data/$from_id/ali.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/ali.txt","none");
        
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
          			bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[یک نفر جدید با ایدی @$username و ایدی عددی $chat_id به ربات اومد!](tg://user?id=$chat_id)
	
	تعداد عضو ها : $member_count
		
		",
		    'parse_mode'=>'MarkDown',
	]);
        }
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🎗سلام `$name` به ربات چالش ساز خوش آمدید!

🔸 با استفاده از من شما میتونید بصورت نوین جدید ربات ها برای کانال های خودتون چالش های خوبی بسازید که از آمدن هزارن نفر به پی وی خودتون راحت بشید.

🔹 کار با من هم راحته روی دکمه ساخت چالش کلیک میکنید  متن جایزه را به من میدید  بعد من بهتون یه لینک اشتراک گذاری میدم شما اون لینک رو هرجا که دوست دارید میزارید.

🔻 بعد اولین نفری که روی لینک کلیک کنه براش جایزه  که شما تعیین کردید نشان داده خواهد شد!

⚠️ به بقیه هم جواب رد خواهد داده شد!

[ربات خود را بسازید](telegram.me/$channel)",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [
              ['text'=>"🔸ساخت چالش"]
              ],
              [
              ['text'=>"😎 سازنده"],['text'=>"🔖 اطلاعات کاربری "]
              ]
              ],
              "resize_keyboard"=>true
        ])
 ]);
}
elseif($text == "😎 سازنده"){
    bot('sendmessage' ,[
        'chat_id'=>$chat_id,
        'text'=>"✅ این ربات توسط کانال @$channel ساخته شده است.",
        ]);
}
elseif($text == "🔖 اطلاعات کاربری"){
    bot('sendmessage' ,[
        'chat_id'=>$chat_id,
        'text'=>"🌀 نام : $name
🆔 ایدی : @$username
♨️ ایدی عددی : [$chat_id](tg://user?id=$chat_id)",
        'parse_mode'=>"MarkDown",
        ]);
}
elseif($text == '🔸ساخت چالش'){
file_put_contents("data/$chat_id/ali.txt", "j");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"خوب حالا جایزی که میخواهید به اولین نفر داده شود را بهم بگید😛",
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($ali == 'j'){
$r = rand(10000000 , 100000000);
mkdir("ch/$r");
file_put_contents("data/$chat_id/ali.txt", "nono");
file_put_contents("ch/$r/j.txt", $text);
file_put_contents("ch/$r/chat_id.txt", $chat_id);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>" 
 حله😋
 لینک زیرو میتونید هرجا که دوست دارید استفاده کنید 
 
https://telegram.me/$bi?start=$r ",
 'parse_mode'=>"MarkDown",
 ]);
    								bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[کاربر $name یک چالش جدید ساخت](tg://user?id=$chat_id)
	
	🎁 جایزه :
	$text
		
		🌀 لینک دریافت جایزه : 

http://t.me/$bi?start=$r
		",
		    'parse_mode'=>'MarkDown',
	]);
}
//--------//
 elseif (strpos($text, '/start') !== false) {
        $chid = str_replace("/start ", "", $text);
 if (file_exists("ch/$chid/j.txt")) {
  if (!file_exists("data/$from_id/ali.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/ali.txt","none");
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
          
   								bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[کاربر $name هم اکنون از طریق چالش وارد ربات شد.](tg://user?id=$chat_id)
	تعداد عضو ها : $member_count
		
		",
		    'parse_mode'=>'MarkDown',
	]);
        }
     $a =   file_get_contents("ch/$chid/j.txt");
     $b =   file_get_contents("ch/$chid/chat_id.txt");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "🎗 تبریک `$name` عزیز شما برنده شدید!
                
💎 این چالش توسط کاربری با ایدی عددی $b ساخته شده است!
[ربات خود را بسازید](telegram.me/)

🎁 جایزه : 
$a",
                'parse_mode'=>"MarkDown",
                'reply_markup'=> json_encode([
                    'keyboard'=>[
                        [
                            ['text'=>"🔙 برگشت"]
                       ],
                        [
                     ['text'=>"🔸ساخت چالش"]
                     ]
                            ],
                            'resize_keyboard'=>true
                        ])
                ]);
                        bot('sendMessage', [
                'chat_id' => $b,
                'text' => "🔝 [کاربر $name برنده چالش شد!](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
            ]);
            unlink("ch/$chid/j.txt");
            unlink("ch/$chid/chat_id.txt");
            rmdir("ch/".$chid);
deleteFolder("ch/".$chid);
        } else {
          if (!file_exists("data/$from_id/ali.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/ali.txt","none");
        file_put_contents("data/$from_id/member.txt","0");
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
          
   								bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[کاربر $name هم اکنون از طریق چالش وارد ربات شد!](tg://user?id=$chat_id)
	
	تعداد عضو ها : $member_count
		
		",
		    'parse_mode'=>'MarkDown',
	]);
        }
        bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
اخ اخ  دیر رسیدی شما برنده نشدید😔
اشکال نداره دفع بود یکم تلاشتو بیشتر کن😏
",
 'parse_mode'=>"MarkDown",
            ]);
}

}
if($text == "🔙 برگشت"){
    bot('sendmessage' ,[
        'chat_id'=>$chat_id,
        'text'=>"↩️ به منوی اول برگشتیم حالا یک گزینه را انتخاب کنید!",
        'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [
              ['text'=>"🔸ساخت چالش"]
              ],
              [
              ['text'=>"😎 سازنده"],['text'=>"🔖 اطلاعات کاربری "]
              ]
              ],
              "resize_keyboard"=>true
        ])
 ]);
}
elseif($text == "/panel" &&$from_id == $admin){
        bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"☑️ سلام ادمین گرامی ( [$name](tg://user?id=$admin) ) به پنل مدیریت خودتون خوش اومدی!
🆔 @TeleGrmBOTs",
'parse_mode'=>'MarkDown',
      'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                  ['text'=>"🔙 برگشت"]
                  ],
                  [
              ['text'=>"👤 آمار"],['text'=>"🌟 تعداد چالش"]
              ],
              ],
            'resize_keyboard'=>true
        ])
            ]);
        }
elseif($text == "👤 آمار" && $from_id == $admin){
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member = count($member_id) -1;
 bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"😎 آمار اعضای ربات : $member",
]);
}
elseif($text == "🌟 تعداد چالش"){
    $chall = scandir("ch");
    $all = count ($chall) -2;
    bot('sendmessage' ,[
        'chat_id'=>$admin,
        'text'=>"🎗 تعداد کل چالش های باز : $all",
        'parse_mode'=>"MarkDown",
        ]);
}
unlink("error_log");


?>