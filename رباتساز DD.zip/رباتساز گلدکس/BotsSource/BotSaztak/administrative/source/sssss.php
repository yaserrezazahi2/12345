elseif($tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator' and $from_id != $admin | strpos($adminlist , "$from_id") == false and $channel_lock != null){
 SendChatAction($chat_id,"typing");
 SendMessage($chat_id,"دوست عزیز برای استفاده از ربات و همچنان حمایت از ما لطفا وارد کانال
➡ $channel_lock
شوید و join رو بزنید و سپس به ربات برگشته و دوباره ربات را استارت کنین.","html","true",$button_remove);





$truechannel1 = json_decode(file_get_contents("https://api.telegram.org/bot$TOKEN/getChatMember?chat_id=$channel_lock&user_id=$from_id"));
$tch1 = $truechannel1->result->status;