
<?php
ob_start();
error_reporting(0);
define('API_KEY','[*[TOKEN]*]');
//-----------------------------------------------------------------------------------------
//فانکشن jijibot :
function jijibot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function save($filename,$TXTdata){
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
//-----------------------------------------------------------------------------------------
//متغیر ها :
// msg
$Dev = array("[*[ADMIN]*]","[*[ADMIN]*]"); // put id of admins
$usernamebot = "[*[idbot]*]";
$token = API_KEY;
$look = file_get_contents("look.txt");
//-----------------------------------------------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$textmassage = $message->text;
$messageid = $update->callback_query->message->message_id;
$tc = $update->message->chat->type;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$data = $update->callback_query->data;
/*$textvip = file_get_contents("textvip.txt");*/
$command = file_get_contents("data/comnt.txt");
$channel = file_get_contents("channel.txt");
$b = file_get_contents("data/b.txt");

// ========================================================================
$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@$channel&user_id=".$from_id));
$tch = $forchannel->result->status;
//=================================================================================================
//فانکشن ها :
function SendMessage($chat_id, $text){
jijibot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
 function Forward($berekoja,$azchejaei,$kodompayam)
{
jijibot('ForwardMessage',[
'chat_id'=>$berekoja,
'from_chat_id'=>$azchejaei,
'message_id'=>$kodompayam
]);
}
//--------------------------------------------------------------
@$user = json_decode(file_get_contents("data/user.json"),true);
@$juser = json_decode(file_get_contents("data/$from_id.json"),true);
@$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
//==================================================================
function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 900;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
jijibot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"❌  جهت جلوگیری از اسپم ربات ، شما 15 دقیقه از ربات بلاک شدید ❌"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);


if($textmassage=="/start"){	
if(file_exists("data/$from_id.json")){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$textvip
	
	به ربات اعتراف گیر خوش اومدی😂😂
          این ربات یه نوع ربات اعتراف گیری هستش
سوالاتتو تو ربات ذخیره کن و لینک مخصوص خودتو بگیر و برای دوستات بفرست تا جواب سوالاتتو بگیری😜

لینک اختصاصیتو بگیر و برای دوستات فوروارد کن و ازشون بخواه تا فالشونو بگیرن و از آیندشون باخبر بشن..یکمی هم از ربات تعریف کن و بگو همه چیو درست جواب میده و خیلی عالیه و حتما امتحان کنن، تا به سوالاتون جواب بدن😜
بعضی دوستان میان میگن چرا جواب سوالا بهم ارسال نمیشه.. دقت کنین لینک مخصوص خودتونو برای دوستاتون ارسال کنید نه لینکی که از دوستتون گرفتین
فقط حواست باشه اگه میخوایی پیام ها بهت ارسال بشن حتما باید تو کانال ما عضو باشی",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"🔗 دریافت لینک من"],['text'=>"⁉️ تنظیم سوال"]
                ],
								                   [['text'=>"📍 درباره ربات"],['text'=>"سازنده ربات"]],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$textvip
	
	به ربات اعتراف گیر خوش اومدی😂😂
          این ربات یه نوع ربات اعتراف گیری هستش
سوالاتتو تو ربات ذخیره کن و لینک مخصوص خودتو بگیر و برای دوستات بفرست تا جواب سوالاتتو بگیری😜

لینک اختصاصیتو بگیر و برای دوستات فوروارد کن و ازشون بخواه تا فالشونو بگیرن و از آیندشون باخبر بشن..یکمی هم از ربات تعریف کن و بگو همه چیو درست جواب میده و خیلی عالیه و حتما امتحان کنن، تا به سوالاتون جواب بدن😜
بعضی دوستان میان میگن چرا جواب سوالا بهم ارسال نمیشه.. دقت کنین لینک مخصوص خودتونو برای دوستاتون ارسال کنید نه لینکی که از دوستتون گرفتین
فقط حواست باشه اگه میخوایی پیام ها بهت ارسال بشن حتما باید تو کانال ما عضو باشی",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"🔗 دریافت لینک من"],['text'=>"⁉️ تنظیم سوال"]
                ],
								               [['text'=>"📍 درباره ربات"],['text'=>"سازنده ربات"]],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["userfild"]["question"][]="اگر بهت بگن ۱ میلیارد برنده شدی،چقدرش به دیگران کمک میکنی؟ چرا؟";
$juser["userfild"]["question"][]="تاحالا عاشق شدی،اسمش چی بوده؟";
$juser["userfild"]["question"][]="تو زندگیت چه فردی رو بیشتر از همه دوست داری؟چرا؟";
$juser["userfild"]["question"][]="یکی از آرزو هات که هنوز برآورده نشده؟؟";
$juser["userfild"]["question"][]="تو زندگیت  آیا شده به‌کسی حسودی کنی و بخوای جاش باشی؟؟چرا؟؟";
$juser["userfild"]["question"][]="اگر بتونی به خاطره از گذشته زندگیت پاک کنی اون چیه؟چرا؟؟؟";
$juser["userfild"]["question"][]="بزرگترین دروغی که گفتی چی بوده؟؟";
$juser["userfild"]["question"][]="از کی بیشتر از همه نفرت داری ؟ چرا ؟؟؟";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif(strpos($textmassage , '/start ') !== false  ) {
$start = str_replace("/start ","",$textmassage);
if($start == $from_id) {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ای بابا نمیشه که خودت به خودت جواب بدی 😲
	
لینک دعوتت رو برای دوستات بفرست و اونارو دعوت کن و سوالاتت رو محرمانه بپرس ازشون 😅",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"🔗 دریافت لینک من"],['text'=>"⁉️ تنظیم سوال"]
                ],
								                   [['text'=>"📍 درباره ربات"],['text'=>"سازنده ربات"]],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else 
{
 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"سلام دوست من 
این ربات از 8 تا سوال میپرسه،اگر به این سوالات پاسخ درست بدی، اتفاقات  که در آینده قراره بیوفته واست رو شرح میده🤗اگر شگفت زده نشدی 😏 دیگه امتحان نکن☺️\n
💫اگر به فال و این موضوعات اعتقاد نداری ،من بهت پیشنهاد میکنم کمی وقت بذاری وبه سوالات پاسخ بدی ، مطمعن باش جوابی بهت میده که شگفت زده میشی 😲 و قدرت فال و ربات رو میبینی 
\n\n💥لطفا پس از دریافت جواب ،خونسردی خودتون رو حفظ کنید و اگر رضایت داشتین ربات به دوستان خودتون معرفی کنید ❤️",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"شروع ☺️😊"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"روی دکمه شروع کلیک کن و فالتو بگیر💛",
    		]);
	jijibot('sendmessage',[
	'chat_id'=>$start,
	'text'=>"یک نفر از طرف شما وارد ربات شد و اگر سوالات رو پر کرد من برات میفرستمشون 😄\n📍 کاربر : [$from_id](tg://user?id=$from_id)",
			 'parse_mode'=>"MarkDown",
    		]);
$juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["userfild"]["fal"]="$start";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}

elseif(json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$look&user_id=$from_id"))->result->status == "left" and file_exists("look.txt")){
    jijibot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"
برای استفاده از ربات ، در کانال زیر عضو شوید 👇

🔹 @$look   🔹 @$look
🔹 @$look  🔹 @$look

بعد از عضویت در کانال دوباره ربات را استارت بزنید

",

      'reply_markup'=>json_encode([
    'inline_keyboard'=>[
  [
  ['text'=>"🚀عضویت در کانال🚀",'url'=>"https://t.me/$look"]
  ],
    
              ]
        ])
        ]);

}
elseif($textmassage=="🔗 دریافت لینک من"&& $b == "b"){
    $baner = file_get_contents("data/baner.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$baner
t.me/$usernamebot?start=$from_id",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"پیام بالا رو به دوستات فوروارد کن و ازشون بخواه تا فالشونو بگیرن و از آیندشون باخبر بشن..یکمی هم از ربات تعریف کن و بگو همه چیو درست جواب میده و خیلی عالیه و حتما امتحان کنن، تا به سوالاتون جواب بدن😜
بعضی دوستان میان میگن چرا جواب سوالا بهم ارسال نمیشه.. دقت کنین لینک مخصوص خودتونو برای دوستاتون ارسال کنید نه لینکی که از دوستتون گرفتین
فقط حواست باشه اگه میخوایی پیام ها بهت ارسال بشن حتما باید تو کانال ما عضو باشی",
    		]);
}
elseif($textmassage=="🔗 دریافت لینک من"){
    $baner = file_get_contents("data/baner.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$baner
t.me/$usernamebot?start=$from_id",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"پیام بالا رو به دوستات فوروارد کن و ازشون بخواه تا فالشونو بگیرن و از آیندشون باخبر بشن..یکمی هم از ربات تعریف کن و بگو همه چیو درست جواب میده و خیلی عالیه و حتما امتحان کنن، تا به سوالاتون جواب بدن😜
بعضی دوستان میان میگن چرا جواب سوالا بهم ارسال نمیشه.. دقت کنین لینک مخصوص خودتونو برای دوستاتون ارسال کنید نه لینکی که از دوستتون گرفتین
فقط حواست باشه اگه میخوایی پیام ها بهت ارسال بشن حتما باید تو کانال ما عضو باشی",
    		]);
}

elseif($textmassage=="📍 درباره ربات"){	
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>" $textvip
این ربات یه نوع ربات اعتراف گیری هستش و هر سوالی که جواب دادین مستقیم به کسی که این ربات و بهتون معرفی کرد ارسال شده و ایشون سوالاتی که نمیتونست مستقیم ازتون بپرسه رو اینجا پرسیده جوابشو گرفت😂
    حالا دیگه اتفاقیه که افتاده و نمیشه کاریش کرد😜
    اگه تو هم سوالی داری که میخوایی از کسی بپرسی با این ربات میتونی سوالاتتو تو ربات ذخیره کنی و بعد لینک مخصوص خودتو بگیری و به دوستات بفرستی تا سوالاتتو جواب بدن و جوابشون مستقیم به تو ارسال بشه😍❤️️",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سوالاتتو تو ربات ذخیره کن و لینک مخصوص خودتو بگیر و برای دوستات بفرست تا جواب سوالاتتو بگیری😜",
    		]);
}

elseif($textmassage=="⁉️ تنظیم سوال"){	
$allqu = $juser["userfild"]["question"];
for($z = 0;$z <= count($allqu) -1;$z++){
$result1 = $result1."$z-".$allqu[$z]."\n";
$result2[]=$z;
}
if($result2[0] == 0){
$q0 = "📍ویرایش سوال 0";
$d0 = "🗑حذف سوال 0";
}
if($result2[1] == 1){
$q1 = "📍ویرایش سوال 1";
$d1 = "🗑حذف سوال 1";
}
if($result2[2] == 2){
$q2 = "📍ویرایش سوال 2";
$d2 = "🗑حذف سوال 2";
}
if($result2[3] == 3){
$q3 = "📍ویرایش سوال 3";
$d3 = "🗑حذف سوال 3";
}
if($result2[4] == 4){
$q4 = "📍ویرایش سوال 4";
$d4 = "🗑حذف سوال 4";
}
if($result2[5] == 5){
$q5 = "📍ویرایش سوال 5";
$d5 = "🗑حذف سوال 5";
}
if($result2[6] == 6){
$q6 = "📍ویرایش سوال 6";
$d6 = "🗑حذف سوال 6";
}
if($result2[7] == 7){
$q7 = "📍ویرایش سوال 7";
$d7 = "🗑حذف سوال 7";
}
if($result2[8] == 8){
$q8 = "📍ویرایش سوال 8";
$d8 = "🗑حذف سوال 8";
}
if($result2[9] == 9){
$q9 = "📍ویرایش سوال 9";
$d9 = "🗑حذف سوال 9";
}
if($result2[10] == 10){
$q10 = "📍ویرایش سوال 10";
$d10 = "🗑حذف سوال 10";
}
if($result2[11] == 11){
$q11 = "📍ویرایش سوال 11";
$d11 = "🗑حذف سوال 11";
}
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎫 قصد تغییر سوال چندم را دارید؟
❓ سوالات فعلی:

`$result1`

توجه : اگر سوالی را خودتان تنظیم نکنید سوالات پیش فرض ربات از آنها پرسیده خواهد شد پس جای نگرانی نیست 😉

اگه میخوای سوالات به تنظیمات اولیه برگرده از دکمه ریستارت استفاده کنید",
'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
  [
['text'=>"$q0",'callback_data'=>'text1'],['text'=>"$q1",'callback_data'=>'text2']
                ],
     [
['text'=>"$q2",'callback_data'=>'text3'],['text'=>"$q3",'callback_data'=>'text4']
                ],
        [
['text'=>"$q4",'callback_data'=>'text5'],['text'=>"$q5",'callback_data'=>'text6']
                ],
	  [
['text'=>"$q6",'callback_data'=>'text7'],['text'=>"$q7",'callback_data'=>'text8']
                ],
					  [
['text'=>"$q8",'callback_data'=>'text9'],['text'=>"$q9",'callback_data'=>'text10']
                ],
					  [
['text'=>"$q10",'callback_data'=>'text11'],['text'=>"$q11",'callback_data'=>'text12']
                ],
  [
['text'=>"$d0",'callback_data'=>'remove1'],['text'=>"$d1",'callback_data'=>'remove2']
                ],
     [
['text'=>"$d2",'callback_data'=>'remove3'],['text'=>"$d3",'callback_data'=>'remove4']
                ],
        [
['text'=>"$d4",'callback_data'=>'remove5'],['text'=>"$d5",'callback_data'=>'remove6']
                ],
	  [
['text'=>"$d6",'callback_data'=>'remove7'],['text'=>"$d7",'callback_data'=>'remove8']
                ],
					  [
['text'=>"$d8",'callback_data'=>'remove9'],['text'=>"$d9",'callback_data'=>'remove10']
                ],
					  [
['text'=>"$d10",'callback_data'=>'remove11'],['text'=>"$d11",'callback_data'=>'remove12']
                ],
								 [
 ['text'=>"🔄 ریستارت",'callback_data'=>'restart'],['text'=>"🌟 افزودن سوال",'callback_data'=>'addqu']
					 ],
            ]
        ])
        ]);
}

elseif($data=="qu"){
$allqu = $cuser["userfild"]["question"];
for($z = 0;$z <= count($allqu) -1;$z++){
$result1 = $result1."$z-".$allqu[$z]."\n";
$result2[]=$z;
}
if($result2[0] == 0){
$q0 = "📍ویرایش سوال 0";
$d0 = "🗑حذف سوال 0";
}
if($result2[1] == 1){
$q1 = "📍ویرایش سوال 1";
$d1 = "🗑حذف سوال 1";
}
if($result2[2] == 2){
$q2 = "📍ویرایش سوال 2";
$d2 = "🗑حذف سوال 2";
}
if($result2[3] == 3){
$q3 = "📍ویرایش سوال 3";
$d3 = "🗑حذف سوال 3";
}
if($result2[4] == 4){
$q4 = "📍ویرایش سوال 4";
$d4 = "🗑حذف سوال 4";
}
if($result2[5] == 5){
$q5 = "📍ویرایش سوال 5";
$d5 = "🗑حذف سوال 5";
}
if($result2[6] == 6){
$q6 = "📍ویرایش سوال 6";
$d6 = "🗑حذف سوال 6";
}
if($result2[7] == 7){
$q7 = "📍ویرایش سوال 7";
$d7 = "🗑حذف سوال 7";
}
if($result2[8] == 8){
$q8 = "📍ویرایش سوال 8";
$d8 = "🗑حذف سوال 8";
}
if($result2[9] == 9){
$q9 = "📍ویرایش سوال 9";
$d9 = "🗑حذف سوال 9";
}
if($result2[10] == 10){
$q10 = "📍ویرایش سوال 10";
$d10 = "🗑حذف سوال 10";
}
if($result2[11] == 11){
$q11 = "📍ویرایش سوال 11";
$d11 = "🗑حذف سوال 11";
}
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🎫 قصد تغییر سوال چندم را دارید؟
❓ سوالات فعلی:

`$result1`

توجه : اگر سوالی را خودتان تنظیم نکنید سوالات پیش فرض ربات از آنها پرسیده خواهد شد پس جای نگرانی نیست 😉

اگه میخوای سوالات به تنظیمات اولیه برگرده از دکمه ریستارت استفاده کنید",
'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
  [
['text'=>"$q0",'callback_data'=>'text1'],['text'=>"$q1",'callback_data'=>'text2']
                ],
     [
['text'=>"$q2",'callback_data'=>'text3'],['text'=>"$q3",'callback_data'=>'text4']
                ],
        [
['text'=>"$q4",'callback_data'=>'text5'],['text'=>"$q5",'callback_data'=>'text6']
                ],
	  [
['text'=>"$q6",'callback_data'=>'text7'],['text'=>"$q7",'callback_data'=>'text8']
                ],
					  [
['text'=>"$q8",'callback_data'=>'text9'],['text'=>"$q9",'callback_data'=>'text10']
                ],
					  [
['text'=>"$q10",'callback_data'=>'text11'],['text'=>"$q11",'callback_data'=>'text12']
                ],
  [
['text'=>"$d0",'callback_data'=>'remove1'],['text'=>"$d1",'callback_data'=>'remove2']
                ],
     [
['text'=>"$d2",'callback_data'=>'remove3'],['text'=>"$d3",'callback_data'=>'remove4']
                ],
        [
['text'=>"$d4",'callback_data'=>'remove5'],['text'=>"$d5",'callback_data'=>'remove6']
                ],
	  [
['text'=>"$d6",'callback_data'=>'remove7'],['text'=>"$d7",'callback_data'=>'remove8']
                ],
					  [
['text'=>"$d8",'callback_data'=>'remove9'],['text'=>"$d9",'callback_data'=>'remove10']
                ],
					  [
['text'=>"$d10",'callback_data'=>'remove11'],['text'=>"$d11",'callback_data'=>'remove12']
                ],
								 [
 ['text'=>"🔄 ریستارت",'callback_data'=>'restart'],['text'=>"🌟 افزودن سوال",'callback_data'=>'addqu']
					 ],
            ]
        ])
        ]);
$cuser["userfild"]["step"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
elseif($data=="text1" or $data=="text2" or $data=="text3" or $data=="text4" or $data=="text5" or $data=="text6" or $data=="text7" or $data=="text8" or $data=="text9" or $data=="text10" or $data=="text11" or $data=="text12"){
$text = str_replace("text","",$data);
$textplus = $text - 1;
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"ℹ️ شما در حال ویرایش سوال $textplus هستید
	
📌 متن سوال رو ارسال کن دوست من",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
									 [
					 ['text'=>"🔙 برگشت",'callback_data'=>'qu']
					 ],
            ]
        ])
        ]);
$cuser["userfild"]["step"]="getedit";
$cuser["userfild"]["editqu"]="$textplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
elseif($textmassage=="سازنده ربات"){	

			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"[سازنده](t.me/$channel)",
	'parse_mode'=>'MarkDown',
    		]);
}
elseif($data=="remove1" or $data=="remove2" or $data=="remove3" or $data=="remove4" or $data=="remove5" or $data=="remove6" or $data=="remove7" or $data=="remove8" or $data=="remove9" or $data=="remove10" or $data=="remove11" or $data=="remove12"){
$text = str_replace("remove","",$data);
$textplus = $text - 1;
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"ℹ️ سوال شماره $textplus با موفقیت پاک شد",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
									 [
					 ['text'=>"🔙 برگشت",'callback_data'=>'qu']
					 ],
            ]
        ])
        ]);
unset($cuser["userfild"]["question"]["$textplus"]);
$cuser["userfild"]["question"] = array_values($cuser["userfild"]["question"]); 
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
elseif($data=="restart"){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"ℹ️ سوالات شما با موفقیت ریستارت شد و به حالت اولیه برگشت",
	        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
									 [
					 ['text'=>"🔙 برگشت",'callback_data'=>'qu']
					 ],
            ]
        ])
    		]);
unset($cuser["userfild"]["question"]);
$cuser["userfild"]["question"][]="اگر بهت بگن ۱ میلیارد برنده شدی،چقدرش به دیگران کمک میکنی؟ چرا؟";
$cuser["userfild"]["question"][]="تاحالا عاشق شدی،اسمش چی بوده؟";
$cuser["userfild"]["question"][]="تو زندگیت چه فردی رو بیشتر از همه دوست داری؟چرا؟";
$cuser["userfild"]["question"][]="یکی از آرزو هات که هنوز برآورده نشده؟؟";
$cuser["userfild"]["question"][]="تو زندگیت  آیا شده به‌کسی حسودی کنی و بخوای جاش باشی؟؟چرا؟؟";
$cuser["userfild"]["question"][]="اگر بتونی به خاطره از گذشته زندگیت پاک کنی اون چیه؟چرا؟؟؟";
$cuser["userfild"]["question"][]="بزرگترین دروغی که گفتی چی بوده؟؟";
$cuser["userfild"]["question"][]="از کی بیشتر از همه نفرت داری ؟ چرا ؟؟؟";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
elseif($data=="addqu"){
$allgetque = count($cuser["userfild"]["question"]);
if($allgetque <= 11){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"❓ متن سوال $allgetque را وارد کنید",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
									 [
					 ['text'=>"🔙 برگشت",'callback_data'=>'qu']
					 ],
            ]
        ])
    		]);
$cuser["userfild"]["step"]="editqu";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"📍 بیش تر این نمیتوانید سوال اضافه کنید",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
									 [
					 ['text'=>"🔙 برگشت",'callback_data'=>'qu']
					 ],
            ]
        ])
    		]);
}
}
elseif($textmassage == 'شروع ☺️😊'){
$get = $juser["userfild"]["fal"];
$inuser = json_decode(file_get_contents("data/$get.json"),true);
$q = $inuser["userfild"]["question"][0];
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$q",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"📍تایپ نمی کنم بریم سوال بعدی"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["step"]="getfal";
$juser["userfild"]["getque"]="1";
unset($juser["userfild"]["answer"]);
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}

elseif($juser["userfild"]["step"] == "getfal" ){
$get = $juser["userfild"]["fal"];
$getque = $juser["userfild"]["getque"]; 
$inuser = json_decode(file_get_contents("data/$get.json"),true);
$allgetque = count($inuser["userfild"]["question"]);
if($getque < $allgetque){
if($textmassage != "📍تایپ نمی کنم بریم سوال بعدی"){
$q = $inuser["userfild"]["question"][$getque];
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$q",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"📍تایپ نمی کنم بریم سوال بعدی"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$getqueplus = $getque + 1 ;
$downgetqu = $getque - 1 ;
$juser["userfild"]["getque"]="$getqueplus";
$juser["userfild"]["answer"][$downgetqu]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
$q = $inuser["userfild"]["question"][$getque];
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$q",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"📍تایپ نمی کنم بریم سوال بعدی"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$getqueplus = $getque + 1 ;
$downgetqu = $getque - 1 ;
$juser["userfild"]["getque"]="$getqueplus";
$juser["userfild"]["answer"][$downgetqu]="پاسخ نداد !";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
else
{
$juser["userfild"]["answer"][]="$textmassage";
$allqu = $juser["userfild"]["answer"];
$allin = $inuser["userfild"]["question"];
for($z = 0;$z <= count($allqu) -1;$z++){
$result = $result."🌟 $allin[$z]\n`📍 $allqu[$z]`\n➖➖➖"."\n";
}
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"نتیجه فال شما به این صورت میباشد👇👇👇",
    		]);
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"به ربات اعتراف گیر خوش اومدی😂😂
این ربات یه نوع ربات اعتراف گیری هستش و هر سوالی که جواب دادین مستقیم به کسی که این ربات و بهتون معرفی کرد ارسال شده و ایشون سوالاتی که نمیتونست مستقیم ازتون بپرسه رو اینجا پرسیده جوابشو گرفت😂
حالا دیگه اتفاقیه که افتاده و نمیشه کاریش کرد😜
اگه تو هم سوالی داری که میخوایی از کسی بپرسی با این ربات میتونی سوالاتتو تو ربات ذخیره کنی و بعد لینک مخصوص خودتو بگیری و به دوستات بفرستی تا سوالاتتو جواب بدن و جوابشون مستقیم به تو ارسال بشه😍",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"🔗 دریافت لینک من"],['text'=>"⁉️ تنظیم سوال"]
                ],
								                   [['text'=>"📍 درباره ربات"],['text'=>"سازنده ربات"]],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سوالاتتو تو ربات ذخیره کن و لینک مخصوص خودتو بگیر و برای دوستات بفرست تا جواب سوالاتتو بگیری😜\n\n\n
🚫دوست من مسولیت استفاده این ربات برعهده خود شماست 
این ربات جنبه فان داره هر گونه مشکلی به وجود بیاد بر عهده خود شماست 🌹
امیدوارم لذت ببرید",
    		]);
jijibot('sendmessage',[
	'chat_id'=>$get,
	'text'=>"🎉 یک نفر به سوالات پاسخ داد 😍
	
$result
🌟 پروفایلش : [$from_id](tg://user?id=$from_id)",
'parse_mode'=>'MarkDown'
    		]);
$juser["userfild"]["question"][0]="1- اگر بهت بگن ۱ میلیارد برنده شدی،چقدرش به دیگران کمک میکنی؟ چرا؟";
$juser["userfild"]["question"][1]="2- تاحالا عاشق شدی،اسمش چی بوده؟";
$juser["userfild"]["question"][2]="3- تو زندگیت چه فردی رو بیشتر از همه دوست داری؟چرا؟";
$juser["userfild"]["question"][3]="4- یکی از آرزو هات که هنوز برآورده نشده؟؟";
$juser["userfild"]["question"][4]="5- تو زندگیت  آیا شده به‌کسی حسودی کنی و بخوای جاش باشی؟؟چرا؟؟";
$juser["userfild"]["question"][5]="6- اگر بتونی به خاطره از گذشته زندگیت پاک کنی اون چیه؟چرا؟؟؟";
$juser["userfild"]["question"][6]="7- بزرگترین دروغی که گفتی چی بوده؟؟";
$juser["userfild"]["question"][7]="8- از کی بیشتر از همه نفرت داری ؟ چرا ؟؟؟";
$juser["userfild"]["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif($juser["userfild"]["step"] == "getedit"){
$get = $juser["userfild"]["editqu"];
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"متن سوال $get تنظیم شد  ✅",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"🔗 دریافت لینک من"],['text'=>"⁉️ تنظیم سوال"]
                ],
								                   [['text'=>"📍 درباره ربات"],['text'=>"سازنده ربات"]],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["step"]="none";
$juser["userfild"]["question"][$get]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
elseif($juser["userfild"]["step"] == "editqu"){
$allgetque = count($juser["userfild"]["question"]);
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سوال $allgetque اضافه شد ✅",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"🔗 دریافت لینک من"],['text'=>"⁉️ تنظیم سوال"]
                ],
								                 [['text'=>"📍 درباره ربات"],['text'=>"سازنده ربات"]],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["step"]="none";
$juser["userfild"]["question"][]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
//==============================================================
//panel admin
elseif($textmassage=="/panel" or $textmassage=="panel" or $textmassage=="مدیریت"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
jijibot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 ادمین عزیز به پنل مدریت ربات خوش امدید",
         'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"]                 
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
	  	[
	  	    	  ["text"=>"تنظیم بنر"]],

   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
}
elseif($textmassage=="برگشت 🔙"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
jijibot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 به منوی مدیریت بازگشتید",
         'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"]                 
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
	  	[
	  ["text"=>"تنظیم بنر"]],
	  	 
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
}
elseif($textmassage=="📍 امار ربات"){
if (in_array($from_id,$Dev)){
$files1 = scandir("data/");
$all = count($files1);
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖 امار ربات شما : 
		
📌 تعداد عضو ها : $all",
                'hide_keyboard'=>true,
		]);
		}
}
elseif ($textmassage == '📍 ارسال به همه') {
if (in_array($from_id,$Dev)){
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا متن خود را ارسال کنید 🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="sendtoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["file"] == 'sendtoall') {
$juser["userfild"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
if ($textmassage != "برگشت 🔙") {
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام با موفقیت ارسال شد ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
$files = glob('data/*.*');
foreach($files as $file) {
    $file = pathinfo($file);
$mmd = $file['filename'];
     jijibot('sendmessage',[
          'chat_id'=>$mmd,        
		  'text'=>"$textmassage",
        ]);
sleep(5);
}
}
}
elseif ($textmassage == '📍 فروارد همگانی') {
if (in_array($from_id,$Dev)){
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا متن خود را ارسال کنید 🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="fortoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["file"] == 'fortoall') {
$juser["userfild"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
if ($textmassage != "برگشت 🔙") {
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام با موفقیت ارسال شد ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
$files = glob('data/*.*');
foreach($files as $file) {
    $file = pathinfo($file);
$mmd = $file['filename'];
Forward($mmd, $chat_id,$message_id);
sleep(5);
}
}
}

elseif ($textmassage == 'تنظیم بنر') {
      save("data/comnt.txt","bnr");
 jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا بنر تبلیغات خودتون ارسال کنید لینک دعوت هر نفر اتماتیک زیر بنر قرار داده میشه:",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);}
   elseif($command == 'bnr'){
             save("data/baner.txt","$textmassage");
                   save("data/comnt.txt","non");
       jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"بنر با موفقیت تنظیم شد لینک خصوصی هر کاربر زیر بنر قرار میگیره",
	       'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"]                 
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
	  	[["text"=>"تنظیم بنر"]],
	  
   ],
      'resize_keyboard'=>true
   ])
 ]);}

      unlink("error_log");

?>