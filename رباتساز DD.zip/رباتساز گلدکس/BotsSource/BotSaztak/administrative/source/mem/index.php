<?php
set_time_limit(0);

flush();

include("jdf.php");

$API_KEY = '[*[TOKEN]*]';
	##------------------------------##
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown"
    ]);
}

function deletemessage($chat_id, $message_id)
{
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function sendaction($chat_id, $action)
{
    bot('sendchataction', [
        'chat_id' => $chat_id,
        'action' => $action
    ]);
}

function Forward($KojaShe, $AzKoja, $KodomMSG)
{
    bot('ForwardMessage', [
        'chat_id' => $KojaShe,
        'from_chat_id' => $AzKoja,
        'message_id' => $KodomMSG
    ]);
}

function sendphoto($chat_id, $photo, $action)
{
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'action' => $action
    ]);
}

function objectToArrays($object)
{
    if (!is_object($object) && !is_array($object)) {
        return $object;
    }
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    return array_map("objectToArrays", $object);
}
function save2($filename,$TXTdata)
  {
  $myfile = fopen($filename, "a") or die("Unable to open file!");
  fwrite($myfile, "$TXTdata");
  fclose($myfile);
  }
  function ttoopp($number){ 
 $saveusers = array(); 
  $usersscan = scandir("data"); 
  unset($usersscan[0]); 
  unset($usersscan[1]); 
  foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("data/$savetojs/members.txt"); 
$saveusers[$savetojs] = $savedis; 
  } 
  $rating = $saveusers; 
    arsort($rating,SORT_NUMERIC);  
    $rate = array();  
    foreach($rating as $key=>$value){  
      $rate[] = $key;  
    }  
    return $rate[$number];  
}
function top_sea($number){ 
 $saveusers = array(); 
  $usersscan = scandir("data"); 
  unset($usersscan[0]); 
  unset($usersscan[1]); 
  foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("data/$savetojs/mosak.txt"); 
$saveusers[$savetojs] = $savedis; 
  } 
  $rating = $saveusers; 
    arsort($rating,SORT_NUMERIC);  
    $rate = array();  
    foreach($rating as $key=>$value){  
      $rate[] = $key;  
    }  
    return $rate[$number];  
}
//====================WHITE ™======================//
	$update = json_decode(file_get_contents('php://input'));
    $danesh = $update->message->reply_to_message->forward_from->id;
	$message = $update->message;
	$channel_post = $update->message->channel_post;
	$code = file_get_contents("data/code.txt");
	$code2 = file_get_contents("data/code2.txt");
	$name = $update->message->from->first_name;
    $username = $update->message->from->username;
	$chid = $update->channel_post->message->message_id;
	$chat_id = $message->chat->id;
	$chatid = $update->callback_query->message->message_id;
	$message_id = $message->message_id;
	$from_id = $message->from->id;
	$c_id = $message->forward_from_chat->id;
	$forward_id = $update->message->forward_from->id;
	$forward_chat = $update->message->forward_from_chat;
	$forward_chat_username = $update->message->forward_from_chat->username;
	$forward_chat_msg_id = $update->message->forward_from_message_id;
	@$shoklt = file_get_contents("data/$chat_id/mosak.txt");
	@$penlist = file_get_contents("data/pen.txt");
	$text = $message->text;
	@mkdir("data/$chat_id");
	$idddd = $update->message->message_id;
	@$saeed = file_get_contents("data/$chat_id/saeed.txt");
	@$list = file_get_contents("users.txt");
	$ADMIN = [*[ADMIN]*];
	$botid = file_get_contents("data/botid.txt");
	$adminid = white_sudo;
	$chnnnel = file_get_contents("channel.txt");
	$channelid = file_get_contents("data/channel2.txt");
    $channeltabid = file_get_contents("data/channel1.txt");;
	$idbot = file_get_contents("data/idbot.txt");
	$look = file_get_contents("look.txt");
	$channel = file_get_contents("data/channel.txt");
	$channel2 = file_get_contents("data/channel2.txt");
    $step = file_get_contents("data/".$from_id."/step.txt");
    $coin = file_get_contents("data/$from_id/coin.txt");
    $member = file_get_contents("data/".$from_id."/member.txt");
    $member2 = file_get_contents("data/".$from_id."/member2.txt");
    $price = file_get_contents("data/".$from_id."/price.txt");
    $count = file_get_contents("data/channels/count.txt");
    $fn = file_get_contents("data/channels/fnumber.txt");
    $little = file_get_contents("data/".$from_id."/little.txt");
	$listbon = file_get_contents("data/pen.txt");
	$chatid = $update->callback_query->message->chat->id;
	$data = $update->callback_query->data;
	$message_id2 = $update->callback_query->message->message_id;
	$fromm_id = $update->inline_query->from->id;
    $fromm_user = $update->inline_query->from->username;
	$inline_query = $update->inline_query;
	$photo = $update->message->photo;
	$query_id = $inline_query->id;
    $cuphoto = $getuserprofile->total_count;
	$getuserphoto = $getuserprofile->photos[0][0]->file_id;
	$inch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@white_program&user_id=$from_id"))->result->status;
$inch2 = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@yourmembers&user_id=$from_id"))->result->status;
	$fatime = jdate("h:i:s");
	$fadate = jdate("Y F d");
	$floodtime = FILE_GET_CONTENTS("data/$chat_id/moderation/floodtime.txt");
	//====================WHITE ™======================//
$admin_keyboard = json_encode([
			'resize_keyboard'=>true,
                'keyboard' => [
                   [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
					[
                        ['text' => "✅سکه همه گانی💰"]
                    ],
                    [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ],
                    [
                        ['text' => "📢 کانال تبلیغات"], ['text' => "ارسال پیام🔥"]
                    ],
                    [
                        ['text' => "💸 سکه به کاربر"],['text' => "🔱کسر کسه از کاربر🔱"]
                    ],
                    [
                        ['text' => "کانال تبلیغات"]
                    ],
                    [
                        ['text' => "کانال اخبار"]
                    ],
                    [
                        ['text' => "تنظیم ای دی ربات"]
                    ],
					[
					['text'=>"بازگشت🔙"]
					]
                ]
            ]);
			$back_keyboard = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
         [['text'=>"🔚 برگشت به منوی ادمین"]]
         ]
     ]);
	 //_______
function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 900;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"❌  جهت جلوگیری از اسپم ربات ، شما 15 دقیقه از ربات بلاک شدید ❌"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
	 if ($text == "/start") {
      $user = file_get_contents('users.txt');
      $members = explode("\n", $user);
      if (!in_array($from_id, $members)) {
        $add_user = file_get_contents('users.txt');
        $add_user .= $from_id . "\n";
        file_put_contents("data/$chat_id/membrs.txt", "0");
        file_put_contents("data/$chat_id/mosak.txt", "5");
        file_put_contents("data/$chat_id/asm.txt", $name);
        file_put_contents("data/$chat_id/mam.txt", $username);
        file_put_contents("data/$chat_id/svd.txt", $fatime);
        file_put_contents("data/$chat_id/tvd.txt", $fadate);
        file_put_contents('users.txt', $add_user);
      }
      file_put_contents("data/$chat_id/saeed.txt", "no");
	  sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "سلام👋🏻😉

به ربات ممبرگیر ما خوش آمدی👻 برای استفاده یکی از دکمه های زیر را بفرست!"
,
'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'keyboard'=>[
[['text'=>"💫🎲دریافت سکه رایگان🎲💫"]],
[['text'=>"🔐مشخصات کاربری"],['text'=>"ثبت تبلیغ🎯"],['text'=>"عابر بانک📥"]],
[['text'=>"پشتیبانی☎️"],['text'=>"کاربران برتر🌐"]]
]
])
]);
}


elseif(json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$look&user_id=$from_id"))->result->status == "left" and file_exists("look.txt")){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"
برای استفاده از ربات ، در کانال زیر عضو شوید 👇

🔹 @$look   🔹 @$look
🔹 @$look  🔹 @$look

بعد از عضویت در کانال دوباره ربات را استارت بزنید

",

      'reply_markup'=>json_encode([
    'inline_keyboard'=>[
  [
  ['text'=>"🚀عضویت در کانال🚀",'url'=>"https://t.me/$look"]
  ],
    
              ]
        ])
        ]);

}





	  elseif (strpos($penlist, "$from_id")) {
      SendMessage($chat_id, "کاربر گرامی شما از سرور ما مسدود شده اید لطفا دیگر پیام نفرستید
  باتشکر
  اگر اشتباهی مسدود شدید به مدیریت خبر دهید تا شمارا ازاد کند 👈ادمین");
    } elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
      $newid = str_replace("/start ", "", $text);
      if ($from_id == $newid) {
        bot('sendMessage', [
          'chat_id' => $chat_id,
          'text' => "عوت خود عضو ربات شوید و سکه ای دریافت نمی کنید✅",
        ]);
      } elseif (strpos($list, "$from_id") !== false) {
        SendMessage($chat_id, "شما قبلا در این ربات عضو شده بودید و نمی توانید با لینک اختصاصی دوستتان عضو ربات شوید");
      } else {
        sendAction($chat_id, 'typing');
        @$sho = file_get_contents("data/$newid/mosak.txt");
        $getsho = $sho + 10;
        file_put_contents("data/$newid/mosak.txt", $getsho);
        @$sea = file_get_contents("data/$newid/membrs.txt");
        $getsea = $sea + 1;
        file_put_contents("data/$newid/membrs.txt", $getsea);
        $user = file_get_contents('users.txt');
        $members = explode("\n", $user);
        if (!in_array($from_id, $members)) {
          $add_user = file_get_contents('users.txt');
          $add_user .= $from_id . "\n";
          file_put_contents("data/$chat_id/membrs.txt", "0");
          file_put_contents("data/$chat_id/mosak.txt", "10");
        file_put_contents("data/$chat_id/asm.txt", $name);
        file_put_contents("data/$chat_id/mam.txt", $username);
        file_put_contents("data/$chat_id/svd.txt", $fatime);
        file_put_contents("data/$chat_id/tvd.txt", $fadate);
          file_put_contents('users.txt', $add_user);
        }
        file_put_contents("data/$chat_id/saeed.txt", "No");
		sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "سلام👋🏻😉

به ربات ممبرگیر ما خوش آمدی👻 برای استفاده یکی از دکمه های زیر را بفرست!",
'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'keyboard'=>[
[['text'=>"💫🎲دریافت سکه رایگان🎲💫"]],
[['text'=>"🔐مشخصات کاربری"],['text'=>"ثبت تبلیغ🎯"],['text'=>"عابر بانک📥"]],
[['text'=>"پشتیبانی☎️"],['text'=>"کاربران برتر🌐"]]
]
])
]);
SendMessage($newid, "کاربر جدیدی وارد ربات شد...!
چت آیدی شخص🙃👈 : [$chat_id](https://t.me/$username)
شما 10 سکه💰  گرفتی!
سکه های شما :💰 $sho");
      }
		
}
elseif ($data == "home") {
			bot('answercallbackquery', [
				'callback_query_id' => $update->callback_query->id,
				'text' => "کمی صبر کنید",
				'show_alert' => false
			]);
			file_put_contents("data/$chatid/saeed.txt", "no");
		sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "به منوی اصلی بازگشتید💉",
'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
   'resize_keyboard'=>true,
                'keyboard'=>[
[['text'=>"💫🎲دریافت سکه رایگان🎲💫"]],
[['text'=>"🔐مشخصات کاربری"],['text'=>"ثبت تبلیغ🎯"],['text'=>"عابر بانک📥"]],
[['text'=>"پشتیبانی☎️"],['text'=>"کاربران برتر🌐"]],
]
])
]);
}
if ($text == "بازگشت🔙") {
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
            'text' => "به منوی اصلی بازگشتید💉🕍",
'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'keyboard' => [
[['text'=>"💫🎲دریافت سکه رایگان🎲💫"]],
[['text'=>"🔐مشخصات کاربری"],['text'=>"ثبت تبلیغ🎯"],['text'=>"عابر بانک📥"]],
[['text'=>"پشتیبانی☎️"],['text'=>"کاربران برتر🌐"]],
                ]
            ])
        ]);

    }
	if ($text == "کاربران برتر🌐") { 
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "برای ادامه کلیک کنید...!",
'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
					[
                        ['text' => "کاربران برتر🌐", 'callback_data' => "fvjvdk"]
                    ]
					
                ]
            ])
        ]);
    }
	elseif ($data == "fvjvdk") {
 $kandom1 = ttoopp(0);
 $kandom2 = ttoopp(1);
 $kandom3 = ttoopp(2);
 //////////////////////
 $member1 = top_sea(0);
 $member2 = top_sea(1);
 $member3 = top_sea(2);
 //////////////////////
 $mosak1 = file_get_contents("data/$member1/membrs.txt");
 $mosak2 = file_get_contents("data/$member2/membrs.txt");
 $mosak3 = file_get_contents("data/$member3/membrs.txt");
 //////////////////////
 $kandom11 = file_get_contents("data/$kandom1/mosak.txt");
 $kandom22 = file_get_contents("data/$kandom2/mosak.txt");
 $kandom33 = file_get_contents("data/$kandom3/mosak.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "🏆نفرات برتر مسابقه در جمع اوری زیرمجموعه :
 
🏅نفر اول: [$member1](tg://user?id=$member1) 
🏛تعداد: $mosak1
 

🏅نفر دوم: [$member2](tg://user?id=$member2)
🏛تعداد: $mosak2


🏅نفر سوم: [$member3](tg://user?id=$member3)
🏛تعداد: $mosak3

/////////////////////

نفرات برتر در جمع اوری سکه 💰:
 
🏅نفر اول: [$kandom1](tg://user?id=$kandom1) 
🚀 تعداد : $kandom11
 

🏅نفر دوم: [$kandom2](tg://user?id=$kandom2)
🚀 تعداد: $kandom22


🏅نفر سوم: [$kandom3](tg://user?id=$kandom3)
🚀 تعداد: $kandom33


ایدی عددی شما : $chatid 👨‍💻",
 				'parse_mode'=>'MarkDown',
        ]);
		}
	if ($text == "💫🎲دریافت سکه رایگان🎲💫") { 
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "به بخش 💫🎲دریافت سکه رایگان🎲💫 -  ممبر شما - خوش آمدید.

💰- در این بخش می توانید  با عضو شدن توی کانال های که آیدی هاشونو توی چنل تبلیغات هست سکه دریافت کنید",
'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "دیدن تبلیغات در کانال و دریافت ممبر", 'url' => "https://t.me/$channeltabid"]
                    ],
                    
					[
                        ['text' => "زیر مجموعه گیری💠", 'callback_data' => "b"]
                    ],
					[
                        ['text' => "سکه روزانه🕒", 'callback_data' => "j"]
                    ],
                    [
                        ['text' => "سازنده", 'url' => "https://t.me/$chnnnel"]
                    ],
					
                ]
            ])
        ]);
    }
	elseif ($data == "b") {
        $zirseke = file_get_contents("data/zirseke.txt");


       sendAction($chatid, 'typing');
      bot('sendphoto', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
             'photo'=>"http://uupload.ir/files/7adr_img_20180327_200512_610.jpg",
        'caption'=>"ممبرگیر شما ، یک ایده جدید ! 👥

👥 افزایش ممبر های کانال و گروه شما
✅ زیر مجموعه گیری با ۲۰ درصد پورسانت
https://telegram.me/$botid?start=$chatid",
        ]);
           } 
		   elseif ($data == "j") {
        date_default_timezone_set('Asia/Tehran');
        $date = date('Ymd');
        @$gettime = file_get_contents("data/$chatid/dates.txt");
        if ($gettime == $date) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "سکه دریافت شده بود",
                'show_alert' => true
            ]);
        } else {
            file_put_contents("data/$chatid/dates.txt", $date);
            @$sho = file_get_contents("data/$chat_id/mosak.txt");
            $ran = rand(1, 5);
            $getsho = $sho + $ran;
            file_put_contents("data/$chat_id/mosak.txt", $getsho);
            $sho2 = file_get_contents("data/$chat_id/mosak.txt");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "$ran گرفتی...!",
                'show_alert' => true
            ]);
        }
    }
	if ($text == "🔐مشخصات کاربری") {
        sendAction($chat_id, 'typing');
        @$sho = file_get_contents("data/$chat_id/mosak.txt");
        @$sea = file_get_contents("data/$chat_id/membrs.txt"); 		
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
                  'text' => " 🔻صفحه مشخصات کاربری

🔵 آیدی تلگرامی : $chat_id
🤖 آیدی رباتی : @$username
🏵 نوع پنل : برنزی
🔻

💰♻️ کله سکه ها : $sho 🏵
💰🎁 هدیه های مدیریت : 10

🔻
👥♻️ کل زیرمجموعه ها : $sea

ربات ممبرگیر شما!",
               ]);
    } 
	if ($text == "پشتیبانی☎️") {
       sendAction($chat_id, 'typing');
		bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
        'text' => "برای ادامه کیلیک کنید!",
        'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
					[
                        ['text' => "صندوق پیام", 'callback_data' => "daryaftpayam"]
                ],
                [
                        ['text' => "ارسال پیام", 'callback_data' => "se"]
                ],
                    ]
                ])
            ]);
	}
	elseif ($data == "se") {
         file_put_contents("data/$chatid/saeed.txt", "spam1");
        bot('sendMessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "✉️ متن پیام خود را با رعایت موارد زیر ارسال نمایید:
ایدی عددی:
متن سوال یا درخواست:

 ⚠به موارد زیر توجه کنید:

1⃣ سوال، پیام، انتقاد و پیشنهادهای خود را درون یک پیام واحد نوشته و ارسال نمایید. (از جواب دادن به مواردی که در چند پیام جداگانه ارسال می شود معذوریم)
2⃣ تا زمان دریافت پاسخ صبور باشید و از پرسش مجدد خودداری کنید.
 
⚠ در صورتی که فرم ارسال پیام شما طبق الگوی داده شده نباشد از پاسخ گویی به پیام شما معذوریم
آیدی عددی شما: $chatid",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت🔙", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);

    } elseif ($saeed == 'spam1') {
        file_put_contents("data/$chat_id/saeed.txt", "No");
		bot('sendMessage', [
            'chat_id' => "482036608",
            'text' => "پیام جدید دریافت شد...!
			متن پیام : $text
			آیدی عددی: $from_id
			نام :$name نام خانوادگی :$last
			آیدیش : @$username",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "ارسال شد به مدیریت",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت", 'callback_data' => "getspam"]
                    ],
                ]
            ])
        ]);
    } 
	elseif ($data == "daryaftpayam") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
       $sss = file_get_contents("data/$chatid/pasokh1.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "$sss",
        ]);
    }
	if ($text == "عابر بانک📥") {
       $almasid = file_get_contents("data/$chat_id/almasid.txt");

        file_put_contents("data/$chat_id/saeed.txt", "entalmas1");
       sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
            'text' => "⚠️کاربر گرامی برای انتقال ممبر از خود به کاربری دیگر به شناسه کاربری[آیدی عددی] شخص نیاز است لطفا آن را وارد نمایید. ",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
            ['text' => "بازگشت", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($saeed == 'entalmas1') {
            if (strpos($list, "$text") !== false) {
         if (preg_match('/^([0-9])/', $text)) {
        file_put_contents("data/$chat_id/almasid.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "entalmas2");
    $sho = file_get_contents("data/$chat_id/mosak.txt");
        $shoo = $sho -1;
       sendAction($chat_id, 'typing');
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " ❓تعداد ممبرهای مورد نظر برای انتقال را وارد کنید:

⚠️ نکته:
 شما قادر به انتقال حداقل 50 ممبر و حداکثر $shoo میباشید ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
            ['text' => "انصراف️", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
            } else {
       sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>  "کاربرگرامی لطفا ایدی عددی را به صورت انگلیسی وارد کنید ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
            ['text' => "انصراف️", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
   }
            } else {
       sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
             'text' => "خطا❌
آیدی عددی وارد شده اشتباه می باشد یا کاربر مورد نظر عضو ربات نمیباشد  ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
            ['text' => "انصراف️", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
   }
    } elseif ($saeed == 'entalmas2') {
            if ($shoklt > $text) {
              if ($text > 50) {
    $ident = file_get_contents("data/$chat_id/almasid.txt");
    $alms = file_get_contents("data/$chat_id/mosak.txt");
          $fle = file_get_contents("data/$ident/mosak.txt");
                $alm = $text;
               $getshe = $fle + $alm;
                file_put_contents("data/$ident/mosak.txt", $getshe);
    $sho = file_get_contents("data/$ident/mosak.txt");
        file_put_contents("data/$chat_id/saeed.txt", "");
                SendMessage($ident, "✅ مقدار $text ممبر از طرف شماره کاربری $chat_id به حساب شما با موفقیت انتقال یافت.
ممبر فعلی👁‍🗨: $sho");
           $getalm = $alms - $alm;
        file_put_contents("data/$chat_id/mosak.txt", "$getalm");
    $ident = file_get_contents("data/$chat_id/almasid.txt");
    $sho = file_get_contents("data/$chat_id/mosak.txt");
               $entshoma = file_get_contents("data/$ident/entshoma.txt");
               $getshee = $entshoma + $text;
                file_put_contents("data/$ident/entshoma.txt", $getshee);
            $ss = file_get_contents("data/$chat_id/enteghal.txt");
           $sss = $ss + $text;
                file_put_contents("data/$chat_id/enteghal.txt", $sss);
                SendMessage($chat_id, " ✅ شما مقدار $text ممبر را با موفقیت به شماره کاربری $ident انتقال دادید.
👁‍🗨ممبر فعلی شما: $sho");
            } else {
                SendMessage($chat_id, "حداقل ممبر مجاز برای انتقال 50 ممبر میباشد");
   }
        } else {
            SendMessage($chat_id, " موجودی شما کافی نیست ❌");
        }
    }
	if ($text == "ثبت تبلیغ🎯") {
        @$sho = file_get_contents("data/$chat_id/mosak.txt");
         sendAction($chat_id, 'typing');
		 bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❗️ مقدار ممبری که مایلید تبلیغات شما به کاربران ربات نشان داده شود را انتخاب کنید.
            موجودی فعلی شما: $sho ممبر 👁‍🗨",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>json_encode([
   'resize_keyboard'=>true,
                'keyboard'=>[
				[
						['text'=>"🔎 پیگیری سفارشات"], ['text'=>"بازگشت🔙"]
                    ],
					[
						['text'=>"5 ممبر👤"], ['text' => "10 ممبر👤"]
                    ],
                    [
                       ['text' => "15 ممبر👤"], ['text' => "20 ممبر👤"]
                    ],
                    [
                        ['text' => "ممبر دلخواه👤"]
                    ]
                ]
            ])
        ]);
	}
	if ($text == "5 ممبر👤") {
        file_put_contents("data/$chat_id/ted.txt", "5");
        $aaa = file_get_contents("data/$chat_id/ted.txt");
        $shoklt = file_get_contents("data/$chat_id/mosak.txt");
        if ($shoklt > $aaa) {
            file_put_contents("data/$chat_id/saeed.txt", "seen3");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
	2⃣ برای بالا رفتن کیفیت ممبر دهی 
	اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


	یوزنیم حتما باید بدون @باشد برای مثال
	@TeleGrmBOTs
	باید نوشته بشه: TeleGrmBOTs",
                'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"برگشت به منو اصلی",'callback_data'=>"home"]
    ]
    ]
    ])
            ]);
        } else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "❌سکه های شما کافی نمیباشد",
            ]);
        }
		
	}
	if ($text == "10 ممبر👤") {
        file_put_contents("data/$chat_id/ted.txt", "10");
        $aaa = file_get_contents("data/$chat_id/ted.txt");
        $shoklt = file_get_contents("data/$chat_id/mosak.txt");
        if ($shoklt > $aaa) {
            file_put_contents("data/$chat_id/saeed.txt", "seen3");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
	2⃣ برای بالا رفتن کیفیت ممبر دهی 
	اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


	یوزنیم حتما باید بدون @باشد برای مثال
	@TeleGrmBOTs
	باید نوشته بشه: TeleGrmBOTs",
                'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"برگشت به منو اصلی",'callback_data'=>"home"]
    ]
    ]
    ])
            ]);
        } else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "❌سکه های شما کافی نمیباشد",
            ]);
        }
		
	}
	if ($text == "15 ممبر👤") {
        file_put_contents("data/$chat_id/ted.txt", "15");
        $aaa = file_get_contents("data/$chat_id/ted.txt");
        $shoklt = file_get_contents("data/$chat_id/mosak.txt");
        if ($shoklt > $aaa) {
            file_put_contents("data/$chat_id/saeed.txt", "seen3");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
	2⃣ برای بالا رفتن کیفیت ممبر دهی 
	اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


	یوزنیم حتما باید بدون @باشد برای مثال
	@TeleGrmBOTs
	باید نوشته بشه: TeleGrmBOTs",
                'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"برگشت به منو اصلی",'callback_data'=>"home"]
    ]
    ]
    ])
            ]);
        } else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "❌سکه های شما کافی نمیباشد",
            ]);
        }
		
	}
	if ($text == "20 ممبر👤") {
        file_put_contents("data/$chat_id/ted.txt", "20");
        $aaa = file_get_contents("data/$chat_id/ted.txt");
        $shoklt = file_get_contents("data/$chat_id/mosak.txt");
        if ($shoklt > $aaa) {
            file_put_contents("data/$chat_id/saeed.txt", "seen3");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
	2⃣ برای بالا رفتن کیفیت ممبر دهی 
	اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


	یوزنیم حتما باید بدون @باشد برای مثال
	@TeleGrmBOTs
	باید نوشته بشه: TeleGrmBOTs",
                'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"برگشت به منو اصلی",'callback_data'=>"home"]
    ]
    ]
    ])
            ]);
        } else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "❌سکه های شما کافی نمیباشد",
            ]);
        }
		
	}
	if($text == "ممبر دلخواه👤"){
		file_put_contents("data/$chat_id/saeed.txt", "delkhah");
		bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "👤 چه تعداد ممبر دلخواه میخواهید؟
👈 شما میتوانید بین 1 الی 1000 ممبر (با توجه به موجودی سکه شما) را به دلخواه انتخاب کنید.",
                'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"برگشت به منو اصلی",'callback_data'=>"home"]
    ]
    ]
    ])
            ]);
        }
		elseif($saeed == "delkhah"){
			SendAction($chat_id,typing);
			$shoklt = file_get_contents("data/$chat_id/mosak.txt");
       if($text >= 20 && 1000 >= $text){
		   if($shoklt >= $text){
			   file_put_contents("data/$chat_id/ted.txt", "$text");
			   file_put_contents("data/$chat_id/saeed.txt", "seen3");
			   bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
	2⃣ برای بالا رفتن کیفیت ممبر دهی 
	اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


	یوزنیم حتما باید بدون @باشد برای مثال
	@TeleGrmBOTs
	باید نوشته بشه: TeleGrmBOTs",
                'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"برگشت به منو اصلی",'callback_data'=>"home"]
    ]
    ]
    ])
            ]);
        } else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "❌سکه های شما کافی نمیباشد",
            ]);
        }
    }
		} elseif ($saeed == "seen3") {
				$msg_id = bot('ForwardMessage', [
					'chat_id' => $channel,
					'from_chat_id' => "$forward_chat_username",
					'message_id' => $forward_chat_msg_id
				])->result->message_id;@$al = file_get_contents("data/$chat_id/ted.txt");
			file_put_contents("data/$chat_id/channne.txt", "@$text");
			$textt = file_get_contents("data/$chat_id/channne.txt");
    $saeed10 = json_decode(file_get_contents("https://api.telegram.org/bot$API_KEY/getChat?chat_id=@$text"));
    $tik2 = objectToArrays($saeed10);
        $ur = $tik2["result"]["title"];
    $urr = $tik2["result"]["description"];
    $urrr = $tik2["result"]["username"];
				bot('sendMessage', [
					'chat_id' => $channel,
 'text'=>"‌نام کانال🌐:‌ $ur
آیدی کانال🌀:🆔 
@$urrr 
تاریخ تبلیغ📆: $fadate
تعداد ممبر های واریزی👥:$al

جهت دریافت سکه روی دکمه عضویت در کانال زیر کلیک کنید👇💎",
     'parse_mode' => "html",
     'reply_markup' => json_encode([
      'inline_keyboard' => [
       [
['text' => "عضویت", 'url' => "http://telegram.me/$urrr"] , ['text' => "دریافت سکه💰", 'callback_data' => "ok"],['text' => "بازگشت به ربات↪️", 'url' => "http://telegram.me/$botid"]
       ],
      ]
     ])
   ]); 
         bot('sendMessage', [
            'chat_id' => $textt,
            'text' => "‌با سلام 😌 

کانال در حال ممبرگیری میباشد ! 
پاک کردن این پیام عضو گیری لغو خواهد شد !",
          'parse_mode' => "html",
          'reply_markup' => json_encode([
            'inline_keyboard' => [
            [
              ['text' => "بازگشت به ربات↪️", 'url' => "http://telegram.me/$botid"], ['text' => "بازگشت به چنل☑️", 'url' => "http://telegram.me/$channeltabid"]
							],
						]
					])
				]);
				$al = file_get_contents("data/$chat_id/ted.txt");
				$sho = file_get_contents("data/$chat_id/mosak.txt");
				$getsho = $sho - $al;
				file_put_contents("data/$chat_id/mosak.txt", $getsho);
				 $don = file_get_contents("data/done.txt");
				 $getdon = $don + 1;
				file_put_contents("data/done.txt", $getdon);
				file_put_contents("ads/cont/$msg_id.txt", $al);
				file_put_contents("ads/date/$msg_id.txt", $fadate);
				file_put_contents("ads/time/$msg_id.txt", $fatime);
				file_put_contents("ads/admin/$msg_id.txt", $chat_id);
				file_put_contents("ads/seen/$msg_id.txt", "0");
				file_put_contents("ads/user/$msg_id.txt", "");
				file_put_contents("data/$chat_id/msg.txt", "$msg_id");
				file_put_contents("data/$chat_id/saeed.txt", "no");
				$inch3 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@".$text."&user_id=".$chat_id); 
				bot('sendMessage', [
					'chat_id' => $chat_id,
					'text' => "خوب کاربر گرامی درخواست ممبرشما با موفقیت در کانال ثبت شد👥
  ساعت درخواست ممبر👥 :$fatime 
   📅تاریخ درخواست  : $fadate
  〰〰〰〰〰〰〰〰〰〰〰〰
  برای رفتن به چنلی که سفارشات بهش ارسال میشه از دکه زیر استفاده کنید✅
  〰〰〰〰〰〰〰〰〰〰〰〰
  تعداد ممبر درخواستی شما: $al",
				'reply_markup' => json_encode([
					'inline_keyboard' => [
						[
							['text' => "ورود به چنل🔻", 'url' => "https://t.me/$channeltabid"]
						],
					]
				])
			]);
		}
			if ($data == "ok") {
			$message_id12 = $update->callback_query->message->reply_to_message->message_id;
        $fromm_id = $update->callback_query->from->id;
        @$ue = file_get_contents("ads/user/$message_id12.txt");
        @$se = file_get_contents("ads/seen/$message_id12.txt");
        if (strpos($ue, "$fromm_id") !== false) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شما قبلا از این سفارش سکه 💰 گرفتی",
                'show_alert' => false
            ]);
        } else {
            $user = file_get_contents("ads/user/$message_id12.txt");
            $members = explode("\n", $user);
            if (!in_array($fromm_id, $members)) {
                $add_user = file_get_contents("ads/user/$message_id12.txt");
                $add_user .= $fromm_id . "\n";
                file_put_contents("ads/user/$message_id12.txt", $add_user);
            }
            $getse = $se + 1;
            file_put_contents("ads/seen/$message_id12.txt", $getse);
            @$sho = file_get_contents("data/$fromm_id/mosak.txt");
            $getsho = $sho + 1;
            file_put_contents("data/$fromm_id/mosak.txt", $getsho);
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "💰1 سکه دریافت کردید|تعداد سکه ها: $sho",
                'show_alert' => false
            ]);
        }
        $end = file_get_contents("ads/seen/$message_id12.txt");
        $ad = file_get_contents("ads/admin/$message_id12.txt");
        $co = file_get_contents("ads/cont/$message_id12.txt");
        $te = file_get_contents("ads/time/$message_id12.txt");
        $de = file_get_contents("ads/date/$message_id12.txt");
        if ($end == $co) {
            file_put_contents("data/$chat_id/ali.txt", "no");
            bot('sendMessage', [
                'chat_id' => $ad,
                'text' => "درخواست ممبر شما به پایان رسید✅👥
	〰〰〰〰〰〰〰〰〰〰〰
	مشخصات👇👇
	〰〰〰〰〰〰〰〰〰〰〰
	👁‍🗨تعداد ممبر درخواستی شما: $co
	⏰ساعت درخواست ممبر: $te
	📆تاریخ درخواست ممبر: $de
	ساعت اتمام درخواست : $fatime
	##########the end##########",
                'parse_mode' => "MarkDown"
            ]);
				@$don = file_get_contents("data/done.txt");
				$getdon = $don - 1;
				file_put_contents("data/done.txt", $getdon);
				@$enn = file_get_contents("data/enf.txt");
				$getenf = $enn + 1;
				file_put_contents("data/enf.txt", $getenf);
				$de = $message_id12 + 1;
				deletemessage($channel, $message_id12);
				deletemessage($channel, $de);
				unlink("ads/seen/$message_id12.txt");
				unlink("ads/admin/$message_id12.txt");
				unlink("ads/cont/$message_id12.txt");
				unlink("ads/time/$message_id12.txt");
				unlink("ads/user/$message_id12.txt");
				unlink("ads/date/$message_id12.txt");
			}
		}
		if ($text == "🔎 پیگیری سفارشات") {
       
        file_put_contents("data/$chat_id/saeed.txt", "mlm");
sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
            'text' => "کد پیگیری خودتون را برام بفرستید",
        ]);
    } elseif ($saeed == "mlm") {
        file_put_contents("data/$chat_id/saeed.txt", "");
        if (file_exists("ads/admin/$text.txt")) {
            $ge = file_get_contents("ads/seen/$text.txt");
            $ad = file_get_contents("ads/admin/$text.txt");
            $co = file_get_contents("ads/cont/$text.txt");
            $te = file_get_contents("ads/time/$text.txt");
            $de = file_get_contents("ads/date/$text.txt");
sendAction($chat_id, 'typing');
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "مشخصات کد پیگیری  $text  بصورت زیر میباشد
👤تعداد ممبر درخواستی شما: $co
⏰ساعت درخواست ممبر: $te
📅تاریخ درخواست ممبر: $de
👥تعداد ممبر در یافتی تا الان : $ge
🕰ساعت درخواست پیگیری: $fatime

موفق و سربلند باشید🤖 ",
           'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
            ['text' => "مشاهده تبلیغ در کانال✅", 'url' => "https://t.me/yourviews/$text"]
                    ],
                ]
            ])
        ]);
        } else {
sendAction($chat_id, 'typing');
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "کد پیگیری شما اشتباه میباشد یا سفارش شما به پایان رسیده هست😬
موفق و سربلند باشید🤖
برای شروع مجدد /start را بزنید",
   
            ]);
        }
    }
	
	//========= panel ==========\\
	if ($chatid == $ADMIN or $chat_id == $ADMIN) {
if ($text == "/panel") {
        file_put_contents("data/$chat_id/saeed.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
		'chat_id' => $chat_id,
            'text' => "به پنل مدیریت خوش آمدی...!",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
			'resize_keyboard'=>true,
                'keyboard' => [
                    [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
					[
                        ['text' => "✅سکه همه گانی💰"]
                    ],
                    [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ],
                    [
                        ['text' => "📢 کانال تبلیغات"], ['text' => "ارسال پیام🔥"]
                    ],
                     [
                        ['text' => "کانال تبلیغات"]
                    ],
                    [
                        ['text' => "کانال اخبار"]
                    ],
                    [
                        ['text' => "تنظیم ای دی ربات"]
                    ],
                    [
                        ['text' => "💸 سکه به کاربر"],['text' => "🔱کسر کسه از کاربر🔱"]
                    ],
					[
					['text'=>"بازگشت🔙"]
					]
                ]
            ])
        ]);
    } 
	if($text == "🔚 برگشت به منوی ادمین" && $chat_id == $ADMIN){
    file_put_contents("data/$chat_id/saeed.txt","none");
    sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مدیر گرامی به پنل مدیریت ربات ‌سکه ای خوش امدید 🙂",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
            ]);
    }	
 if ($text == "📊 آمار کلی ربات 📊" && $chat_id == $ADMIN){
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
        @$don = file_get_contents("data/done.txt");
        @$enf = file_get_contents("data/enf.txt");
        bot('sendmessage', [
            'chat_id'=>$chat_id,
            'text' => "⚠️ وضعیت ربات ⚠️
👤 تعداد کاربران 👤: $member_count
♨️ تبلیغات مانده ♨️: $don
🌐 تبلیغات انجام شده 🌐: $enf",
'reply_to_message_id'=>$message_id,
        ]);
    }
	if ($text == "🗳 ارسال" && $chat_id == $ADMIN ){
        file_put_contents("data/$chat_id/saeed.txt", "send");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برا  کاربرا  . بدو وقت ندارم 😑",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == "send") {
        file_put_contents("data/$chat_id/saeed.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } if ($text == "🗂 فروارد" && $chat_id == $ADMIN){
        file_put_contents("data/$chat_id/saeed.txt", "fwd");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را فروارد کنید فقط زود که حوصله ندارم 😤",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'fwd') {
        file_put_contents("data/$chat_id/saeed.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } if ($text == "❌ بلاک" && $chat_id == $ADMIN ){
       
        file_put_contents("data/$chat_id/saeed.txt", "pen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات 😡",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم 😤
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => $admin_keyboard
        ]);
    } if ($text == "♻️ انبلاک" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/saeed.txt", "unpen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ی بخشیدی حالا . ایدی عددیشو بدع تا انبلاکش کنم 😕",
            'reply_to_message_id'=>$message_id,
'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
	if ($text == "📢 کانال تبلیغات" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/saeed.txt", "setc");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب یوزر نیم چنل را بفرست    همراه با @ بفرستید  ",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'setc') {
        file_put_contents("data/channel.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله چنل تبلیغات این شد
 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
    if ($text == "کانال تبلیغات" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/saeed.txt", "ali");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب یوزر نیم چنل را بفرست    بدون @ بفرستید  ",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'ali') {
        file_put_contents("data/channel1.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله چنل تبلیغات این شد
 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
     if ($text == "کانال اخبار" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/saeed.txt", "reza");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب یوزر نیم چنل را بفرست    همراه با @ بفرستید  ",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'reza') {
        file_put_contents("data/channel2.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله چنل اخبار این شد
 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
    if ($text == "تنظیم ای دی ربات" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/saeed.txt", "saeed");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب یوزر نیم ربات را بفرست    بدون @ بفرستید  ",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'saeed') {
        file_put_contents("data/botid.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله ایدی ربات  این شد
 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
	if($text == "ارسال پیام🔥" && $chat_id == $ADMIN){
		sendAction($chat_id, 'typing');
		bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
        'text' => "برای ادامه کیلیک کنید!",
        'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                [
                        ['text' => "برای ادامه کیلیک کنید!", 'callback_data' => "pasokh"]
                ],
                    ]
                ])
            ]);
	}
        elseif ($data == "pasokh") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "pasokh1");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
        ]);
    } elseif ($saeed == 'pasokh1') {
        file_put_contents("data/pasokh.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "pasokh2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "متن پیام خود را وارد کنید",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($saeed == 'pasokh2') {

        $pasokh = file_get_contents("data/pasokh.txt");
        file_put_contents("data/$pasokh/pasokh1.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "");
        bot('sendMessage', [
            'chat_id' => $pasokh,
            'text' => "کاربر گرامی شما یک پیام از طرف پشتیبانی دارید
            جهت مشاهده پیام به صندوق دریافت پیام مراجعه کنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "صندوق دریافت پیام", 'callback_data' => "daryaftpayam"]
                    ],
                ]
            ])
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
        ]);
    }
	if($text == "✅سکه همه گانی💰" && $chat_id == $ADMIN){
		sendAction($chat_id, 'typing');
		bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
        'text' => "برای ادامه کیلیک کنید!",
        'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                [
                        ['text' => "برای ادامه کیلیک کنید!", 'callback_data' => "saeedii"]
                ],
                    ]
                ])
            ]);
	}
	elseif ($data == "saeedii") {
            file_put_contents("data/$chat_id/mosak.txt");
            @$sho = file_get_contents("data/$chat_id/mosak.txt");
            $ran = rand(10,10);
            $getsho = $sho + $ran;
            file_put_contents("data/$chat_id/mosak.txt", $getsho);
            $sho2 = file_get_contents("data/$chat_id/mosak.txt");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => " تعداد $ran سکه برای همه کاربران ارسال کردید",
                'show_alert' => true
            ]);
		}
	if ($text == "💸 سکه به کاربر" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/saeed.txt", "buy");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'buy') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "buy2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد سکه ها چقدر باشه",
            'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'buy2') {
    $buy = file_get_contents("data/buy.txt");
          $fle = file_get_contents("data/$buy/mosak.txt");
               $getshe = $fle + $text;
                file_put_contents("data/$buy/mosak.txt", $getshe);
        file_put_contents("data/$chat_id/saeed.txt", "");
        bot('sendMessage', [
            'chat_id' => $buy,
            'text' => "کاربر عزیز ...
مقدار $text سکه از طرف مدیریت به شما ارسال شد !!"
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    }
	if ($text == "🔱کسر کسه از کاربر🔱" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/saeed.txt", "by");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'by') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "by2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد سکه ها چقدر باشه",
            'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($saeed == 'by2') {
    $buy = file_get_contents("data/buy.txt");
          $fle = file_get_contents("data/$buy/mosak.txt");
               $getshe = $fle - $text;
                file_put_contents("data/$buy/mosak.txt", $getshe);
        file_put_contents("data/$chat_id/saeed.txt", "");
        bot('sendMessage', [
            'chat_id' => $buy,
            'text' => "کاربر عزیز ...
مقدار $text سکه از طرف مدیریت از شما کم شد !!"
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    }
	}
	unlink("error_log");
	?>
	