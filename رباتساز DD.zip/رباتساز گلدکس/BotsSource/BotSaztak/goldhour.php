<?php

include("index1.php");
date_default_timezone_set('Asia/tehran');
$time = explode(PHP_EOL,file_get_contents("data/time.txt"));
if($time[0] != null && $time[0] != "off")
if($time[0] <= time()){
$time_off = jdate("H:i:s, Y F d",$time[1]);
file_put_contents("data/invite coin.txt",2);
file_put_contents("data/check.txt",40);
bot('SendMessage',[
'chat_id'=>"@$mych",
'text'=>"🎉 #ساعت_طلایی_فعال_شد 🔻
------------------
👥با دعوت هر 1 نفر میتونید ⭐️2 امتیاز دریافت کنید
------------------
↓تاریخ و ساعت غیرفعال شدن↓",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⌚️ $time_off",'callback_data'=>"none"]],
[['text'=>"ورود به ربات",'url'=>"https://t.me/$BOT_ID"]]
]
])
]);
file_put_contents("data/time.txt",$time[0] + (3600 * 24).PHP_EOL.$time[1]);
}
elseif($time[1] <= time()){
$time_on = jdate("H:i:s, Y F d",$time[0]);
file_put_contents("data/invite coin.txt",1);
file_put_contents("data/check.txt",50);
bot('SendMessage',[
'chat_id'=>"@$mych",
'text'=>"➖➖➖➖➖➖
❌ #ساعت_طلایی_غیرفعال_شد
-------------
👥با دعوت هر 1 نفر میتونید ⭐️{1}امتیاز دریافت کنید
-------------
↓تاریخ و ساعت فعال شدن مجدد↓",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⌚️ $time_on",'callback_data'=>"none"]],
[['text'=>"ورود به ربات",'url'=>"https://t.me/$BOT_ID"]]
]
])
]);
file_put_contents("data/time.txt",$time[0].PHP_EOL.($time[1] + (3600 * 24)));
}

?>