<?php
ob_start();
ini_set("log_errors" , "off");
$admin = '**ADMIN**';
$API_KEY ="**TOKEN**";
$GetINFObot = json_decode(file_get_contents("https://api.telegram.org/bot".$API_KEY."/getMe"));
$botid = $GetINFObot->result->first_name;
$usernamebot= $GetINFObot->result->username;
define('API_KEY','**TOKEN**');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
 function sendaction($chat_id, $action){
 bot('sendchataction',[
 'chat_id'=>$chat_id,
 'action'=>$action
 ]);
 }
 function EditMessageText($chat_id, $message_id, $text1, $parse_mode, $disable_web_page_preview, $keyboard){
     bot('editMessagetext', 
     ['chat_id' => $chat_id,
     'message_id' => $message_id,
     'text' => $text1,
     'parse_mode' => $parse_mode,
     'disable_web_page_preview' => $disable_web_page_preview,
     'reply_markup' => $keyboard]);}
 function GetChatMember($chatid,$userid){
	$truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=".$chatid."&user_id=".$userid));
	$tch = $truechannel->result->status;
	return $tch;
	}
///=======-========//
include("jdf.php");
$date =  jdate('d');
$fasl =  jdate('f');
$h =  jdate('G:i:s');
$m = jdate('q');
$s = jdate('s');
$hafte = jdate('l');
$y = jdate('Y');
$l = jdate('Y/n/j');
$mo =  jdate('F');
$q =  jdate('Q');
$hour =  jdate('h');
$sec =  jdate('s');
$min =  jdate('i');
//===========-======//
$boolean = file_get_contents('booleans.txt');
$booleans= explode("\n",$boolean);
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$editm = $update->edited_message;
$message_id = $message->message_id;
$chat_id = $message->chat->id;
$first = $update->message->from->first_name;
$last = $update->message->from->last_name;
$username = $update->message->from->username;
$text1 = $message->text;
$tc = $update->message->chat->type;
$message_id2 = $update->callback_query->message->message_id;
$audio=$message->audio;
$afile_id=$audio->file_id;
$chat_d = $message->from->id;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$reply = $update->message->reply_to_message->forward_from->id;
$forward = $update->message->forward_from;
$query=$update->callback_query;
$inline=$update->inline_query;
$channel_forward = $update->channel_post->forward_from;
$channel_text = $update->channel_post->text;
$messageid = $update->callback_query->message->message_id;
$reply = $update->message->reply_to_message;
@mkdir("data");
@mkdir("data/$chat_d");
@mkdir("data/group");
////Shore_derfeie///================--------------------
$step=file_get_contents("data/one.txt");
@$cr=file_get_contents("data/$chat_d/cr.txt");
@$cf=file_get_contents("data/$chat_d/cf.txt");
@$button = file_get_contents("buuton.text");
///====================-/--------------//====//
$start = file_get_contents("start.txt");
$start = str_replace("BOTID",$usernamebot,$start);
$start = str_replace("BOTNAME",$botid,$start);
$start = str_replace("FIRSTNAME",$first,$start);
$start = str_replace("LASTNAME",$last,$start);
$start = str_replace("USERNAME",$username,$start);
$start = str_replace("DATA",$l,$start);
$start = str_replace("MIN",$min,$start);
$start = str_replace("SEC",$sec,$start);
$start = str_replace("HOUR",$hour,$start);
///============----============//
@$backmod=file_get_contents("bamod.txt");
@$backbuuton =file_get_contents("back.txt");    
@$back2 =file_get_contents("back2.txt");    
@$prof = file_get_contents("profile.txt");
@$feed = file_get_contents("feed.txt");
$az = file_get_contents("data/$chat_d/az.txt");
///////=================---=================///
@$backstart=file_get_contents("backtxt.txt");
$backstart = str_replace("FIRSTNAME",$first,$backstart);
$backstart = str_replace("LASTNAME",$last,$backstart);
$backstart = str_replace("USERNAME",$username,$backstart);
$backstart = str_replace("DATA",$l,$backstart);
$backstart = str_replace("MIN",$min,$backstart);
$backstart = str_replace("SEC",$sec,$backstart);
$backstart = str_replace("HOUR",$hour,$backstart);
//////////======================================///
$stats = file_get_contents("data/$chat_d/stats.txt");
///==========---=================//
@$re = file_get_contents("reza.txt");
$re = str_replace("FIRSTNAME",$first,$re);
$re = str_replace("LASTNAME",$last,$re);
$re = str_replace("USERNAME",$username,$re);
$re = str_replace("DATA",$l,$re);
$re = str_replace("MIN",$min,$re);
$re = str_replace("SEC",$sec,$re);
$re = str_replace("HOUR",$hour,$re);
//////============--==============//
@$edit = file_get_contents("edit.txt");
@$a = file_get_contents("a.txt");
@$b = file_get_contents("b.txt");
$moz =file_get_contents("data/moz.txt");
///=======-------=========================//
@$fe = file_get_contents("z.txt");
$fe = str_replace("FIRSTNAME",$first,$fe);
$fe = str_replace("LASTNAME",$last,$fe);
$fe = str_replace("USERNAME",$username,$fe);
$fe = str_replace("DATA",$l,$fe);
$fe = str_replace("MIN",$min,$fe);
$fe = str_replace("SEC",$sec,$fe);
$fe = str_replace("HOUR",$hour,$fe);
//////================--==================//
@$c = file_get_contents("c.txt");
@$d = file_get_contents("d.txt");
@$e = file_get_contents("e.txt");
///=============--==================//
@$etxt = file_get_contents("etxt.txt");
$etxt = str_replace("FIRSTNAME",$first,$etxt);
$etxt = str_replace("LASTNAME",$last,$etxt);
$etxt = str_replace("USERNAME",$username,$etxt);
$etxt = str_replace("DATA",$l,$etxt);
$etxt = str_replace("MIN",$min,$etxt);
$etxt = str_replace("SEC",$sec,$etxt);
$etxt = str_replace("HOUR",$hour,$etxt);
////=============--===================//
@$seda = file_get_contents("seda.txt");
$seda = str_replace("FIRSTNAME",$first,$seda);
$seda = str_replace("LASTNAME",$last,$seda);
$seda = str_replace("USERNAME",$username,$seda);
$seda = str_replace("DATA",$l,$seda);
$seda = str_replace("MIN",$min,$seda);
$seda = str_replace("SEC",$sec,$seda);
$seda = str_replace("HOUR",$hour,$seda);
///=============--===================//
@$f = file_get_contents("f.txt");
@$g = file_get_contents("g.txt");
///===========-===================//
@$gtxt = file_get_contents("gtxt.txt");
$gtxt = str_replace("FIRSTNAME",$first,$gtxt);
$gtxt = str_replace("LASTNAME",$last,$gtxt);
$gtxt = str_replace("USERNAME",$username,$gtxt);
$gtxt = str_replace("DATA",$l,$gtxt);
$gtxt = str_replace("MIN",$min,$gtxt);
$gtxt = str_replace("SEC",$sec,$gtxt);
$gtxt = str_replace("HOUR",$hour,$gtxt);
////=============---=================///
@$fetxt = file_get_contents("fetxt.txt");
$kir = file_get_contents("kir.txt");
////==============----=====================//
@$vtxt = file_get_contents("vtxt.txt");
$vtxt = str_replace("FIRSTNAME",$first,$vtxt);
$vtxt = str_replace("LASTNAME",$last,$vtxt);
$vtxt = str_replace("USERNAME",$username,$vtxt);
$vtxt = str_replace("DATA",$l,$vtxt);
$vtxt = str_replace("MIN",$min,$vtxt);
$vtxt = str_replace("SEC",$sec,$vtxt);
$vtxt = str_replace("HOUR",$hour,$vtxt);
///===============----==================///
@$j = file_get_contents("j.txt");
///=========-======================//
@$jtxt = file_get_contents("jtxt.txt");
$jtxt = str_replace("FIRSTNAME",$first,$jtxt);
$jtxt = str_replace("LASTNAME",$last,$jtxt);
$jtxt = str_replace("USERNAME",$username,$jtxt);
$jtxt = str_replace("DATA",$l,$jtxt);
$jtxt = str_replace("MIN",$min,$jtxt);
$jtxt = str_replace("SEC",$sec,$jtxt);
$jtxt = str_replace("HOUR",$hour,$jtxt);
////==================-------===============//
@$k = file_get_contents("k.txt");
///=============-====================//
@$ke = file_get_contents("ke.txt");
$ke = str_replace("FIRSTNAME",$first,$ke);
$ke = str_replace("LASTNAME",$last,$ke);
$ke = str_replace("USERNAME",$username,$ke);
$ke = str_replace("DATA",$l,$ke);
$ke = str_replace("MIN",$min,$ke);
$ke = str_replace("SEC",$sec,$ke);
$ke = str_replace("HOUR",$hour,$ke);
///==================-================//
@$ktxt = file_get_contents("ktxt.txt");
$ktxt = str_replace("FIRSTNAME",$first,$ktxt);
$ktxt = str_replace("LASTNAME",$last,$ktxt);
$ktxt = str_replace("USERNAME",$username,$ktxt);
$ktxt = str_replace("DATA",$l,$ktxt);
$ktxt = str_replace("MIN",$min,$ktxt);
$ktxt = str_replace("SEC",$sec,$ktxt);
$ktxt = str_replace("HOUR",$hour,$ktxt);
////===============---====================//
@$link = file_get_contents("link.txt");
////==================---------------------///
@$lin = file_get_contents("lintxt.txt");
$lin = str_replace("FIRSTNAME",$first,$lin);
$lin = str_replace("LASTNAME",$last,$lin);
$lin = str_replace("USERNAME",$username,$lin);
$lin = str_replace("DATA",$l,$lin);
$lin = str_replace("MIN",$min,$lin);
$lin = str_replace("SEC",$sec,$lin);
$lin = str_replace("HOUR",$hour,$lin);
////////===============----=================///
@$saeed = file_get_contents("data/$chat_d/saeed.txt");
$know = file_get_contents("data/group/on.txt");
///=================-==================///
$ma=file_get_contents("data/ma.txt");
$ma1=file_get_contents("data/ma1.txt");
$ma2=file_get_contents("data/ma2.txt");
$ma3=file_get_contents("data/ma3.txt");
$ma4=file_get_contents("data/ma4.txt");
$ma5=file_get_contents("data/ma5.txt");
$ma6=file_get_contents("data/ma6.txt");
$ma7=file_get_contents("data/ma7.txt");
$ma8=file_get_contents("data/ma8.txt");
$ma9=file_get_contents("data/ma9.txt");
$ma10=file_get_contents("data/ma10.txt");
$hasan = file_get_contents("data/hasan.txt");
$hosin = file_get_contents("data/hosin.txt");
$pasokh = file_get_contents("data/word/$text1.txt");
$music=file_get_contents("data/$chat_d/music.txt");
$rezafuck = file_get_contents("data/word/$text1.txt");
$botsaz = file_get_contents("data/".$chat_d."/step.txt");
//=============-================//
	$user = file_get_contents('Member.txt');
    $members = explode("\n",$user);
    if (!in_array($chat_d,$members)){
     $add_user = file_get_contents('Member.txt');
     $add_user .= $chat_d."\n";
     file_put_contents('Member.txt',$add_user);
    }
    $txxt = file_get_contents('Group.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('Group.txt');
      $aaddd .= $chat_id."\n";
	  if ($chat_id != $from_id){
		file_put_contents('Group.txt',$aaddd);
	  }
    }
//=============-================//
if($text1=="/start"){
file_put_contents("data/$chat_d/namme.txt","$first");
file_put_contents("data/$chat_d/uname.txt","$username");
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"$start",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$hasan"]],		    
[['text'=>"$feed"],['text'=>"$link"]],	
[['text'=>"$a"]],
[['text'=>"$b"],['text'=>"$c"]],
[['text'=>"$d"]],
[['text'=>"$e"],['text'=>"$f"]],
[['text'=>"$z"]],
[['text'=>"$seda"],['text'=>"$ke"]],
[['text'=>"$ma"]],
[['text'=>"$k"],['text'=>"$j"]],
[['text'=>"$g"]],
		]
		])
		
	]);
	}
if($text1=="/start" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"لطفا برای ثبت ربات : /set$chat_d کلیک کنید.
	اگر استفاده کرده اید دگر نزنید!",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ساخت دکمه"],['text'=>"دکمه شیشه ای"]],
[['text'=>"آمار ربات"],['text'=>"راهنما"]],
[['text'=>"امکانات"],['text'=>"پشتیبان گیری"]],
[['text'=>"تنظیمات"],['text'=>"مدیریت گروه"]],
[['text'=>"پاسخ سریع"],['text'=>"ارسال مطلب"]],
[['text'=>"فورواد مطلب"],['text'=>"دستورات"]],
[['text'=>"$tell"]],
[['text'=>"$backbuuton"]]
		]
		])
		
	]);
	}


	
	if($text1=="$backbuuton"){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"$backstart",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$hasan"]],		    
[['text'=>"$feed"],['text'=>"$link"]],	
[['text'=>"$a"]],
[['text'=>"$b"],['text'=>"$c"]],
[['text'=>"$d"]],
[['text'=>"$e"],['text'=>"$f"]],
[['text'=>"$z"]],
[['text'=>"$seda"],['text'=>"$ke"]],
[['text'=>"$ma"]],
[['text'=>"$k"],['text'=>"$j"]],
[['text'=>"$g"],['text'=>"مدیریت"]],
		]
		])
		
	]);
	}
	//////////////////////////
	if($text1=="ساخت دکمه" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"یکی از امکانات ربات را انتخاب نمایید :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"],['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backbuuton"],['text'=>"$backmod"]],
]
		
])
		
	]);
	}
		if($text1=="ارسال مطلب" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"یکی از امکانات ربات را انتخاب نمایید :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن دستی"]]		    ,
[['text'=>"دکمه استیکر به عکس"]],
[['text'=>"دکمه متن به صدا"],['text'=>"متن به گیف"]],
[['text'=>"دکمه عکس به استیکر"]],
[['text'=>"$backbuuton"],['text'=>"$backmod"]],
]
		
])
		
	]);
	}
	
if($text1=="مدیریت" &&  $chat_d == $admin){
    $tell = file_get_contents("data/tell.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"👇پنل مدیریت ربات $botid :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ساخت دکمه"],['text'=>"دکمه شیشه ای"]],
[['text'=>"آمار ربات"],['text'=>"راهنما"]],
[['text'=>"امکانات"],['text'=>"پشتیبان گیری"]],
[['text'=>"تنظیمات"],['text'=>"مدیریت گروه"]],
[['text'=>"پاسخ سریع"],['text'=>"ارسال مطلب"]],
[['text'=>"فورواد مطلب"],['text'=>"دستورات"]],
[['text'=>"$tell"]],
[['text'=>"$backbuuton"]]

]
		])
		
	]);
	}
	if($text1=="$backmod" &&  $chat_d == $admin){
$backbuuton =file_get_contents("back.txt");    
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"👇پنل مدیریت ربات $botid :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ساخت دکمه"],['text'=>"دکمه شیشه ای"]],
[['text'=>"آمار ربات"],['text'=>"راهنما"]],
[['text'=>"امکانات"],['text'=>"پشتیبان گیری"]],
[['text'=>"تنظیمات"],['text'=>"مدیریت گروه"]],
[['text'=>"پاسخ سریع"],['text'=>"ارسال مطلب"]],
[['text'=>"فورواد مطلب"],['text'=>"دستورات"]],
[['text'=>"$tell"]],
[['text'=>"$backbuuton"]]
]
		])
		
	]);
	}
	if($text1=="/set$chat_d" &&  $chat_d == $admin){
file_put_contents("reza.txt","⬇️");
file_put_contents("back.txt","برگشت");
file_put_contents("back2.txt","منوی اصلی");
file_put_contents("data/group/active.txt","خوش آمد گویی : فعال");
file_put_contents("ketxt.txt","عکس خود را ارسال نمایید تا آن را به استیکر تبدیل کنم.");
file_put_contents("vtxt.txt","کلمه خود را ارسال نمایید به انگلیسی : مثال Reza");
file_put_contents("fetxt.txt","لطفا کلمه مورد نظر خود را ارسال نمایید : مثال R");
file_put_contents("etxt.txt","تاریخ و زمان فعلی :");
file_put_contents("editt.txt","برای تعققیرات کلیک کنید");
file_put_contents("jtxt.txt","به بخش ماشین حساب خوش آمدید✔️
برای جمع از علامت +
برای ضرب از علامت *
برای تفریق از علامت -
و برای تقسیم از علامت / استفاده کنید🔢
مثال :
1+5*8/2");
file_put_contents("bamod.txt","منوی مدیریت");
file_put_contents("gtxt.txt","🇮🇸لطفا کلمه خود را به انگلیسی یا فارسی ارسال کنید:🇮🇷");
file_put_contents("start.txt","به ربات خوش آمدید");
file_put_contents("backtxt.txt","به منوی اصلی خوش آمدید.");
file_put_contents("block.txt","0");
file_put_contents("profile.txt","📈گزارش بازدید و ذخیره این تصویر (سه شنبه):
👁 $negah نفر تصویر شما را نگاه کردند
💾 $zakhire نفر تصویر پروفایل شما را ذخیره کردند

برای مشاهده اسم و تصویر این افراد روی دکمه ی مشاهده این افراد بزنید👇");
file_put_contents("reza.txt","OK");
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"ربات فعال شد با تشکر",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
		    [['text'=>"مدیریت"]]
]
		])
		
	]);
	}
		if($text1=="آمار ربات" &&  $chat_d == $admin){
		    file_get_contents("data/history.txt","on");
		  $block = file_get_contents("block.txt");
	$onli = count($members) -2;
	$mmemcount = count($members) -1;
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"
👥اعضای ربات : $mmemcount
➖➖➖➖➖➖➖➖➖➖➖➖
👤افراد آنلاین : $onli
➖➖➖➖➖➖➖➖➖➖➖➖
👤افراد بلاک شده از ربات : $block
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"],['text'=>"$backbuuton"]],

		]
		])
		
	]);
	}
		if($text1=="راهنما" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"▪️آموزش استفاده از ربات :
🔻نکات زیر را با دقت بخوانید و به آن عمل کنید :
➖➖➖➖➖➖➖➖➖➖➖➖➖
▫️ربات ما : دارای امکانات کمی میباشد.
▪️ربات دارای بخش های زیر میباشد :
🔻:ساخت دکمه: شما با این امکان قادر خواهید بود دکمه نیز بسازید.
🔻:قفل ربات: شما میتوانید ربات را بروی کانال خود قفل نمایید.
🔻:آمار ربات: دریافت آمار های همگانی ربات
🔻:پشتیبان گیری : از فایل های ربات مثل (آمار و ...) پشتیبان گیری کنید.
🔻:تنظیمات : تعقییر تمامی پیام های ربات و دکمه های ربات.
🔻:مدیریت گروه : ضد لینک کردن ربات.
🔻:دستیار کانال : ارسال مطلب به کانال با ربات با تشکر
➖➖➖➖➖➖➖➖➖➖➖➖➖
🔻پشتیبانی 24 ساعته : @saeedphp
$spave",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
	]);
	}
			if($text1=="پشتیبان گیری" &&  $chat_d == $admin){
	bot('senddocument',[
	'chat_id'=>$chat_d,
	'document'=>"https://mohammad.max-web.ir/Haji/پشتیبانی ربات شما )( .zip",
	'caption'=>"🔻شامل متن استارت :
🔻آمار ربات.
🙏متاسفانه نمیتوانیم به دلیل سوء استفاده موارد بیشتری را ارسال کنیم.",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
	]);
	}
			if($text1=="تنظیمات" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"برای تغییر متن : و نام بعضی از دکمه شروع به کار کنید :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن ها"],['text'=>"دکمه ها"]],
[['text'=>"$backmod"]],
		]
		])
		
	]);
	}
				if($text1=="دکمه ها" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"برای تعقییر نام هر دکمه کلیک نمایید.",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"دکمه برگشت"],['text'=>"دکمه منوی اصلی"]],
[['text'=>"$backmod"]],
		]
		])
		
	]);
	}
				if($text1=="متن ها" &&  $chat_d == $admin){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"برای تعقییر متن هر کدام کلیک کنید.",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن شروع"],['text'=>"متن برگشت"]],
[['text'=>"متن موزیک"],['text'=>"متن ویرایشگر"]],
[['text'=>"متن پروفایل چکر"],['text'=>"متن عکس به استیکر"]],
[['text'=>"متن تاریخ و زمان"],['text'=>"متن مترجم"]],
[['text'=>"متن بازی دوز"],['text'=>"متن ماشین حساب"]],
[['text'=>"متن کوتاه کننده لینک"]],
[['text'=>"$backmod"]],
		]
		])
		
	]);
	}
	
	
	elseif($text1=="متن کوتاه کننده لینک"&& $chat_d == $admin){
				file_put_contents("lintxt.txt","lin");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($lin=="lin"){
					file_put_contents("lintxt.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("lintxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("lintxt.txt","$text1");
							file_put_contents("lintxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"ثبت شد.",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
	
	
	
elseif($text1=="متن شروع"&& $chat_d == $admin){
				file_put_contents("start.txt","start");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($start=="start"){
					file_put_contents("start.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("start.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("start.txt","$text1");
							file_put_contents("start.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"ثبت شد.",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="دکمه برگشت"&& $chat_d == $admin){
				file_put_contents("back.txt","back");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($backbuuton=="back"){
					file_put_contents("back.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("back.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("back.txt","$text1");
							file_put_contents("back.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="متن ویرایشگر"&& $chat_d == $admin){
				file_put_contents("edit.txt","edit");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($edit=="edit"){
					file_put_contents("edit.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("edit.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("edit.txt","$text1");
							file_put_contents("edit.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}

elseif($text1=="متن مترجم"&& $chat_d == $admin){
				file_put_contents("gtxt.txt","gtxt");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($gtxt=="gtxt"){
					file_put_contents("gtxt.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("gtxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("gtxt.txt","$text1");
							file_put_contents("gtxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}

elseif($text1=="متن ماشین حساب"&& $chat_d == $admin){
				file_put_contents("jtxt.txt","jtxt");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($jtxt=="jtxt"){
					file_put_contents("jtxt.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("jtxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("jtxt.txt","$text1");
							file_put_contents("jtxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
//========-=========//
elseif($text1=="دکمه استیکر به عکس"&& $chat_d == $admin){
				file_put_contents("feed.txt","fd");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه ؟",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($feed=="fd"){
					file_put_contents("feed.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("feed.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("feed.txt","$text1");
							file_put_contents("feed.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
elseif($text1=="دکمه متن به صدا"&& $chat_d == $admin){
				file_put_contents("seda.txt","seda");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه ؟",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($seda=="seda"){
					file_put_contents("seda.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("seda.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("seda.txt","$text1");
							file_put_contents("seda.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}


elseif($text1=="متن به گیف"&& $chat_d == $admin){
				file_put_contents("z.txt","z");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($fe=="z"){
					file_put_contents("z.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("z.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("z.txt","$text1");
							file_put_contents("z.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[

[['text'=>"$backmod"]]

		]
		])
		
]);
}
}

elseif($text1=="متن عکس به استیکر"&& $chat_d == $admin){
				file_put_contents("ktxt.txt","ktxt");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($ktxt=="ktxt"){
					file_put_contents("ktxt.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("ktxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("ktxt.txt","$text1");
							file_put_contents("ktxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}


elseif($text1=="متن تاریخ و زمان"&& $chat_d == $admin){
				file_put_contents("etxt.txt","etxt");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($etxt=="etxt"){
					file_put_contents("etxt.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("etxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("etxt.txt","$text1");
							file_put_contents("etxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="قفل ربات"&& $chat_d == $admin){
				file_put_contents("kir.txt","kir");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"ایدی کانال خود را بدون @ بدهید ربات در کانال ادمین باشد.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($kir=="kir"){
					file_put_contents("kir.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("kir.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("kir.txt","$text1");
							file_put_contents("kir.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"کانال شما شد : $text1",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
//=======-===========//
elseif($text1=="دکمه منوی اصلی"&& $chat_d == $admin){
				file_put_contents("back2.txt","back2");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($back2=="back2"){
					file_put_contents("back2.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("back2.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("back2.txt","$text1");
							file_put_contents("back2.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="دکمه منوی اصلی"&& $chat_d == $admin){
				file_put_contents("back2.txt","back2");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($back2=="back2"){
					file_put_contents("back2.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("back2.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("back2.txt","$text1");
							file_put_contents("back2.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="متن برگشت"&& $chat_d == $admin){
				file_put_contents("backtxt.txt","backtxt");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر را ارسال نمایید.",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($backstart=="backtxt"){
					file_put_contents("backtxt.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("backtxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("backtxt.txt","$text1");
							file_put_contents("backtxt.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="ویرایشگر موزیک"&& $chat_d == $admin){
				file_put_contents("a.txt","a");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($a=="a"){
					file_put_contents("a.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("a.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("a.txt","$text1");
							file_put_contents("a.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}


elseif($text1=="ربات ساز"&& $chat_d == $admin){
				file_put_contents("d.txt","d");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($d=="d"){
					file_put_contents("d.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("d.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("d.txt","$text1");
							file_put_contents("d.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}


elseif($text1=="مترجم"&& $chat_d == $admin){
				file_put_contents("g.txt","g");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($g=="g"){
					file_put_contents("g.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("g.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("g.txt","$text1");
							file_put_contents("g.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}

elseif($text1=="پروفایل چکر"&& $chat_d == $admin){
				file_put_contents("b.txt","b");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($b=="b"){
					file_put_contents("b.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("b.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("b.txt","$text1");
							file_put_contents("b.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]]
,[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}




elseif($text1=="دکمه عکس به استیکر"&& $chat_d == $admin){
				file_put_contents("ke.txt","ke");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($ke=="ke"){
					file_put_contents("ke.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("ke.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("ke.txt","$text1");
							file_put_contents("ke.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}






elseif($text1=="ماشین حساب"&& $chat_d == $admin){
				file_put_contents("j.txt","j");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($j=="j"){
					file_put_contents("j.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("j.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("j.txt","$text1");
							file_put_contents("j.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}

elseif($text1=="تاریخ و زمان"&& $chat_d == $admin){
				file_put_contents("e.txt","e");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($e=="e"){
					file_put_contents("e.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("e.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("e.txt","$text1");
							file_put_contents("e.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]]
,[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}



elseif($text1=="کوتاه کننده لینک"&& $chat_d == $admin){
				file_put_contents("link.txt","link");
				file_put_contents("lintxt.txt","لینک خود را ارسال نمایید :");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($link=="link"){
					file_put_contents("link.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("link.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("link.txt","$text1");
							file_put_contents("link.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}






elseif($text1=="اطلاعات شخصی"&& $chat_d == $admin){
				file_put_contents("c.txt","c");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($c=="c"){
					file_put_contents("c.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("c.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("c.txt","$text1");
							file_put_contents("c.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="تاریخ و زمان"&& $chat_d == $admin){
				file_put_contents("e.txt","e");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($e=="e"){
					file_put_contents("e.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("e.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("e.txt","$text1");
							file_put_contents("e.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]]
,[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
elseif($text1=="بازی دوز"&& $chat_d == $admin){
				file_put_contents("k.txt","k");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام این دکمه چه باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($k=="k"){
					file_put_contents("k.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("k.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("k.txt","$text1");
							file_put_contents("k.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"OK,Set Done Pleas Choose Next Button !",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ارسال مطلب"]],
[['text'=>"موزیک"],['text'=>"ویرایشگر موزیک"]],		    
[['text'=>"اطلاعات شخصی"]],
[['text'=>"پروفایل چکر"],['text'=>"ربات ساز"]],
[['text'=>"خبرنامه"],['text'=>"مترجم"]],
[['text'=>"تاریخ و زمان"],['text'=>"بازی دوز"]],
[['text'=>"ماشین حساب"]],
[['text'=>"کوتاه کننده لینک"]],
[['text'=>"$backmod"]]

		]
		])
		
]);
}
}
///=====-Edit Mozik ======//
elseif($text1=="ثبت تگ موزیک"){
				file_put_contents("data/$chat_d/cr.txt","cr");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"لطفا موضوع آهنگ رو بفرستید",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
			[['text'=>"ثبت نام خواننده"],['text'=>"ثبت تگ موزیک"]],
[['text'=>"دریافت موزیک"]],
[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($cr=="cr"){
					file_put_contents("data/$chat_d/cr.txt","null");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/$chat_d/cr.txt","null");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/$chat_d/cr.txt","$text1");
							file_put_contents("data/$chat_d/cr.txt","null");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"موضوع آهنگ با موفقیت ذخیره شد✅",
					'reply_markup'=>$key2,
					]);		
						}
		}elseif($text1=="ثبت نام خواننده"){
				file_put_contents("data/$chat_d/cf.txt","cf");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"لطفا نام خواننده رو وارد کنید",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"ثبت نام خواننده"],['text'=>"ثبت تگ موزیک"]],
[['text'=>"دریافت موزیک"]],
[['text'=>"$backbuuton"]]
				]
				])
				]);
				}elseif($cf=="cf"){
					file_put_contents("data/$chat_d/cf.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/$chat_d/cf.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/$chat_d/cf.txt","$text1");
							file_put_contents("data/$chat_d/cf.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"نام خواننده با موفقیت ذخیره شد✅",
					'reply_markup'=>$key2,
					]);		
						}}
						elseif($text1=="دریافت موزیک"){
			$mz=file_get_contents("data/$chat_d/cr.txt");
			$nam=file_get_contents("data/$chat_d/cf.txt");
			if($nam==null && $mz==null){
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"قسمت موضوع و نام خواننده خالی میباشد\nلطفا تمام مشخصات تکمیل و بعد به زدن این دکمه بکنید🚫",
				'reply_markup'=>$keyhome,
				]);
				
				}elseif($mz==null){
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"قسمت موضوع تکمیل نیست🚫",
				'reply_markup'=>$keyhome,
				]);
				}elseif($nam==null){
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"قسمت نام خواننده تکمیل نشده⛔",
				'reply_markup'=>$keyhome,
				]);
				}else{
				file_put_contents("data/$chat_d/cr.txt","$cr");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"لطفا آهنگتون رو بفرستید \nفرمت آهنگ باید حتما mp3'باشد",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]]
				]
				])
				]);
				
				}
			}elseif($cr=="$cr"){
			if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/$chat_d/cr.txt","null");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$keyhome,
					]);			
					}elseif(isset($message->audio)){
					    @$cr=file_get_contents("data/$chat_d/cr.txt");
@$cf=file_get_contents("data/$chat_d/cf.txt");
						file_put_contents("data/$chat_d/fuck.txt","null");
		$url = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY.'/getFile?file_id='.$afile_id),true);
					$path=$url['result']['file_path'];
 $file = 'https://api.telegram.org/file/bot'.API_KEY.'/'.$path;
		file_put_contents("data/$chat_d/test.mp3",file_get_contents($file));
		bot('sendaudio',[
		'chat_id'=>$chat_id,
		'audio'=>new CURLFile("data/$chat_d/test.mp3"),
		'title'=>$cr,
		'performer'=>$cf,
		'caption'=>"ربات تعققیر نام موسیقی : $botid",
		'reply_markup'=>$keyhome,
		]);
		}
		}
//========Edit Mozik========//
	elseif($text1== "$a" ){
	  $editt = file_get_contents("editt.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"$editt",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"ثبت نام خواننده"],['text'=>"ثبت تگ موزیک"]],
[['text'=>"دریافت موزیک"]],
[['text'=>"$backbuuton"]]
		]
		])
		
	]);
	}
	
		elseif($text1=="امکانات"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔻امکانات ربات :
🔻ساخت دکمه های کاربردی :
🔻پشتیبانی آنلاین :
🔻و دها هزار امکان دیگر دوست عزیز :
🔻مدیریت ربات $botid از این به بعد با شما نیز میباشد.",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"تست سرعت"]],
[['text'=>"$backmod"],['text'=>"$backbuuton"]],
		]
		])
		
	]);
	}
	
			if($text1=="مدیریت گروه"){
			  $active = file_get_contents("data/group/active.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"بخش مدیریت گروه خوش آمدید: ",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
		        [['text'=>"افزودن ربات در گروه"]],
		        [['text'=>"لیست گروه ها"],['text'=>"چت در گروه"]],
		        [['text'=>"$active"]],
		        [['text'=>"$backmod"]]
		]
		])
		
	]);
	}
	
	
	elseif($text1=="تنظیمات دیگر"){
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>"بخش تنظیمات کلی",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن"],['text'=>"دکمه شیشه ای"]],
[['text'=>"دستورات"],['text'=>"پیام ها"]],
[['text'=>"امکانات"]],
[['text'=>"$backmod"]]
		]
		])
		
	]);
	}
	
	
	
	
			elseif($text1=="خوش آمد گویی : فعال"){
	file_put_contents("data/group/well.txt","");
	file_put_contents("data/group/out.txt","");		
	file_put_contents("data/group/active.txt","خوش آمد گویی : غیرفعال");
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>" خوش آمد گویی : ☑️",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
		    [['text'=>"افزودن ربات در گروه"]],
		        [['text'=>"لیست گروه ها"],['text'=>"چت در گروه"]],
		        [['text'=>"خوش آمد گویی : غیرفعال"]],
		        [['text'=>"$backmod"]]
		]
		])
		
	]);
	}
		elseif($text1=="خوش آمد گویی : غیرفعال"){
	file_put_contents("data/group/well.txt","🖐 سلام به گروه خوش آمدی");
	file_put_contents("data/group/out.txt","🖐بدرود داداش 😐");
	file_put_contents("data/group/active.txt","خوش آمد گویی : فعال");
	bot('sendmessage',[
	'chat_id'=>$chat_d,
	'text'=>" خوش آمد گویی : ✅",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
		    [['text'=>"افزودن ربات در گروه"]],
		        [['text'=>"لیست گروه ها"],['text'=>"چت در گروه"]],
		        [['text'=>"خوش آمد گویی : فعال"]],
		        [['text'=>"$backmod"]]
		]
		])
		
	]);
	}
	
				elseif($text1=="بازی دوز"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"آپدیت بعدی : 22 بهمن",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
		]
		])
		
	]);
	}
	
	elseif($text1==" $c "){
	@$re = file_get_contents("reza.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$re",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"نام شما",'callback_data'=>"nam"],['text'=>"$first",'callback_data'=>"fname"]
    ],
    [
        ['text'=>"یوزرنیم",'callback_data'=>"ma"],['text'=>"$username",'url'=>"https://t.me/$username"]
        ],
         [
        ['text'=>"ایدی عددی شما",'callback_data'=>"uma"],['text'=>"$chat_d",'callback_data'=>"xasa"]
        ],
		    
		]
		])
		
	]);
	}

elseif($text1 ==  "$j" && $chat_d== $chat_d){
file_put_contents("data/$chat_d/stats.txt","calc");
    bot('sendMessage',[
 'chat_id'=>$chat_d,
 'text'=>"$jtxt",
  'reply_markup'=>json_encode([
                    'keyboard'=>[
	[['text'=>"$backbuuton"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}  
elseif($stats == "calc"){
     file_put_contents("data/$chat_d/stats.txt","none");
    $text1 = $message->text;
    $an = file_get_contents('http://api.mathjs.org/v1/?expr='.urlencode($text1));
bot('sendmessage',[
  'chat_id'=>$chat_d,
  'text'=>"جواب : $an",
   'message_id'=>$message_id,
  'parse_mode'=>"HTML"
]);
}

 elseif($text1 == "$g"){
      file_put_contents("data/$chat_d/stats.txt","tar");
      bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"$gtxt",
   'message_id'=>$message_id,
]);
}
elseif($stats == "tar"){
     file_put_contents("data/$chat_d/stats.txt","none");
    $text1 = $message->text;
    $url = "http://api.mostafa-am.ir/translate-txt/en/".$text1;
   $jsurl=json_decode(file_get_contents($url),true);
   $text1=$jsurl['text'][0];
  $urll = "http://api.mostafa-am.ir/translate-txt/fa/".$text1;
   $jsur=json_decode(file_get_contents($urll),true);
   $text1=$jsur['text'][0];
 bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"$text1 : $text1",
   'message_id'=>$message_id,
]);
}

elseif($text1 == "$b"){
$negah = rand(1 , 3);
$zakhire = rand(1 , 4);
    bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>"https://telegram.me/$username",
'caption'=>"$prof",

	]);
	}

elseif($text1 == "$d"){
    bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👇دوست عزیز شماره شما در ربات ثبت نشده است !
🔻برای ثبت شماره کلیک نمایید.",
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'inline_keyboard'=>[
	    [
	        ['text'=>"ثبت شماره",'url'=>"https://t.me/"]
	        ],
	]
	])
	]);
	}



elseif($text1 == "$e"){
    bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>"https://telegram.me/$username",
'caption'=>"$etxt",
 'message_id'=>$message_id,
 'parse_mode'=>"html",
	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'inline_keyboard'=>[
[
['text'=>"تاریخ امروز",'callback_data'=>"en"],['text'=>"$l",'callback_data'=>"bio"]
],
[
['text'=>"ساعت",'callback_data'=>"en"],['text'=>"$h",'callback_data'=>"bio"]
],
[
['text'=>"روز هفته",'callback_data'=>"en"],['text'=>"$hafte",'callback_data'=>"bio"]
],
[
['text'=>"حیوان سال",'callback_data'=>"en"],['text'=>"$m",'callback_data'=>"bio"]
],
[
['text'=>"فصل",'callback_data'=>"en"],['text'=>"$fasl",'callback_data'=>"bio"]
],
[
['text'=>"ماه",'callback_data'=>"en"],['text'=>"$mo",'callback_data'=>"bio"]
],
[
['text'=>"روز های باقیمانه از سال",'callback_data'=>"en"],['text'=>"$q",'callback_data'=>"bio"]
],
	]
	])
	]);
	}
elseif($text1 == "$feed"){
    file_put_contents("data/$chat_d/stats.txt","sticker2axe");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"استیکر خود را ارسال نمایید.",
  'message_id'=>$message_id,
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($stats == "sticker2axe"){
    file_put_contents("data/$chat_d/stats.txt","none");
  if(isset($message->sticker)){
 $file = $message->sticker->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents("data/$chat_d/axe.png",file_get_contents("https://api.telegram.org/file/bot$token/$patch"));
       bot('sendphoto',[
        'chat_id'=>$chat_id,
        'photo'=>new CURLFile("data/$chat_d/axe.png"),
         'caption'=>"عکس تبدیل شده شما 🔝"
    ]);
    unlink("data/$chat_d/axe.png");
    }
  }




elseif($text1 == "$fe"){
    file_put_contents("data/$chat_d/stats.txt","txt2gif");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$fetxt",
  'reply_to_message_id'=>$message_id,
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($stats == "txt2gif"){
    file_put_contents("data/$chat_d/stats.txt","none");
      $text2 = $message->text;
      $neman = json_decode(file_get_contents("http://www.flamingtext.com/net-fu/image_output.cgi?_comBuyRedirect=false&script=blue-fire&text=$text2&symbol_tagname=popular&fontsize=70&fontname=futura_poster&fontname_tagname=cool&textBorder=15&growSize=0&antialias=on&hinting=on&justify=2&letterSpacing=0&lineSpacing=0&textSlant=0&textVerticalSlant=0&textAngle=0&textOutline=off&textOutline=false&textOutlineSize=2&textColor=%230000CC&angle=0&blueFlame=on&blueFlame=false&framerate=75&frames=5&pframes=5&oframes=4&distance=2&transparent=off&transparent=false&extAnim=gif&animLoop=on&animLoop=false&defaultFrameRate=75&doScale=off&scaleWidth=240&scaleHeight=120&&_=1469943010141"));
$neman2 = $neman->src;
  bot('senddocument',[
        'chat_id'=>$chat_id,
        'document'=>"$neman2",
        'caption'=>"@$usernamebot"
    ]);
}
	elseif($text1 == "$seda"){
file_put_contents("data/$chat_d/stats.txt","text2voice");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$vtxt",
  'reply_to_message_id'=>$message_id,
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($stats == "text2voice"){
    file_put_contents("data/$chat_d/stats.txt","none");
    $text2 = $message->text;
    $vo = file_get_contents('http://tts.baidu.com/text2audio?lan=en&ie=UTF-8&text='.urlencode($text2));
    $voi = file_put_contents("data/$chat_d/voice.ogg",$vo);
    bot('sendvoice',[
        'chat_id'=>$chat_id,
        'voice'=> new CURLFile("data/$chat_d/voice.ogg"),
        'caption'=>"وویس $text1 : @$botuname"
    ]);
    unlink("data/$chat_d/voice.ogg");
}

elseif($text1 == "$ke"){
    file_put_contents("data/$chat_d/stats.txt","axe2sticker");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$ktxt",
  'reply_to_message_id'=>$message_id,
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($stats == "axe2sticker"){
    file_put_contents("data/$chat_d/stats.txt","none");
    if(isset($message->photo)){
$photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
       $siz = $get->result->file_size;
      $pic4 = file_get_contents("https://api.telegram.org/file/bot$token/$patch");
      file_put_contents("data/$chat_d/axe.png",$pic4);
       bot('sendsticker',[
        'chat_id'=>$chat_id,
        'sticker'=>new CURLFile("data/$chat_d/axe.png"),
    ]);
    unlink("data/$chat_d/axe.png");
    }
  }
   elseif($text1 =="$link"){
      file_put_contents("data/$chat_d/stats.txt","shorturl");
      bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"$lin",
   'message_id'=>$message_id,
]);
}
elseif($stats == "shorturl"){
     file_put_contents("data/$chat_d/stats.txt","none");
    $text2 = $message->text;
$sho = file_get_contents('https://api.bot-dev.org/short/?url='.urlencode($text2));
bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>$sho,
  'message_id'=>$message_id,
 'parse_mode'=>"MarkDown"
  ]);
}
//========-==============//
elseif($text1=="متن دستی"&& $chat_d == $admin){
				file_put_contents("data/ma1.txt","ma1");
				file_put_contents("data/time.txt","$l");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن مورد نظر شماره 1 را ارسال نمایید",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($ma1=="ma1"){
					file_put_contents("data/ma1.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/ma1.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/ma1.txt","$text1");
							file_put_contents("data/ma1.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"اولین مطلب کاربری شما تمام شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن 2"]],
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
elseif($text1=="متن 2"&& $chat_d == $admin){
				file_put_contents("data/ma2.txt","ma2");
								file_put_contents("data/time1.txt","$l");

				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن 2 :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($ma2=="ma2"){
					file_put_contents("data/ma2.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/ma2.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/ma2.txt","$text1");
							file_put_contents("data/ma2.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن 2 ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن 3"]],
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
elseif($text1=="متن 3"&& $chat_d == $admin){
				file_put_contents("data/ma3.txt","ma3");
								file_put_contents("data/time3.txt","$l");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن 3 :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($ma3=="ma3"){
					file_put_contents("data/ma3.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/ma3.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/ma3.txt","$text1");
							file_put_contents("data/ma3.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن 3 ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن 4"]],
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
elseif($text1=="متن 4"&& $chat_d == $admin){
				file_put_contents("data/ma4.txt","ma4");
						file_put_contents("data/time4.txt","$l");
		
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن 4 :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($ma4=="ma4"){
					file_put_contents("data/ma4.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/ma4.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/ma4.txt","$text1");
							file_put_contents("data/ma4.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن 4 ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"متن 5"]],
[['text'=>"اتمام مطالب"]],
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}

elseif($text1=="متن 5"&& $chat_d == $admin){
				file_put_contents("data/ma5.txt","ma5");
								file_put_contents("data/time5.txt","$l");

				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"متن 5 :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($ma5=="ma5"){
					file_put_contents("data/ma5.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/ma5.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/ma5.txt","$text1");
							file_put_contents("data/ma5.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"متن 5 ثبث شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"اتمام مطالب"]],
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
elseif($text1=="اتمام مطالب"&& $chat_d == $admin){
				file_put_contents("data/ma.txt","ma");
				bot('sendmessage',[
				'chat_id'=>$chat_id,
				'text'=>"نام دکمه چی باشد :",
				'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
				[['text'=>"$backbuuton"]],
				]
				])
				]);
				}elseif($ma=="ma"){
					file_put_contents("data/ma.txt","$text1");
				if($text1=="برگشت به منوی قبلی↪"){
						file_put_contents("data/ma.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"به منوی قبل برگشتید↪",
					'reply_markup'=>$key2,
					]);			
						}else{
							file_put_contents("data/ma.txt","$text1");
							file_put_contents("data/ma.txt","$text1");
						bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"ثبت شد",
				'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$backmod"]],

		]
		])
		
]);
}
}
	if($text1=="$ma"){
	 $time = file_get_contents("data/time.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$ma1",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
	[['text'=>"مطلب بعدی",'callback_data'=>"nex"]]	    
		]
		])
		
	]);
	}
	if($data=="nex"){
	    	 $tim = file_get_contents("data/time1.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
	   'message_id' => $message_id2,
	'text'=>"👇مطلب آپلود شده در $tim
➖➖➖➖➖➖➖➖➖➖➖➖➖
	$ma2",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
	[['text'=>"مطلب قبلی",'callback_data'=>"ne"]],[['text'=>"مطلب بعدی",'callback_data'=>"nex1"]]	    
		]
		])
		
	]);
	}
if($data=="nex1"){
    	 $ti = file_get_contents("data/time2.txt");

	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇مطلب آپلود شده در $ti 
➖➖➖➖➖➖➖➖➖➖➖➖➖
	$ma3",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[['text'=>"مطلب قبلی",'callback_data'=>"nex"]],	[['text'=>"مطلب بعدی",'callback_data'=>"nex2"]]	    
		]
		])
		
	]);
	
}
if($data=="nex2"){	 
    $tii = file_get_contents("data/time3.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
	'message_id' => $message_id2,
	'text'=>"👇مطلب آپلود شده در $tii 
➖➖➖➖➖➖➖➖➖➖➖➖➖
	$ma4",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[['text'=>"مطلب قبلی",'callback_data'=>"nex1"]],	[['text'=>"مطلب بعدی",'callback_data'=>"nex3"]]	    
		]
		])
		
	]);
	}

if($data=="nex3"){
    	 $timee = file_get_contents("data/time4.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇مطلب آپلود شده در $timee 
	➖➖➖➖➖➖➖➖➖➖➖➖➖
	$ma5",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[['text'=>"مطلب قبلی",'callback_data'=>"nex2"]], 
		]
		])
		
	]);
	}

if($data=="ne"){
$time = file_get_contents("data/time.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇مطلب آپلود شده در $time 
	➖➖➖➖➖➖➖➖➖➖➖➖➖
	$ma1",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
	[['text'=>"مطلب بعدی",'callback_data'=>"nex"]]	    
		]
		])
		
	]);
	
}
///==============-===============//
if($text1 =="/creat"){
    bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"برای ساخت ربات کلیک کنید",
	'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>"ساخت ربات",'callback_data'=>"botsaz"]],
    ]
    ])
    ]);
}
if($data=="botsaz"){
$time = file_get_contents("data/time.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"🔻دوست عزیز برای ساخت ربات کافیه :
👇از دکمه زیر استفاده کنی :
1️⃣ : نخست شماره خود را برای بازیابی اکانت خود ارسال نمایید.
2️⃣ : ربات خود را بدون برنامه نویسی بسازید .
▪️تشکر فراوان.",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
	[['text'=>"ورود و ساخت ربات",'url'=>"https://t.me/?start=$chat_d"]],	    
		]
		])
		
	]);
	
}
//=================-=============//
if($text1 =="$hosin"){
$nam = file_get_contents("data/tell.txt");    
$nam1 = file_get_contents("data/info.txt");    
$nam2 = file_get_contents("data/jok.txt");    
$nam3 = file_get_contents("data/now.txt");    
$nam4 = file_get_contents("data/dirin.txt");    
$nam5 = file_get_contents("data/yes.txt");    
$nam6 = file_get_contents("data/inline.txt");    
$nam7 = file_get_contents("data/vighe.txt");    
$nam8 = file_get_contents("data/sors.txt");    
$nam9 = file_get_contents("data/amar.txt");    
$dick = file_get_contents("data/dick.txt");
$majazi = file_get_contents("data/majzi.txt");
    bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"$dick",
	'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
    ['text'=>"$nam9",'callback_data'=>"ab"],['text'=>"$majzi",'callback_data'=>"as"]
    ],
[
    ['text'=>"$nam8",'callback_data'=>"ab1"],['text'=>"$nam4",'callback_data'=>"ab2"]
    ],
    [
        ['text'=>"$nam1",'callback_data'=>"ab3"]
        ],
[
    ['text'=>"$nam2",'callback_data'=>"ab4"],['text'=>"$nam3",'callback_data'=>"ab5"]
    ],
    [
        ['text'=>"$nam5",'callback_data'=>"ab6"]
        ],
        [
            ['text'=>"$nam6",'switch_inline_query'=>"$chat_d"],['text'=>"$nam7",'switch_inline_query'=>"set"]
            ],
            [
                ['text'=>"$nam",'callback_data'=>"tellon"]
                ],
    ]
    ])
    ]);
}


if($text1 =="$hasan"){
$nam = file_get_contents("data/tell.txt");    
$nam1 = file_get_contents("data/info.txt");    
$nam2 = file_get_contents("data/jok.txt");    
$nam3 = file_get_contents("data/now.txt");    
$nam4 = file_get_contents("data/dirin.txt");    
$nam5 = file_get_contents("data/yes.txt");    
$nam6 = file_get_contents("data/inline.txt");    
$nam7 = file_get_contents("data/vighe.txt");    
$nam8 = file_get_contents("data/sors.txt");    
$nam9 = file_get_contents("data/amar.txt");    
$dick = file_get_contents("data/dick.txt");
$majazi = file_get_contents("data/majzi.txt");
    bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"$dick",
	'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
    ['text'=>"$nam9",'callback_data'=>"ab"],['text'=>"$majazi",'callback_data'=>"as"]
    ],
[
    ['text'=>"$nam8",'callback_data'=>"ab1"],['text'=>"$nam4",'callback_data'=>"ab2"]
    ],
    [
        ['text'=>"$nam1",'callback_data'=>"ab3"]
        ],
[
    ['text'=>"$nam2",'callback_data'=>"ab4"],['text'=>"$nam3",'callback_data'=>"ab5"]
    ],
    [
        ['text'=>"$nam5",'callback_data'=>"ab6"]
        ],
        [
            ['text'=>"$nam6",'switch_inline_query'=>"$chat_d"],['text'=>"$nam7",'switch_inline_query'=>"set"]
            ],
            [
                ['text'=>"$nam",'callback_data'=>"tellon"]
                ],
    ]
    ])
    ]);
}
elseif($data == "a"){
    $url2 = "http://topapi.ir/falhafez/index.php?apikey=1";
   $jsurl=json_decode(file_get_contents($url2),true);
   $text1=$jsurl['status']['image2'];
   $text2=$jsurl['status']['text'];
    bot('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"[لینک عکس]($text1)
$text2 ",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($data == "ab4"){
    $url2 = "http://topapi.ir/text/jok/index.php?apikey=1";
   $jsurl=json_decode(file_get_contents($url2),true);
   $text2=$jsurl['status']['text'];
    bot('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"
$text2 ",
 'parse_mode'=>"MarkDown",
  ]);
}
elseif($data == "ab5"){
    $url2 = "https://topapi.ir/key1/rss/?url=http://www.yjc.ir/fa/rss/3";
   $jsurl=json_decode(file_get_contents($url2),true);
   $title=$jsurl['status']['title'];
      $title2=$jsurl['status']['title'];
    bot('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"[لینک عکس]($text1)
$title
$title2",
 'parse_mode'=>"MarkDown",
  ]);
}

	if ($data == "tellon") {
         file_put_contents("data/$chatid/saeed.txt", "sp");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "👇دوست عزیز پشنهاد میشود :
پیام  \ نظر \ و . . . هرچیز دیگر دارید را دریک پیام خلاصه و ارسال نمایید.",
        ]);

    } if ($saeed == 'sp') {
        file_put_contents("data/$chat_id/saeed.txt", "no");
		bot('sendMessage', [
            'chat_id' => "$admin",
            'text' => "
👤$first :
👇متن پایین را در تاریخ $l ارسال نمود :
➖➖➖➖➖➖
[$text1]
$space",
]);
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "▪️در صورت صحت پیام به شما جواب داده خواهد شد",
        ]);
    } 
if($text1 =="دکمه شیشه ای"&& $chat_d == $admin){
file_put_contents("data/dick.txt","منوی کاربردی ربات خوش آمدی $first");
    bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"برای ساخت کلیک نمایید :",
	'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>"ساخت دکمه شیشه ای",'callback_data'=>"make"]],
    ]
    ])
    ]);
}
if($data=="make"){
$time = file_get_contents("data/time.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"نوع چینش : را انتخاب نمایید :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"چینش : درهم1️⃣",'callback_data'=>"set1"]
        ],
		]
		])
		
	]);
	
}


if($data=="set1"){
 file_put_contents("data/shishei.txt","shie1");
 $tell = file_get_contents("data/telltik.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇در هرسرط [یک]دکمه شیشه ای قرار میگیره :",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"ساخت دکمه",'callback_data'=>"dokme"]
    ],
    [
        ['text'=>"راهنما",'callback_data'=>"help"],['text'=>"نهایی کردن",'callback_data'=>"end"]
        ],
        [
            ['text'=>"پشتیبانی: ☑️",'callback_data'=>"tell"]
            ],
		]
		])
		
	]);
	
}
if($data=="dokme"){
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"برای فعال سازی هرکدام کلیک نمایید :
🔻برای تعقییر متن هرکدام از دکمه از :
/chengall
استفاده نمایید.",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[[
    ['text'=>"جک : ☑️",'callback_data'=>"jok"],['text'=>"حافظ : ☑️",'callback_data'=>"infoall"]
    ],
[
    ['text'=>"کارتون دیرین دیرین : ☑️",'callback_data'=>"dirindirin"]
    ],
[
    ['text'=>"اطلاعات شخصی : ☑️",'callback_data'=>"yeson"],['text'=>"اینلاین : ☑️",'callback_data'=>"inline"]
    ]    ,
    [
        ['text'=>"اشتراک ویژه : ☑️",'callback_data'=>"vighe"],['text'=>"ارسال سورس : ☑️",'callback_data'=>"sors"]
        ],
        [
            ['text'=>"آمار ربات: ☑️",'callback_data'=>"amar"],['text'=>"شماره مجازی : ☑️",'callback_data'=>"majazi"]
            ],
        
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="tell"){
file_put_contents("data/tell.txt","پشتیبانی");
file_put_contents("data/telltik.txt","پشتیبانی : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇برای استفاده هرکدام کلیک نمایید :
پشتیبانی : ✅",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"ساخت دکمه",'callback_data'=>"dokme"]
    ],
    [
        ['text'=>"راهنما",'callback_data'=>"help"],['text'=>"نهایی کردن",'callback_data'=>"end"]
        ],
        [
            ['text'=>"پشتیبانی  : ✅️",'callback_data'=>"telloff"]
            ],
		]
		])
		
	]);
	
}
if($data=="telloff"){
 file_put_contents("data/tell.txt","");
 file_put_contents("data/telltik.txt","پشتیبانی : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇برای استفاده هرکدام کلیک نمایید :
پشتیبانی : ☑️",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"ساخت دکمه",'callback_data'=>"dokme"]
    ],
    [
        ['text'=>"راهنما",'callback_data'=>"help"],['text'=>"نهایی کردن",'callback_data'=>"end"]
        ],
        [
            ['text'=>"پشتیبانی  : ☑️️",'callback_data'=>"tell"]
            ],
		]
		])
		
	]);
	
}
////===========-Speak-=========///
if($data=="infoyou"){
 file_put_contents("data/info.txt","اطلاعات یاب کشور");
 file_put_contents("data/infoyou.txt","️اطلاعات یاب کشور : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
▫️اطلاعات یاب : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space️",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اطلاعات یاب کشور : ✅️",'callback_data'=>"infoyouoff"]
    ],
    [
        ['text'=>"منوی دکمه",'callback_data'=>"dokmehome"]
        ],
		]
		])
		
	]);
	
}

if($data=="infoyouoff"){
 file_put_contents("data/info.txt","");
 file_put_contents("data/infoyou.txt","️اطلاعات یاب کشور : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
▫️اطلاعات یاب : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اطلاعات یاب کشور : ☑️️",'callback_data'=>"infoyou"]
    ],
    [
        ['text'=>"منوی دکمه",'callback_data'=>"dokmehome"]
        ],
		]
		])
		
	]);
	
}
///=============---=================//
if($data=="majazi"){
 file_put_contents("data/majzi.txt","شماره مجازی");
  file_put_contents("data/majzitxt.txt"," شماره مجازی: ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
▫️شماره مجازی : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"شماره مجازی : ✅️",'callback_data'=>"majazioff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="majazioff"){
 file_put_contents("data/majzi.txt","");
  file_put_contents("data/majzitxt.txt","شماره مجازی : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
▫شماره مجازی : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"شماره مجازی : ☑️",'callback_data'=>"majazi"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
///============NumberCell===========//
if($data=="jok"){
 file_put_contents("data/jok.txt","جک");
  file_put_contents("data/joktxt.txt","جک : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
▫️جک : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"جک : ✅️",'callback_data'=>"jokoff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="jokoff"){
 file_put_contents("data/jok.txt","");
  file_put_contents("data/joktxt.txt","جک : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
▫️جک : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"جک : ☑️",'callback_data'=>"jok"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="infoall"){
 file_put_contents("data/now.txt","حافظ");
  file_put_contents("data/nowall.txt","حافظ : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
حافظ : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"حافظ : ✅",'callback_data'=>"infoalloff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="infoalloff"){
 file_put_contents("data/now.txt","");
  file_put_contents("data/nowall.txt","حافظ : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
حافظ : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"حافظ : ☑️",'callback_data'=>"infoall"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="dirindirin"){
 file_put_contents("data/dirin.txt","کارتون");
  file_put_contents("data/drinab.txt","دیرین دیرین : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
دیرین دیرین : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"دیرین دیرین : ✅",'callback_data'=>"dirinoff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="dirinoff"){
 file_put_contents("data/dirin.txt","");
  file_put_contents("data/drinab.txt","دیرین دیرین : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
دیرین دیرین : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"حافظ : ☑️",'callback_data'=>"dirindirin"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="yeson"){
 file_put_contents("data/yes.txt","اطلاعات کاربری");
  file_put_contents("data/yesab.txt","اطلاعات شخصی : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
اطلاعات شخصی : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اطلاعات شخصی : ✅",'callback_data'=>"yesoff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="yesoff"){
 file_put_contents("data/yes.txt","");
  file_put_contents("data/yesab.txt","اطلاعات شخصی : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
اطلاعات شخصی : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اطلاعات شخصی : ☑️",'callback_data'=>"yeson"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="inline"){
 file_put_contents("data/inline.txt","اشتراک برای دیگران");
  file_put_contents("data/inlineab.txt","اینلاین : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
اینلاین : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اینلاین : ✅",'callback_data'=>"inlineoff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="inlineoff"){
 file_put_contents("data/inline.txt","");
  file_put_contents("data/inlineab.txt","اینلاین : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
اینلاین : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اینلاین : ☑️",'callback_data'=>"inline"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="vighe"){
 file_put_contents("data/vighe.txt","اشتراک برای اطلاعات");
  file_put_contents("data/vigheab.txt","اشتراک ویژه : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
اشتراک ویژه : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اشتراک ویژه : ✅",'callback_data'=>"vigheoff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="vigheoff"){
 file_put_contents("data/vighe.txt","");
  file_put_contents("data/vigheab.txt","اشتراک ویژه : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
اشتراک ویژه : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"اشتراک ویژه : ☑️",'callback_data'=>"inline"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="amar"){
 file_put_contents("data/amar.txt","آمار");
  file_put_contents("data/amarab.txt","آمار : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
آمار : ✅
⬇️درحال حاضر این امکان فعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"آمار : ✅",'callback_data'=>"amaroff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="amaroff"){
 file_put_contents("data/amar.txt","");
  file_put_contents("data/amarab.txt","آمار : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
آمار : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"آمار : ☑️",'callback_data'=>"amar"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}

if($data=="sorsoff"){
 file_put_contents("data/sors.txt","");
  file_put_contents("data/sorsab.txt","سورس : ☑️");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
سورس : ☑️
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"سورس : ☑️",'callback_data'=>"sors"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
if($data=="sors"){
 file_put_contents("data/sors.txt","سورس");
  file_put_contents("data/sorsab.txt","سورس : ✅");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
سورس : ✅
⬇️درحال حاضر این امکان غیرفعال است⬇️
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"سورس : ✅",'callback_data'=>"sorsoff"]
    ],
    [
        ['text'=>"$backmod",'callback_data'=>"home"]
        ],
		]
		])
		
	]);
	
}
///==========-Speak-=============//
if($data=="home"){
$tell = file_get_contents("data/telltik.txt");
$obs =file_get_contents("data/tikab.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"👇برای استفاده هرکدام کلیک نمایید :
$tell",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
[
    ['text'=>"ساخت دکمه",'callback_data'=>"dokme"]
    ],
    [
        ['text'=>"راهنما",'callback_data'=>"help"],['text'=>"نهایی کردن",'callback_data'=>"end"]
        ],
        [
            ['text'=>"$tell",'callback_data'=>"telloff"]
            ],
		]
		])
		
	]);
	
}
if($data=="help"){
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
🔸راهنمای بخش طلایی :
🔻لطفا این 3 نکته را بخوانید :
➖➖➖➖➖➖➖➖➖
🔵ساخت دکمه شیشه ای :
🔺ادمین عزیز : برای ساخت دکمه شیشه ای شما نخست ⬇️ :
🔻دکمه های خودتون رو میسازید.
🔸بعدش بعد ساخت نهایی کردن رو میزنید.
➖➖➖➖➖➖➖➖➖
🔴استفاده از API : 
🔹برای استفاده از Api قرار داده شده کافی فقط اون ارو لمس کنید.
⏺برای فعال کردن پشتیبانی هم کافی است کلیک کنید.
➖➖➖➖➖➖➖➖➖
💭سوالات بیشتر از : @S_L_T
$space",
	'reply_markup'=>json_encode([
		'resize_keyboard'=>true,
		'inline_keyboard'=>[
        [
            ['text'=>"$backmod",'callback_data'=>"home"]
            ],
		]
		])
		
	]);
	
}
///=======-LinkSet-======//
if($text1=="عکس"){
    $url2 = "http://api.mostafa-am.ir/fun-photo/";
   $jsurl=json_decode(file_get_contents($url2),true);
   $text1=$jsurl['animals'];
   $text2=$jsurl['cars'];
   $text3=$jsurl['laugh'];
   $text4=$jsurl['nature'];
   $text5=$jsurl['textgraphy'];
   bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$text1,
		'caption'=>"$botid",
	]);
	bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$text2,
	'caption'=>"$botid",
	]);
	bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$text3,
		'caption'=>"$botid",
	]);
	bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$text4,
		'caption'=>"$botid",
	]);
	bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$text5,
	'caption'=>"$botid",
	]);
	}
if($text1 =="تست سرعت"){
$ran = rand(70 , 100);
   bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"👇درحال تست سرعت ربات شما :",
]);
 sleep(1);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id,
 'text'=>'1%'
 ]);
 sleep(1);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'18%'
 ]);
 sleep(1);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'42%'
 ]);
 sleep(1);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'53%'
 ]);
 sleep(1);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'65%'
 ]);
sleep(1);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'89%'
 ]);
sleep(0);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'99%'
 ]);
sleep(0);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'100%'
 ]);


sleep(0);
 bot('editmessagetext',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>"
🤖ربات : [$botid]
📋فرم در تست :[$l]
👈سرعت ربات :[$ran]
👇ادمین تست : [$username]
$space"
 ]);
}
	elseif ($data == "a"){
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "متن را با دقت بخوانید . . .",
            'show_alert' => false
        ]);
        file_put_contents("data/$chat_d/saeed.txt", "setc5");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "برای دریافت کارتون کلیک نمایید :",
      'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "دیرین دیرین"]
                    ],
                ]
            ])
        ]);
    }  elseif ($saeed == 'setc5') {
        file_put_contents("data/channel3.txt", $text1);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "",
           
        ]);
    } 
///==========-Cube-=========//
	elseif ($data == "ab2"){
$ran = rand(100 , 1800);
$rand = rand(100 , 1800);
$ranw = rand(100 , 1800);
$ranq = rand(100 , 1800);
$rane = rand(100 , 1800);
$ranp = rand(100 , 1800);
   bot('sendvideo',[
	'chat_id'=>$chatid,
	'video'=>"https://t.me/dirindirin/$ran",
		'caption'=>"$botid",
	]);
	bot('sendvideo',[
	'chat_id'=>$chatid,
	'video'=>"https://t.me/dirindirin/$rand",
	'caption'=>"$botid",
	]);
	bot('sendvideo',[
	'chat_id'=>$chatid,
	'video'=>"https://t.me/dirindirin/$ranw",
		'caption'=>"$botid",
	]);
	bot('sendvideo',[
	'chat_id'=>$chatid,
	'video'=>"https://t.me/dirindirin/$ranq",
		'caption'=>"$botid",
	]);
	bot('sendvideo',[
	'chat_id'=>$chatid,
	'video'=>"https://t.me/dirindirin/$rane",
	'caption'=>"$botid",
	]);
	}
		elseif ($data == "ab1"){
$ran = rand(1 , 100);
$rand = rand(1 , 100);
$ranw = rand(1 , 100);
$ranq = rand(1 , 100);
$rane = rand(1 , 100);
$ranp = rand(1 , 100);
   bot('senddocument',[
	'chat_id'=>$chatid,
	'document'=>"https://t.me/crapisors/$ran",
		'caption'=>"$botid",
	]);
	bot('senddocument',[
	'chat_id'=>$chatid,
	'document'=>"https://t.me/crapisors/$rand",
	'caption'=>"$botid",
	]);
	bot('senddocument',[
	'chat_id'=>$chatid,
	'document'=>"https://t.me/crapisors/$ranw",
		'caption'=>"$botid",
	]);
	bot('senddocument',[
	'chat_id'=>$chatid,
	'document'=>"https://t.me/crapisors/$ranq",
		'caption'=>"$botid",
	]);
	bot('senddocument',[
	'chat_id'=>$chatid,
	'document'=>"https://t.me/crapisors/$rane",
	'caption'=>"$botid",
	]);
	}
	if($data=="ab"){
 $onli = count($members) -2;
	$mmemcount = count($members) -1;
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇آمار ربات در $i به این صورت میباشد :
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
[
    ['text'=>"اعضای ربات",'callback_data'=>"amar1"],['text'=>"اعضای آنلاین",'callback_data'=>"amar2"]
    ],
    [
        ['text'=>"$mmemcount",'callback_data'=>"amar4"],['text'=>"$onli",'callback_data'=>"amar5"]
        ]
		]
		])
		
	]);
	
}
	if($data=="end"){
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇دوست عزیز این عمالات به چه صورت نمایش داده شوند ؟
دستور = /setting
دکمه = در منوی اصلی قرار میگیره
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
[
    ['text'=>"دستور",'callback_data'=>"setc"],['text'=>"دکمه",'callback_data'=>"setc2"]
    ],
   
		]
		])
		
	]);
	
}

	if($data=="ab6"){
$same = file_get_contents("data/$chatid/namme.txt");
$username = file_get_contents("data/$chatid/uname.txt");
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇اطلاعات کاربری شما در  ربات 👇
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
[
    ['text'=>"نام شما",'callback_data'=>"time1"],['text'=>"$same",'callback_data'=>"time3"]
    ],
    [
        ['text'=>"ایدی عددی شما",'callback_data'=>"time"],['text'=>"$chatid",'url'=>"https://t.me/$username"]
        ],
   [
       ['text'=>"ایدی شما",'callback_data'=>"time908"],['text'=>"$username",'url'=>"https://t.me/$username"]
       ],
		]
		])
		
	]);
	
}
////Downloadr////
	elseif ($data == "se"){
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "setc5");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "نام دکمه چی باشد ؟ :",
        ]);
    } elseif ($saeed == 'setc5') {
        file_put_contents("data/hasan.txt", $text1);
        file_put_contents("data/$chat_d/saeed.txt", "No");
        bot('senddocument', [
            'chat_id' => $chat_id,
            'document' => "",
        ]);
    } 
///Downloadrde////

	elseif ($data == "setc2"){
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "setc5");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "نام دکمه چی باشد ؟ :",
        ]);
    } elseif ($saeed == 'setc5') {
        file_put_contents("data/hasan.txt", $text1);
        file_put_contents("data/$chat_d/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "ثبت شد",
            'reply_markup' => json_encode([
              		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$hasan"]],		    
[['text'=>"$feed"],['text'=>"$link"]],	
[['text'=>"$a"]],
[['text'=>"$b"],['text'=>"$c"]],
[['text'=>"$d"]],
[['text'=>"$e"],['text'=>"$f"]],
[['text'=>"$z"]],
[['text'=>"$seda"],['text'=>"$ke"]],
[['text'=>"$ma"]],
[['text'=>"$k"],['text'=>"$j"]],
[['text'=>"$g"]],  
                ]
            ])
        ]);
    }     
    
    	elseif ($data == "setc"){
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "setc1");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "نام دستور را وارد نمایید :",
        ]);
    } elseif ($saeed == 'setc1') {
        file_put_contents("data/hosin.txt", $text1);
        file_put_contents("data/$chat_d/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "ثبت شد",
            'reply_markup' => json_encode([
              		'resize_keyboard'=>true,
		'keyboard'=>[
[['text'=>"$hasan"]],		    
[['text'=>"$feed"],['text'=>"$link"]],	
[['text'=>"$a"]],
[['text'=>"$b"],['text'=>"$c"]],
[['text'=>"$d"]],
[['text'=>"$e"],['text'=>"$f"]],
[['text'=>"$z"]],
[['text'=>"$seda"],['text'=>"$ke"]],
[['text'=>"$ma"]],
[['text'=>"$k"],['text'=>"$j"]],
[['text'=>"$g"]],  
                ]
            ])
        ]);
    }     
///==========-==========///
if("$text1"){
$javab = file_get_contents("data/word/$text1.txt");
    bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"$javab",
]);
}
////===================New_Tabe===============//
	if($data=="as"){
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇 : دریافت شماره مجازی به دو صورت امکان پذیر است :
▪️خرید شماره مجازی :
▫️ دریافت شماره مجازی رایگان از مدیریت.	
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"▪️خرید شماره▪️",'callback_data'=>"buy"],['text'=>"▫️دریافت رایگان▫️",'callback_data'=>"free"]
		        ],
		]
		])
		
	]);
	
}
	if($data=="buy"){
	bot('EditMessageText',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇لطفا یک کدام را انتخاب کن :	
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"Amrica : آمریکا️",'callback_data'=>"amrica"],
],
		    [
		        ['text'=>"China : چین️",'callback_data'=>"chin"],
		        ],
		        		    [
		        ['text'=>"Andozi : اندوزی",'callback_data'=>"ando"],
		        ],
		        		    [
		        ['text'=>"Japan : ژاپن️",'callback_data'=>"japan"],
		        ],
		        		    [
		        ['text'=>"Russia : روسیه",'callback_data'=>"russia"],
		        ],
		        		    [
		        ['text'=>"Iran : ایران",'callback_data'=>"iran"],
		        ],
		]
		])
		
	]);
	
}

	if($data=="amrica"){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"
👇سفارش جدید : 
▪️سفارش دهنده : @$username
▫️نام شخص : $first
👇اگر قصد فروش را دارید به ایدی زیر پیام ارسال نمایید.
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"$first",'url'=>"https://t.me/$username"],
],
[
    ['text'=>"مبلغ قابل دریافت شما 2000T",'callback_data'=>"give"]
    ]
		]
		])
		
	]);
		bot('sendmessage',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇سفارش داده شد :
📋 فاکتور حساب شما :
1️⃣ عدد شماره مجازی آمریکا به قیمت 2.000T .
$space",
 ]);
    
}
	if($data=="chin"){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"
👇سفارش جدید : 
▪️سفارش دهنده : @$username
▫️نام شخص : $first
👇اگر قصد فروش را دارید به ایدی زیر پیام ارسال نمایید.
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"$first",'url'=>"https://t.me/$username"],
],
[
    ['text'=>"مبلغ قابل دریافت شما 2000T",'callback_data'=>"give"]
    ]
		]
		])
		
	]);
		bot('sendmessage',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇سفارش داده شد :
📋 فاکتور حساب شما :
1️⃣:شماره مجازی چین
$space",
 ]);
    
}
	if($data=="ando"){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"
👇سفارش جدید : 
▪️سفارش دهنده : @$username
▫️نام شخص : $first
👇اگر قصد فروش را دارید به ایدی زیر پیام ارسال نمایید.
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"$first",'url'=>"https://t.me/$username"],
],
[
    ['text'=>"مبلغ قابل دریافت شما 2000T",'callback_data'=>"give"]
    ]
		]
		])
		
	]);
		bot('sendmessage',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇سفارش داده شد :
📋 فاکتور حساب شما :
1️⃣:شماره مجازی اندونزی
$space",
 ]);
    
}
	if($data=="japan"){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"
👇سفارش جدید : 
▪️سفارش دهنده : @$username
▫️نام شخص : $first
👇اگر قصد فروش را دارید به ایدی زیر پیام ارسال نمایید.
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"$first",'url'=>"https://t.me/$username"],
],
[
    ['text'=>"مبلغ قابل دریافت شما 2000T",'callback_data'=>"give"]
    ]
		]
		])
		
	]);
		bot('sendmessage',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇سفارش داده شد :
📋 فاکتور حساب شما :
1️⃣: شماره مجازی ژاپن
$space",
 ]);
    
}
	if($data=="iran"){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"
👇سفارش جدید : 
▪️سفارش دهنده : @$username
▫️نام شخص : $first
👇اگر قصد فروش را دارید به ایدی زیر پیام ارسال نمایید.
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"$first",'url'=>"https://t.me/$username"],
],
[
    ['text'=>"مبلغ قابل دریافت شما 2000T",'callback_data'=>"give"]
    ]
		]
		])
		
	]);
		bot('sendmessage',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇سفارش داده شد :
📋 فاکتور حساب شما :
1️⃣:شماره مجازی روسیه
$space",
 ]);
    
}
	if($data=="russia"){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"
👇سفارش جدید : 
▪️سفارش دهنده : @$username
▫️نام شخص : $first
👇اگر قصد فروش را دارید به ایدی زیر پیام ارسال نمایید.
$space",
	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		    [
		        ['text'=>"$first",'url'=>"https://t.me/$username"],
],
[
    ['text'=>"مبلغ قابل دریافت شما 2000T",'callback_data'=>"give"]
    ]
		]
		])
		
	]);
		bot('sendmessage',[
	'chat_id'=>$chatid,
		   'message_id' => $message_id2,
	'text'=>"
👇سفارش داده شد :
📋 فاکتور حساب شما :
1️⃣:شماره مجازی روسیه
$space",
 ]);
    
}

///=========----==============///
elseif($update->message->new_chat_member){
$new = file_get_contents("data/group/well.txt");
file_get_contents("data/group/out.txt");
$title = $update->message->chat->title;
if ($tc == 'group' | $tc == 'supergroup'){
sendAction($chat_id, 'typing');
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$new 
شما را [$first]ادد کرده .",
 	'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		     [
		         ['text'=>"$first",'url'=>"https://t.me/$username"]
		         ]
		    ]
		])
		
 ]);
}
}
elseif($update->message->delete_chat_photo){
    $title = $update->message->chat->title;
if ($tc == 'group' | $tc == 'supergroup'){
$remove_photo = $update->message->delete_chat_photo;
sendAction($chat_id, 'typing');
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$shitm",
  'parse_mode'=>'html',
	]);
	}
}
///==========---=============///
if($text1 == "تعقییر شکل"){
    bot('sendmessage',[
        'chat_id'=>$chat_d,
'text'=>"",
  'parse_mode'=>'html',
	'reply_markup'=>json_encode([
		'keyboard'=>[
]
])
]);
}

?>	
