<?php

ob_start();
ini_set("log_errors" , "off");
define('API_KEY','[TOKEN]');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//=----FUNCTION----=//

//=--------TAGS--------=//
$update = json_decode(file_get_contents("php://input"));
$message = $update->message;
$text = $message->text;
$Dev = "[ADMIN]";
@$reply = $update->message->reply_to_message->forward_from->id;
$rt = $update->message->reply_to_message;
$name =$message->from->first_name;
$chat_id = $update->message->from->id;
$tc = $update->message->chat->type;
$chatid = $update->callback_query->message->chat->id;
@$step = file_get_contents("data/$chat_id/step.txt");
@$typegold = file_get_contents("data/bottype.txt");
@mkdir("data/$chat_id");
if($text =="/start"){
            file_put_contents("data/$chat_id/step.txt","off");
var_dump(bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
سلام 😉 [$name ]
  
به ربات اب و هوا خوش اومدید 🌟

از طریق این ربات میتوانید اب و هوایه تمام شهرها  استان هارا دریافت کنید 🎖

از دکمه های زیر استفاده کن 🔻
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⛅️دریافت اب و هوای منطقه⛅️"],['text'=>"🚦 پشتیبانی"]],
]
])
]));    
if($typegold != "gold"){
var_dump(bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"ساخته شده توسط رباتساز:
@Createcupbot",
'parse_mode'=>'html']));
}}
elseif($text =="🔙"){
var_dump(bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🚦 به منوی قبلی بازگشتید
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⛅️دریافت اب و هوای منطقه⛅️"],['text'=>"🚦 پشتیبانی"]],
]
])
]));    
}
if($message->text =="⛅️دریافت اب و هوای منطقه⛅️"){
    file_put_contents("data/$chat_id/step.txt","on");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🏘 نام شهر خود را ارسال نمایید :",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
    'one_time_keyboard'=>true,
    'remove_keyboard'=>true,
'keyboard'=>[
]])]);    
}
if($step =="on"){
     file_put_contents("data/$chat_id/text.txt","$text");
        file_put_contents("data/$chat_id/step.txt","off");
    $url = json_decode(file_get_contents("https://bestapi.ml/a/wethr/speedphp.php?city_name=$text"),true);
    $time = $url["cooltm"]["result"]["time"];
$dama = $url["cooltm"]["result"]["dama"];
$jahat = $url["cooltm"]["result"]["jahatbad"];
$hava =$url["cooltm"]["result"]["hava"];
$up = $url["cooltm"]["result"]["update"];
$bish = $url["cooltm"]["result"]["bishinedama24"];
$kam = $url["cooltm"]["result"]["kaminedama24"];
$day = $url["cooltm"]["result"]["day"];
if($time !=null){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"درحال بارگذاری $text",
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🖼 نام استان / شهر : $text

♻️ $up

🔆اطلاعات هوا امروز : امروز $day هوای $hava با $dama جهت باد $jahat

♨️دمای هوا : بیشتر دما : $bish | کمترین  دمای هوا : $kam
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
    'one_time_keyboard'=>true,
    'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🌈24 ساعت آینده"],['text'=>"🌈48 ساعت آینده"],['text'=>"🌈72 ساعت آینده"]],
[['text'=>"🔙"]]
]])]);    
}else{
	bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"دوست عزیز این شهر/ استان یافت نشد متاسفم️"
		]);
    
}}
if($text =="🌈24 ساعت آینده"){
    $city = file_get_contents("data/$chat_id/text.txt");
        file_put_contents("data/$chat_id/step.txt","off");
    $url = json_decode(file_get_contents("https://bestapi.ml/a/wethr/speedphp.php?city_name=$city"),true);
$hava = $url["cooltm"]["result"]["saataval24"]["avalhava24"];
$dama = $url["cooltm"]["result"]["saataval24"]["avaldama24"];
$photo = $url["cooltm"]["result"]["saataval24"]["avalphoto24"];

bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>"
☁️استان / شهر : $city

⭐️دمای هوا : $dama
",
]);    
}

if($text =="🌈72 ساعت آینده"){
    $city = file_get_contents("data/$chat_id/text.txt");
        file_put_contents("data/$chat_id/step.txt","off");
    $url = json_decode(file_get_contents("https://bestapi.ml/a/wethr/speedphp.php?city_name=$city"),true);
$hava = $url["cooltm"]["result"]["saatsevom24"]["sevomhava24"];
$dama = $url["cooltm"]["result"]["saatsevom24"]["sevomdama24"];
$photo = $url["cooltm"]["result"]["saatsevom24"]["sevomphoto24"];
bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>"
☁️استان / شهر : $city

⭐️دمای هوا : $dama
",
]);    
}

if($text =="🌈48 ساعت آینده"){
    $city = file_get_contents("data/$chat_id/text.txt");
        file_put_contents("data/$chat_id/step.txt","off");
    $url = json_decode(file_get_contents("https://bestapi.ml/a/wethr/speedphp.php?city_name=$city"),true);
$hava = $url["cooltm"]["result"]["saatdovom24"]["dovomhava24"];
$dama = $url["cooltm"]["result"]["saatdovom24"]["dovomdama24"];
$photo = $url["cooltm"]["result"]["saatdovom24"]["dovomphoto24"];

bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>"
☁️استان / شهر : $city

⭐️دمای هوا : $dama
",
]);    
}
elseif($text=="🚦 پشتیبانی" && $tc == "private"){
			file_put_contents("data/$chat_id/step.txt","nazarshoma");
				bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"
نظرات شما باعث دلگرمی ماست❤️
➖➖➖➖➖
انتفادات پیشنهادات و نظرات خود را برای ما ارسال کنید✔️
➖➖➖
پیام خود را وارد کنید		
",
                 'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
[['text'=>"🔙"]]
	]
	])
	]);
	}
	elseif($step == "nazarshoma" ){   
	    if ($text != "🔙") {	

$message_id = $update->message->message_id;
bot('ForwardMessage',[
'chat_id'=>[ADMIN],
'from_chat_id'=>$chat_id,
'message_id'=>$message_id,
]);
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"✔️نظر شما ارسال شد.\nبا تشکر از شما",
	]);	
	}}
	elseif($text == "$text" && $rt && $chat_id == [ADMIN]){
	bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"پیام شما برای فرد ارسال شد ✔️"
		]);
	bot('sendmessage',[
        "chat_id"=>$reply,
        "text"=>"🙃پاسخ مدیریت <i>: $text</i>",
'parse_mode'=>'html'
		]);
}