<?php
ini_set("log_errors" , "off");
ob_start();
include 'Class.php';
include 'jdf.php';
//
$button_manage = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
[['text'=>'پیام همگانی'],['text'=>'فوروارد همگانی']],
[['text'=>'آمار']],
],'resize_keyboard'=>true]);
$button_admin = json_encode(['keyboard'=>[
[['text'=>'دریافت لینک اختصاصی دعوت از دوستان ✉️']],
[['text'=>'ساخت کد شارژ😱'],['text'=>"دریافت نت رایگان🗳"]],
[['text'=>'تعداد زیر مجموعه های من👤']],
[['text'=>"مدیریت"]],
],'resize_keyboard'=>true]);
$button_official = json_encode(['keyboard'=>[
[['text'=>'دریافت لینک اختصاصی دعوت از دوستان ✉️']],
[['text'=>'ساخت کد شارژ😱'],['text'=>"دریافت نت رایگان🗳"]],
[['text'=>'تعداد زیر مجموعه های من👤']],
],'resize_keyboard'=>true]);
$button_operator = json_encode(['keyboard'=>[
[['text'=>'💙همراه اول💙']],
[['text'=>'💛ایرانسل💛'],['text'=>'💜رایتل💜']],
[['text'=>'↩️منوی اصلی']],
],'resize_keyboard'=>true]);
$button_net = json_encode(['keyboard'=>[
[['text'=>'10 گیگ l سه ماهه♻️'],['text'=>'25 گیگ l یک ماهه♻️']],
[['text'=>'↩️منوی اصلی']],
],'resize_keyboard'=>true]);
$button_back = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
],'resize_keyboard'=>true]);
//
$update = json_decode(file_get_contents('php://input'));
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->message->from->id;
$messageid = $update->callback_query->message->message_id;
$data_id = $update->callback_query->id;
$txt = $update->callback_query->message->text;
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$from_username = $update->message->from->username;
$from_first = $update->message->from->first_name;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$text = $update->message->text;
$message_id = $update->message->message_id;
$stickerid = $update->message->sticker->file_id;
$videoid = $update->message->video->file_id;
$voiceid = $update->message->voice->file_id;
$fileid = $update->message->document->file_id;
$photo = $update->message->photo;
$photoid = $photo[count($photo)-1]->file_id;
$musicid = $update->message->audio->file_id;
$caption = $update->message->caption;
$cde = time();
$code = md5("$cde$from_id");
$time = jdate("h:i:s");
$date = jdate("Y F d");
$kanalnet = "[*[Channel]*]";
$command = file_get_contents('user/'.$from_id."/command.txt");
$coin = file_get_contents('user/'.$from_id."/coin.txt");
$username = $update->message->from->username;
$name = $update->message->from->first_name;
$coin_wait = file_get_contents('user/'.$wait."/coin.txt");
$Member = file_get_contents('admin/Member.txt');
$data = $update->callback_query->data;
$hessab = file_get_contents("data/bottype.txt");
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$kanalnet&user_id=$from_id"));
$tch = $truechannel->result->status;
//
if(strpos($block ,"$from_id") !== false){
SendMessage($chat_id,"شما از ربات بلاک شده اید!");
return false;
}
//
elseif ($from_id != $chat_id and $chat_id != $feed) {
LeaveChat($chat_id);
}
//===============
elseif(strpos($text,'/start') !== false) {
$id = str_replace("/start ","",$text);
mkdir("user/$from_id");
if (!file_exists("user/$from_id/coin.txt")) {
save("user/$from_id/coin.txt","0");
save("user/$from_id/command.txt","none");
SendMessage($chat_id,"`👤 ثبت نام با موفقیت انجام شد .`
/start
را دوباره ارسال کنید 😊","markdown","true");
if ($id != "") {
if ($id != $from_id) {
SendMessage($id,"یک نفر با لینک اختصاصی شما وارد ربات شد.");
$coin = file_get_contents("user/$id/coin.txt");
settype($coin,"integer");
$newcoin = $coin + 1;
save("user/$id/coin.txt",$newcoin);
}else{
SendMessage($chat_id,"شما قبلا در ربات عضو بودید !");
}}}
if($hessab != "gold"){
SendMessage($chat_id,"ربات خود را بسازید :
@Createcupbot","html","true",$button_admin);
}else{
SendMessage($chat_id,"یک گزینه انتخاب کنید","html","true",$button_official);
}}
//==============
elseif($text == '↩️منوی اصلی'){
if($from_id == $admin){
file_put_contents('user/'.$from_id."/command.txt","none");
SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_admin);
}else{
file_put_contents('user/'.$from_id."/command.txt","none");
SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official);
}}
//===============
elseif($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
SendMessage($chat_id,"📛 برای حمایت از ما و همچنان ربات ابتدا وارد کانال های زیر بشید 👇

🆔 $kanalnet

✅ سپس روی JOIN بزنید و به ربات برگشته عبارت 👇

🔸 /start

✴️ رو بزنید تا دکمه های ربات نمایش داده بشن👌","html","true",$button_remove);
}
//===============
elseif($text == 'ساخت کد شارژ😱'){
SendMessage($chat_id,"اپراتور خود را انتخاب کنید","html","true",$button_operator);
}
//===============
elseif($text == '💛ایرانسل💛'){
if($coin >= 7){
$rand = rand(0000000000000000,9999999999999999);
$ce = $rand;
SendMessage($chat_id,"کد شارژ شما ساخته شد 👇

♨️ کد شارژ : `$ce`

برای کپی شدن روی کد کلیک کنید.","markdown","true",$button_official);
$gold = file_get_contents("user/$chat_id/coin.txt");
$newgold = $gold - 7;
save("user/$chat_id/coin.txt","$newgold");
}else{
SendMessage($chat_id,"متاسفانه تعداد زیر مجموعه های شما به 7 نرسیده لطفا برای دریافت لینک دعوت خود به دکمه (دریافت لینک اختصاصی دعوت از دوستان ✉️) مراجعه کنید.","html","true",$button_official);
}}
//===============
elseif($text == '💙همراه اول💙'){
if($coin >= 10){
$rand = rand(000000000000000,999999999999999);
$ce = $rand;
SendMessage($chat_id,"کد شارژ شما ساخته شد 👇

♨️ کد شارژ : `$ce`

برای کپی شدن روی کد کلیک کنید.","markdown","true",$button_official);
$gold = file_get_contents("user/$chat_id/coin.txt");
$newgold = $gold - 10;
save("user/$chat_id/coin.txt","$newgold");
}else{
SendMessage($chat_id,"متاسفانه تعداد زیر مجموعه های شما به 10 نرسیده لطفا برای دریافت لینک دعوت خود به دکمه (دریافت لینک اختصاصی دعوت از دوستان ✉️) مراجعه کنید.","html","true",$button_official);
}}
//===============
elseif($text == '💜رایتل💜'){
if($coin >= 5){
$rand = rand(0000000000000000,9999999999999999);
$ce = $rand;
SendMessage($chat_id,"کد شارژ شما ساخته شد 👇

♨️ کد شارژ : `$ce`

برای کپی شدن روی کد کلیک کنید.","markdown","true",$button_official);
$gold = file_get_contents("user/$chat_id/coin.txt");
$newgold = $gold - 5;
save("user/$chat_id/coin.txt","$newgold");
}else{
SendMessage($chat_id,"متاسفانه تعداد زیر مجموعه های شما به 5 نرسیده لطفا برای دریافت لینک دعوت خود به دکمه (دریافت لینک اختصاصی دعوت از دوستان ✉️) مراجعه کنید.","html","true",$button_official);
}}
//========================
elseif($text == "دریافت نت رایگان🗳"){
sendmessage($chat_id,"مقدار و زمان اینترنت خود را انتخاب کنید!","html","true",$button_net);
}
//===============
elseif($text == "10 گیگ l سه ماهه♻️"){
if($coin >= 20){
SendMessage($chat_id,"شماره خود را ارسال کنید !
توجه کنید که تعداد درخاست کننده گان زیاد است پس صبور باشید...","html","true",$button_official);
$gold = file_get_contents("user/$chat_id/coin.txt");
$newgold = $gold - 20;
save("user/$chat_id/coin.txt","$newgold");
}else{
SendMessage($chat_id,"متاسفانه تعداد زیر مجموعه های شما به 20 نرسیده لطفا برای دریافت لینک دعوت خود به دکمه (دریافت لینک اختصاصی دعوت از دوستان ✉️) مراجعه کنید.","html","true",$button_official);
}}
//===============
elseif($text == "25 گیگ l یک ماهه♻️"){
if($coin >= 35){
SendMessage($chat_id,"شماره خود را ارسال کنید !
توجه کنید که تعداد درخاست کننده گان زیاد است پس صبور باشید...","html","true",$button_official);
$gold = file_get_contents("user/$chat_id/coin.txt");
$newgold = $gold - 35;
save("user/$chat_id/coin.txt","$newgold");
}else{
SendMessage($chat_id,"متاسفانه تعداد زیر مجموعه های شما به 35 نرسیده لطفا برای دریافت لینک دعوت خود به دکمه (دریافت لینک اختصاصی دعوت از دوستان ✉️) مراجعه کنید.","html","true",$button_official);
}}    
//===============
elseif($text == 'تعداد زیر مجموعه های من👤'){
SendMessage($chat_id,"شما $coin زیر مجموعه دارید.️","html","true",$button_official);
}
//===============
elseif($text == 'دریافت لینک اختصاصی دعوت از دوستان ✉️'){
var_dump(bot('sendPhoto',[
'chat_id'=>$update->message->chat->id,
'photo'=>"http://uupload.ir/files/p5to_photo_2017-07-29_11-52-50.jpg",
'caption'=>"ـ$name دعوتت کرده که عضو ربات شارژ رایگان بشی در این ربات میتونی کد شارژ درست کنی و شارژ بفروشی یا مثلا برای خودت شارژ بگیری روی لینک زیر کلیک کن👇
t.me/$UserNameBot?start=$from_id"]));
SendMessage($chat_id,"دعوت‌نامه بالا رو برای دوستات و در گرو‌ه‌هایی که عضو هستی، بفرست ⤴️","html","true",$button_official);
}
//===============
elseif($text == 'مدیریت' and $from_id == $admin){
SendMessage($chat_id,"به پنل مدیریت خوش اومدید","html","true",$button_manage);
}
elseif($text == 'آمار' and $from_id == $admin){
$txtt = file_get_contents('admin/Member.txt');
$member_id = explode("\n",$txtt);
$mmemcount = count($member_id) -1;
SendMessage($chat_id,"کل کاربران: $mmemcount نفر","html","true");
}
elseif($text == 'فوروارد همگانی' and $from_id == $admin){
file_put_contents("user/".$from_id."/command.txt","s2a fwd");
SendMessage($chat_id,"پیام مورد نظر را فوروارد کنید","html","true",$button_back);
}
elseif($command == 's2a fwd' and $from_id == $admin){
file_put_contents("user/".$from_id."/command.txt","none");
SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
$all_member = fopen( "admin/Member.txt", 'r');
while( !feof( $all_member)) {
$user = fgets( $all_member);
ForwardMessage($user,$admin,$message_id);
}}
elseif($text == 'پیام همگانی' and $from_id == $admin){
file_put_contents("user/".$from_id."/command.txt","s2a");
SendMessage($chat_id,"پیامتون رو وارد کنید","html","true",$button_back);
}
elseif($command == 's2a' and $from_id == $admin){
file_put_contents("user/".$from_id."/command.txt","none");
SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
$all_member = fopen( "admin/Member.txt", 'r');
while( !feof( $all_member)) {
$user = fgets( $all_member);
if($sticker_id != null){
SendSticker($user,$stickerid);
}
elseif($videoid != null){
SendVideo($user,$videoid,$caption);
}
elseif($voiceid != null){
SendVoice($user,$voiceid,'',$caption);
}
elseif($fileid != null){
SendDocument($user,$fileid,'',$caption);
}
elseif($musicid != null){
SendAudio($user,$musicid,'',$caption);
}
elseif($photoid != null){
SendPhoto($user,$photoid,'',$caption);
}
elseif($text != null){
SendMessage($user,$text,"html","true");
}}}
// End Source
$txxt = file_get_contents('admin/Member.txt');
$pmembersid= explode("\n",$txxt);
if (!in_array($chat_id,$pmembersid)){
$aaddd = file_get_contents('admin/Member.txt');
$aaddd .= $chat_id."\n";
file_put_contents('admin/Member.txt',$aaddd);
}
//
if(file_exists("erorr_log")){
unlink('error_log');}
//
?>