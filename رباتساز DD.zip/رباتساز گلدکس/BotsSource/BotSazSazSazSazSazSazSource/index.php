<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[(*TOKEN*)]');
ini_set("log_errors" , "off");
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$c_id2 = $message->forward_from_chat->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactnum = $contact->phone_number;
$admin = "[(*ADMIN*)]";
$channel_logs = "[(*CHANNEL*)]";
$rpto = $update->message->reply_to_message->forward_from->id;
$URL = "http://Crystal.megaranhost.ir/Altos";
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$createfree = $user["createfree"];
$createbot = $user["createbot"];
$Stoken = $user["Stoken"];
$type = $user["type"];
$yourbotsaz = $user["yourbotsaz"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
//------
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($textmessage == "/start" or $textmessage == "🔙"){
	$num = $user["number"];
	if($num == null){
		$user["step"] = "contact";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به ربات ساز ما خوشامدید😊🌹
با این ربات میتونی برای خودت یک ربات ساز بسازی🙂
برای شروع به وسیله دکمه زیر شمارت رو شیر کن👇🏻",
 'parse_mode'=>"HTML",
 'reply_to_message_id'=>$message_id,
 	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>'➰تنظیم شماره من➰' , 'request_contact' => true]
                ]
            	],
            	'resize_keyboard'=>true
       		])
	 ]);  
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به ربات ساز طلائی خوشومدی دوست من🤠
با استفاده از من میتونی برای خودت یک ربات ساز کامل داشته باشی 🎉
البته این ربات ساز رایگان نیست🔴
برای ساخت یک ربات ساز کامل و بدون تبلیغ فقط کافیه با مبلغ 8 هزار تومان اقدام به ساخت ربات ساز خودت بکنی✔️
برای تست از بخش ساخت ربات رایگان میتونی برای یک روز ربات ساز خودتو داشته باشی➰
جهت خرید حساب ویژه هم میتونی از دکمه های زیر استفاده بکنی⬇️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"▪️ساخت ربات ساز▪️"]],
	[['text'=>"🔻آپدیت ربات ساز🔻"],['text'=>"🔺حذف ربات ساز🔺"]],
	    [['text'=>"🔸ساخت ربات رایگان🔸"]],
	[['text'=>"▫️لیست ربات های من▫️"],['text'=>"🔘خرید حساب ویژه🔘"]],
	[['text'=>"➰پشتیبانی➰"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	}
	if($contact && $step == "contact"){
	 if($contactid == $from_id){
		  $offset = strpos($contactnum,"98");
 if ($offset !== false){
	 $user["number"] = $contactnum;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به ربات ساز طلائی خوشومدی دوست من🤠
با استفاده از من میتونی برای خودت یک ربات ساز کامل داشته باشی 🎉
البته این ربات ساز رایگان نیست🔴
برای ساخت یک ربات ساز کامل و بدون تبلیغ فقط کافیه با مبلغ 8 هزار تومان اقدام به ساخت ربات ساز خودت بکنی✔️
برای تست از بخش ساخت ربات رایگان میتونی برای یک روز ربات ساز خودتو داشته باشی➰
جهت خرید حساب ویژه هم میتونی از دکمه های زیر استفاده بکنی⬇️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"▪️ساخت ربات ساز▪️"]],
	[['text'=>"🔻آپدیت ربات ساز🔻"],['text'=>"🔺حذف ربات ساز🔺"]],
	    [['text'=>"🔸ساخت ربات رایگان🔸"]],
	[['text'=>"▫️لیست ربات های من▫️"],['text'=>"🔘خرید حساب ویژه🔘"]],
	[['text'=>"➰پشتیبانی➰"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
     }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لطفا فقط از شماره ایران جهت ساخت ربات ساز استفاده کنید❌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
 	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>'➰تنظیم شماره من➰' , 'request_contact' => true]
                ]
            	],
            	'resize_keyboard'=>true
       		])
	 ]);  
	 }
	 }else{
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لطفا با استفاده از دکمه زیر اقدام به ثبت شماره خود نمایید👇🏻",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
 	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>'➰تنظیم شماره من➰' , 'request_contact' => true]
                ]
            	],
            	'resize_keyboard'=>true
       		])
	 ]);
	 }
	 }
	 //---
	  elseif($textmessage == "➰پشتیبانی➰"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به پشتیبانی آنلاین ربات ساز خوش اومدی😊
از الان هر پیامی بفرستی به مدیران ربات ارسال میشه😊
برای قطع مکالمه از دکمه زیر استفاده کن👇🏻",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
	   elseif($step == "support" and $textmessage != "🔙"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیام شما به پشتیبانی ارسال شد منتظر جواب بمانید😃
برای لغو گفتگو از دکمه زیر استفاده کنید👇🏻",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"دوست عزیز شما یک پیام از طرف پشتیبانی ربات دریافت کردید✔️
------------------------------
$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما به فرد ارسال شد✔️",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	 //---
	 elseif($textmessage == "🔘خرید حساب ویژه🔘"){
		 if($type == "vip"){
			 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ما ویژه است🌹
با تشکر از خرید شما😃",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }else{
			 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش خرید حساب ویژه خوش آمدی😁
برای ساخت ربات ساز میتونی اول برای یک روز یک ربات ساز بسازی و تست کنی !
از بخش (ساخت ربات رایگان) اقدام به این کار کن.
برای خرید حساب ویژه فقط با مبلغ 8 هزار تومان با استفاده از دکمه (پشتیبانی) با مدیران ربات در ارتباط باش😅
با تشکر",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
			 
		 }
	 }
	 //---
	  elseif($textmessage == "▫️لیست ربات های من▫️"){
		 if($createbot == "true" and $type == "vip"){
			 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ویژه است✔️
شما در ربات یک ربات ساز با آیدی
@$yourbotsaz
دارید که در سیستم ما ثبت شده🌟
توکن این ربات را نیز میتوانید از @BotFather بدست آورید😅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [['text'=>"➰ورود به ربات ساز شما➰", 'url'=>"https://telegram.me/$yourbotsaz"]],
              ]
        ])
	 ]);  
		 }else{
			 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما هنوز در ربات ساز ما رباتی ثبت نکرده اید📛
برای ثبت ربات ساز خود از بخش (ساخت ربات ساز) اقدام به ساخت ربات ساز شخصی خود نمایید😄",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
			 
		 }
	 }
	 //---
	 elseif($textmessage == "🔻آپدیت ربات ساز🔻"){
			  $user["step"] = "updatebotsaz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش آپدیت ربات ساز خوش اومدی دوست من🌹
توجه داشته باش که با آپدیت ربات ساز هیچ مشکلی برای تنظیمات ربات ساز و اعضای ربات سازت پیش نماید فقط ربات سازت به آخرین نسخه آپدیت میشه😄
▪️اگه قصد ادامه داری توکن ربات سازت رو برای از @BotFather ارسال کن :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	 }
	 elseif($step == "updatebotsaz" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("../../BotSaz/$un/index.php"))){
		 $user["step"] = "none";
		 $user["yourbotsaz"] = $un;
		 $user["type"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	file_get_contents("$URL/BotSazSazApi.php?token=$textmessage&id=$from_id&type=update");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپسس ..
ربات ساز @$un با موفقیت در سیستم ما آپدیت شد😊
در ربات خود یک مرتبه دستور /start را ارسال کنید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز آپدیت شد❗️
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"خطایی رخ داد❌
ممکن است :
1️⃣توکن شما نادرست باشد(چک کنید).
2️⃣توکن شما مربوط به @$yourbotsaz نباشد (توکن همین ربات را ارسال نمایید).
حال دوباره توکن را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
}
}
	 //---
	 elseif($textmessage == "🔺حذف ربات ساز🔺"){
		 if($type == "vip"){
			  $user["step"] = "deletebotsaz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش حذف ربات ساز خوش اومدی دوست من🌹
توجه داشته باش که با حذف ربات ساز همه اعضای ربات سازت پاک میشن و ربات ساز تو از سیستم ما حذف میشه و در عوض میتونی یک ربات ساز دیگه بسازی !😄
▪️اگه قصد ادامه داری توکن ربات سازت رو برای از @BotFather ارسال کن :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	 }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه نمیباشد و هنوز در سیستم ما ربات سازی ثبت نکرده اید❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);   
	 }
	 }
		 elseif($step == "deletebotsaz" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("../../BotSaz/$un/index.php")) && $un == $yourbotsaz){
	file_get_contents("$URL/BotSazSazApi.php?token=$textmessage&id=$from_id&type=delete");
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپسس ...
ربات ساز شما با آیدی @$un با موفقیت از سیستم ما حذف شد❌
جهت ساخت ربات ساز میتوانید از طریق همین ربات اقدام کنید ...",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز حذف شد❗️
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots - 1;
                       file_put_contents("data/vipbots.txt",$newbots);
	 $user["step"] = "none";
	 $user["createbot"] = "none";
	 $user["yourbotsaz"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"خطایی رخ داد❌
ممکن است :
1️⃣توکن شما نادرست باشد(چک کنید).
2️⃣توکن شما مربوط به @$yourbotsaz نباشد (توکن همین ربات را ارسال نمایید).
حال دوباره توکن را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
}
}
	 //---
	 elseif($textmessage == "▪️ساخت ربات ساز▪️"){
		 if($type == "vip" and $createbot == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر گرامی😃
حتی اعضای ویژه نیز نمیتوانند بیشتر از یک ربات ساز بسازند😁
شما از قبل یک ربات ساز با آیدی @$yourbotsaz ساخته اید🙂
همچنین میتوانید از بخش (حذف ربات ساز) این ربات ساز رو حذف کنید و یکی دیگه بسازید😄",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($type == "vip"){
			if($createbot != "true"){
			$user["step"] = "createbot";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با تشکر از خرید شما🌹
حساب شما ویژه است و میتوانید ربات ساز شخصی خود را داشته باشید✔️
🔸جهت ساخت ربات ساز شخصی خود در مرحله اول میبایست از @BotFather توکن خود را گرفته و اینجا ارسال نمایید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{
			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دوست من !
حساب شما در ربات ساز ویژه نمیباشد😅
برای تست ربات ساز میتوانید از بخش (ساخت ربات رایگان) برای یک روز ربات ساز خود را بسازید😃
جهت خرید اشتراک با استفاده از دکمه (پشتیبانی)  اقدام به خرید نمایید😄
قیمت خرید اشتراک 8 هزار تومان بوده ➰
با تشکر🌟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbot" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("../../BotSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbot"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	file_get_contents("$URL/BotSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد✔️
آیدی ربات ساز شما :
@$un
مدیر ربات ساز :
[$from_id](tg://user?id=$from_id)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز ساخته شد❗️
نوع حساب : ویژه
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپس !
مشکلی پیش اومد😢
احتمالا توکن خرابه یا این ربات با این آیدی قبلا ثبت شده😊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
	}
	//---
	elseif($textmessage == "🔸ساخت ربات رایگان🔸"){
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"در حال حاظر امکان ساخت ربات رایگان (1 روزه) در ربات ساز غیرفعال است❌",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
   ]);  
  }
//-----admin-panel-----
elseif($textmessage == "مدیریت" or $textmessage == "پنل" or $textmessage == "/panel"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"مدیر گرامی به پنل مدیریت ربات ساز خوش آمدید😊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"➰آمار کلی➰"]],
	[['text'=>"🔸ویژه کردن🔸"],['text'=>"🔹لغو حساب ویژه🔹"]],
	    [['text'=>"🎗دریافت شماره کاربر🎗"]],
	[['text'=>"➰ارسال همگانی➰"],['text'=>"➰فروارد همگانی➰"]],
	   [['text'=>"🌟شارژ ربات ساز برای ساخت ربات ساز🌟"]],
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما دسترسی به بخش مدیریت را ندارید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "➰آمار کلی➰"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers
🔸تعداد ربات های ویژه : $vipbots
🔹تعداد ربات های رایگان : $freebots",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "🔸ویژه کردن🔸"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما با موفقیت توسط مدیران ربات ویژه شد🌹
ازین پس میتوانید ربات ساز شخصی خود را داشته باشید😃
با تشکر از خرید شما😊",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔹لغو حساب ویژه🔹"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما توسط مدیران ربات ساز رایگان شد😄",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "➰ارسال همگانی➰"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال همگانی ارسال نمایید➰",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "🔙"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "➰فروارد همگانی➰"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "🔙" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "🎗دریافت شماره کاربر🎗"){	
$user["step"] = "getnumber";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"💥برای دریافت شما کاربر آیدی عددی فرد را ارسال کنید :",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); }
elseif($chat_id == $admin and $textmessage != "🔙" && $step == "getnumber"){
	if(file_exists("data/$textmessage.json")){
		$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$number1 = $user1["number"];
bot('sendContact',[
 'chat_id'=>$admin,
 'phone_number'=>$number1,
 'first_name'=>"شماره فرد",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"شماره فرد ارسال شد😄
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
]);
}
}		
elseif($chat_id == $admin and $textmessage == "🌟شارژ ربات ساز برای ساخت ربات ساز🌟"){
$user["step"] = "charge";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای شارژ ربات ساز آیدی ربات ساز رو بدون @ ارسال کنید😄",
 'parse_mode'=>"MarkDown",
     'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]);
}
elseif($chat_id == $admin and $textmessage != "🔙" && $step == "charge"){
if(file_exists("../../BotSaz/$textmessage/index.php")){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر برای ساخت 1 عدد ربات ساز شارژ شد!",
 'parse_mode'=>"MarkDown",
]);
$settings = json_decode(file_get_contents("../../BotSaz/$textmessage/data/settings.json"),true);
$sellbotsaz = $settings["sellbotsaz"];
$new = $sellbotsaz + 1;
$settings["sellbotsaz"] = $new;
$outjson1 = json_encode($settings,true);
file_put_contents("../../BotSaz/$textmessage/data/settings.json",$outjson1);
}else{
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"ربات ساز مورد نظر یافت نشد!",
 'parse_mode'=>"MarkDown",
]);  
    
}
}
unlink('error_log');
?>

 'chat_id'=>$textmessage,
 'text'=>"حساب شما در سرویس ربات ساز هوشمند در بخش نقره ای ویژه شد🎉",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔹ویژه کردن برنزی🔹"){	
$user["step"] = "set-vip-user-bnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"برگشت⇦"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "برگشت⇦" and $step == "set-vip-user-bnz"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typebnz"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما در سرویس ربات ساز هوشمند در بخش برنزی ویژه شد🎉
",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔹ویژه کردن الماسی🔹"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"برگشت⇦"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "برگشت⇦" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما در سرویس ربات ساز هوشمند در بخش الماسی ویژه شد🎉",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔹رایگان کردن حساب الماسی🔹"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"برگشت⇦"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب ویژه شما باطل شد🤘🏿",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "❄️ارسال پیام همگانی❄️"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال همگانی ارسال نمایید➰",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"برگشت⇦"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "برگشت⇦"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "🌈فروارد همگانی🌈"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"برگشت⇦"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "برگشت⇦" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
}
}
unlink('error_log');
?>
?>
