<?php
set_time_limit(0);
ob_start();
$API_KEY = '[*[TOKEN]*]';
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown"
    ]);
}

function deletemessage($chat_id, $message_id)
{
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function sendaction($chat_id, $action)
{
    bot('sendchataction', [
        'chat_id' => $chat_id,
        'action' => $action
    ]);
}

function Forward($KojaShe, $AzKoja, $KodomMSG)
{
    bot('ForwardMessage', [
        'chat_id' => $KojaShe,
        'from_chat_id' => $AzKoja,
        'message_id' => $KodomMSG
    ]);
}

function sendphoto($chat_id, $photo, $action)
{
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'action' => $action
    ]);
}

function objectToArrays($object)
{
    if (!is_object($object) && !is_array($object)) {
        return $object;
    }
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    return array_map("objectToArrays", $object);
}

 //==== متغیر ها ====//
 $admin_keyboard = json_encode([
			'resize_keyboard'=>true,
                'keyboard' => [
                    [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
                    [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ]
                ]
            ]);
 $back_keyboard = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
         [['text'=>"🔚 برگشت به منوی ادمین"]]
         ]
     ]);
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$channel_post = $update->message->channel_post;
$code = file_get_contents("data/code.txt");
$code2 = file_get_contents("data/code2.txt");
$chid = $update->channel_post->message->message_id;
$chat_id = $message->chat->id;
$name = $update->message->from->first_name;
$last = $update->message->from->last_name;
$username = $update->message->from->username;
$message_id = $message->message_id;
$from_id = $message->from->id;
$c_id = $message->forward_from_chat->id;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
@$shoklt = file_get_contents("data/$chat_id/shoklat.txt");
@$sea = file_get_contents("data/$chat_id/membrs.txt");
@$penlist = file_get_contents("data/pen.txt");
$text = $message->text;
@mkdir("data/$chat_id");
@$ali = file_get_contents("data/$chat_id/ali.txt");
@$list = file_get_contents("users.txt");
$ADMIN = '[*[ADMIN]*]';
$channel = file_get_contents("data/channel.txt");
$channel2 = file_get_contents("data/channel2.txt");
$bot_type = file_get_contents("data/bottype.txt");
$adstext = file_get_contents("data/adstext.txt");
$creator_cmd = file_get_contents("data/creator-cmd.txt");
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id2 = $update->callback_query->message->message_id;
$fromm_id = $update->inline_query->from->id;
$fromm_user = $update->inline_query->from->username;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
$message_id222 = $update->message->message_id;
if(!file_exists("data/$from_id")){file_put_contents("data/$from_id/membrs.txt","0");}

if ($text =="/start") {
        $user = file_get_contents('users.txt');
        $members = explode("\n", $user);
        if (!in_array($from_id, $members)) {
            $add_user = file_get_contents('users.txt');
            $add_user .= $from_id . "\n";
            file_put_contents("data/$chat_id/membrs.txt", "0");
            file_put_contents("data/$chat_id/shoklat.txt", "10");
            file_put_contents('users.txt', $add_user);
        }
        			if($bot_type != 'gold'){
		bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>$adstext,
		]);
	}
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📱به ربات هک تلگرام (غیر قانونی)خوش اومدین🌹
💯با دقت مطالعه کنید💯
⚒ کارایی های ربات : 
1⃣ توانایی تشخیص نام مخاطبینی که در حال چت در اکانت هک شده هستند.  
❗️این ربات توانایی تشخیص متن پیام ها را (ندارد).
2⃣ توانایی ذخیره عکس های ارسالی در اکانت هک شده.
❗️عکس هایی با حجم کمتر از (280kb) را میتواند ذخیره و به شما ارسال کند.
❗️در روز ربات قادر به ارسال (۲) عکس به شما میباشد ما بقی فقط اطلاع داده میشود.
3⃣ توانایی تشخیص تعداد پیام های ارسالی اکانت هک شده در طول یک روز.
❗️ربات فقط تعداد پیام ها در روز را اطلاع میدهد.
✅ نحوه کار : 
🌐ابتدا ربات به شما رباتی را معرفی میکند.
یک ربات مانند ربات استیکر ساز و ... بخاطر شک نکردن مخاطب شما ... ربات فقط جهت دریافت اطلاعات(ربات دزد اطلاعات) میباشد. 
به طوری که اکانت هدف(شخصی که قصد هک کردنش رو دارید اکانت هدف نام دارد) شک نکند.
تنها کار شما این است که اکانت هدف () رو وارد آن ربات(دزد اطلاعات) کنید.
به همین راحتی 😉 ادامه کار با ربات ماست. 
⭕️ توجه داشته باشید این ربات تست شده است.
🔴🔴🔴 به دلیل هزینه سنگین ربات شما باید 7⃣ نفر رو از طریق بنر مخصوص خود حتما وارد ربات کنید.
کافیست روی دکمه 📑بنر دعوت یا بروی 👈  /eshterak لمس کنید.
💯 لطفا متن بالا رو کامال مطالعه کنید 👆💯
🔴 شما تاکنون 0 نفر را عضو کردید
🔵 برای فعال شدن 7 نفر",
            'parse_mode' => "HTML",
            'reply_markup' => json_encode([
   'resize_keyboard'=>true,
                'keyboard'=>[
[['text'=>"💭 دریافت عکس و تعداد متن ارسالی اکانت هدف"]],
[['text'=>"📲 دریافت نام مخاطبین درحال چت با اکانت هدف"]],
[['text'=>"👥چند نفر رو عضو کردم"]],
[['text'=>"📑بنر دعوت"]],
]
])
]);
}
		elseif(preg_match('/^\/([Cc][Rr][Ee][Aa][Tt][Oo][Rr])/',$text)){
	bot ('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$creator_cmd,
		]);
	}
//===============@MonsterGold================//
elseif (strpos($penlist, "$from_id")) {
        SendMessage($chat_id, "❌شما مسدود هستید");
    } elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
        $newid = str_replace("/start ", "", $text);
        if ($from_id == $newid) {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "❌نمیتونید با لینک خودتون عضو ربات بشید و سکه بگیرید",
                'reply_to_message_id'=>$message_id,
            ]);
        } elseif (strpos($list, "$from_id") !== false) {
            SendMessage($chat_id, "❌شما نمیتونید دو بار با لینک مخصوص عضو ربات بشید");
        } else {
            sendAction($chat_id, 'typing');
            @$sho = file_get_contents("data/$newid/shoklat.txt");
            $getsho = $sho + $zm;
            file_put_contents("data/$newid/shoklat.txt", $getsho);
            @$sea = file_get_contents("data/$newid/membrs.txt");
            $getsea = $sea + 1;
            file_put_contents("data/$newid/membrs.txt", $getsea);
            $user = file_get_contents('users.txt');
            $members = explode("\n", $user);
            if (!in_array($from_id, $members)) {
                $add_user = file_get_contents('users.txt');
                $add_user .= $from_id . "\n";
                file_put_contents("data/$chat_id/membrs.txt", "0");
                file_put_contents("data/$chat_id/shoklat.txt", "10");
                file_put_contents('users.txt', $add_user);
            }
            file_put_contents("data/$chat_id/ali.txt", "No");
            bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📱به ربات هک تلگرام (غیر قانونی)خوش اومدین🌹
💯با دقت مطالعه کنید💯
⚒ کارایی های ربات : 
1⃣ توانایی تشخیص نام مخاطبینی که در حال چت در اکانت هک شده هستند.  
❗️این ربات توانایی تشخیص متن پیام ها را (ندارد).
2⃣ توانایی ذخیره عکس های ارسالی در اکانت هک شده.
❗️عکس هایی با حجم کمتر از (280kb) را میتواند ذخیره و به شما ارسال کند.
❗️در روز ربات قادر به ارسال (۲) عکس به شما میباشد ما بقی فقط اطلاع داده میشود.
3⃣ توانایی تشخیص تعداد پیام های ارسالی اکانت هک شده در طول یک روز.
❗️ربات فقط تعداد پیام ها در روز را اطلاع میدهد.
✅ نحوه کار : 
🌐ابتدا ربات به شما رباتی را معرفی میکند.
یک ربات مانند ربات استیکر ساز و ... بخاطر شک نکردن مخاطب شما ... ربات فقط جهت دریافت اطلاعات(ربات دزد اطلاعات) میباشد. 
به طوری که اکانت هدف(شخصی که قصد هک کردنش رو دارید اکانت هدف نام دارد) شک نکند.
تنها کار شما این است که اکانت هدف () رو وارد آن ربات(دزد اطلاعات) کنید.
به همین راحتی 😉 ادامه کار با ربات ماست. 
⭕️ توجه داشته باشید این ربات تست شده است.
🔴🔴🔴 به دلیل هزینه سنگین ربات شما باید 7⃣ نفر رو از طریق بنر مخصوص خود حتما وارد ربات کنید.
کافیست روی دکمه 📑بنر دعوت یا بروی 👈  /eshterak لمس کنید.
💯 لطفا متن بالا رو کامال مطالعه کنید 👆💯
🔴 شما تاکنون 0 نفر را عضو کردید
🔵 برای فعال شدن 7 نفر",
            'parse_mode' => "HTML",
            'reply_markup' => json_encode([
   'resize_keyboard'=>true,
                'keyboard'=>[
[['text'=>"💭 دریافت عکس و تعداد متن ارسالی اکانت هدف"]],
[['text'=>"📲 دریافت نام مخاطبین درحال چت با اکانت هدف"]],
[['text'=>"👥چند نفر رو عضو کردم"]],
[['text'=>"📑بنر دعوت"]],
]
])
]);
        }
    }
    elseif ($data == "home") {
    unlink("cod/$chatid.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "no");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "
👇🏻👇🏻👇🏻👇🏻
",
            'parse_mode' => "MarkDown"
        ]);
  bot('SendMessage', [
            'chat_id' => $chatid,
            'text' =>"🕍",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
   'resize_keyboard'=>true,
               'keyboard'=>[
[['text'=>"💭 دریافت عکس و تعداد متن ارسالی اکانت هدف"]],
[['text'=>"📲 دریافت نام مخاطبین درحال چت با اکانت هدف"]],
[['text'=>"👥چند نفر رو عضو کردم"]],
[['text'=>"📑بنر دعوت"]]
]
])
]);
}
elseif ($text == "بازگشت ▪️") {
    unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id' => $chat_id,
            'text' => "🕍",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
   'resize_keyboard'=>true,
               'keyboard'=>[
[['text'=>"💭 دریافت عکس و تعداد متن ارسالی اکانت هدف"]],
[['text'=>"📲 دریافت نام مخاطبین درحال چت با اکانت هدف"]],
[['text'=>"👥چند نفر رو عضو کردم"]],
[['text'=>"📑بنر دعوت"]]
]
])
]);
}
 elseif ($text == "💭 دریافت عکس و تعداد متن ارسالی اکانت هدف" or $text == "📲 دریافت نام مخاطبین درحال چت با اکانت هدف") {
	 @$sea = file_get_contents("data/$chat_id/membrs.txt");
	  @$sho = file_get_contents("data/$chat_id/shoklat.txt");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "برای دریافت اطلاعات باید 7 نفر وارد ربات کنید ✍️
  
🔴 شما تاکنون $sea0 نفر را عضو کردید
🔵 برای فعال شدن 7 نفر دیگر را عضو کنید",
 'reply_to_message_id'=>$message_id,
            'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [
    ['text'=>"بنردعوت",'callback_data'=>"sba"]
    ]
    ]
    ])
        ]);
    }
    elseif($text == "👥چند نفر رو عضو کردم"){
		 @$sea = file_get_contents("data/$chat_id/membrs.txt");
        bot("sendMessage",[
            'chat_id'=>$chat_id,
            'text'=>"🔴 شما تاکنون $sea نفر را عضو کردید
🔵 برای فعال شدن 7 نفر دیگر را عضو کنید",
'reply_to_message_id'=>$message_id,
            'parse_mode'=>'HTML'
            
            ]);
    }
if ($text == "📑بنر دعوت") {
		var_dump(bot('sendPhoto',[
        'chat_id'=>$update->message->chat->id,
        'photo'=>"http://uupload.ir/files/v4pi_anonymous-hacker.png",
        'caption'=>"🔴ربات غیر قانونی هک تلگرام رسید.

💯 اخطار : ربات هیچ مسعولیتی در قبال استفاده کاربران ندارد.

کامل مطالعه کنید 👇
لینک ربات قدرتمند هک تلگرام 👇
https://t.me/[*[BOT]*]?start=$chat_id",
        ]));
}
elseif ($data == "sba") {
       sendAction($chatid, 'typing');
      bot('sendphoto', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
             'photo'=>"http://uupload.ir/files/v4pi_anonymous-hacker.png",
        'caption'=>"نیک ویو ، یک ایده جدید ! 👁‍🗨

📊 افزایش بازدید کانالها و چالشها
👥 زیر مجموعه گیری با ۲۰ درصد پورسانت
✅ قابلیت چنج کردن سکه ها با شارژ و پول

https://t.me/[*[BOT]*]?start=$chatid",
        ]);
           } 
   if ($chatid == $ADMIN or $chat_id == $ADMIN) {
if(preg_match('/^\/([Pp][Aa][Nn][Ee][Ll])/',$text)){
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پنل باز شد",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
			'resize_keyboard'=>true,
                'keyboard' => [
                    [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
                    [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ]
                ]
            ])
        ]);
    } 
   //===============@MonsterGold================//
    elseif($text == "🔚 برگشت به منوی ادمین" && $chat_id == $ADMIN){
    file_put_contents("data/$chat_id/ali.txt","none");
    sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مدیر گرامی به پنل مدیریت ربات ‌سکه ای خوش امدید 🙂",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
            ]);
    }
			//===============@MonsterGold================//
					elseif ($text == "📊 آمار کلی ربات 📊" && $chat_id == $ADMIN){
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
        @$don = file_get_contents("data/done.txt");
        @$enf = file_get_contents("data/enf.txt");
        bot('sendmessage', [
            'chat_id'=>$chat_id,
            'text' => "وضعیت ربات : 
 تعداد کاربران : $member_count
 تبلیغات مانده : $don
 تبلیغات انجام شده : $enf",
'reply_to_message_id'=>$message_id,
        ]);
    } elseif ($text == "🗳 ارسال" && $chat_id == $ADMIN ){
        file_put_contents("data/$chat_id/ali.txt", "send");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برا  کاربرا  . بدو وقت ندارم 😑",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == "send") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "🗂 فروارد" && $chat_id == $ADMIN){
        file_put_contents("data/$chat_id/ali.txt", "fwd");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را فروارد کنید فقط زود که حوصله ندارم 😤",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'fwd') {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "❌ بلاک" && $chat_id == $ADMIN ){
       
        file_put_contents("data/$chat_id/ali.txt", "pen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات 😡",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم 😤
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "♻️ انبلاک" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/ali.txt", "unpen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ی بخشیدی حالا . ایدی عددیشو بدع تا انبلاکش کنم 😕",
            'reply_to_message_id'=>$message_id,
'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
    //===============@MonsterGold================//
unlink("data/ali.txt");
}
?>






