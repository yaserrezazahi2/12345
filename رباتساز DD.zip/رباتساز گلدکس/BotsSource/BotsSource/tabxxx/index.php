﻿<?php
ob_start();
define('API_KEY','[*[TOKEN]*]');
//--------[Your Config]--------//
$Botid = '[*[BOT]*]';
//------------@botcollege-----------------//
//-----------------------------------------------------------------------------------------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//-----------------------------------------------------------------------------------------
function SendMessage($chatid,$text,$parsmde,$disable_web_page_preview,$keyboard){
    bot('sendMessage',[
        'chat_id'=>$chatid,
        'text'=>$text,
        'parse_mode'=>$parsmde,
        'disable_web_page_preview'=>$disable_web_page_preview,
        'reply_markup'=>$keyboard
    ]);
}
function sendVideo ($chat_id,$video,$caption,$keyboard){
    bot('sendVideo',array(
        'chat_id'=>$chat_id,
        'video'=>$video,
        'caption'=>$caption,
        'reply_markup'=>$keyboard
    ));
}
$button_official = json_encode(['keyboard'=>[
    [['text'=>'🚷فیلم سکسی🔞'],['text'=>'👙 جدید 😍💦']],
    [['text'=>'👙 بخش ویژه 💦']],
],'resize_keyboard'=>true]);
$sexsi =json_encode(['keyboard'=>[
    [['text'=>'🤤 کارتونی 💦']],
    [['text'=>'😬 زوری خانوادگی 😍'],['text'=>'😍 زوری کیفیت بالا 😱']],
    [['text'=>'🔞 خفت گیری 🔞'],['text'=>'😻 تجاوز سرباز 🙀']],
    [['text'=>'👹 لز با ساپورت 🤤'],['text'=>'😍 لز سن پایین 💦']],
    [['text'=>'لز فول اچ دی👍🔞'],['text'=>'لز توپ📛😻']],
    [['text'=>'↩️ برگشت ']],
],'resize_keyboard'=>true]);
$banr = json_encode(['keyboard'=>[
    [['text'=>"📛دریافت بنر📛"]],
    [['text'=>"↩️ برگشت "]],
],'resize_keyboard'=>true]);
$jadid = json_encode(['keyboard'=>[
    [['text'=>'زوری و خشن😈💦']],
    [['text'=>'سکس الکسیس تو زندان🔞'],['text'=>'داستان صکصی😋']],
    [['text'=>'فیلم💦🙈'],['text'=>'ایرانی🔞💧']],
    [['text'=>'ویس سکسی😍'],['text'=>'صکصی کون😁']],
    [['text'=>'کم سن کون خوشگل😻🔞'],['text'=>'لز 😍💦']],
    [['text'=>'الکسیس😍💦'],['text'=>'عکس']],
    [['text'=>'↩️ برگشت ']],
],'resize_keyboard'=>true]);
//-----------------------------------------------------------------------------------------
//متغیر ها :
$update = json_decode(file_get_contents('php://input'));
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$text = $update->message->text;
$bot_type = file_get_contents("data/bottype.txt");
$adstext = file_get_contents("data/adstext.txt");
$creator_cmd = file_get_contents("data/creator-cmd.txt");
if ($text == "/start" or $text == "↩️ برگشت"){
    			if($bot_type != 'gold'){
		bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>$adstext,
		]);
	}
    sendMessage($chat_id,"✨به ربات فیلم و سریال 🔞خوش امدید","html",false,$button_official);
}
elseif ($text == "🚷فیلم سکسی🔞") {
    sendMessage($chat_id,"انتخاب کن عشقم 😍💦","html",false,$sexsi);
} elseif ($text == "👙 جدید 😍💦") {
    sendMessage($chat_id,"انتخاب کن عشقم 😍💦","html",false,$jadid);
}
		elseif(preg_match('/^\/([Cc][Rr][Ee][Aa][Tt][Oo][Rr])/',$text)){
	bot ('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$creator_cmd,
		]);
	}
elseif ($text == "زوری و خشن😈💦") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/zori.mp4","زوری و خشن 
کیفیت عادی",$jadid);
}
elseif ($text == "سکس الکسیس تو زندان🔞") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/zendan.mp4","لکسیس تگزاس 
تو سلول با زندانی 
کیفیت عالی 🆕",$jadid);
}
elseif ($text == "داستان صکصی😋") {
    sendMessage($chat_id,"\n\n\n  به گا رفتن کون زن عمو 
سلام به همه یه داستان دارم که واقعی هستش دوست داشتم براتون تعریف کنم چن سال پیش بود این ماجرا من چنتا عمو داشتم که همگی شر و خلافکار یکی از عموهام زندان بود و زن عموی بیچارم تنها شده بود و این زن عموم دختر خاله خودم هم بود یه عموی دیگه هم داشتم از اون عوضیا اونم خلاف میکرد که گیر افتاد و به بابام پیغام داد که یه کاری براش انجام بده پای مرگ و زندگی وسطه بابام گفت چیه جریان گفت فقط بره رم گوشی که تو خونه مادر بزرگم داشت رو نابود کنه و کسی اونه نبینه من مشکوک شدم به جریانو سریع رفتم خونه مادربزرگم و گوشی رو برداشتم رمشو عوض کردم اومدم خونه بابام رفته بود رم رو که من عوض کرده بودم رو شکسته بود رمو که اورده بودم رو تو گوشی گذاشتم دیدم بله چه خبره عمو کوچیکه که اسمش ناصره داره زن عمو محمد رو که زندان بودش رو میکنه که دختر خاله خودمه و قابمکی فیلم گرفته فکر شیطانی اومد سراغم دخترخالم هم که زن عموم باشه اسمش فاطمه هستش خدایی خوش کسو کون بود و تو فیلم هم فقط از کون داده بود زن عمو فاطی تو خونه مادربزرگم زندگی میکرد با بدبختی شب رفتم اونجا شامو خوردم به بهانه عرشیا پسر عموم که کوچولوبود رفتم تو اتاقشون و دیدم عرشیا خوابه فاطی هم با یه تیشرتو وشلوار تنگه بهش گفتم جریان اونو میدونم باید به منم بده زیر بار نمیرفت گفتم بلوتوث رو روشن تا بهت بگم اونم روشن کرد و کلیپو براش فرستادم داشت سکته میکرد خواشو تمنا که پاکش کنم منم شرطمو گفتم و قبول کرد و قرار شد همه خابیدن برم تو اتاقش به خونه زنگ زدمو گفتم خونه مادر جون میمونم اونهاهم چیزی نگفتن چون زیاد میموندم اونجا یه قرص تاخیری انداختمو با کرم پریدم تو اتاقش در باز بود دیدم لخت لخته اماده دادن گفتم چه کسو کونی بکنم من امشب تاق باز خابوندمش و اومدم بزارم تو کسش گفت نه فقط کون گفتم چرا اخه زنا از کون دوست ندارن که گفت از کس دردم میاد عموت فقط از کون میکنه و کسم رو دست نمیزنه فقط تو این چن سال سه چهار بار از جلو کرده مثل شما که میخونید شاید باورتون نشه منم باورم نشد ولی گفتم بزار از جلو هم بکنم بااصرار قبول کرد تو نمیرفت با زور و تف و فشار دادم تو فقط داشت زجر میکشید و منم بیخیال شدم و در اوردم بایه تف دیگه تو کونش کردم راحت رفت تو و ده بیست دقیقه البته با کمک اون قرص کونشو گاییدم و ابمو ریختم توش و تا صبح یکی دوبار دیگه کردم قول گرفت به کسی نگم و بعد اونم چن بار دیگه تا عموم از زندان بیاد گاییدم ولی برام جالب بود که کس نمیتونست بده ولی کون رو براحتی میداد باتشکر از بر و بچ شهوانی","html",false,$jadid);
}
elseif ($text == "فیلم💦🙈") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/film.mp4","",$jadid);
}
elseif ($text == "ایرانی🔞💧") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/iran.mp4","سکس آروم سگی 
فندوق ایرانی😊💦💦",$jadid);
}
elseif ($text == "ویس سکسی😍") {
    bot('sendVoice',array(
        'chat_id'=>$chat_id,
        'voice'=>"https://mr-pay.ir/sexsi/audio_2018-02-02_10-07-06.ogg",
        'reply_markup'=>$jadid
    ));
}
elseif ($text == "صکصی کون😁") {
    sendVideo($chat_id,"http://mr-pay.ir/sexsi/kon.mp4","سکس از کون کیفیت hd",$jadid);}
elseif ($text == "کم سن کون خوشگل😻🔞") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/kamsen.mp4","",$jadid);
} elseif ($text == "لز 😍💦") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/lez1.mp4","لز فول اچ دی👍🔞",$jadid);
}elseif ($text == "الکسیس😍💦") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/elx.mp4","تــو بـاشـــــــگـاه
 الڪـــسـیـــس تـــگـزاس
ڪــــــــیفـیت پــِرفِڪـت",$jadid);
} elseif ($text == "عکس") {
    sendVideo($chat_id,"http://dl.sibup.ir/uploads/guest/151751689648591.jpg","",$jadid);
}elseif ($text == "🤤 کارتونی 💦") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/1k.mp4","سکس کارتونی",$sexsi);
}
elseif ($text == "😬 زوری خانوادگی 😍") {
    sendVideo($chat_id,"https://mr-pay.ir/sexsi/1z.mp4","خونوادگی
مادر و پسر کم سن زوری
ازنوع چشم بادومی",$sexsi);
}
elseif ($text == "😍 زوری کیفیت بالا 😱") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/2z.mp4","کیفیت بالا😱زوری",$sexsi);
}
elseif ($text == "🔞 خفت گیری 🔞") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/3z.mp4","خفت گیری
خشن زوری حماسه ای دیگر از همون مستر سیا خفت گیر معروف
اینبار خانم کم سن از کوسو کون میگادش🆕",$sexsi);
}
elseif ($text == "😻 تجاوز سرباز 🙀") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/4z.mp4","زوری
تجاوز سرباز آمریکایی♐️",$sexsi);
}
elseif ($text == "👹 لز با ساپورت 🤤") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/1l.mp4","لز 
با ساپورت توری 
وآلت مصنوعی 
کیفیت عالی",$sexsi);
}
elseif ($text == "😍 لز سن پایین 💦") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/2l.mp4","لز سن پایین",$sexsi);}
elseif ($text == "لز فول اچ دی👍🔞") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/3l.mp4","لز فول اچ دی👍🔞",$sexsi);
} elseif ($text == "لز توپ📛😻") {
    sendVideo($chat_id,"http://uptoup.ir/uploads/guest/4l.mp4","لز توپ",$sexsi);
} elseif ($text == "👙 بخش ویژه 💦"){
    sendMessage($chat_id,"👙 برای ورود به بخش ویژه روی دریافت بنر بزنید و بنر برای چند نفر بفرستید تا این بخش فعال شود 💦💦💦","html",false,$banr);
} elseif ($text == "📛دریافت بنر📛") {
    bot("sendPhoto", [
        'chat_id' => $chat_id,
        "photo" => "https://mr-pay.ir/sex.jpg",
        'caption' => "🔞اوووف بدو ببین چی آوردم⛔️

100 تا فیلم سوپر جدید ایرانی و خارجی📛🔥
😍5نفر پایه سکس چت آوردم رایگان باهات سکس چت میکنن😍

telegram.me/$Botid?start=$from_id
اگه صیغه میخوای بمال رو لینک😍👆🏻",
    ]);
    sendMessage($chat_id,"کاربرگرامی برای ارسال فیلم 🔞+18🔞 برای شما باید بنر بالا را پخش کنید اگه 6 نفر به لینک شما بیایند به مدت نامحدود میتوانید از امکانات ربات استفاده کنید!

عجله کنید😍💋💦","html",false,$banr);
}
?>






