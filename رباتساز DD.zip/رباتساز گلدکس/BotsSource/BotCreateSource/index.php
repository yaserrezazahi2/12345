<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[*[TOKEN]*]');
//----######------
function makereq($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//##############=--API_REQ
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}
//----######------
//---------
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
//=========
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$username = $update->message->from->username;
$textmessage = isset($update->message->text)?$update->message->text:'';
$admin = '[*[ADMIN]*]';
$time = file_get_contents("http://irapi.ir/time/");
$step = file_get_contents("data/".$from_id."/step.txt");
$bots = file_get_contents("data/".$from_id."/bots.txt");
$bottoken = file_get_contents("data/".$from_id."/token.txt");
$cha = file_get_contents("data/AdsCh.txt");
$tag = file_get_contents("data/id.txt");
$sudo = file_get_contents("data/sudo.txt");
$tedad = file_get_contents("data/".$from_id."/tedad.txt");
//-------
function SendMessage($ChatId, $TextMsg)
{
 makereq('sendMessage',[
'chat_id'=>$ChatId,
'text'=>$TextMsg,
'parse_mode'=>"MarkDown"
]);
}
function Forward($KojaShe,$AzKoja,$KodomMSG)
{
makereq('ForwardMessage',[
'chat_id'=>$KojaShe,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
function save($filename,$TXTdata)
	{
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
//===========
if ($textmessage == '🔙 برگشت') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🎈برگشتیم به منوی اصلی

🔻از دکمه های زیر استفاده کنید🔻",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"⚙️ساخت ربات"],
                ],
                [
                ['text'=>"🤖ربات های من"],['text'=>"📌حذف ربات"]
                ],
                [
                ['text'=>"🖌ارسال نظر"],['text'=>"📑راهنما"]
                ],
                [
                ['text'=>"💎امکانات ربات"],
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($step == 'create bot') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نا معتبر !");
		}
		else
		{
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		save("data/$from_id/token.txt","$token");
		SendMessage($chat_id,"در حال ساخت ربات شما !");
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/admin");
		save("bots/$un/data/admin/step.txt","none");
		save("bots/$un/users.txt","");
		save("bots/$un/groups.txt","");
		save("bots/$un/supergroups.txt","");
		save("bots/$un/data/admins.txt","");
		save("bots/$un/data/admins.txt","$from_id");		
		$source = file_get_contents("bot/index.php");
		$source = str_replace("[TOKEN]",$token,$source);
		$source = str_replace("[ADMIN]",$from_id,$source);
		save("bots/$un/index.php",$source);	
file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://wolfis.adrinaserver.site/Altos/Bots/BotSazCreate/[*[BOT]*]/bots/$un/index.php");
		var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شده است\nبرای ورود به ربات خود کلیک کنید 👇😃",
        	'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                ['text'=>"@$un",'url'=>"https://t.me/$un"]
                ]
            	]
       		])
    		]));
		}
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی اصلی خوش آمدید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"⚙️ساخت ربات"],
                ],
                [
                ['text'=>"🤖ربات های من"],['text'=>"📌حذف ربات"]
                ],
                [
                ['text'=>"🖌ارسال نظر"],['text'=>"📑راهنما"]
                ],
                [
                ['text'=>"💎امکانات ربات"],
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));

    		save("data/$from_id/step.txt","none");
}
elseif ($step == 'create bot1') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نا معتبر !");
		}
		else
		{
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		save("data/$from_id/token.txt","$token");
		SendMessage($chat_id,"در حال ساخت ربات شما !");
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/admin");
		save("bots/$un/data/admin/step.txt","none");
		save("bots/$un/users.txt","");
		save("bots/$un/groups.txt","");
		save("bots/$un/supergroups.txt","");
		save("bots/$un/data/admins.txt","");
		save("bots/$un/data/admins.txt","$from_id");		
		$source = file_get_contents("bot/index1.php");
		$source = str_replace("[TOKEN]",$token,$source);
		$source = str_replace("[ADMIN]",$from_id,$source);
		save("bots/$un/index.php",$source);	
file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://wolfis.adrinaserver.site/Altos/Bots/BotSazCreate/[*[BOT]*]/bots/$un/index.php");
		var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شده است\nبرای ورود به ربات خود کلیک کنید 👇😃",
        	'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                ['text'=>"@$un",'url'=>"https://t.me/$un"]
                ]
            	]
       		])
    		]));
		}
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی اصلی خوش آمدید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"⚙️ساخت ربات"],
                ],
                [
                ['text'=>"🤖ربات های من"],['text'=>"📌حذف ربات"]
                ],
                [
                ['text'=>"🖌ارسال نظر"],['text'=>"📑راهنما"]
                ],
                [
                ['text'=>"💎امکانات ربات"],
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));

    		
}
elseif ($step == 'create bot2') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نا معتبر !");
		}
		else
		{
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		save("data/$from_id/token.txt","$token");
		SendMessage($chat_id,"در حال ساخت ربات شما !");
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/admin");
		save("bots/$un/data/admin/step.txt","none");
		save("bots/$un/users.txt","");
		save("bots/$un/groups.txt","");
		save("bots/$un/supergroups.txt","");
		save("bots/$un/data/admins.txt","");
		save("bots/$un/data/admins.txt","$from_id");		
		$source = file_get_contents("bot/index2.php");
		$source = str_replace("[TOKEN]",$token,$source);
		$source = str_replace("[ADMIN]",$from_id,$source);
		save("bots/$un/index.php",$source);	
file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://wolfis.adrinaserver.site/Altos/Bots/BotSazCreate/[*[BOT]*]/bots/$un/index.php");
		var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شده است\nبرای ورود به ربات خود کلیک کنید 👇😃",
        	'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                ['text'=>"@$un",'url'=>"https://t.me/$un"]
                ]
            	]
       		])
    		]));
		}
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی اصلی خوش آمدید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"⚙️ساخت ربات"],
                ],
                [
                ['text'=>"🤖ربات های من"],['text'=>"📌حذف ربات"]
                ],
                [
                ['text'=>"🖌ارسال نظر"],['text'=>"📑راهنما"]
                ],
                [
                ['text'=>"💎امکانات ربات"],
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));

    		
}
elseif($textmessage == '/start')
{

if (!file_exists("data/$from_id/step.txt")) {
mkdir("data/$from_id");
save("data/$from_id/step.txt","none");
save("data/$from_id/tedad.txt","0");
$myfile2 = fopen("data/users.txt", "a") or die("Unable to open file!");	
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
}

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"📍سلام دوست عزیز به رباتساز « بیت  »  خوش اومدید

🔮با رباتساز میتوانید رباهای کاربردی برای سرگرمی اعضای کانال خود بسازید

🔮جهت ساخت ربات میتوانید از ربات ما استفاده کنید.
➖➖➖➖➖➖
",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"⚙️ساخت ربات"],
                ],
                [
                ['text'=>"🤖ربات های من"],['text'=>"📌حذف ربات"]
                ],
                [
                ['text'=>"🖌ارسال نظر"],['text'=>"📑راهنما"]
                ],
                [
                ['text'=>"💎امکانات ربات"],
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
makereq('ForwardMessage' ,[
    'chat_id'=>$chat_id,
    'from_chat_id'=>"@$cha",
    'message_id'=>"$tag",
    ]);
if($textmessage == "") {
    makereq('sendmessage',[
        'chat_id'=>$chat_id,
        'text'=>"🎟این ربات توسط (بیت تیم) ساخته شده است
➖➖➖➖➖➖",
]);
}
elseif ($textmessage == '⚙️ساخت ربات') {
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"به بخش ساخت ربات خوش اومدید 🍂",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
               
				[
				['text'=>"📟ربات تبچی"],['text'=>"📩ربات پیامرسان"]
				],
				[
				    ['text'=>"📌ربات ست وبهوک"]
				],
				[
                
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '📟ربات تبچی') {
save("data/$from_id/step.txt","create bot");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"📍 توکن ربات مورد نظر رو وارد کنید:(اگر نمیدونید توکن چیه به دکمه راهنما مراجعه کنید)",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '📌ربات ست وبهوک') {
save("data/$from_id/step.txt","create bot1");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"📍 توکن ربات مورد نظر رو وارد کنید:(اگر نمیدونید توکن چیه به دکمه راهنما مراجعه کنید)",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '📩ربات پیامرسان') {
save("data/$from_id/step.txt","create bot2");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"📍 توکن ربات مورد نظر رو وارد کنید:(اگر نمیدونید توکن چیه به دکمه راهنما مراجعه کنید)",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '📌حذف ربات') {
    if (file_exists("data/$from_id/bots.txt")) {
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🗑 برای حذف ، ربات مورد نظر خود را انتخاب کنید.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
                   ['text'=>"@$bots ❌"]
                ],
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}else
{
    	SendMessage($chat_id,"🎈 رباتی به نام شما ثبت نشده است.");
}
}
elseif ($textmessage == "@$bots ❌") {
        if (file_exists("data/$from_id/bots.txt")) {
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"⭕️ آیا مطمئن هستید ربات شما با آیدی @$bots حذف شود؟",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"❌ بله , حذف کن"]
                ],
                [
                ['text'=>"🔙 برگشت"]
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}else
{
    	SendMessage($chat_id,"🎈 رباتی به نام شما ثبت نشده است.");
}
}
elseif ($textmessage == "❌ بله , حذف کن") {
        if (file_exists("data/$from_id/bots.txt")) {
	unlink("bots/$bots/index.php");
	unlink("bots/$bots/users.txt");
	unlink("bots/$bots/groups.txt");
	unlink("bots/$bots/supergroups.txt");
	unlink("bots/$bots/data/admins.txt");
	unlink("bots/$bots/data/admin/step.txt");
	rmdir("bots/$bots/data/admin");
	rmdir("bots/$bots/data");
	rmdir("bots/$bots");
	unlink("data/$from_id/bots.txt");
	file_get_contents("https://api.telegram.org/bot".$bottoken."/setwebhook");
	save("data/$from_id/tedad.txt","0");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️ ربات شما با موفقیت حذف شد.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"⚙️ساخت ربات"],
                ],
                [
                ['text'=>"🤖ربات های من"],['text'=>"📌حذف ربات"]
                ],
                [
                ['text'=>"🖌ارسال نظر"],['text'=>"📑راهنما"]
                ],
                [
                ['text'=>"💎امکانات ربات"],
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}else
{
    	SendMessage($chat_id,"🎈 رباتی به نام شما ثبت نشده است.");
}
}
elseif ($textmessage == '🖌ارسال نظر') {
save("data/$from_id/step.txt","feedback");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"✍️ نظرات شما به پیشرفت و ارائه خدمات بهتر کمک میکند.

📝 برای ارسال نظر خود , پیغام خود را ارسال کنید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($step == 'feedback') {
    save("data/$from_id/step.txt","none");
	SendMessage($chat_id,"نظر شما با موفقیت ارسال شد !");
		SendMessage($admin,"🔗اطلاعات کاربری:

🔮 @$username
➖➖➖➖➖➖
📩نظر جدید :

$textmessage");
}
elseif ($textmessage == '📑راهنما') {
	SendMessage($chat_id,"1️⃣ ابتدا به ربات ( @BotFather ) مراجعه کنید
2️⃣ دستور /newbot رو ارسال کنید
3️⃣ یک نام برای ربات ارسال کنید
4️⃣ پس از ارسال نام،یک یوزرنیم ارسال کنید
❌ توجه کنین حتما باید در آخر یوزرنیم ارسالی کلمه bot با حروف کوچیک یا بزرگ (فرقی نداره) وجود داشته باشه
5️⃣ اگر با پیغام زیر برخورد کردید
Sorry, this username is already taken. Please try something different.
یعنی قبلا یکی این یوزرنیم رو ثبت کرده یوزرنیم دیگری وارد کنید. اگر این پیغام رو دریافت نکردید یعنی کار حل است
6️⃣ حالا به ربات ساز مراجعه کنید و دکمه (⚙️ساخت ربات) رو بزنید و نوع ربات را برای ساخت انتخاب کنید
7️⃣ سپس به پیام آخری که از ربات ( @BotFather ) دریافت کردید بروید سپس زیر جمله Use this token to access the HTTP API: توکنی میبینید روی اون بزنید تا کپی شه
8️⃣ سپس توکنی که کپی کردید را برای ربات ساز ارسال کنید⬅️
9️⃣ ربات شما با موفقیت ساخته شد✔️
➖➖➖➖➖➖");
}
elseif ($textmessage == '💎امکانات ربات') {
	SendMessage($chat_id,"💎امکانات ربات های ساخته شده:

1⃣بدون هیچ گونه تبلیغات
2⃣سرعت باورنکردنی
3⃣پشتیبانی 24 ساعت
4⃣بدون هیچ قطعی
➖➖➖➖➖➖");
}
elseif ($textmessage == '🤖ربات های من') {
        if (file_exists("data/$from_id/bots.txt")) {
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🤖 ربات های شما :\n➖➖➖➖➖➖\n@$bots\n➖➖➖➖➖➖",
		'parse_mode'=>'MarkDown'
]));
}else
{
    	SendMessage($chat_id,"🎈 رباتی به نام شما ثبت نشده است.");
}
}

elseif ($textmessage == "/panel" && $from_id == $admin){
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"`پنل مدیریت با موفقیت باز شد\nیکی از دکمه هارا انتخاب کنید :`",
        'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
           'keyboard'=>[
              [
                ['text'=>"امار"]
                ],
                [
                    ['text'=>"🎲فروارد"],['text'=>"📮ارسال"]
],
[
['text'=>"📟تنظیم تبلیغ"],['text'=>"💊تنظیم کانال تبلیغات"],
              ],
            [
            ['text'=>"👨‍🔧افزودن ادمین"]
            ]
            ],
            'resize_keyboard'=>true
        ])
    ]));  
	}
	if ($textmessage == '⚠️back') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🎈برگشتیم به منوی اصلی

🔻از دکمه های زیر استفاده کنید🔻",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
               [
                ['text'=>"امار"]
                ],
                [
                    ['text'=>"🎲فروارد"],['text'=>"📮ارسال"]
],
[
['text'=>"📟تنظیم تبلیغ"],['text'=>"💊تنظیم کانال تبلیغات"],
              ],
            [
            ['text'=>"👨‍🔧افزودن ادمین"]
            ]
            ],
            'resize_keyboard'=>true
        ])
    ]));  
	}
		elseif($textmessage == 'امار' && $chat_id == $admin)
	{
	    $number = count(scandir("bots"))-1;
		$txtt = file_get_contents('data/users.txt');
		$membersidd= explode("\n",$txtt);
		$mmemcount = count($membersidd) -1;
{
sendmessage($chat_id,"👤تعداد اعضای ربات : { $mmemcount }

➖➖➖➖➖➖➖

🤖تعداد ربات های فعال : { $number }

➖➖➖➖➖➖➖
Ｃｈａｎｎｅｌ : @BeetTeam");
}
}
elseif ($textmessage == "📮ارسال" && $chat_id == $admin ){
        file_put_contents("data/$chat_id/step.txt", "send");
        makereq('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "ادمین گرامی

🎟پیام خود را ارسال کنید تا به تمامی کاربران ربات ارسال شود.
➖➖➖➖➖➖",
'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"⚠️back"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
            
        ]);
    } elseif ($step == "send") {
        file_put_contents("data/$chat_id/step.txt", "no");
        $fp = fopen("data/users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $textmessage ,$admin);
        }
        makereq('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "پیام شما با موفقیت برای کاربران ارسال شد✔️
➖➖➖➖➖➖➖",
            'parse_mode'=>"MarkDown",
        ]);
    }
    elseif ($textmessage == "🎲فروارد" && $chat_id == $admin){
        file_put_contents("data/$chat_id/step.txt", "fwd");
        makereq('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را فروارد کنید فقط زود که حوصله ندارم 😤",
            'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"⚠️back"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
        ]);
    } elseif ($step == 'fwd') {
        file_put_contents("data/$chat_id/step.txt", "no");
        $forp = fopen("data/users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        makereq('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
        ]);
    }
    elseif($textmessage == "📟تنظیم تبلیغ" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","ads");
makereq('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"〽️ عدد پیامی که باید از کانال (@$cha) فروارد بشه رو بگو.",
'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"⚠️back"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
]);
}elseif($step == "ads"){
file_put_contents("data/$from_id/step.txt","none");
 file_put_contents("data/id.txt",$textmessage);
makereq('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✅ ثبت شد...",
]);
}

elseif($textmessage == "💊تنظیم کانال تبلیغات" && $from_id == $admin){
 file_put_contents("data/$from_id/step.txt","ads ch");
makereq('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🌀 ایدی کانال تبلیغات را بدون @ ارسال کنید.",
'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"⚠️back"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])

]);
}
elseif($step == "ads ch"){
file_put_contents("data/$from_id/step.txt","none");
 file_put_contents("data/AdsCh.txt",$textmessage);
makereq('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🔸 تنظیم شد!",
'parse_mode'=>"MarkDown"
]);
}
elseif($textmessage == "👨‍🔧افزودن ادمین" && $from_id == $admin){
 file_put_contents("data/$from_id/step.txt","sudo");
makereq('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♊️ ایدی عددی ادمین دوم ربات رو ارسال کنید.",
'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"⚠️back"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])

]);
sendmessage($sudo,"👀 شما ادمین شدید برای رفتن به بخش مدیریتی کلمه `/sudo` را ارسال کنید.","MarkDown");
}
elseif($step == "sudo"){
file_put_contents("data/$from_id/step.txt","none");
 file_put_contents("data/sudo.txt",$textmessage);
makereq('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"⚛ کاربر $sudo به عنوان ادمین دوم ربات در ساعت ($time) انتخاب شد.

♎️ برای رفتن به پنل مدیریت ادمین دوم کلمه /sudo را باید ادمین دوم ارسال کند ",
'parse_mode'=>"MarkDown"
]);
}
//==============Panel Sudo============//
elseif ($textmessage == "/sudo" && $from_id == $sudo){
    makereq('sendmessage' ,[
        'chat_id'=>$sudo,
        'text'=>"☑️ سلام ادمین گرامی ( [$name](tg://user?id=$sudo) ) به پنل مدیریت خودتون خوش اومدی!",
        'parse_mode'=>"MarkDown",
        'reply_markup'=> json_encode ([
            'keyboard'=>[
                [
                  ['text'=>"🔙 برگشت"]
                  ],
                  [
              ['text'=>"👥 آمار"],
              ],
[
['text'=>"📩پیام همگانی"]
],
              ],
            'resize_keyboard'=>true
        ])
            ]);
}
elseif($textmessage == "👥 آمار" && $from_id == $sudo){
    $user = file_get_contents("data/users.txt");
    $member_id = explode("\n",$user);
    $member = count($member_id) -1;
 makereq('sendmessage',[
'chat_id'=>$sudo,
'text'=>"😎 آمار اعضای ربات : $member",
 ]);
}
elseif ($textmessage == "📩پیام همگانی" && $from_id == $sudo ){
        file_put_contents("data/$chat_id/step.txt", "send");
        makereq('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "ادمین گرامی

🎟پیام خود را ارسال کنید تا به تمامی کاربران ربات ارسال شود.
➖➖➖➖➖➖",
'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"⚠️back"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
            
        ]);
    } elseif ($step == "send") {
        file_put_contents("data/$chat_id/step.txt", "no");
        $fp = fopen("data/users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $textmessage ,$admin);
        }
        makereq('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "پیام شما با موفقیت برای کاربران ارسال شد✔️
➖➖➖➖➖➖➖",
            'parse_mode'=>"MarkDown",
        ]);
    }

unlink("error_log");
?>

