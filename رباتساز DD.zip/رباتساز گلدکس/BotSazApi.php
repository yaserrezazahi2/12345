<?php
/*
نوشته شده توسط
@SOOROSHH
تیم حرفه ای
SROUSHESDI
*/
$token = $_GET['token'];
$id = $_GET['id'];
$type = $_GET['type'];
$ads = $_GET['ads'];
$account = $_GET['account'];
$creator_cmd = $_GET['creator_cmd'];
$channel = $_GET['channel'];
$WEBADRESS = "https://Crystal.megaranhost.ir/Altos";
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if(is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 if($type == "dlserv"){
deletefolder("Bots");
deletefolder("Sites");
deletefolder("data");
deletefolder("BotsSource");
unlink("index.php");
unlink("BotSazSazApi.php");
unlink("BotSazApi.php");
	}
 if($token !== null && $id !== null && $type !== null && $account !== null){
//---
	 	if($type == "delete"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/Bot/$un/index.php"))){
deletefolder("Bots/Bot/$un");
rmdir("Bots/Bot/$un");
	}}
//-------------------------
	 	if($type == "delete1"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/BotGrams/$un/index.php"))){
deletefolder("Bots/BotGrams/$un");
rmdir("Bots/BotGrams/$un");
	}}
//-------------------------

 if($type == "payamresan"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/other");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/other/$id");
  mkdir("Bots/Bot/$un/other/access");
  mkdir("Bots/Bot/$un/other/button");
  mkdir("Bots/Bot/$un/other/profile");
  mkdir("Bots/Bot/$un/other/setting");
  mkdir("Bots/Bot/$un/other/wordlist");
  mkdir("Bots/Bot/$un/other/button/caption");
  mkdir("Bots/Bot/$un/other/button/file");
  mkdir("Bots/Bot/$un/other/button/forward");
  mkdir("Bots/Bot/$un/other/button/music");
  mkdir("Bots/Bot/$un/other/button/photo");
  mkdir("Bots/Bot/$un/other/button/feed");
  mkdir("Bots/Bot/$un/other/button/sticker");
  mkdir("Bots/Bot/$un/other/button/text");
  mkdir("Bots/Bot/$un/other/button/video");
  mkdir("Bots/Bot/$un/other/button/voice");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  save("Bots/Bot/$un/other/setting/start.txt","Hi!✋ 
  <b>Welcome To My Bot</b>");
  save("Bots/Bot/$un/other/setting/send.txt","<b>Sent To My Admin!</b>");
  save("Bots/Bot/$un/other/setting/sticker.txt","✅");
  save("Bots/Bot/$un/other/setting/file.txt","✅");
  save("Bots/Bot/$un/other/setting/aks.txt","✅");
  save("Bots/Bot/$un/other/setting/music.txt","✅");
  save("Bots/Bot/$un/other/setting/film.txt","✅");
  save("Bots/Bot/$un/other/setting/voice.txt","✅");
  save("Bots/Bot/$un/other/setting/join.txt","✅");
  save("Bots/Bot/$un/other/setting/link.txt","✅");
  save("Bots/Bot/$un/other/setting/forward.txt","✅");
  save("Bots/Bot/$un/other/setting/pm_forward.txt","⛔️");
  save("Bots/Bot/$un/other/setting/pm_resani.txt","✅");
  save("Bots/Bot/$un/other/setting/on-off.txt","true");
  save("Bots/Bot/$un/other/setting/profile.txt","✅");
  save("Bots/Bot/$un/other/setting/contact.txt","⛔️");
  save("Bots/Bot/$un/other/setting/location.txt","⛔️");
  $class = file_get_contents("BotsSource/BotsSource/payamresan/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$id,$class);
  save("Bots/Bot/$un/Class.php",$class);
  $index = file_get_contents("BotsSource/BotsSource/payamresan/index.php");
  save("Bots/Bot/$un/index.php",$index);	
  $butt = file_get_contents("BotsSource/BotsSource/payamresan/Button.php");
  save("Bots/Bot/$un/other/Button.php",$butt);	
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
   //---
  if($type == "antispam"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
    $index = file_get_contents("BotsSource/BotsSource/antispam/index.php");
	$index = str_replace("[*[TOKEN]*]",$token,$index);
	  $index = str_replace("[*[ADMIN]*]",$id,$index);
	  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  save("Bots/Bot/$un/index.php",$index);
  $nophoto = file_get_contents("BotsSource/BotsSource/antispam/nophoto.png");
  save("Bots/Bot/$un//data/nophoto.png",$nophoto);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 //---
       if($type == "tabxxx"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/tabxxx/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
    $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  
   if($type == "profile1"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/profile/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("BotsSource/BotsSource/profile/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "face"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/face/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[WEB]*]","$WEBADRESS/Bots/Bot/$un",$index);
  save("Bots/Bot/$un/index.php",$index);
 $getphoto = file_get_contents("BotsSource/BotsSource/face/getphoto.php");
  save("Bots/Bot/$un/getphoto.php",$getphoto);	
   $send = file_get_contents("BotsSource/BotsSource/face/send.php");
  save("Bots/Bot/$un/send.php",$send);
   $sendphoto = file_get_contents("BotsSource/BotsSource/face/sendphoto.php");
  save("Bots/Bot/$un/sendphoto.php",$sendphoto);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
    if($type == "estickers"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/estickers/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "note"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/check");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/note/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
   if($type == "hacker"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/hacker/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "shortlink"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/shortlink/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "webhook"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/webhook/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  
  	if($type == "hajicreate"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/kosnane/$un/index.php"))){
mkdir("Bots/kosnane/$un");
mkdir("Bots/kosnane/$un/data");
$index = file_get_contents("BotsSource/createmg/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/kosnane/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/kosnane/$un/index.php");
	}}
	
   if($type == "gpgram"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/other");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/pay");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $logo = file_get_contents("BotsSource/BotsSource/gpgram/other/logo.jpg");
  save("Bots/Bot/$un/other/logo.jpg",$logo);
   $nophoto = file_get_contents("BotsSource/BotsSource/gpgram/other/nophoto.png");
  save("Bots/Bot/$un/other/nophoto.jpg",$nophoto);
    $ping = file_get_contents("BotsSource/BotsSource/gpgram/other/ping.jpg");
  save("Bots/Bot/$un/other/ping.jpg",$ping);
  //---
  
  $add = file_get_contents("BotsSource/BotsSource/gpgram/add.php");
  save("Bots/Bot/$un/add.php",$add);	
    $base = file_get_contents("BotsSource/BotsSource/gpgram/base.php");
	$base = str_replace("[*[TOKEN]*]",$token,$base);
	  $base = str_replace("[*[ADMIN]*]",$id,$base);
	  $base = str_replace("[*[ID]*]",$un,$base);
	  $base = str_replace("[*[CHENNEL]*]",$channel,$base);
  save("Bots/Bot/$un/base.php",$base);
  $bot = file_get_contents("BotsSource/BotsSource/gpgram/bot.php");
  save("Bots/Bot/$un/bot.php",$bot);
    $filter = file_get_contents("BotsSource/BotsSource/gpgram/filter.php");
  save("Bots/Bot/$un/filter.php",$filter);
  $fun = file_get_contents("BotsSource/BotsSource/gpgram/fun.php");
  save("Bots/Bot/$un/fun.php",$fun);
  $help = file_get_contents("BotsSource/BotsSource/gpgram/help.php");
  save("Bots/Bot/$un/help.php",$help);
  $lock = file_get_contents("BotsSource/BotsSource/gpgram/lock.php");
  save("Bots/Bot/$un/lock.php",$lock);
  $lockchannel = file_get_contents("BotsSource/BotsSource/gpgram/lockchannel.php");
  save("Bots/Bot/$un/lockchannel.php",$lockchannel);
  $lockplus = file_get_contents("BotsSource/BotsSource/gpgram/lockplus.php");
  save("Bots/Bot/$un/lockplus.php",$lockplus);
  $msgcheck = file_get_contents("BotsSource/BotsSource/gpgram/msgcheck.php");
  save("Bots/Bot/$un/msgcheck.php",$msgcheck);
  $panel = file_get_contents("BotsSource/BotsSource/gpgram/panel.php");
  save("Bots/Bot/$un/panel.php",$panel);
  $panelplus = file_get_contents("BotsSource/BotsSource/gpgram/panelplus.php");
  save("Bots/Bot/$un/panelplus.php",$panelplus);
  $plus = file_get_contents("BotsSource/BotsSource/gpgram/plus.php");
  save("Bots/Bot/$un/plus.php",$plus);
  $plusmsgcheck = file_get_contents("BotsSource/BotsSource/gpgram/plusmsgcheck.php");
  save("Bots/Bot/$un/plusmsgcheck.php",$plusmsgcheck);
  $pv = file_get_contents("BotsSource/BotsSource/gpgram/pv.php");
  save("Bots/Bot/$un/pv.php",$pv);
  $settings = file_get_contents("BotsSource/BotsSource/gpgram/settings.php");
  save("Bots/Bot/$un/settings.php",$settings);
  $settingsplus = file_get_contents("BotsSource/BotsSource/gpgram/settingsplus.php");
  save("Bots/Bot/$un/settingsplus.php",$settingsplus);
  $sharge = file_get_contents("BotsSource/BotsSource/gpgram/sharge.php");
  save("Bots/Bot/$un/sharge.php",$sharge);
  $tools = file_get_contents("BotsSource/BotsSource/gpgram/tools.php");
  save("Bots/Bot/$un/tools.php",$tools);
  $toolsplus = file_get_contents("BotsSource/BotsSource/gpgram/toolsplus.php");
  save("Bots/Bot/$un/toolsplus.php",$toolsplus);
  $upmsgcheck = file_get_contents("BotsSource/BotsSource/gpgram/upmsgcheck.php");
  save("Bots/Bot/$un/upmsgcheck.php",$upmsgcheck);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/bot.php");
  }}
  
 if($type == "banner"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/banner/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("BotsSource/BotsSource/banner/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);	
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  //---
 if($type == "chatrandom"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/user");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/chatrandom/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);	
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  //---
 if($type == "editmusic"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/editmusic/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "fileconvert"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/fileconvert/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "font"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/font/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "motarjem"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/motarjem/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "shortlink"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/shortlink/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "webhook"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/webhook/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "fallgir"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/fallgir/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "profile"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/profile/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("BotsSource/BotsSource/profile/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "eshterakresane"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/mailes");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/eshterakresane/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("BotsSource/BotsSource/eshterakresane/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "mailsent"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/mailsent/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "music"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/music/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $img = file_get_contents("BotsSource/BotsSource/music/data/img.png");
  save("Bots/Bot/$un/data/img.png",$img);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "viewbtn"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/admin");
  mkdir("Bots/Bot/$un/ads");
  mkdir("Bots/Bot/$un/cod");
  mkdir("Bots/Bot/$un/code");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/user");
  //--
  mkdir("Bots/Bot/$un/admin/ads");
  mkdir("Bots/Bot/$un/admin/code");
  mkdir("Bots/Bot/$un/admin/user");
  //--
  mkdir("Bots/Bot/$un/ads/admin");
  mkdir("Bots/Bot/$un/ads/ads admin");
  mkdir("Bots/Bot/$un/ads/ads end");
  mkdir("Bots/Bot/$un/ads/ads etmam");
  mkdir("Bots/Bot/$un/ads/ads log");
  mkdir("Bots/Bot/$un/ads/ads msg id");
  mkdir("Bots/Bot/$un/ads/ads ok");
  mkdir("Bots/Bot/$un/ads/ads rad");
  mkdir("Bots/Bot/$un/ads/ads start");
  mkdir("Bots/Bot/$un/ads/ads tally");
  mkdir("Bots/Bot/$un/ads/ads tedad");
  mkdir("Bots/Bot/$un/ads/ads username");
  mkdir("Bots/Bot/$un/ads/cont");
  mkdir("Bots/Bot/$un/ads/date");
  mkdir("Bots/Bot/$un/ads/seen");
  mkdir("Bots/Bot/$un/ads/time");
  mkdir("Bots/Bot/$un/ads/user");
  //-------
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $sup = $_GET['sup'];
  $Class = file_get_contents("BotsSource/BotsSource/viewbtn/Class.php");
  $Class = str_replace("[*[TOKEN]*]",$token,$Class);
  $Class = str_replace("[*[ADMIN]*]",$id,$Class);
  $Class = str_replace("[*[CHENNEL]*]",$channel,$Class);
  save("Bots/Bot/$un/Class.php",$Class);
  $index = file_get_contents("BotsSource/BotsSource/viewbtn/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  $index = str_replace("[*[SUP]*]",$sup,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "tabchi"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/tabchi/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("BotsSource/BotsSource/banner/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);	
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "addkon"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/addkon/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);	
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
 if($type == "kasb"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/admin");
  mkdir("Bots/Bot/$un/user");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $Class = file_get_contents("BotsSource/BotsSource/kasb/Class.php");
  $Class = str_replace("[*[TOKEN]*]",$token,$Class);
  $Class = str_replace("[*[ADMIN]*]",$id,$Class);
  save("Bots/Bot/$un/Class.php",$Class);
    $index = file_get_contents("BotsSource/BotsSource/kasb/index.php");
  save("Bots/Bot/$un/index.php",$index);	
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
   if($type == "esmfamil"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/esmfamil/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  save("Bots/Bot/$un/index.php",$index);
  $wordlist = file_get_contents("BotsSource/BotsSource/esmfamil/wordlist.json");
  save("Bots/Bot/$un/data/wordlist.json",$wordlist);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "kalamat"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/database");
  mkdir("Bots/Bot/$un/database/soal-javab");
  mkdir("Bots/Bot/$un/database/soal-javab/donafare");
  mkdir("Bots/Bot/$un/database/soal-javab/joghraphy");
  mkdir("Bots/Bot/$un/database/soal-javab/mazhabi");
  mkdir("Bots/Bot/$un/database/soal-javab/omomi");
  mkdir("Bots/Bot/$un/database/soal-javab/tarikhi");
  mkdir("Bots/Bot/$un/database/soal-javab/varzeshi");
  mkdir("Bots/Bot/$un/database/soal-javab/technology");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
   $c6 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/technology/count.txt");
  save("Bots/Bot/$un/database/soal-javab/technology/count.txt",$c6);
 $c5 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/varzeshi/count.txt");
  save("Bots/Bot/$un/database/soal-javab/varzeshi/count.txt",$c5);
$c4 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/tarikhi/count.txt");
  save("Bots/Bot/$un/database/soal-javab/tarikhi/count.txt",$c4);
$c3 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/omomi/count.txt");
  save("Bots/Bot/$un/database/soal-javab/omomi/count.txt",$c3);
$c2 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/mazhabi/count.txt");
  save("Bots/Bot/$un/database/soal-javab/mazhabi/count.txt",$c2);
  $c1 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/joghraphy/count.txt");
  save("Bots/Bot/$un/database/soal-javab/joghraphy/count.txt",$c1);
  //---
  $num1 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/donafare/1.txt");
  save("Bots/Bot/$un/database/soal-javab/donafare/1.txt",$num1);
    $num2 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/donafare/2.txt");
  save("Bots/Bot/$un/database/soal-javab/donafare/2.txt",$num2);
      $num3 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/donafare/3.txt");
  save("Bots/Bot/$un/database/soal-javab/donafare/3.txt",$num3);
      $num4 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/donafare/4.txt");
  save("Bots/Bot/$un/database/soal-javab/donafare/4.txt",$num4);
      $num5 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/donafare/5.txt");
  save("Bots/Bot/$un/database/soal-javab/donafare/5.txt",$num5);
      $num6 = file_get_contents("BotsSource/BotsSource/kalamat/database/soal-javab/donafare/6.txt");
  save("Bots/Bot/$un/database/soal-javab/donafare/6.txt",$num6);
  
  $index = file_get_contents("BotsSource/BotsSource/kalamat/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "limit"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $handler = file_get_contents("BotsSource/BotsSource/limit/handler.php");
  $handler = str_replace("[*[TOKEN]*]",$token,$handler);
  $handler = str_replace("[*[ADMIN]*]",$id,$handler);
  save("Bots/Bot/$un/handler.php",$handler);
  $index = file_get_contents("BotsSource/BotsSource/limit/index.php");
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  if($type == "face"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/face/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[WEB]*]","$WEBADRESS/Bots/Bot/$un",$index);
  save("Bots/Bot/$un/index.php",$index);
 $getphoto = file_get_contents("BotsSource/BotsSource/face/getphoto.php");
  save("Bots/Bot/$un/getphoto.php",$getphoto);	
   $send = file_get_contents("BotsSource/BotsSource/face/send.php");
  save("Bots/Bot/$un/send.php",$send);
   $sendphoto = file_get_contents("BotsSource/BotsSource/face/sendphoto.php");
  save("Bots/Bot/$un/sendphoto.php",$sendphoto);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
    if($type == "sandali"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("BotsSource/BotsSource/sandali/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}

  
  
  
  
  //------botgrams---------//
  if($type == "antisoam3"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
    $index = file_get_contents("CreateGramRobot/antispam3/index.php");
	$index = str_replace("[*[TOKEN]*]",$token,$index);
	  $index = str_replace("[*[ADMIN]*]",$id,$index);
	  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  save("Bots/BotGrams/$un/index.php",$index);
  $arabi = file_get_contents("CreateGramRobot/antispam3/arabi.php");
  save("Bots/BotGrams/$un/arabi.php",$arabi);
  $english = file_get_contents("CreateGramRobot/antispam3/english.php");
  save("Bots/BotGrams/$un/english.php",$english);
  $persian = file_get_contents("CreateGramRobot/antispam3/persian.php");
  save("Bots/BotGrams/$un/persian.php",$persian);
  $nophoto = file_get_contents("CreateGramRobot/antispam3/nophoto.png");
  save("Bots/BotGrams/$un//data/nophoto.png",$nophoto);
  $adstext = file_get_contents("$ads");
  save("Bots/BotGrams/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/index.php");
}}
  
   if($type == "EditPixel"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/index.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
    $index = file_get_contents("CreateGramRobot/EditPixel/index.php");
	$index = str_replace("[*[TOKEN]*]",$token,$index);
	  $index = str_replace("[*[ADMIN]*]",$id,$index);
	  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  save("Bots/BotGrams/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/BotGrams/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/index.php");
}}
 


   if($type == "AsllBede"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/index.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
    $index = file_get_contents("CreateGramRobot/AsllBede/index.php");
	$index = str_replace("[*[TOKEN]*]",$token,$index);
	  $index = str_replace("[*[ADMIN]*]",$id,$index);
	  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  save("Bots/BotGrams/$un/index.php",$index);
  $photo = file_get_contents("CreateGramRobot/AsllBede/photo/girl/IMG_20180314_233339_831.jpg");
  save("Bots/BotGrams/$un/photo/girl/IMG_20180314_233339_831.jpg",$photo);
    $photo2 = file_get_contents("CreateGramRobot/AsllBede/photo/boy/images-4.jpg");
  save("Bots/BotGrams/$un/photo/boy/images-4.jpg",$photo2);
  $user = file_get_contents("CreateGramRobot/AsllBede/user.json");
  save("Bots/BotGrams/$un/user.json",$user);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/index.php");
}}

    if($type == "AntiSpamSohal"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/index.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("CreateGramRobot/AntiSpamSohal/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  save("Bots/BotGrams/$un/index.php",$index);
  $lang = file_get_contents("CreateGramRobot/AntiSpamSohal/lang.php");
  save("Bots/BotGrams/$un/lang.php",$lang);
  $plug = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/plug.php",$plug);
    $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/index.php");
  }}

   if($type == "MusicYab"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/musicyab.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
    $MusicYab = file_get_contents("CreateGramRobot/MusicYab/musicyab.php");
	$MusicYab = str_replace("[*[TOKEN]*]",$token,$MusicYab);
	  $MusicYab = str_replace("[*[ADMIN]*]",$id,$MusicYab);
	  $MusicYab = str_replace("[*[CHENNEL]*]",$channel,$MusicYab);
  save("Bots/BotGrams/$un/musicyab.php",$MusicYab);
      $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/musicyab.php");
}}

    if($type == "Tabadol"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/Tabadol.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
  $Tabadol = file_get_contents("CreateGramRobot/Tabadol/Tabadol.php");
  $Tabadol = str_replace("[*[TOKEN]*]",$token,$Tabadol);
  $Tabadol = str_replace("[*[ADMIN]*]",$id,$Tabadol);
  $Tabadol = str_replace("[*[BOT]*]",$un,$Tabadol);
  $Tabadol = str_replace("[*[CHANNEL]*]",$channel,$Tabadol);
  save("Bots/BotGrams/$un/Tabadol.php",$Tabadol);
    $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/Tabadol.php");
  }}
  
     if($type == "AntiSpamRoboIRani"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/AntiSpamRoboIRani.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
  $AntiSpamRoboIRani = file_get_contents("CreateGramRobot/AntiSpamRoboIRani/AntiSpamRoboIRani.php");
  $AntiSpamRoboIRani = str_replace("[*[TOKEN]*]",$token,$AntiSpamRoboIRani);
  $AntiSpamRoboIRani = str_replace("[*[ADMIN]*]",$id,$AntiSpamRoboIRani);
  $AntiSpamRoboIRani = str_replace("[*[BOT]*]",$un,$AntiSpamRoboIRani);
  $AntiSpamRoboIRani = str_replace("[*[CHANNEL]*]",$channel,$AntiSpamRoboIRani);
  save("Bots/BotGrams/$un/AntiSpamRoboIRani.php",$AntiSpamRoboIRani);
    $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/AntiSpamRoboIRani.php");
  }}
  
       if($type == "gethob"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/gethob.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
  $gethob = file_get_contents("CreateGramRobot/gethob/gethob.php");
  $gethob = str_replace("[*[TOKEN]*]",$token,$gethob);
  $gethob = str_replace("[*[ADMIN]*]",$id,$gethob);
  $gethob = str_replace("[*[BOT]*]",$un,$gethob);
  $gethob = str_replace("[*[CHANNEL]*]",$channel,$gethob);
  save("Bots/BotGrams/$un/gethob.php",$gethob);
    $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/gethob.php");
  }}
  
  
 if($type == "iViewGeer"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/admin");
  mkdir("Bots/Bot/$un/ads");
  mkdir("Bots/Bot/$un/cod");
  mkdir("Bots/Bot/$un/code");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/user");
  //--
  mkdir("Bots/Bot/$un/admin/ads");
  mkdir("Bots/Bot/$un/admin/code");
  mkdir("Bots/Bot/$un/admin/user");
  //--
  mkdir("Bots/Bot/$un/ads/admin");
  mkdir("Bots/Bot/$un/ads/ads admin");
  mkdir("Bots/Bot/$un/ads/ads end");
  mkdir("Bots/Bot/$un/ads/ads etmam");
  mkdir("Bots/Bot/$un/ads/ads log");
  mkdir("Bots/Bot/$un/ads/ads msg id");
  mkdir("Bots/Bot/$un/ads/ads ok");
  mkdir("Bots/Bot/$un/ads/ads rad");
  mkdir("Bots/Bot/$un/ads/ads start");
  mkdir("Bots/Bot/$un/ads/ads tally");
  mkdir("Bots/Bot/$un/ads/ads tedad");
  mkdir("Bots/Bot/$un/ads/ads username");
  mkdir("Bots/Bot/$un/ads/cont");
  mkdir("Bots/Bot/$un/ads/date");
  mkdir("Bots/Bot/$un/ads/seen");
  mkdir("Bots/Bot/$un/ads/time");
  mkdir("Bots/Bot/$un/ads/user");
  //-------
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $sup = $_GET['sup'];
  $Class = file_get_contents("CreateGramRobot/iViewGeer/Class.php");
  $Class = str_replace("[*[TOKEN]*]",$token,$Class);
  $Class = str_replace("[*[ADMIN]*]",$id,$Class);
  $Class = str_replace("[*[CHENNEL]*]",$channel,$Class);
  save("Bots/Bot/$un/Class.php",$Class);
  $index = file_get_contents("CreateGramRobot/iViewGeer/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  $index = str_replace("[*[SUP]*]",$sup,$index);
  save("Bots/Bot/$un/index.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}

  

  
if($type == "HostVid"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("CreateGramRobot/HostVid/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("CreateGramRobot/HostVid/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  
if($type == "ViewGeerLov"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/data");
  if($account == "vip"){
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
  $index = file_get_contents("CreateGramRobot/ViewGeerLov/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHENNEL]*]",$channel,$index);
  $index = str_replace("[*[SUP]*]",$sup,$index);
  save("Bots/Bot/$un/index.php",$index);
  $jdf = file_get_contents("CreateGramRobot/ViewGeerLov/jdf.php");
  save("Bots/Bot/$un/jdf.php",$jdf);
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
  }}
  
	if($type == "create997"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/CreateGramBots/$un/index.php"))){
mkdir("Bots/CreateGramBots/$un");
mkdir("Bots/CreateGramBots/$un/data");
$index = file_get_contents("BotsSource/CreateGramBots/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/CreateGramBots/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/CreateGramBots/$un/index.php");
	}}
	
	if($type == "create9964675785785897"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/CreateGramBots/$un/index.php"))){
mkdir("Bots/CreateGramBots/$un");
mkdir("Bots/CreateGramBots/$un/data");
$index = file_get_contents("BotsSource/CreateGramBots1/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/CreateGramBots/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/CreateGramBots/$un/index.php");
	}}
	
		if($type == "parvazAntispam"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
mkdir("Bots/Bot/$un");
mkdir("Bots/Bot/$un/data");
$index = file_get_contents("CreateGramRobot/parvazAntispam/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/Bot/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/CreateGramBots/$un/index.php");
	}}
			  		if($type == "BotSazcreatecup"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazcreatecup/$un/index.php"))){
mkdir("Bots/BotSazcreatecup/$un");
mkdir("Bots/BotSazcreatecup/$un/data");
mkdir("Bots/BotSazcreatecup/$un/code");
mkdir("Bots/BotSazcreatecup/$un/bots");
mkdir("Bots/BotSazcreatecup/$un/source");
mkdir("Bots/BotSazcreatecup/$un/source/member");
mkdir("Bots/BotSazcreatecup/$un/source/hava");
mkdir("Bots/BotSazcreatecup/$un/source/net");
mkdir("Bots/BotSazcreatecup/$un/source/File");
mkdir("Bots/BotSazcreatecup/$un/source/font");
mkdir("Bots/BotSazcreatecup/$un/source/harfnashenas");
mkdir("Bots/BotSazcreatecup/$un/source/music");
mkdir("Bots/BotSazcreatecup/$un/source/pv");
mkdir("Bots/BotSazcreatecup/$un/source/cup1");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/data");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/code");
mkdir("Bots/BotSazcreatecup/$un/source/bots");
mkdir("Bots/BotSazcreatecup/$un/source/setwebhook");
mkdir("Bots/BotSazcreatecup/$un/source/XObot");
mkdir("Bots/BotSazcreatecup/$un/source/harfnashenas/data");
mkdir("Bots/BotSazcreatecup/$un/source/music/data");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/File");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/font");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/harfnashenas");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/music");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/pv");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/setwebhook");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/XObot");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/harfnashenas/data");
mkdir("Bots/BotSazcreatecup/$un/source/cup1/source/music/data");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/Chatnashenas");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/pm");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/see");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/tab");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/view");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/view/user");
mkdir("Bots/BotSazcreatecup/$un/source/botsaz/zeee");
$index = file_get_contents("BotsSource/BotSazcreatecup/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazcreatecup/$un/index.php",$index);	
  $indexbet = file_get_contents("BotsSource/BotSazcreatecup/source/File/index.php");
  save("Bots/BotSazcreatecup/$un/source/File/index.php",$indexbet);	
  $indexcup = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/Chatnashenas/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/Chatnashenas/index.php",$indexcup);	
  $indexcup1 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/pm/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/pm/index.php",$indexcup1);	
  $indexcup2 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/pm/Class.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/pm/Class.php",$indexcup2);	
  $indexcup3 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/pm/Button.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/pm/Button.php",$indexcup3);	
     $indexcup4 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/see/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/see/index.php",$indexcup4);	
     $indexcup5 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/see/Class.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/see/Class.php",$indexcup5);	
     $indexcup6 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/see/jdf.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/see/jdf.php",$indexcup6);	
       $indexcup7 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/tab/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/tab/index.php",$indexcup7);	
         $indexcup8 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/tab/Class.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/tab/Class.php",$indexcup8);	
     $indexcup9 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/view/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/view/index.php",$indexcup9);	
       $indexcup10 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/view/Class.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/view/Class.php",$indexcup10);	
         $indexcup11 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/view/user/coin.txt");
  save("Bots/BotSazcreatecup/$un/source/botsaz/view/user/coin.txt",$indexcup11);	
     $indexcup12 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/zeee/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/zeee/index.php",$indexcup12);	
     $indexcup13 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/zeee/Class.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/zeee/Class.php",$indexcup13);	
    $indexcup14 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/index.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/index.php",$indexcup14);	
     $indexcup15 = file_get_contents("BotsSource/BotSazcreatecup/source/botsaz/Class.php");
  save("Bots/BotSazcreatecup/$un/source/botsaz/Class.php",$indexcup15);	
    $indexcup16 = file_get_contents("BotsSource/BotSazcreatecup/source/hava/index.php");
  save("Bots/BotSazcreatecup/$un/source/hava/index.php",$indexcup16);	
   $indexcup17 = file_get_contents("BotsSource/BotSazcreatecup/source/mamber/bot.php");
  save("Bots/BotSazcreatecup/$un/source/member/bot.php",$indexcup17);	
   $indexcup18 = file_get_contents("BotsSource/BotSazcreatecup/source/mamber/bot.php");
  save("Bots/BotSazcreatecup/$un/source/net/index.php",$indexcup18);	
     $indexcup19 = file_get_contents("BotsSource/BotSazcreatecup/source/net/Class.php");
  save("Bots/BotSazcreatecup/$un/source/net/Class.php",$indexcup19);	
     $indexcup20 = file_get_contents("BotsSource/BotSazcreatecup/source/net/jdf.php");
  save("Bots/BotSazcreatecup/$un/source/net/jdf.php",$indexcup20);	
  $indexbet1 = file_get_contents("BotsSource/BotSazcreatecup/source/font/index.php");
  save("Bots/BotSazcreatecup/$un/source/font/index.php",$indexbet1);	
  $indexbet2 = file_get_contents("BotsSource/BotSazcreatecup/source/harfnashenas/index.php");
  save("Bots/BotSazcreatecup/$un/source/harfnashenas/index.php",$indexbet2);	
  $indexbet3 = file_get_contents("BotsSource/BotSazcreatecup/source/music/index.php");
  save("Bots/BotSazcreatecup/$un/source/music/index.php",$indexbet3);	
  $indexbet4 = file_get_contents("BotsSource/BotSazcreatecup/source/pv/index.php");
  save("Bots/BotSazcreatecup/$un/source/pv/index.php",$indexbet4);	
  $indexbet5 = file_get_contents("BotsSource/BotSazcreatecup/source/setwebhook/index.php");
  save("Bots/BotSazcreatecup/$un/source/setwebhook/index.php",$indexbet5);	
  $indexbet6 = file_get_contents("BotsSource/BotSazcreatecup/source/XObot/index.php");
  save("Bots/BotSazcreatecup/$un/source/XObot/index.php",$indexbet6);	
   $indexbet7 = file_get_contents("BotsSource/BotSazcreatecup/source/cup1/source/font/index.php");
  save("Bots/BotSazcreatecup/$un/source/cup1/source/font/index.php",$indexbet7);	
  $indexbet8 = file_get_contents("BotsSource/BotSazcreatecup/source/cup1/source/harfnashenas/index.php");
  save("Bots/BotSazcreatecup/$un/source/cup1/source/harfnashenas/index.php",$indexbet8);	
  $indexbet9 = file_get_contents("BotsSource/BotSazcreatecup/source/cup1/source/music/index.php");
  save("Bots/BotSazcreatecup/$un/source/cup1/source/music/index.php",$indexbet9);	
  $indexbet10 = file_get_contents("BotsSource/BotSazcreatecup/source/cup1/source/pv/index.php");
  save("Bots/BotSazcreatecup/$un/source/cup1/source/pv/index.php",$indexbet10);	
  $indexbet11 = file_get_contents("BotsSource/BotSazcreatecup/source/cup1/source/setwebhook/index.php");
  save("Bots/BotSazcreatecup/$un/source/cup1/source/setwebhook/index.php",$indexbet11);	
  $indexbet12 = file_get_contents("BotsSource/BotSazcreatecup/source/cup1/source/XObot/index.php");
  save("Bots/BotSazcreatecup/$un/source/cup1/source/XObot/index.php",$indexbet12);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazcreatecup/$un/index.php");
	}}
	
		  		if($type == "BotSazbet"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazbet/$un/index.php"))){
mkdir("Bots/BotSazbet/$un");
mkdir("Bots/BotSazbet/$un/data");
mkdir("Bots/BotSazbet/$un/code");
mkdir("Bots/BotSazbet/$un/bots");
mkdir("Bots/BotSazbet/$un/source");
mkdir("Bots/BotSazbet/$un/source/File");
mkdir("Bots/BotSazbet/$un/source/font");
mkdir("Bots/BotSazbet/$un/source/harfnashenas");
mkdir("Bots/BotSazbet/$un/source/music");
mkdir("Bots/BotSazbet/$un/source/pv");
mkdir("Bots/BotSazbet/$un/source/setwebhook");
mkdir("Bots/BotSazbet/$un/source/XObot");
mkdir("Bots/BotSazbet/$un/source/harfnashenas/data");
mkdir("Bots/BotSazbet/$un/source/music/data");
$index = file_get_contents("BotsSource/BotSazbet/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazbet/$un/index.php",$index);	
  $indexbet = file_get_contents("BotsSource/BotSazbet/source/File/index.php");
  save("Bots/BotSazbet/$un/source/File/index.php",$indexbet);	
  $indexbet1 = file_get_contents("BotsSource/BotSazbet/source/font/index.php");
  save("Bots/BotSazbet/$un/source/font/index.php",$indexbet1);	
  $indexbet2 = file_get_contents("BotsSource/BotSazbet/source/harfnashenas/index.php");
  save("Bots/BotSazbet/$un/source/harfnashenas/index.php",$indexbet2);	
  $indexbet3 = file_get_contents("BotsSource/BotSazbet/source/music/index.php");
  save("Bots/BotSazbet/$un/source/music/index.php",$indexbet3);	
  $indexbet4 = file_get_contents("BotsSource/BotSazbet/source/pv/index.php");
  save("Bots/BotSazbet/$un/source/pv/index.php",$indexbet4);	
  $indexbet5 = file_get_contents("BotsSource/BotSazbet/source/setwebhook/index.php");
  save("Bots/BotSazbet/$un/source/setwebhook/index.php",$indexbet5);	
  $indexbet6 = file_get_contents("BotsSource/BotSazbet/source/XObot/index.php");
  save("Bots/BotSazbet/$un/source/XObot/index.php",$indexbet6);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazbet/$un/index.php");
	}}
	
	  		if($type == "BotSaztak"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSaztak/$un/index1.php"))){
  mkdir("Bots/BotSaztak/$un");
  mkdir("Bots/BotSaztak/$un/data");
  mkdir("Bots/BotSaztak/$un/bot");
  mkdir("Bots/BotSaztak/$un/administrative");
  mkdir("Bots/BotSaztak/$un/administrative/source");
  mkdir("Bots/BotSaztak/$un/administrative/source/add");
  mkdir("Bots/BotSaztak/$un/administrative/source/aksneveshte");
  mkdir("Bots/BotSaztak/$un/administrative/source/ali");
  mkdir("Bots/BotSaztak/$un/administrative/source/anti");
  mkdir("Bots/BotSaztak/$un/administrative/source/baner");
  mkdir("Bots/BotSaztak/$un/administrative/source/baner2");
  mkdir("Bots/BotSaztak/$un/administrative/source/chalesh");
  mkdir("Bots/BotSaztak/$un/administrative/source/Chatnashenas");
  mkdir("Bots/BotSaztak/$un/administrative/source/esm");
  mkdir("Bots/BotSaztak/$un/administrative/source/fal");
  mkdir("Bots/BotSaztak/$un/administrative/source/mem");
  mkdir("Bots/BotSaztak/$un/administrative/source/gard");
  mkdir("Bots/BotSaztak/$un/administrative/source/pv");
  mkdir("Bots/BotSaztak/$un/administrative/source/pv/bot");
  mkdir("Bots/BotSaztak/$un/administrative/source/see");
  mkdir("Bots/BotSaztak/$un/administrative/source/tab");
  mkdir("Bots/BotSaztak/$un/administrative/source/view");
  mkdir("Bots/BotSaztak/$un/administrative/source/zed");
  mkdir("Bots/BotSaztak/$un/administrative/source/zed1");
  mkdir("Bots/BotSaztak/$un/administrative/source/zeee");
  mkdir("Bots/BotSaztak/$un/administrative/vips");
  mkdir("Bots/BotSaztak/$un/administrative/access");
  mkdir("Bots/BotSaztak/$un/administrative/user");
  mkdir("Bots/BotSaztak/$un/administrative/data");
  mkdir("Bots/BotSaztak/$un/administrative/code");
  mkdir("Bots/BotSaztak/$un/administrative/code1");
  mkdir("Bots/BotSaztak/$un/administrative/banall-member");
  $classtak1010 = file_get_contents("BotsSource/BotSaztak/jdf.php");
  save("Bots/BotSaztak/$un/jdf.php",$classtak1010);
$index = file_get_contents("BotsSource/BotSaztak/index1.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSaztak/$un/index1.php",$index);	
  $classtak = file_get_contents("BotsSource/BotSaztak/administrative/access/class.php");
  $classtak = str_replace("[*[TOKEN]*]",$token,$classtak);
  $classtak = str_replace("[*[ADMIN]*]",$id,$classtak);
  $classtak = str_replace("[*[CHANNEL]*]",$channel,$classtak);
  $classtak = str_replace("[*[BOT]*]",$un,$classtak);
  save("Bots/BotSaztak/$un/administrative/access/class.php",$classtak);	
  $classtak1 = file_get_contents("BotsSource/BotSaztak/goldhour.php");
  save("Bots/BotSaztak/$un/goldhour.php",$classtak1);	
  $classtak2 = file_get_contents("BotsSource/BotSaztak/ali.php");
  save("Bots/BotSaztak/$un/ali.php",$classtak2);	
  $classtak3 = file_get_contents("BotsSource/BotSaztak/send.php");
  save("Bots/BotSaztak/$un/send.php",$classtak3);	
     $butt3 = file_get_contents("BotsSource/Botsaztak/administrative/source/add/index.php");
  save("Bots/$un/administrative/source/add/index.php",$butt3);	
    $butt4 = file_get_contents("BotsSource/Botsaztak/administrative/source/aksneveshte/Class.php");
  save("Bots/$un/administrative/source/aksneveshte/Class.php",$butt4);	
    $butt5 = file_get_contents("Botsdatas/tak/administrative/source/aksneveshte/index.php");
  save("Bots/$un/administrative/source/aksneveshte/index.php",$butt5);	
    $butt6 = file_get_contents("BotsSource/Botsaztak/administrative/source/ali/index.php");
  save("Bots/$un/administrative/source/ali/index.php",$butt6);	
    $butt7 = file_get_contents("BotsSource/Botsaztak/administrative/source/anti/base.php");
  save("Bots/$un/administrative/source/anti/base.php",$butt7);	
    $butt8 = file_get_contents("BotsSource/Botsaztak/administrative/source/anti/index.php");
  save("Bots/$un/administrative/source/anti/index.php",$butt8);	
    $butt9 = file_get_contents("BotsSource/Botsaztak/administrative/source/anti/jdf.php");
  save("Bots/$un/administrative/source/anti/jdf.php",$butt9);	
    $butt10 = file_get_contents("BotsSource/Botsaztak/administrative/source/baner/index.php");
  save("Bots/$un/administrative/source/baner/index.php",$butt10);	
    $butt11 = file_get_contents("BotsSource/Botsaztak/administrative/source/baner/class.php");
  save("Bots/$un/administrative/source/baner/class.php",$butt11);	
        $butt1300 = file_get_contents("BotsSource/Botsaztak/administrative/source/baner2/b.php");
  save("Bots/$un/administrative/source/baner2/b.php",$butt1300);	
    $butt12 = file_get_contents("BotsSource/Botsaztak/administrative/source/baner2/jdf.php");
  save("Bots/$un/administrative/source/baner/jdf.php",$butt12);	
    $butt13 = file_get_contents("BotsSource/Botsaztak/administrative/source/chalesh/index.php");
  save("Bots/$un/administrative/source/chalesh/index.php",$butt13);	
      $butt14 = file_get_contents("BotsSource/Botsaztak/administrative/source/Chatnashenes/index.php");
  save("Bots/$un/administrative/source/Chatnashenas/index.php",$butt14);	
    $butt15 = file_get_contents("BotsSource/Botsaztak/administrative/source/esm/Class.php");
  save("Bots/$un/administrative/source/esm/Class.php",$butt15);	
    $butt16 = file_get_contents("BotsSource/Botsaztak/administrative/source/esm/wordlist.json");
  save("Bots/$un/administrative/source/esm/wordlist.json",$butt16);	
    $butt17 = file_get_contents("BotsSource/Botsaztak/administrative/source/fal/class.php");
  save("Bots/$un/administrative/source/fal/class.php",$butt17);	
  $butt18 = file_get_contents("BotsSource/Botsaztak/administrative/source/gard/index.php");
  save("Bots/$un/administrative/source/gard/index.php",$butt18);	
   $butt19 = file_get_contents("BotsSource/Botsaztak/administrative/source/gard/indexvip.php");
  save("Bots/$un/administrative/source/gard/indexvip.php",$butt19);	
    $butt20 = file_get_contents("BotsSource/Botsaztak/administrative/source/gard/Class.php");
  save("Bots/$un/administrative/source/gard/Class.php",$butt20);	
    $butt21 = file_get_contents("BotsSource/Botsaztak/administrative/source/mem/jdf.php");
  save("Bots/$un/administrative/source/mem/jdf.php",$butt21);	
    $butt22 = file_get_contents("BotsSource/Botsaztak/administrative/source/mem/Bots.php");
  save("Bots/$un/administrative/source/mem/Bots.php",$butt22);	
    $butt23 = file_get_contents("BotsSource/Botsaztak/administrative/source/mem/index.php");
  save("Bots/$un/administrative/source/mem/index.php",$butt23);	
    $butt24 = file_get_contents("BotsSource/Botsaztak/administrative/source/pv/index.php");
  save("Bots/$un/administrative/source/pv/index.php",$butt24);	
    $butt25 = file_get_contents("BotsSource/Botsaztak/administrative/source/pv/Bots/index.php");
  save("Bots/$un/administrative/source/pv/Bots/index.php",$butt25);	
    $butt26 = file_get_contents("BotsSource/Botsaztak/administrative/source/see/Class.php");
  save("Bots/$un/administrative/source/see/Class.php",$butt26);	
      $butt221 = file_get_contents("BotsSource/Botsaztak/administrative/source/see/jdf.php");
  save("Bots/$un/administrative/source/see/jdf.php",$butt221);	
    $butt232 = file_get_contents("BotsSource/Botsaztak/administrative/source/see/index.php");
  save("Bots/$un/administrative/source/see/index.php",$butt232);	
    $butt243 = file_get_contents("BotsSource/Botsaztak/administrative/source/tab/Class.php");
  save("Bots/$un/administrative/source/tab/Class.php",$butt243);	
    $butt254 = file_get_contents("BotsSource/Botsaztak/administrative/source/view/index.php");
  save("Bots/$un/administrative/source/view/index.php",$butt254);	
    $butt265 = file_get_contents("BotsSource/Botsaztak/administrative/source/view/Class.php");
  save("Bots/$un/administrative/source/view/Class.php",$butt265);	
    $butt27 = file_get_contents("BotsSource/Botsaztak/administrative/source/zed/Class.php");
  save("Bots/$un/administrative/source/zed/Class.php",$butt27);	
    $butt28 = file_get_contents("BotsSource/Botsaztak/administrative/source/zed1/index.php");
  save("Bots/$un/administrative/source/zed1/index.php",$butt28);	
      $butt31 = file_get_contents("BotsSource/Botsaztak/administrative/source/Button.php");
  save("Bots/$un/administrative/source/Button.php",$butt31);	
    $butt32 = file_get_contents("BotsSource/Botsaztak/administrative/source/Class.php");
  save("Bots/$un/administrative/source/Class.php",$butt32);	
    $butt33 = file_get_contents("BotsSource/Botsaztak/administrative/source/index.php");
  save("Bots/$un/administrative/source/index.php",$butt33);	
    $butt34 = file_get_contents("BotsSource/Botsaztak/administrative/source/sssss.php");
    save("Bots/$un/administrative/source/sssss.php",$butt34);
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSaztak/$un/index1.php");
	}}
	
	  		if($type == "BotSazhaji1"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazhaji1/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
	  		if($type == "BotSazcyberalfa"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazcyberalfa/$un/index.php"))){
mkdir("Bots/BotSazcyberalfa/$un");
mkdir("Bots/BotSazcyberalfa/$un/data");
mkdir("Bots/BotSazcyberalfa/$un/Bots");
mkdir("Bots/BotSazcyberalfa/$un/administrative");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/aksneveshte");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/Chatnashenas");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/see");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/pm");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/tab");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/view");
mkdir("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/zeee");
mkdir("Bots/BotSazcyberalfa/$un/administrative/access");
mkdir("Bots/BotSazcyberalfa/$un/administrative/user");
mkdir("Bots/BotSazcyberalfa/$un/administrative/code");
mkdir("Bots/BotSazcyberalfa/$un/administrative/banall-member");

$index = file_get_contents("BotsSource/BotSazcyberalfa/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazcyberalfa/$un/index.php",$index);
  $index11 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/access/Class.php");
  $index11 = str_replace("[*[TOKEN]*]",$token,$index11);
  $index11 = str_replace("[*[ADMIN]*]",$id,$index11);
  $index11 = str_replace("[*[CHANNEL]*]",$channel,$index11);
  $index11 = str_replace("[*[BOT]*]",$un,$index11);
  save("Bots/BotSazcyberalfa/$un/administrative/access/Class.php",$index11);
     $butt3 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/pm/index.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/pm/index.php",$butt3);	
    $butt4 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/pm/Class.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/pm/Class.php",$butt4);	
    $butt5 = file_get_contents("Botsdatas/tak/cyber/administrative/source/RoBotsaz/pm/Button.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/pm/Button.php",$butt5);	
    $butt6 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/see/index.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/see/index.php",$butt6);	
    $butt7 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/see/Class.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/see/Class.php",$butt7);	
    $butt8 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/see/jdf.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/see/jdf.php",$butt8);	
    $butt9 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/tab/Class.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/tab/Class.php",$butt9);	
    $butt10 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/tab/index.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/tab/index.php",$butt10);	
    $butt11 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/view/Class.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/view/Class.php",$butt11);	
        $butt1300 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/zeee/Class.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/zeee/Class.php",$butt1300);	
    $butt12 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/zeee/index.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/zeee/index.php",$butt12);	
    $butt13 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/Chatnashenas/index.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/Chatnashenas/index.php",$butt13);	
      $butt14 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/index.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/index.php",$butt14);	
    $butt15 = file_get_contents("BotsSource/BotSazcyberalfa/administrative/source/RoBotsaz/Class.php");
  save("Bots/BotSazcyberalfa/$un/administrative/source/RoBotsaz/Class.php",$butt15);
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazcyberalfa/$un/index.php");
	}}
	 		if($type == "BotSazpro3"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazpro3/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
  		if($type == "BotSazpro22"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazpro22/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
			if($type == "member"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bot/$un/bot.php"))){
mkdir("Bot/$un");
mkdir("Bot/$un/data");
$index = file_get_contents("BotsSource/member/bot.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bot/$un/bot.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bot/$un/bot.php");
	}}
			if($type == "BOTSAZNEW"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("CreateGramRobot/bt/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
		if($type == "BotSazNovin"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazNovin/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
		   		if($type == "BotSazdaienew"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bot/$un/index.php"))){
save('botsdatas/user/'.$from_id."/command.txt","none");
mkdir("Bot/$un");
mkdir("Bot/$un/Bot");
mkdir("Bot/$un/botsdatas");
mkdir("Bot/$un/botsdatas/source");
mkdir("Bot/$un/botsdatas/source/botadd");
mkdir("Bot/$un/botsdatas/source/botanti");
mkdir("Bot/$un/botsdatas/source/botchat");
mkdir("Bot/$un/botsdatas/source/botchat2");
mkdir("Bot/$un/botsdatas/source/botpv");
mkdir("Bot/$un/botsdatas/source/botpv2");
mkdir("Bot/$un/botsdatas/source/botfamily");
mkdir("Bot/$un/botsdatas/source/bothads");
mkdir("Bot/$un/botsdatas/source/botview");
mkdir("Bot/$un/botsdatas/source/botzed");
mkdir("Bot/$un/botsdatas/source/botmember");
mkdir("Bot/$un/botsdatas/source/botwar");
mkdir("Bot/$un/botsdatas/source/botsharj");
mkdir("Bot/$un/botsdatas/source/bottab");
mkdir("Bot/$un/botsdatas/access");
mkdir("Bot/$un/botsdatas/source/botfamily/kalamat");
mkdir("Bot/$un/botsdatas/user");
mkdir("Bot/$un/botsdatas/banall-member");
save("Bot/$un/botsdatas/coin.txt","0");

$class23 = file_get_contents("botsdatas/source/daie/jdf.php");
save("Bot/$un/jdf.php",$class23);

$index = file_get_contents("BotsSource/daie/index1.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
save("Bot/$un/index.php",$index);
$index1 = file_get_contents("BotsSource/daie/botsdatas/access/Class.php");
  $index1 = str_replace("[*[TOKEN]*]",$token,$index1);
  $index1 = str_replace("[*[ADMIN]*]",$id,$index1);
  $index1 = str_replace("[*[CHANNEL]*]",$channel,$index1);
  $index1 = str_replace("[*[BOT]*]",$un,$index1);
 save("Bot/$un/botsdatas/access/Class.php",$index1);
   $index = file_get_contents("botsdatas/source/daie/botsdatas/source/botadd/index.php");
  save("Bot/$un/botsdatas/source/botadd/index.php",$index);	
  $butt = file_get_contents("botsdatas/source/daie/botsdatas/source/botsdatas/source/botanti/add.php");
  save("Bot/$un/botsdatas/source/botanti/add.php",$butt);	
   $butt2 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/base.php");
  save("Bot/$un/botsdatas/source/botanti/base.php",$butt2);	
    $butt3 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/bot.php");
  save("Bot/$un/botsdatas/source/botanti/bot.php",$butt3);	
    $butt4 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/filter.php");
  save("Bot/$un/botsdatas/source/botanti/filter.php",$butt4);	
    $butt5 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/fun.php");
  save("Bot/$un/botsdatas/source/botanti/fun.php",$butt5);	
    $butt6 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/funplus.php");
  save("Bot/$un/botsdatas/source/botanti/funplus.php",$butt6);	
    $butt7 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/help.php");
  save("Bot/$un/botsdatas/source/botanti/help.php",$butt7);	
    $butt8 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/lock.php");
  save("Bot/$un/botsdatas/source/botanti/lock.php",$butt8);	
    $butt9 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/settings.php");
  save("Bot/$un/botsdatas/source/botanti/settings.php",$butt9);	
    $butt10 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/pv.php");
  save("Bot/$un/botsdatas/source/botanti/pv.php",$butt10);	
    $butt11 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/panel.php");
  save("Bot/$un/botsdatas/source/botanti/panel.php",$butt11);	
        $butt1300 = file_get_contents("botsdatas/source/daie/botsdatas/source/bottab/index.php");
  save("Bot/$un/botsdatas/source/bottab/index.php",$butt1300);	
    $butt12 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/lockplus.php");
  save("Bot/$un/botsdatas/source/botanti/lockplus.php",$butt12);	
    $butt13 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/lockchannel.php");
  save("Bot/$un/botsdatas/source/botanti/lockchannel.php",$butt13);	
      $butt14 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/tools.php");
  save("Bot/$un/botsdatas/source/botanti/tools.php",$butt14);	
    $butt15 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/toolsplus.php");
  save("Bot/$un/botsdatas/source/botanti/toolsplus.php",$butt15);	
    $butt16 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/msgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/msgcheck.php",$butt16);	
    $butt17 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/sharge.php");
  save("Bot/$un/botsdatas/source/botanti/sharge.php",$butt17);	
  
  $butt18 = file_get_contents("botsdatas/source/daie/botsdatas/source/botsdatas/source/botanti/plus.php");
  save("Bot/$un/botsdatas/source/botanti/plus.php",$butt18);	
   $butt19 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/upmsgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/upmsgcheck.php",$butt19);	
    $butt20 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/plusupmsgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/plusupmsgcheck.php",$butt20);	
    $butt21 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/plusmsgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/plusmsgcheck.php",$butt21);	
    $butt22 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/Class.php");
  save("Bot/$un/botsdatas/source/botchat/Class.php",$butt22);	
    $butt23 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/config.php");
  save("Bot/$un/botsdatas/source/botchat/config.php",$butt23);	
    $butt24 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/index.php");
  save("Bot/$un/botsdatas/source/botchat/index.php",$butt24);	
    $butt25 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/sendall.php");
  save("Bot/$un/botsdatas/source/botchat/sendall.php",$butt25);	
    $butt26 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/sendtab.php");
  save("Bot/$un/botsdatas/source/botchat/sendtab.php",$butt26);	
      $butt221 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/Class.php");
  save("Bot/$un/botsdatas/source/botchat2/Class.php",$butt221);	
    $butt232 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/config.php");
  save("Bot/$un/botsdatas/source/botchat2/config.php",$butt232);	
    $butt243 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/index.php");
  save("Bot/$un/botsdatas/source/botchat2/index.php",$butt243);	
    $butt254 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/sendall.php");
  save("Bot/$un/botsdatas/source/botchat2/sendall.php",$butt254);	
    $butt265 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/sendtab.php");
  save("Bot/$un/botsdatas/source/botchat2/sendtab.php",$butt265);	
    $butt27 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/index.php");
  save("Bot/$un/botsdatas/source/botfamily/index.php",$butt27);	
    $butt28 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/api-rand.php");
  save("Bot/$un/botsdatas/source/botfamily/api-rand.php",$butt28);	

    $butt29 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/ashya.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/ashya.txt",$butt29);	
    $butt30 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/esm.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/esm.txt",$butt30);	
      $butt31 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/famil.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/famil.txt",$butt31);	
    $butt32 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/ghaza.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/ghaza.txt",$butt32);	
    $butt33 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/heyvan.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/heyvan.txt",$butt33);	
    $butt34 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/keshvar.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/keshvar.txt",$butt34);	
      $butt295 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/mive.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/mive.txt",$butt295);	
    $butt306 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/rang.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/rang.txt",$butt306);	
      $butt317 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/shahr.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/shahr.txt",$butt317);	
    $butt328 = file_get_contents("botsdatas/source/daie/botsdatas/source/bothads/index.php");
  save("Bot/$un/botsdatas/source/bothads/index.php",$butt328);	
    $butt339 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/bot.php");
  save("Bot/$un/botsdatas/source/botmember/bot.php",$butt339);	
    $butt3410 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/jdf.php");
  save("Bot/$un/botsdatas/source/botmember/jdf.php",$butt3410);	
  
      $butt32814 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv/Button.php");
  save("Bot/$un/botsdatas/source/botpv/Button.php",$butt32814);	
    $butt33915 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv/Class.php");
  save("Bot/$un/botsdatas/source/botpv/Class.php",$butt33915);	
    $butt341016 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv/index.php");
  save("Bot/$un/botsdatas/source/botpv/index.php",$butt341016);	
      $butt32817 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv2/index.php");
  save("Bot/$un/botsdatas/source/botpv2/index.php",$butt32817);	
    $butt33918 = file_get_contents("botsdatas/source/daie/botsdatas/source/botsharj/index.php");
  save("Bot/$un/botsdatas/source/botsharj/index.php",$butt33918);	
    $butt341019 = file_get_contents("botsdatas/source/daie/botsdatas/source/botview/jdf.php");
  save("Bot/$un/botsdatas/source/botview/jdf.php",$butt341019);	
      $butt32820 = file_get_contents("botsdatas/source/daie/botsdatas/source/botview/index.php");
  save("Bot/$un/botsdatas/source/botview/index.php",$butt32820);	
    $butt33921 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/index.php");
  save("Bot/$un/botsdatas/source/botwar/index.php",$butt33921);	
    $butt341022 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/telegram.php");
  save("Bot/$un/botsdatas/source/botwar/telegram.php",$butt341022);	
      $butt32823 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/lvp.php");
  save("Bot/$un/botsdatas/source/bothads/lvp.php",$butt32823);
  mkdir("Bot/$un/botsdatas/source/botwar/config");
  
    $butt33924 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/config/pricetroop.php");
  save("Bot/$un/botsdatas/source/botwar/config/pricetroop.php",$butt33924);	
    $butt341025 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/config/pricetale.php");
  save("Bot/$un/botsdatas/source/botwar/config/pricetale.php",$butt341025);	
      $butt32826 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/index.php");
  save("Bot/$un/botsdatas/source/botzed/index.php",$butt32826);	
    $butt33927 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/arabi.php");
  save("Bot/$un/botsdatas/source/botzed/arabi.php",$butt33927);	
    $butt341028 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/english.php");
  save("Bot/$un/botsdatas/source/botzed/english.php",$butt341028);	
      $butt32829 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/persian.php");
  save("Bot/$un/botsdatas/source/botzed/persian.php",$butt32829);	
    $butt33930 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/bot.php");
  save("Bot/$un/botsdatas/source/botmember/bot.php",$butt33930);	
    $butt341031 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/jdf.php");
  save("Bot/$un/botsdatas/source/botmember/jdf.php",$butt341031);	
  
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bot/$un/index.php");
	}}
	
			   		if($type == "BotSazdaie"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bot/$un/index.php"))){
save('botsdatas/user/'.$from_id."/command.txt","none");
mkdir("Bot/$un");
mkdir("Bot/$un/Bot");
mkdir("Bot/$un/botsdatas");
mkdir("Bot/$un/botsdatas/source");
mkdir("Bot/$un/botsdatas/source/botadd");
mkdir("Bot/$un/botsdatas/source/botanti");
mkdir("Bot/$un/botsdatas/source/botchat");
mkdir("Bot/$un/botsdatas/source/botchat2");
mkdir("Bot/$un/botsdatas/source/botpv");
mkdir("Bot/$un/botsdatas/source/botpv2");
mkdir("Bot/$un/botsdatas/source/botfamily");
mkdir("Bot/$un/botsdatas/source/bothads");
mkdir("Bot/$un/botsdatas/source/botview");
mkdir("Bot/$un/botsdatas/source/botzed");
mkdir("Bot/$un/botsdatas/source/botmember");
mkdir("Bot/$un/botsdatas/source/botwar");
mkdir("Bot/$un/botsdatas/source/botsharj");
mkdir("Bot/$un/botsdatas/source/bottab");
mkdir("Bot/$un/botsdatas/access");
mkdir("Bot/$un/botsdatas/source/botfamily/kalamat");
mkdir("Bot/$un/botsdatas/user");
mkdir("Bot/$un/botsdatas/banall-member");
save("Bot/$un/botsdatas/coin.txt","0");

$class23 = file_get_contents("botsdatas/source/daie/jdf.php");
save("Bot/$un/jdf.php",$class23);

$index = file_get_contents("botsdatas/source/daie/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
save("Bot/$un/index.php",$index);
$index1 = file_get_contents("botsdatas/source/daie/botsdatas/access/Class.php");
  $index1 = str_replace("[*[TOKEN]*]",$token,$index1);
  $index1 = str_replace("[*[ADMIN]*]",$id,$index1);
  $index1 = str_replace("[*[CHANNEL]*]",$channel,$index1);
  $index1 = str_replace("[*[BOT]*]",$un,$index1);
 save("Bot/$un/botsdatas/access/Class.php",$index1);
   $index = file_get_contents("botsdatas/source/daie/botsdatas/source/botadd/index.php");
  save("Bot/$un/botsdatas/source/botadd/index.php",$index);	
  $butt = file_get_contents("botsdatas/source/daie/botsdatas/source/botsdatas/source/botanti/add.php");
  save("Bot/$un/botsdatas/source/botanti/add.php",$butt);	
   $butt2 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/base.php");
  save("Bot/$un/botsdatas/source/botanti/base.php",$butt2);	
    $butt3 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/bot.php");
  save("Bot/$un/botsdatas/source/botanti/bot.php",$butt3);	
    $butt4 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/filter.php");
  save("Bot/$un/botsdatas/source/botanti/filter.php",$butt4);	
    $butt5 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/fun.php");
  save("Bot/$un/botsdatas/source/botanti/fun.php",$butt5);	
    $butt6 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/funplus.php");
  save("Bot/$un/botsdatas/source/botanti/funplus.php",$butt6);	
    $butt7 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/help.php");
  save("Bot/$un/botsdatas/source/botanti/help.php",$butt7);	
    $butt8 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/lock.php");
  save("Bot/$un/botsdatas/source/botanti/lock.php",$butt8);	
    $butt9 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/settings.php");
  save("Bot/$un/botsdatas/source/botanti/settings.php",$butt9);	
    $butt10 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/pv.php");
  save("Bot/$un/botsdatas/source/botanti/pv.php",$butt10);	
    $butt11 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/panel.php");
  save("Bot/$un/botsdatas/source/botanti/panel.php",$butt11);	
        $butt1300 = file_get_contents("botsdatas/source/daie/botsdatas/source/bottab/index.php");
  save("Bot/$un/botsdatas/source/bottab/index.php",$butt1300);	
    $butt12 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/lockplus.php");
  save("Bot/$un/botsdatas/source/botanti/lockplus.php",$butt12);	
    $butt13 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/lockchannel.php");
  save("Bot/$un/botsdatas/source/botanti/lockchannel.php",$butt13);	
      $butt14 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/tools.php");
  save("Bot/$un/botsdatas/source/botanti/tools.php",$butt14);	
    $butt15 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/toolsplus.php");
  save("Bot/$un/botsdatas/source/botanti/toolsplus.php",$butt15);	
    $butt16 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/msgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/msgcheck.php",$butt16);	
    $butt17 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/sharge.php");
  save("Bot/$un/botsdatas/source/botanti/sharge.php",$butt17);	
  
  $butt18 = file_get_contents("botsdatas/source/daie/botsdatas/source/botsdatas/source/botanti/plus.php");
  save("Bot/$un/botsdatas/source/botanti/plus.php",$butt18);	
   $butt19 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/upmsgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/upmsgcheck.php",$butt19);	
    $butt20 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/plusupmsgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/plusupmsgcheck.php",$butt20);	
    $butt21 = file_get_contents("botsdatas/source/daie/botsdatas/source/botanti/plusmsgcheck.php");
  save("Bot/$un/botsdatas/source/botanti/plusmsgcheck.php",$butt21);	
    $butt22 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/Class.php");
  save("Bot/$un/botsdatas/source/botchat/Class.php",$butt22);	
    $butt23 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/config.php");
  save("Bot/$un/botsdatas/source/botchat/config.php",$butt23);	
    $butt24 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/index.php");
  save("Bot/$un/botsdatas/source/botchat/index.php",$butt24);	
    $butt25 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/sendall.php");
  save("Bot/$un/botsdatas/source/botchat/sendall.php",$butt25);	
    $butt26 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat/sendtab.php");
  save("Bot/$un/botsdatas/source/botchat/sendtab.php",$butt26);	
      $butt221 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/Class.php");
  save("Bot/$un/botsdatas/source/botchat2/Class.php",$butt221);	
    $butt232 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/config.php");
  save("Bot/$un/botsdatas/source/botchat2/config.php",$butt232);	
    $butt243 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/index.php");
  save("Bot/$un/botsdatas/source/botchat2/index.php",$butt243);	
    $butt254 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/sendall.php");
  save("Bot/$un/botsdatas/source/botchat2/sendall.php",$butt254);	
    $butt265 = file_get_contents("botsdatas/source/daie/botsdatas/source/botchat2/sendtab.php");
  save("Bot/$un/botsdatas/source/botchat2/sendtab.php",$butt265);	
    $butt27 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/index.php");
  save("Bot/$un/botsdatas/source/botfamily/index.php",$butt27);	
    $butt28 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/api-rand.php");
  save("Bot/$un/botsdatas/source/botfamily/api-rand.php",$butt28);	

    $butt29 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/ashya.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/ashya.txt",$butt29);	
    $butt30 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/esm.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/esm.txt",$butt30);	
      $butt31 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/famil.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/famil.txt",$butt31);	
    $butt32 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/ghaza.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/ghaza.txt",$butt32);	
    $butt33 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/heyvan.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/heyvan.txt",$butt33);	
    $butt34 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/keshvar.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/keshvar.txt",$butt34);	
      $butt295 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/mive.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/mive.txt",$butt295);	
    $butt306 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/rang.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/rang.txt",$butt306);	
      $butt317 = file_get_contents("botsdatas/source/daie/botsdatas/source/botfamily/kalamat/shahr.txt");
  save("Bot/$un/botsdatas/source/botfamily/kalamat/shahr.txt",$butt317);	
    $butt328 = file_get_contents("botsdatas/source/daie/botsdatas/source/bothads/index.php");
  save("Bot/$un/botsdatas/source/bothads/index.php",$butt328);	
    $butt339 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/bot.php");
  save("Bot/$un/botsdatas/source/botmember/bot.php",$butt339);	
    $butt3410 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/jdf.php");
  save("Bot/$un/botsdatas/source/botmember/jdf.php",$butt3410);	
  
      $butt32814 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv/Button.php");
  save("Bot/$un/botsdatas/source/botpv/Button.php",$butt32814);	
    $butt33915 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv/Class.php");
  save("Bot/$un/botsdatas/source/botpv/Class.php",$butt33915);	
    $butt341016 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv/index.php");
  save("Bot/$un/botsdatas/source/botpv/index.php",$butt341016);	
      $butt32817 = file_get_contents("botsdatas/source/daie/botsdatas/source/botpv2/index.php");
  save("Bot/$un/botsdatas/source/botpv2/index.php",$butt32817);	
    $butt33918 = file_get_contents("botsdatas/source/daie/botsdatas/source/botsharj/index.php");
  save("Bot/$un/botsdatas/source/botsharj/index.php",$butt33918);	
    $butt341019 = file_get_contents("botsdatas/source/daie/botsdatas/source/botview/jdf.php");
  save("Bot/$un/botsdatas/source/botview/jdf.php",$butt341019);	
      $butt32820 = file_get_contents("botsdatas/source/daie/botsdatas/source/botview/index.php");
  save("Bot/$un/botsdatas/source/botview/index.php",$butt32820);	
    $butt33921 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/index.php");
  save("Bot/$un/botsdatas/source/botwar/index.php",$butt33921);	
    $butt341022 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/telegram.php");
  save("Bot/$un/botsdatas/source/botwar/telegram.php",$butt341022);	
      $butt32823 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/lvp.php");
  save("Bot/$un/botsdatas/source/bothads/lvp.php",$butt32823);
  mkdir("Bot/$un/botsdatas/source/botwar/config");
  
    $butt33924 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/config/pricetroop.php");
  save("Bot/$un/botsdatas/source/botwar/config/pricetroop.php",$butt33924);	
    $butt341025 = file_get_contents("botsdatas/source/daie/botsdatas/source/botwar/config/pricetale.php");
  save("Bot/$un/botsdatas/source/botwar/config/pricetale.php",$butt341025);	
      $butt32826 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/index.php");
  save("Bot/$un/botsdatas/source/botzed/index.php",$butt32826);	
    $butt33927 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/arabi.php");
  save("Bot/$un/botsdatas/source/botzed/arabi.php",$butt33927);	
    $butt341028 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/english.php");
  save("Bot/$un/botsdatas/source/botzed/english.php",$butt341028);	
      $butt32829 = file_get_contents("botsdatas/source/daie/botsdatas/source/botzed/persian.php");
  save("Bot/$un/botsdatas/source/botzed/persian.php",$butt32829);	
    $butt33930 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/bot.php");
  save("Bot/$un/botsdatas/source/botmember/bot.php",$butt33930);	
    $butt341031 = file_get_contents("botsdatas/source/daie/botsdatas/source/botmember/jdf.php");
  save("Bot/$un/botsdatas/source/botmember/jdf.php",$butt341031);	
  
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bot/$un/index.php");
	}}
	
	   		if($type == "BotSazcreategnew"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazcreategnew/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazhajinew/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazhajinew/$un/index.php");
	}}
	
	   		if($type == "BotSazhajinew"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazhajinew/$un/index.php"))){
mkdir("Bots/BotSazhajinew/$un");
mkdir("Bots/BotSazhajinew/$un/data");
$index = file_get_contents("BotsSource/BotSazhajinew/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazhajinew/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazhajinew/$un/index.php");
	}}
  
    		if($type == "BotSaztaj"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSaztaj/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
		     		if($type == "BotSazcreategram62"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazcreategram62/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
	     		if($type == "BotSazcreategram6"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazcreategram6/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
     		if($type == "BotSazcreategram41"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/BotSazcreategram41/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
	
  		if($type == "BotSazpro"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazNovin/$un/index.php"))){
mkdir("Bots/BotSazNovin/$un");
mkdir("Bots/BotSazNovin/$un/data");
$index = file_get_contents("BotsSource/Botsaz/index.php");
  $index = str_replace("[*[TOKEN]*]",$token,$index);
  $index = str_replace("[*[ADMIN]*]",$id,$index);
  $index = str_replace("[*[CHANNEL]*]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/BotSazNovin/$un/index.php",$index);	
    file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazNovin/$un/index.php");
	}}
  
   if($type == "pyemresan1"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotGrams/$un/pyemresan1.php"))){
  mkdir("Bots/BotGrams/$un");
  mkdir("Bots/BotGrams/$un/data");
  if($account == "vip"){
	  save("Bots/BotGrams/$un/data/bottype.txt","gold");
  }
    $index = file_get_contents("CreateGramRobot/pyemresan1/pyemresan1.php");
	$index = str_replace("[*[TOKEN]*]",$token,$index);
	  $index = str_replace("[*[ADMIN]*]",$id,$index);
  save("Bots/BotGrams/$un/pyemresan1.php",$index);
  $adstext = file_get_contents("$ads");
  save("Bots/BotGrams/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/BotGrams/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotGrams/$un/pyemresan1.php");
}}
  
     if($type == "pyemresan2"){
	 $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/Bot/$un/index.php"))){
  mkdir("Bots/Bot/$un");
  mkdir("Bots/Bot/$un/other");
  mkdir("Bots/Bot/$un/data");
  mkdir("Bots/Bot/$un/other/$id");
  mkdir("Bots/Bot/$un/other/access");
  mkdir("Bots/Bot/$un/other/button");
  mkdir("Bots/Bot/$un/other/profile");
  mkdir("Bots/Bot/$un/other/setting");
  mkdir("Bots/Bot/$un/other/wordlist");
  mkdir("Bots/Bot/$un/other/button/caption");
  mkdir("Bots/Bot/$un/other/button/file");
  mkdir("Bots/Bot/$un/other/button/forward");
  mkdir("Bots/Bot/$un/other/button/music");
  mkdir("Bots/Bot/$un/other/button/photo");
  mkdir("Bots/Bot/$un/other/button/feed");
  mkdir("Bots/Bot/$un/other/button/sticker");
  mkdir("Bots/Bot/$un/other/button/text");
  mkdir("Bots/Bot/$un/other/button/video");
  mkdir("Bots/Bot/$un/other/button/voice");
	  save("Bots/Bot/$un/data/bottype.txt","gold");
  }
$class = file_get_contents("BotsSource/BotsSource/payamresan/Class.php");
  $class = str_replace("[*[TOKEN]*]",$token,$class);
  $class = str_replace("[*[ADMIN]*]",$id,$class);
  save("Bots/Bot/$un/Class.php",$class);
  $index = file_get_contents("BotsSource/BotsSource/payamresan/index.php");
  save("Bots/Bot/$un/index.php",$index);  
  $butt = file_get_contents("BotsSource/BotsSource/payamresan/Button.php");
  save("Bots/Bot/$un/other/Button.php",$butt);  
  $adstext = file_get_contents("$ads");
  save("Bots/Bot/$un/data/adstext.txt",$adstext);
  $creator_cmd = file_get_contents("$creator_cmd");
  save("Bots/Bot/$un/data/creator-cmd.txt",$creator_cmd);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/Bot/$un/index.php");
}}

 ?>

