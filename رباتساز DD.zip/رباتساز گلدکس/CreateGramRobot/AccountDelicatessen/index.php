<?php
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
define('API_KEY','[*[TOKEN]*]');
$API_KEY = '[*[TOKEN]*]'; //توکن ربات بدون @ بزارید
$channel = '[*[CHANNEL]*]'; // ایدی کانال قفل بدون @ بزارید
define('API_TELEGRAM','https://api.telegram.org/bot'.API_KEY.'/');
//----######------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//##############=--API_REQ
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}


function SendMessage($chat_id, $text , $reply_id){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$text,
        'reply_to_message_id'=>$message_id,
        'parse_mode'=>"MarkDown"
    ]);
}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
	function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
  bot('editMessagetext',[
    'chat_id'=>$chat_id,
 'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
 'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
 ]);
 }
 function sendAction($chat_id, $action){
bot('sendChataction',[
'chat_id'=>$chat_id,
'action'=>$action]);
}
function objectToArrays($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        if (is_object($object)) {
            $object = get_object_vars($object);
        }
        return array_map("objectToArrays", $object);
    }
    	function sendphoto($ChatId, $photo_id,$caption){
    bot('sendphoto',[
        'chat_id'=>$ChatId,
        'photo'=>$photo_id,
        'caption'=>$caption
    ]);
}
function sendvideo($chat_id,$video_id,$caption){
    bot('sendvideo',[
        'chat_id'=>$ChatId,
        'video'=>$video_id,
        'caption'=>$caption
    ]);
}
function sendaudio($chat_id,$audio_id,$caption){
    bot('sendaudio',[
        'chat_id'=>$ChatId,
        'audio'=>$audio_id,
        'caption'=>$caption
    ]);
}
function sendvoice($chat_id,$voice_id,$caption){
    bot('sendvoice',[
        'chat_id'=>$ChatId,
        'voice'=>$audio_id,
        'caption'=>$caption
    ]);
}
function senddocument($chat_id,$document_id,$caption){
    bot('senddocument',[
        'chat_id'=>$ChatId,
        'document'=>$document_id,
        'caption'=>$caption
    ]);
}
function sendsticker($chat_id,$sticker_id,$caption){
    bot('sendsticker',[
        'chat_id'=>$ChatId,
        'sticker'=>$sticker_id,
        'caption'=>$caption
    ]);
}
function ForwardMessage($chatid,$from_chat,$message_id){
	bot('ForwardMessage',[
	'chat_id'=>$chatid,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
	}
	//====================================//
	$update = json_decode(file_get_contents('php://input'));
	var_dump($update);
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$text = $update->message->text;
$message_id = $update->message->message_id;
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot$API_KEY/getChatMember?chat_id=@$channel&user_id=".$from_id));
$tch = $truechannel->result->status;
@mkdir("user");
@mkdir("user/$from_id");
$amirm = file_get_contents("user/$chat_id/amirm.txt");
$number = file_get_contents("user/$chat_id/number.txt");
$hash = file_get_contents("user/$chat_id/hash.txt");
$code = file_get_contents("user/$chat_id/code.txt");

if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
▫️شما در کانال اسپانسر عضو نیستید ⚜️
◼️عضو شوید و سپس /start را بفرستید",
            'parse_mode' => "html",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "@$channel", 'url' => "https://telegram.me/$channel"]
                    ],
                    
                ]
            ])
        ]);
	}
	
	if(preg_match('/^\/([Ss]tart)/',$text)){
		file_put_contents("user/$chat_id/amirm.txt","name");
        bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
'text'=>"سلام دوست عزیز به ربات دلیت اکانت خوش اومدی🌹
این ربات به شما کمک می کند تا سریعتر دلیت اکانت کنبد❌
برای شروع به روی > حذف اکانت خودم<🛡 بزنید
",
'reply_markup'=>json_encode([
      'keyboard'=>[
[['text'=>'❌حذف اکانت خودم']],
      ],'resize_keyboard'=>true])
  ]);
	}
	
	elseif($text == "منوی اصلی*️⃣"){
unlink("user/$from_id/amirm.txt");
unlink("user/$from_id/code.txt");
unlink("user/$from_id/number.txt");
unlink("user/$from_id/hash.txt");
bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"شما به منوی اصلی ربات بازگشتید↪️
چه دستوری میفرمایید❗️",
'reply_markup'=>json_encode([
      'keyboard'=>[
[['text'=>'❌حذف اکانت خودم']],
      ],'resize_keyboard'=>true])
  ]);
}
	
  elseif($text == "❌حذف اکانت خودم"){
  file_put_contents("user/$chat_id/amirm.txt","dell1");
      if(preg_match('([+]|[0]|[1]|[2]|[3]|[4]|[5]|[6]|[7]|[8]|[9])',$text)){
	  bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"شماره شما اشتباه هست 😬
شماره شما باید مثل مثال زیر باشد👇🏻
`+9809130651847`",
  ]); 
}else{
	  bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"شماره خود را وارد کنید مثلا👇🏻
 `+9809130651847`",
  ]);
} 
}

elseif($amirm == "dell1"){
	  file_put_contents("user/$chat_id/number.txt",$text);
	    $url2 = "http://irosou.nightmizban.ga/tg/deleteacc?phone=$text";
   $jsurl=json_decode(file_get_contents($url2),true);
   $jdel=$jsurl['result']['access_hash']; 
   $jer=$jsurl['description']; 
   file_put_contents("user/$chat_id/hash.txt",$jdel);
   if($jer == "too Many Request, Please Try Later !!"){
   file_put_contents("user/$chat_id/amirm.txt","none");
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما بیش از اندازه تلاش کردید‼️
این اخطار از سوی تلگرام میباشد❕
💠تیم برنامه نویسی  [$channel](telegram.me/$channel)",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'منوی اصلی*️⃣']],
      ],'resize_keyboard'=>False])
 ]);
   }else{
   	  file_put_contents("user/$chat_id/amirm.txt","dell111");
	  bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"کد 8 رقمی که تلگرام برای شما فرستاد را بفرستید⚙️",
  ]);
}
}
   
elseif($amirm == "dell111"){
	  file_put_contents("user/$chat_id/code.txt",$text);
	  $url2 = "http://irosou.nightmizban.ga/tg/deleteacc?phone=$number&access_hash=$hash&password=$text";
   $jsurl=json_decode(file_get_contents($url2),true);
   $jdelsa=$jsurl['description']; 
   if($jdelsa == "Access Hash / Password Not True !!"){
   file_put_contents("user/$chat_id/amirm.txt","none");
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
کد ارسال شده اشتباه هست❌",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'منوی اصلی*️⃣']],
      ],'resize_keyboard'=>False])
 ]);
   }else{
   file_put_contents("user/$chat_id/amirm.txt","dell1111111");
	  bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"خب  توجه کنید دکمه >تایید > از بین میرود اکانت شما پس شوخی نیست ❌
اگر شما واقعا میخواهید اکانت خود را حذف کنتید بروی تایید کلیک نمایید✳️
اگر میخواید لغو شود بروی >شوخی کردم > کلیک نمایید
 $jdels",
 'reply_markup'=>json_encode([
      'keyboard'=>[
              [
              ['text'=>"تایید می کنم✅"],['text'=>"شوخی کردم❌"]
              ],
            ],
            'resize_keyboard'=>true
        ])
  ]);
}
}

elseif($text == "تایید می کنم✅" && $amirm == "dell1111111"){
  $url2 = "http://irosou.nightmizban.ga/tg/deleteacc?phone=".$number."&access_hash=".$hash."&password=".$code."&do_delete=true";
   $jsurl=json_decode(file_get_contents($url2),true);
   $jdelss=$jsurl['description'];
	  bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"اکانت شما تا 3 ثانیه دیگر بصورت خودکار حذف میشود❌
#پس تا دورودی دیگر بدورد😂
 $jdelss",
  'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'منوی اصلی*️⃣']],
      ],'resize_keyboard'=>False])
  ]);
}

elseif($text == "شوخی کردم❌" && $amirm == "dell1111111"){
  $url2 = "http://irosou.nightmizban.ga/tg/deleteacc?phone=".$number."&access_hash=".$hash."&password=".$code."&do_delete=flase";
   $jsurl=json_decode(file_get_contents($url2),true);
   $jdelss=$jsurl['description'];
	  bot('sendMessage',[
        'parse_mode' => "MarkDown",
 'chat_id'=>$chat_id,
 'text'=>"حذف اکانت شما لغو شد⭕️
برا برگشت به منوی اصلی کلیک کنید👇🏻",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'منوی اصلی*️⃣']],
      ],'resize_keyboard'=>False])
  ]);
}



//unlink("error_log");
$user = file_get_contents('user/Member.txt');
    $members = explode("\n",$user);
    if (!in_array($chat_id,$members)){
      $add_user = file_get_contents('user/Member.txt');
      $add_user .= $chat_id."\n";
     file_put_contents('user/Member.txt',$add_user);
    }
	/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/