<?php
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
ob_start();
error_reporting(0);
define('API_KEY','[*[TOKEN]*]');

//---------------------------------/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است


function paybot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//--------------------------------@AftabDeveloper---------------------------------------------------------
//متغیر ها :
// msg
$Dev = array("[*[ADMIN]*]","",""); // put id of admins
$usernamebot = "@$un";
$channel = '[*[CHENNEL]*]';
//---------------------------------------@AftabDeveloper--------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$textmassage = $message->text;
$messageid = $update->callback_query->message->message_id;
$tc = $update->message->chat->type;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$data = $update->callback_query->data;
$membercall = $update->callback_query->id;
//================================@AftabDeveloper====================================
@$juser = json_decode(file_get_contents("data/$from_id.json"),true);
@$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
//============================@AftabDeveloper======================================
if($textmassage=="/start"){	
if(isset($juser["userfild"]["city"])){
	paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎈❤️ برای شناسایی کسانی که اصلشان [اطلاعاتشان] با شما مطابقت دارد روی دکمه جست جو ضربه بزنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"اصل های من❣️"]
                ],
								           [
                   ['text'=>"🔖 پروفایل"],['text'=>"🎗توسعه دهنده"]
                ],
									           [
                   ['text'=>"⚙️ تغییر مشخصات"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام $first_name 👋🏻

به ربات دوست یابی خوش امدید 🌹

به وسیله این ربات میتونی برای خودت دوست پیدا کنی ! و دوستی با مشخصات مورد علاقت رو پیدا کنی 😝 

🌟 جنیست خود را انتخاب کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🤴🏻 پسر",'callback_data'=>'boy'],['text'=>"👸🏻 دختر",'callback_data'=>'girl']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
	  	]);
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["userfild"]["search"]="3";
$juser["userfild"]["member"]="0";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif(strpos($textmassage , '/start ') !== false  ) {
$start = str_replace("/start ","",$textmassage);
if(file_exists("data/$from_id.json")){
	paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎈❤️ برای شناسایی کسانی که اصلشان [اطلاعاتشان] با شما مطابقت دارد روی دکمه جست جو ضربه بزنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"اصل های من❣️"]
                ],
								           [
                   ['text'=>"🔖 پروفایل"],['text'=>"🎗توسعه دهنده"]
                ],
													           [
                   ['text'=>"⚙️ تغییر مشخصات"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else 
{
$inuser = json_decode(file_get_contents("data/$start.json"),true);
$member = $inuser["userfild"]["member"];
$search = $inuser["userfild"]["search"];
$plusmember = $member + 1;
$plussearch = $search + 3;
paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام $first_name 👋🏻

به ربات دوست یابی خوش امدید 🌹

به وسیله این ربات میتونی برای خودت دوست پیدا کنی ! و دوستی با مشخصات مورد علاقت رو پیدا کنی 😝 

🌟 جنیست خود را انتخاب کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🤴🏻 پسر",'callback_data'=>'boy'],['text'=>"👸🏻 دختر",'callback_data'=>'girl']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
	  	]);
paybot('sendmessage',[
	'chat_id'=>$start,
	'text'=>"🌟 کاربر [$first_name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده
	
💎 سه فرصت جست جو و یک زیر مجموعه به زیر مجموعه های شما اضافه شد

🔍 تعداد فرصت های جست جو : $plussearch 
👥 تعداد زیر مجموعه ها : $plusmember",
			 'parse_mode'=>"MarkDown",
	  	]);
$inuser["userfild"]["member"]="$plusmember";
$inuser["userfild"]["search"]="$plussearch";
$inuser = json_encode($inuser,true);
file_put_contents("data/$start.json",$inuser);
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["userfild"]["search"]="3";
$juser["userfild"]["member"]="0";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif($textmassage=="اصل های من❣️"){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$search = $juser["userfild"]["search"];
if($search > 0){
$sex = $juser["userfild"]["sex"];
$age = $juser["userfild"]["age"];
$city = $juser["userfild"]["city"];	
$getmsg = $juser["userfild"]["msg"];	
$getsex = str_replace(["پسر","دختر"],["girl","boy"],$sex);
$allFiles = scandir("photo/$getsex/");
$files = array_diff($allFiles, array('.', '..'));
$random = array_rand($files);
$nameboy = array("محمد","مهدی","علی","احمد","محسن","حسن","@AftabDeveloper","جواد","میلاد","نیما","رامین","سهیل","احسان","ایمان","مهرداد","مهران","محمد رضا","محمد امین","محمد","مهدی","علی","فربد","فرزاد","سهیل");
$namegirl = array("ساناز","معصومه","مهناز","شهناز","زهره","روژین","شهلا","زهرا","فریبا","مریم","فریبا","سهیلا","مبینا","پریسا","فرناز","فاطمه","حدیث","پریناز","ساناز","معصومه","مهناز","مرضیه","نازنین","نگار","شیرین","شهره","تانیا","اتنا","لیلا","لاله");
$getname = str_replace(["boy","girl"],["nameboy","namegirl"],$getsex);
$nameget = $$getname;
$rand = $age - rand(0,2);
$id = paybot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>new CURLFile("photo/$getsex/$files[$random]"),
	'caption'=>"🔸 اسم : $nameget[$random] 
🔸 سن : $rand
🔸 استان : $city

🎈 وضعیت : انلاین",
	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"❤️ ارسال درخواست دوستی",'callback_data'=>'req']
   ],
         [
   ['text'=>"💬 درخواست چت",'callback_data'=>'chat']
   ],
         [
   ['text'=>"▶️ نفر بعدی",'callback_data'=>'next']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
    		]);
   paybot('deletemessage',[
                'chat_id'=>$chat_id,
            'message_id'=>$getmsg
            ]);
$msg = $id->result->message_id;
$plussearch = $search - 1 ;
$juser["userfild"]["search"]="$plussearch";
$juser["userfild"]["msg"]="$msg";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔆 دوست عزیز 
💎 تعداد فرصت های استفاده از جست جو شما به پایان رسیده است

🌟 با دعوت هر نفر سه فرصت جست جو دریافت کنید و زمانی که تعداد زیر مجموعه های شما 5 نفر شد میتوانید ارسال درخواست دوستی کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🔗 لینک من",'callback_data'=>'link']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
	  	]);
}
}
else
{
			paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🍃  برای استفاده از این ربات لازم است ابتدا وارد کانال زیر شوید 

@$channel 📣 @$channel  📣
@$channel 📣 @$channel  📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"💎 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
    		]);
}
}
elseif($textmassage=="🔖 پروفایل"){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$getuserprofile = paybot('getUserProfilePhotos',['user_id'=>"$from_id"]);
$result = $getuserprofile->result;
$getuserphoto = $result->photos[0][0]->file_id;
$sex = $juser["userfild"]["sex"];
$age = $juser["userfild"]["age"];
$city = $juser["userfild"]["city"];
if(isset($getuserphoto)){
paybot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"$getuserphoto",
	'caption'=>"🗣نام : $first_name
👽جنیست : $sex
🤠سن : $age
⛪️استان : $city",
    		]);
}
else
{
paybot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"http://uupload.ir/files/qyml_nophoto.png",
	'caption'=>"🗣نام : $first_name
👽جنیست : $sex
🤠سن : $age
⛪️استان : $city
$getuserphoto",
    		]);
}
}
else
{
			paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🍃  برای استفاده از این ربات لازم است ابتدا وارد کانال زیر شوید 

@$channel 📣 @$channel  📣
@$channel 📣 @$channel  📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"💎 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
    		]);
}
}
elseif($textmassage=="🎗توسعه دهنده"){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
			paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"‼️ربات اصل بده توسط تیم 
@$channel
ساخته شده 🤠♥️",
    		]);
}
else
{
			paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🍃  برای استفاده از این ربات لازم است ابتدا وارد کانال زیر شوید 

@$channel 📣 @$channel  📣
@$channel 📣 @$channel  📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"💎 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
    		]);
}
}
elseif($textmassage=="❌ بستن چت"){
	paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎈❤️ برای شناسایی کسانی که اصلشان [اطلاعاتشان] با شما مطابقت دارد روی دکمه جست جو ضربه بزنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"اصل های من❣️"]
                ],
								           [
                   ['text'=>"🔖 پروفایل"],['text'=>"🎗توسعه دهنده"]
                ],
													           [
                   ['text'=>"⚙️ تغییر مشخصات"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["step"]="none";
$juser["userfild"]["chat"]="true";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
elseif($textmassage=="⚙️ تغییر مشخصات"){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 جنیست خود را انتخاب کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🤴🏻 پسر",'callback_data'=>'boy'],['text'=>"👸🏻 دختر",'callback_data'=>'girl']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
	  	]);
}
else
{
			paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🍃  برای استفاده از این ربات لازم است ابتدا وارد کانال زیر شوید 

@$channel 📣 @$channel  📣
@$channel 📣 @$channel  📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"💎 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
    		]);
}
}
elseif($data=="req"){
$member = $cuser["userfild"]["member"];
if($member >= 5){
	paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🎈 درخواست دوستی شما با موفقیت ارسال شد ",
	  	]);
			   paybot('deletemessage',[
                'chat_id'=>$chatid,
            'message_id'=>$messageid
            ]);
}
else
{
paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🔆 دوست عزیز ،
💎 برای استفاده از این قابلیت ، باید اکانت خودت رو به ویژه تبدیل کنی.

❄️ با دعوت هر نفر سه فرصت جست جو دریافت کنید و زمانی که تعداد زیر مجموعه های شما 5 نفر شد میتوانید ارسال درخواست دوستی کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🔗 لینک من",'callback_data'=>'link']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
	  	]);
}
}
elseif($data=="chat"){
$chat = $cuser["userfild"]["chat"];
if($chat != true){
paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"⏳ در حال برقرار ارتباط ...",
	'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"❌ بستن چت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
	  	]);
			paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"💬 چت اغا شد 
	
😆 به طرف مقابل سلام کن",
	  	]);
		   paybot('deletemessage',[
                'chat_id'=>$chatid,
            'message_id'=>$messageid
            ]);
$cuser["userfild"]["step"]="chat";
$cuser["userfild"]["get"]="0";
$cuser["userfild"]["chat"]="true";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
	paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"⏳ در حال برقرار ارتباط ...",
	  	]);
					paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"💎 ارتباط توسط طرف مقابل رد شد",
	  	]);
}
}
elseif($data=="next"){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$fromid"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$search = $cuser["userfild"]["search"];
if($search > 0){
$sex = $cuser["userfild"]["sex"];
$age = $cuser["userfild"]["age"];
$city = $cuser["userfild"]["city"];	
$getmsg = $cuser["userfild"]["msg"];	
$getsex = str_replace(["پسر","دختر"],["girl","boy"],$sex);
$allFiles = scandir("photo/$getsex/");
$files = array_diff($allFiles, array('.', '..'));
$random = array_rand($files);
$nameboy = array("محمد","مهدی","علی","احمد","محسن","حسن","@AftabDeveloper","جواد","میلاد","نیما","رامین","سهیل","احسان","ایمان","مهرداد","مهران","محمد رضا","محمد امین","محمد","مهدی","علی","فربد","فرزاد","سهیل");
$namegirl = array("ساناز","معصومه","مهناز","شهناز","زهره","روژین","شهلا","زهرا","فریبا","مریم","فریبا","سهیلا","مبینا","پریسا","فرناز","فاطمه","حدیث","پریناز","ساناز","معصومه","مهناز","مرضیه","نازنین","نگار","شیرین","شهره","تانیا","اتنا","لیلا","لاله");
$getname = str_replace(["boy","girl"],["nameboy","namegirl"],$getsex);
$nameget = $$getname;
$rand = $age - rand(0,2);
$id = paybot('sendphoto',[
	'chat_id'=>$chatid,
	'photo'=>new CURLFile("photo/$getsex/$files[$random]"),
	'caption'=>"🔸 اسم : $nameget[$random] 
🔸 سن : $rand
🔸 استان : $city

🎈 وضعیت : انلاین",
	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"❤️ ارسال درخواست دوستی",'callback_data'=>'req']
   ],
         [
   ['text'=>"💬 درخواست چت",'callback_data'=>'chat']
   ],
         [
   ['text'=>"▶️ نفر بعدی",'callback_data'=>'next']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
    		]);
   paybot('deletemessage',[
                'chat_id'=>$chatid,
            'message_id'=>$getmsg
            ]);
$msg = $id->result->message_id;
$plussearch = $search - 1 ;
$cuser["userfild"]["search"]="$plussearch";
$cuser["userfild"]["msg"]="$msg";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🔆 دوست عزیز 
💎 تعداد فرصت های استفاده از جست جو شما به پایان رسیده است

🌟 با دعوت هر نفر سه فرصت جست جو دریافت کنید و زمانی که تعداد زیر مجموعه های شما 5 نفر شد میتوانید ارسال درخواست دوستی کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🔗 لینک من",'callback_data'=>'link']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
	  	]);
}
}
else
{
			paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🍃  برای استفاده از این ربات لازم است ابتدا وارد کانال زیر شوید 

@$channel @$channel  📣
@$channel @$channel  📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"💎 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
    		]);
}
}
elseif($data=="link"){
$member = $cuser["userfild"]["member"];
$search = $cuser["userfild"]["search"];
paybot('sendphoto',[
	'chat_id'=>$chatid,
	'photo'=>"http://s8.picofile.com/file/8323355126/ax_asheghane_fantezi_10_1.jpg",
	'caption'=>"در عرض چند ثانیه دوست خودتون رو پیدا کنید 😍

تو این ربات عضو شو و ببین چه کسایی دنبال دوستی با شخصی مثل شما هستن 😉

سریع عضو شو و فرد مورد علاقت رو پیدا کن ❤️
t.me/$usernamebot?start=$fromid",
    		]);
	paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🎈 پیام بالا حاوی لینک دعوت شما به ربات است 
	
🌟 با دعوت هر نفر سه فرصت جست جو دریافت کنید و زمانی که تعداد زیر مجموعه های شما 5 نفر شد میتوانید ارسال درخواست دوستی کنید

🔍 تعداد فرصت های جست جو : $search 
👥 تعداد زیر مجموعه ها : $member",
	  	]);
}
elseif($data=="boy" or $data=="girl"){
$getsexs = str_replace(["boy","girl"],["پسر","دختر"],$data);
paybot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"جنیست شما $get ثبت شد ✅
	
🎈 سن خود را به عدد وارد کنید 
💎 توجه داشته باشید حتما باید عددی بین 12 تا 70 باشد و به لاتین وارد شود",
	]);
$cuser["userfild"]["step"]="getage";
$cuser["userfild"]["sex"]="$getsexs";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
elseif($data=="joinfirst"){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$fromid"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){	
$age = $cuser["userfild"]["age"];
if($age >= 12 && $age <= 70){	
paybot('deletemessage',[
    'chat_id'=>$chatid,
    'message_id'=>$messageid
    ]);
paybot('sendmessage',[
                'chat_id'=>$chatid,
        "text"=>"سن شما با موفقیت $age سال ثبت شد ✅
		
💎 استان خود را انتخاب کنید",
	   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [
   ['text'=>"آذربایجان شرقی",'callback_data'=>'آذربایجان شرقی'],['text'=>"اردبیل",'callback_data'=>'اردبیل'],['text'=>"اصفهان",'callback_data'=>'اصفهان']
   ],
      [
   ['text'=>"آذربایجان غربی",'callback_data'=>'آذربایجان غربی'],['text'=>"البرز",'callback_data'=>'البرز'],['text'=>"بوشهر",'callback_data'=>'بوشهر']
   ],
      [
   ['text'=>"چهارمحال و بختیاری",'callback_data'=>'چهارمحال و بختیاری'],['text'=>"تهران",'callback_data'=>'تهران'],['text'=>"ایلام",'callback_data'=>'ایلام']
   ],
      [
   ['text'=>"خراسان جنوبی",'callback_data'=>'خراسان جنوبی'],['text'=>"خوزستان",'callback_data'=>'خوزستان'],['text'=>"زنجان",'callback_data'=>'زنجان']
   ],
      [
   ['text'=>"خراسان شمالی",'callback_data'=>'خراسان شمالی'],['text'=>"سمنان",'callback_data'=>'سمنان'],['text'=>"فارس",'callback_data'=>'فارس']
   ],
      [
   ['text'=>"خراسان رضوی",'callback_data'=>'خراسان رضوی'],['text'=>"قزوین",'callback_data'=>'قزوین'],['text'=>"قم",'callback_data'=>'قم']
   ],
      [
   ['text'=>"سیستان و بلوچستان",'callback_data'=>'سیستان و بلوچستان'],['text'=>"کردستان",'callback_data'=>'کردستان'],['text'=>"کرمان",'callback_data'=>'کرمان']
   ],
      [
   ['text'=>"کهگیلویه و بویراحمد",'callback_data'=>'کهگیلویه و بویراحمد'],['text'=>"کرمانشاه",'callback_data'=>'کرمانشاه'],['text'=>"گیلان",'callback_data'=>'گیلان']
   ],
         [
   ['text'=>"گلستان",'callback_data'=>'گلستان'],['text'=>"لرستان",'callback_data'=>'لرستان'],['text'=>"مازندران",'callback_data'=>'مازندران']
   ],
      [
   ['text'=>"مرکزی",'callback_data'=>'مرکزی'],['text'=>"هرمزگان",'callback_data'=>'هرمزگان'],['text'=>"همدان",'callback_data'=>'همدان'],['text'=>"یزد",'callback_data'=>'یزد']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
    		]);
$cuser["userfild"]["step"]="setcity";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
 paybot('sendmessage',[
        "chat_id"=>$chatid,
        "text"=>"💎 باید سن خود را به عدد و لاتین وارد کنید و عدد وارد شده بین 12 تا 70 باشید",
    		]);
$cuser["userfild"]["step"]="getage";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
else
{
      paybot('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "❌ هنوز داخل کانال @$channel عضو نیستید",
            'show_alert' =>true
        ]);
}
}
elseif($juser["userfild"]["step"] == "getage" ){
$forchannel = paybot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"]);
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
if($textmassage >= 12 && $textmassage <= 70){	
paybot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"سن شما با موفقیت $textmassage سال ثبت شد ✅
		
💎 استان خود را انتخاب کنید",
	   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [
   ['text'=>"آذربایجان شرقی",'callback_data'=>'آذربایجان شرقی'],['text'=>"اردبیل",'callback_data'=>'اردبیل'],['text'=>"اصفهان",'callback_data'=>'اصفهان']
   ],
      [
   ['text'=>"آذربایجان غربی",'callback_data'=>'آذربایجان غربی'],['text'=>"البرز",'callback_data'=>'البرز'],['text'=>"بوشهر",'callback_data'=>'بوشهر']
   ],
      [
   ['text'=>"چهارمحال و بختیاری",'callback_data'=>'چهارمحال و بختیاری'],['text'=>"تهران",'callback_data'=>'تهران'],['text'=>"ایلام",'callback_data'=>'ایلام']
   ],
      [
   ['text'=>"خراسان جنوبی",'callback_data'=>'خراسان جنوبی'],['text'=>"خوزستان",'callback_data'=>'خوزستان'],['text'=>"زنجان",'callback_data'=>'زنجان']
   ],
      [
   ['text'=>"خراسان شمالی",'callback_data'=>'خراسان شمالی'],['text'=>"سمنان",'callback_data'=>'سمنان'],['text'=>"فارس",'callback_data'=>'فارس']
   ],
      [
   ['text'=>"خراسان رضوی",'callback_data'=>'خراسان رضوی'],['text'=>"قزوین",'callback_data'=>'قزوین'],['text'=>"قم",'callback_data'=>'قم']
   ],
      [
   ['text'=>"سیستان و بلوچستان",'callback_data'=>'سیستان و بلوچستان'],['text'=>"کردستان",'callback_data'=>'کردستان'],['text'=>"کرمان",'callback_data'=>'کرمان']
   ],
      [
   ['text'=>"کهگیلویه و بویراحمد",'callback_data'=>'کهگیلویه و بویراحمد'],['text'=>"کرمانشاه",'callback_data'=>'کرمانشاه'],['text'=>"گیلان",'callback_data'=>'گیلان']
   ],
         [
   ['text'=>"گلستان",'callback_data'=>'گلستان'],['text'=>"لرستان",'callback_data'=>'لرستان'],['text'=>"مازندران",'callback_data'=>'مازندران']
   ],
      [
   ['text'=>"مرکزی",'callback_data'=>'مرکزی'],['text'=>"هرمزگان",'callback_data'=>'هرمزگان'],['text'=>"همدان",'callback_data'=>'همدان'],['text'=>"یزد",'callback_data'=>'یزد']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
    		]);
$juser["userfild"]["step"]="setcity";
$juser["userfild"]["age"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
 paybot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💎 باید سن خود را به عدد و لاتین وارد کنید و عدد وارد شده بین 12 تا 70 باشید",
    		]);
}
}
else
{
 paybot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💎 برای استفاده از ربات دوست یابی ابتدا در کانال زیر عضو شوید
		
@$channel @$channel 📣
@$channel @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"💎 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'joinfirst']
	],
              ]
        ])
    		]);
$juser["userfild"]["age"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif($cuser["userfild"]["step"] == "setcity" ){
$array = array("آذربایجان شرقی","اردبیل","اصفهان","آذربایجان غربی","البرز","بوشهر","چهارمحال و بختیاری","تهران","ایلام","خراسان جنوبی","خوزستان","زنجان","خراسان شمالی","سمنان","فارس","خراسان رضوی","قزوین","قم","سیستان و بلوچستان","کردستان","کرمان","کهگیلویه و بویراحمد","کرمانشاه","گیلان","گلستان","لرستان","مازندران","مرکزی","هرمزگان","همدان","یزد");
if(in_array($data, $array)) {
paybot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
        "text"=>"استان شما با موفقیت $data ثبت شد ✅",
    		]);
	paybot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🎈❤️ برای شناسایی کسانی که اصلشان [اطلاعاتشان] با شما مطابقت دارد روی دکمه جست جو ضربه بزنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"اصل های من❣️"]
                ],
								           [
                   ['text'=>"🔖 پروفایل"],['text'=>"🎗توسعه دهنده"]
                ],
													           [
                   ['text'=>"⚙️ تغییر مشخصات"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$cuser["userfild"]["step"]="none";
$cuser["userfild"]["city"]="$data";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($juser["userfild"]["step"] == "chat" ){
$get = $juser["userfild"]["get"];
if($get < 3){
$array = array("سلام","خوبین ؟","اهل کجایین ؟");
for($z = 0;$z <= 30;$z++){
	paybot('sendChatAction',[
	'chat_id'=>$chat_id,
	'action'=>"typing",
    		]);	
}	
	paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"$array[$get]",
    		]);
$getplus = $get + 1 ;
$juser["userfild"]["get"]="$getplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
$member = $juser["userfild"]["member"];
if($member < 5){
	paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💎 چت توسط ربات بسته شده 
	
🌟 کاربران عادی تنها میتوانید 3 پیام رد بدل کنند 
🎈 برای ویژه کردن حساب خود از دکمه زیر استفاده کنید",
			   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [
   ['text'=>"🔗 لینک من",'callback_data'=>'link']
   ],
  	],
	  	'resize_keyboard'=>true,
  	])
    		]);
$juser["userfild"]["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
	paybot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💎 چت توسط طرف مقابل بسته شد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				           [
                   ['text'=>"اصل های من❣️"]
                ],
								           [
                   ['text'=>"🔖 پروفایل"],['text'=>"🎗توسعه دهنده"]
                ],
																	           [
                   ['text'=>"⚙️ تغییر مشخصات"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
}
//==============================================================
//panel admin
elseif($textmassage=="/panel" or $textmassage=="panel" or $textmassage=="مدیریت"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
paybot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 ادمین عزیز به پنل مدریت ربات خوش امدید",
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"💎 امار ربات"],['text'=>"💎 ویژه کردن"]               
		 ],
 	[
	  	['text'=>"💎 ارسال به همه"],['text'=>"💎 فروارد همگانی"]
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
}
elseif($textmassage=="برگشت 🔙"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
paybot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 به منوی مدیریت بازگشتید",
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"💎 امار ربات"],['text'=>"💎 ویژه کردن"]               
		 ],
 	[
	  	['text'=>"💎 ارسال به همه"],['text'=>"💎 فروارد همگانی"]
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["fileget"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
}
elseif($textmassage=="💎 امار ربات"){
if (in_array($from_id,$Dev)){
$files1 = scandir("data/");
$all = count($files1);
				paybot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖 امار ربات شما : 
		
📌 تعداد عضو ها : $all",
                'hide_keyboard'=>true,
		]);
		}
}
elseif ($textmassage == '💎 ویژه کردن' ) {
if (in_array($from_id,$Dev)){
         paybot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا ایدی کاربر را ارسال کنید 🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["fileget"]="senduse";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["fileget"] == 'senduse') {
if ($textmassage != "برگشت 🔙") {
$id = $juser["userfild"]["idsend"];
$inuser = json_decode(file_get_contents("data/$textmassage.json"),true);
$coin = $inuser["userfild"]["search"];
$member = $inuser["userfild"]["member"];
$coinplus = $coin + 30;
$memberplus = $member + 5;
         paybot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"فرد با موفقیت ویژه شد ✅
			
💎 تعداد 30 فرصت نیز برای کابر ارسال شد
💎 ایدی فرد : $textmassage",
 ]);
$inuser["userfild"]["search"]="$coinplus";
$inuser["userfild"]["member"]="$memberplus";
$inuser = json_encode($inuser,true);
file_put_contents("data/$textmassage.json",$inuser);
}
}
elseif ($textmassage == '💎 ارسال به همه' ) {
if (in_array($from_id,$Dev)){
         paybot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا متن خود را ارسال کنید 🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="sendtoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["file"] == 'sendtoall') {
if ($textmassage != "برگشت 🔙") {
         paybot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام شما با موفقیت برای ارسال همگانی تنظیم شد  ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
$inuser = json_decode(file_get_contents("user.json"),true);
$inuser["text"]="$textmassage";
$inuser["sendtoall"]="true";
$inuser = json_encode($inuser,true);
file_put_contents("user.json",$inuser);	
$juser["userfild"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
}
elseif ($textmassage == '💎 فروارد همگانی' ) {
if (in_array($from_id,$Dev)){
         paybot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا متن خود را فوروارد کنید  🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="fortoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["file"] == 'fortoall') {
if ($textmassage != "برگشت 🔙") {
         paybot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
$inuser = json_decode(file_get_contents("user.json"),true);
$inuser["msg"]="$message_id";
$inuser["chat"]="$chat_id";
$inuser["fortoall"]="true";
$inuser = json_encode($inuser,true);
file_put_contents("user.json",$inuser);	
$juser["userfild"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
?>