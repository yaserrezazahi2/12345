/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/<?php
ini_set("log_errors" , "off");
set_time_limit(0);

ob_start();

$API_KEY = '[*[TOKEN]*]';
$GetINFObot = json_decode(file_get_contents("https://api.telegram.org/bot".$API_KEY."/getMe"));
$botid = $GetINFObot->result->username;
##------------------------------##
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
function sendMesViaKey($chat_id,$text,$keyborad)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'reply_markup' => $keyborad
    ]);

}

function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
    ]);
}

function deletemessage($chat_id, $message_id)
{
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function sendaction($chat_id, $action)
{
    bot('sendchataction', [
        'chat_id' => $chat_id,
        'action' => $action
    ]);
}

function Forward($KojaShe, $AzKoja, $KodomMSG)
{
    bot('ForwardMessage', [
        'chat_id' => $KojaShe,
        'from_chat_id' => $AzKoja,
        'message_id' => $KodomMSG
    ]);
}

function sendphoto($chat_id, $photo, $action)
{
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'action' => $action
    ]);
}

function GetChatMember($chatid,$userid){
    $truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=".$chatid."&user_id=".$userid));
    $tch = $truechannel->result->status;
    return $tch;
}
function ttoopp($number){ 
 $saveusers = array(); 
  $usersscan = scandir("data"); 
  unset($usersscan[0]); 
  unset($usersscan[1]); 
  foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("data/$savetojs/shoklat.txt"); 
$saveusers[$savetojs] = $savedis; 
  } 
  $rating = $saveusers; 
    arsort($rating,SORT_NUMERIC);  
    $rate = array();  
    foreach($rating as $key=>$value){  
      $rate[] = $key;  
    }  
    return $rate[$number];  
}
function top_sea($number){ 
 $saveusers = array(); 
  $usersscan = scandir("data"); 
  unset($usersscan[0]); 
  unset($usersscan[1]); 
  foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("data/$savetojs/membrs.txt"); 
$saveusers[$savetojs] = $savedis; 
  } 
  $rating = $saveusers; 
    arsort($rating,SORT_NUMERIC);  
    $rate = array();  
    foreach($rating as $key=>$value){  
      $rate[] = $key;  
    }  
    return $rate[$number];  
} 
function getrank($fadmin){  
     
  $saveusers = array(); 
  $usersscan = scandir("data"); 
  unset($usersscan[0]); 
  unset($usersscan[1]); 
  foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("data/$savetojs/shoklat.txt"); 
$saveusers[$savetojs] = $savedis; 
  } 
  $rating = $saveusers; 
  if(isset($rating[$fadmin])){  
    arsort($rating,SORT_NUMERIC);  
    $rate = array();  
    foreach($rating as $key=>$value){  
      $rate[] = $key;  
    }  
    $flipped = array_flip($rate);  
    return $flipped[$fadmin]+1;  
  }else{  
    return false;  
  }  
}
//====================WHITE ™======================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$channel_post = $update->message->channel_post;
$code = file_get_contents("data/code.txt");
$code2 = file_get_contents("data/code2.txt");
$chid = $update->channel_post->message->message_id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$name = $update->message->from->first_name;
$last = $update->message->from->last_name;
$username = $update->message->from->username;
$c_id = $message->forward_from_chat->id;
$data_id = $update->callback_query->from->id;
$data_username = $update->callback_query->from->username;
$forward_id = $update->message->forward_from->id;
$data_first = $update->callback_query->from->first_name;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$reply = $update->message->reply_to_message;
@$shoklt = file_get_contents("data/$chat_id/shoklat.txt");
@$penlist = file_get_contents("data/pen.txt");
$text = $message->text;
@mkdir("data/$chat_id");
@$saeed = file_get_contents("data/$chat_id/saeed.txt");
@$list = file_get_contents("users.txt");
$ADMIN = [*[ADMIN]*];
$hostone = file_get_contents("data/hostone.txt");
$hostfive = file_get_contents("data/hostfive.txt");
$hostten = file_get_contents("data/hostten.txt");
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id2 = $update->callback_query->message->message_id;
$fromm_id = $update->inline_query->from->id;
$fromm_user = $update->inline_query->from->username;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
//====================WHITE ™======================//
$keybord_1 = json_encode([
    'inline_keyboard' => [
        [
            ['text' => "💎 جمع آوری سکه رایگان 💎", 'callback_data' => "ba"], ['text' => "حساب کاربری  💥", 'callback_data' => "hesab"]
        ],
        [
            ['text' => "هاست اسپانسری 😚", 'callback_data' => "espan"], ['text' => "", 'url' => "http://t.me/megamizban"]
        ],
        [
            ['text' => "هاست رایگان  🛍", 'callback_data' => "tab"], ['text' => "پشتیبانی ⚙️", 'callback_data' => "se"]
        ],
        [
            ['text' => "برترین کاربران 🛎", 'callback_data' => "topse"]
        ],
    ]
]);
$keybord_2 = json_encode([
    'inline_keyboard' => [
        [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
    ]
]);
$keybord_3 = json_encode([
    'inline_keyboard' => [
        [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"],['text' => "پاسخ پشتیبانی", 'callback_data' => "pasokh"]
                ],
    ]
]);

if ($text == "/start") {
    
            $user = file_get_contents('users.txt');
            $members = explode("\n", $user);
            if (!in_array($from_id, $members)) {
            $add_user = file_get_contents('users.txt');
            $add_user .= $from_id . "\n";
            file_put_contents("data/$chat_id/membrs.txt", "0");
            file_put_contents("data/$chat_id/shoklat.txt", "1");
            file_put_contents('users.txt', $add_user);
            }
            file_put_contents("data/$chat_id/saeed.txt", "no");
            sendAction($chat_id, 'typing');
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
            bot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "با سلام  😅
به ربات هاست دهی رایگان خوش آمدی 😆
حالا یکی از ربات های رو انتخاب کن 🤒",
                'parse_mode' => "MarkDown",
                 'reply_markup' => $keybord_1
    ]);
}
	elseif (strpos($penlist, "$from_id")) {
    SendMessage($chat_id, "⛔️ کاربر عزیز شما از سرور ما بلاک شدید لطفا دیگر پیام ندید با تشکر");
} elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
    $newid = str_replace("/start ", "", $text);
    if ($from_id == $newid) {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "⁉️ چجوری خودت میخوای با لینک خودت عضو رباتت بشی انوقت سکه هم میخوای",
        ]);
    } elseif (strpos($list, "$from_id") !== false) {
        SendMessage($chat_id, "شما قبلا در این ربات عضو شدی و نمیتونی با لینک عضویت دوستت عضو ربات بشی😑");
    } else {
        sendAction($chat_id, 'typing');
        @$sho = file_get_contents("data/$newid/shoklat.txt");
        $getsho = $sho + 1;
        file_put_contents("data/$newid/shoklat.txt", $getsho);
        @$sea = file_get_contents("data/$newid/membrs.txt");
        $getsea = $sea + 1;
        file_put_contents("data/$newid/membrs.txt", $getsea);
        $user = file_get_contents('users.txt');
        $members = explode("\n", $user);
        if (!in_array($from_id, $members)) {
            $add_user = file_get_contents('users.txt');
            $add_user .= $from_id . "\n";
            file_put_contents("data/$chat_id/membrs.txt", "0");
            file_put_contents("data/$chat_id/shoklat.txt", "1");
            file_put_contents('users.txt', $add_user);
        }
        file_put_contents("data/$chat_id/saeed.txt", "No");
        sendAction($chat_id, 'typing');
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
            bot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "با سلام  😅
به ربات هاست دهی رایگان خوش آمدی 😆
حالا یکی از ربات های رو انتخاب کن 🤒",
                'parse_mode' => "MarkDown",
                 'reply_markup' => $keybord_1
    ]);
        SendMessage($newid, "🎉 تبریک یک نفر با لینک عضویت شما عوض ربات شد و شما 1  سکه به دست  آوردین ✅");

    }
}
elseif ($data == "home") {
    file_put_contents("data/$chatid/saeed.txt", "no");
    unlink("cod/$chatid.txt");
    bot('answercallbackquery', [
        'callback_query_id' => $update->callback_query->id,
        'text' => "♻️ Please wait ...",
        'show_alert' => false
    ]);
    file_put_contents("data/$chatid/saeed.txt", "no");
	sendAction($chat_id, 'typing');
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
			SendMessage($chat_id, "");
    bot('editmessagetext', [
        'chat_id' => $chatid,
        'message_id' => $message_id2,
       'text' => "با سلام  😅
به ربات هاست دهی رایگان خوش آمدی 😆
حالا یکی از ربات های رو انتخاب کن 🤒",
                'parse_mode' => "MarkDown",
        'reply_markup' => $keybord_1
    ]);


}
elseif($data == "tab"){
bot('answercallbackquery', [
        'callback_query_id' => $update->callback_query->id,
        'text' => "♻️ Please wait ...",
        'show_alert' => false
    ]);
    bot('editmessagetext', [
        'chat_id' => $chatid,
        'message_id' => $message_id2,
        'text' => "
به بخش | هاست رایگان 🛍 | خوش آمدید با سکه هایی که دارید میتونید هاست رایگان دریافت کنید 🎉
تعداد سکه برای دریافت هاست ❗️❗️

هاست یک گیگ 20 سکه لازم دارید!
هاست سه گیگ 30 سکه لازم دارید !
هاست ده گیگ 40 سکه لازم دارید!",
        'parse_mode' => "MarkDown",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
			[
                    ['text' => "هاست یک گیگ 💠", 'callback_data' => "hostone"]
                ],
                [
                    ['text' => "هاست سه گیگ 💠", 'callback_data' => "hostthree"]
                ],
				[
                    ['text' => "هاست ده گیگ 💠", 'callback_data' => "hostten"]
                ],
                [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
				 ]
        ])
    ]);
} 
elseif($data == "hostone"){
    $Coin_one = file_get_contents("data/$chatid/shoklat.txt");
    if ($Coin_one > 20){
        file_put_contents("data/$chatid/saeed.txt", "hostone");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "لطفا یک زیر دامنه را ارسال کنید برای
",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "رفتن به منوی هاست رایگان 🛍", 'callback_data' => "tab"]
                    ],
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }else{
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "موجوی شما کافی نمیباشد  ❗️❗️",
            'show_alert' => true
        ]);

    } 
	} elseif($data == "hostthree"){
    $Coin_three = file_get_contents("data/$chatid/shoklat.txt");
    if ($Coin_three > 30){
        file_put_contents("data/$chatid/saeed.txt", "hostthree");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "لطفا یک زیر دامنه را ارسال کنید برای
",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "رفتن به منوی هاست رایگان 🛍", 'callback_data' => "tab"]
                    ],
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }else{
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "موجوی شما کافی نمیباشد  ❗️❗️",
            'show_alert' => true
        ]);

    } 
	} elseif($data == "hostten"){
    $Coin_ten = file_get_contents("data/$chatid/shoklat.txt");
    if ($Coin_ten > 40){
        file_put_contents("data/$chatid/saeed.txt", "hostten");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "لطفا یک زیر دامنه را ارسال کنید برای
",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "رفتن به منوی هاست رایگان 🛍", 'callback_data' => "tab"]
                    ],
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }else{
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "موجوی شما کافی نمیباشد  ❗️❗️",
            'show_alert' => true
        ]);

    } 
	} 
	elseif($saeed == "hostone"){
    @$sho = file_get_contents("data/$chatid/shoklat.txt");
	@$hostone = file_get_contents("data/hostone.txt");
	$getsho = $sho - 10;
	@$don = file_get_contents("data/done.txt");
        $getdon = $don + 1;
        file_put_contents("data/done.txt", $getdon);
    file_put_contents("data/$chatid/shoklat.txt", $getsho);
    file_put_contents("data/$chat_id/saeed.txt","no");
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "$hostone",
        'parse_mode' => "html",
        'reply_markup' => $keybord_2
    ]);

    $tedadhost = file_get_contents("data/$chat_id/tedad-host.txt");
    if ($tedadhost == null){
        file_put_contents("data/$chat_id/tedad-host.txt","0");
    }
    file_put_contents("data/$chat_id/tedad-host.txt",$tedadhost+1);
    file_put_contents("data/$chat_id/$tedadhost.txt",$text);
    $number = file_get_contents("data/$chat_id/$tedadhost.txt");
    bot('sendMessage', [
        'chat_id' => $ADMIN,
        'text' => "ادمین عزیز  ❗️
در خواست یک هاست یک گیگ صورت گرفته 💯
دامنه که دوست عزیز سفارش داده اند ❇️
[` $number `]
اطلاعات شخص ♥️
$name 
$last
$username
$chat_id",
        'parse_mode' => "html",
		'reply_markup' => $keybord_2
    ]);





} elseif($saeed == "hostthree"){
    @$sho = file_get_contents("data/$chatid/shoklat.txt");
	@$hostfive = file_get_contents("data/hostfive.txt");
	$getsho = $sho - 15;
	@$don = file_get_contents("data/done.txt");
        $getdon = $don + 1;
        file_put_contents("data/done.txt", $getdon);
    file_put_contents("data/$chatid/shoklat.txt", $getsho);
    file_put_contents("data/$chat_id/saeed.txt","no");
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "$hostfive",
        'parse_mode' => "html",
        'reply_markup' => $keybord_2
    ]);

    $tedadhost = file_get_contents("data/$chat_id/tedad-host.txt");
    if ($tedadhost == null){
        file_put_contents("data/$chat_id/tedad-host.txt","0");
    }
    file_put_contents("data/$chat_id/tedad-host.txt",$tedadhost+1);
    file_put_contents("data/$chat_id/$tedadhost.txt",$text);
    $number = file_get_contents("data/$chat_id/$tedadhost.txt");
    bot('sendMessage', [
        'chat_id' => $ADMIN,
        'text' => "ادمین عزیز  ❗️
در خواست یک هاست سه گیگ صورت گرفته 💯
دامنه که دوست عزیز سفارش داده اند ❇️
[` $number `]
اطلاعات شخص ♥️
$name 
$last
$username
$chat_id",
        'parse_mode' => "html",
		'reply_markup' => $keybord_2
    ]);





} elseif($saeed == "hostten"){
    @$sho = file_get_contents("data/$chatid/shoklat.txt");
	@$hostten = file_get_contents("data/hostten.txt");
	$getsho = $sho - 15;
	@$don = file_get_contents("data/done.txt");
        $getdon = $don + 1;
        file_put_contents("data/done.txt", $getdon);
    file_put_contents("data/$chatid/shoklat.txt", $getsho);
    file_put_contents("data/$chat_id/saeed.txt","no");
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "$hostten",
        'parse_mode' => "html",
        'reply_markup' => $keybord_2
    ]);

    $tedadhost = file_get_contents("data/$chat_id/tedad-host.txt");
    if ($tedadhost == null){
        file_put_contents("data/$chat_id/tedad-host.txt","0");
    }
    file_put_contents("data/$chat_id/tedad-host.txt",$tedadhost+1);
    file_put_contents("data/$chat_id/$tedadhost.txt",$text);
    $number = file_get_contents("data/$chat_id/$tedadhost.txt");
    bot('sendMessage', [
        'chat_id' => $ADMIN,
        'text' => "ادمین عزیز  ❗️
در خواست یک هاست ده گیگ صورت گرفته 💯
دامنه که دوست عزیز سفارش داده اند ❇️
[` $number `]
اطلاعات شخص ♥️
$name 
$last
$username
$chat_id",
        'parse_mode' => "html",
		'reply_markup' => $keybord_2
    ]);





} if ($data == "ba") {
       sendAction($chatid, 'typing');
      bot('sendphoto', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
             'photo'=>"",
        'caption'=>"
هاست میخای؟

نداری؟

خب اینکه کاری نداره 😉

روی لینک زیر کلیک کن و صاحب هاست شو😃

http://telegram.me/[*[BOT]*]?start=$chatid",
        ]);
		bot('sendmessage', [
        'chat_id' => $chatid,
        'message_id' => $message_id2,
        'text' => "
هاست میخای؟

نداری؟

خب اینکه کاری نداره 😉

روی لینک زیر کلیک کن و صاحب هاست شو😃

http://telegram.me/[*[BOT]*]?start=$chatid",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
            ]
        ])
    ]);
           } 
		   if ($data == "topse") {
 $kandom1 = ttoopp(0);
 $kandom2 = ttoopp(1);
 $kandom3 = ttoopp(2);
 //////////////////////
 $kandom11 = file_get_contents("data/$kandom1/shoklat.txt");
 $kandom22 = file_get_contents("data/$kandom2/shoklat.txt");
 $kandom33 = file_get_contents("data/$kandom3/shoklat.txt");
 //////////////////////
 $name1  = file_get_contents("data/$kandom1/name.txt");
 $name2  = file_get_contents("data/$kandom2/name.txt");
 $name3  = file_get_contents("data/$kandom3/name.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "⚜️ برترین های امروز
🏅نفر اول: [$kandom1](tg://user?id=$kandom1) 
🚀 تعداد : $kandom11

🏅نفر دوم: [$kandom2](tg://user?id=$kandom2)
🚀 تعداد: $kandom22

🏅نفر سوم: [$kandom3](tg://user?id=$kandom3)
🚀 تعداد: $kandom33
-  -  -  -  -
این از برترین کاربران ما 😎
جهت شرکت روی دکمه جمع آوری سکه بزن 😉",
 				'parse_mode' => "MarkDown",
        'reply_markup' => $keybord_2
        ]);
		}
		if ($data == "espan") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "♥️ هاست دهی ♥️
➖➖➖➖➖➖
⏳ کسانی که نیاز به هاست دارند میتوانند با شرایط آن را رایگان دریافت کنند 😳
➖➖➖
☣️ شرایط :
📌 دارای کانال بالای 250 ممبر واقعی !

➖➖➖➖➖➖
💡 جهت دریافت و اطلاعات بیشتر با پشتیبانی در تماس باشید",
 				'parse_mode' => "HTML",
        'reply_markup' => $keybord_2
        ]);
		}
		if ($data == "se") {
		
         file_put_contents("data/$chatid/saeed.txt", "sp");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "جانم ؟
هر سوالی یا مشکلی دارید بعد این پیام بفرستید تا بچهای پشتیبانی پیگیری کنن پاسختون رو بدن",
'parse_mode' => "HTML",
        'reply_markup' => $keybord_2
        ]);

    } if ($saeed == 'sp') {
        file_put_contents("data/$chat_id/saeed.txt", "no");
		bot('sendMessage', [
            'chat_id' => "$ADMIN",
            'text' => "
			پیام جدید ارسال شد🤷‍♂️ 
➖➖➖ 
متن ارسال شده : $text
➖➖➖
اطلاعات ارسال کننده🔅
نام فرد〽️  : $name
نام خانوادگی فرد🌐 : $last
آیدی عددی فرد🆔  : $from_id
آیدی تلگرامیش💠 : https://t.me/$username
",
'parse_mode' => "html",
                'parse_mode' => "HTML",
        'reply_markup' => $keybord_3
]);
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "ارسال شد به مدیریت",
			'parse_mode' => "HTML",
        'reply_markup' => $keybord_2
        ]);
    } 
	if ($data == "daryaftpayam") {
	        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
       $sss = file_get_contents("data/$chatid/pasokh1.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "پیام مدیریت🔖
➖➖➖
$sss
➖➖➖
موفق باشید🤷‍♂️",
        ]);
    }
	elseif ($data == "hesab") {
    @$sho = file_get_contents("data/$chatid/shoklat.txt");
    @$sea = file_get_contents("data/$chatid/membrs.txt");
    bot('editmessagetext', [
        'chat_id' => $chatid,
        'message_id' => $message_id2,
        'text' => "شخصات کاربری شما👇

📝 نام :  $data_first
📟 آیدی عددی شما : $chatid 
👤 نام حساب کاربری شما : @$data_username

〰〰〰〰〰〰〰〰〰〰〰〰

👥 تعداد افراد دعوت شده توسط شما : $sea
💰 تعداد سکه های شما : $sho
",
       'parse_mode' => "HTML",
        'reply_markup' => $keybord_2


 ]);
}
if ($chatid == $ADMIN or $chat_id == $ADMIN) {
    if ($text == "/panel") {
        file_put_contents("data/$chat_id/saeed.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "بابای اومد 😱 ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "آمار ربات 📊", 'callback_data' => "am"]
                    ],
                    [
                        ['text' => "ارسال ✅", 'callback_data' => "send"], ['text' => "فوروارد 🏷", 'callback_data' => "fwd"]
                    ],
                    [
                        ['text' => "بلاک 📝", 'callback_data' => "pen"], ['text' => "آنبلاک 📝", 'callback_data' => "unpen"]
                    ],
                    [
                        ['text' => "امتیاز به کاربر  🌸", 'callback_data' => "buy"],['text' => "گرفتن امتیاز از کاربر  🌸", 'callback_data' => "kan"]
                    ],
					[
					['text' => "پاسخ پشتیبانی", 'callback_data' => "pasokh"]
					],
                    [
                        ['text' => "➖➖➖➖➖➖➖➖➖➖➖➖➖➖", 'callback_data' => "pp"]
                    ],
                    [
                        ['text' => "تنظیم هاست یک گیگ 💧", 'callback_data' => "setone"]
                    ],
                    [
                        ['text' => "تنظیم هاست سه گیگ 💧", 'callback_data' => "setthree"]
                    ],
					 [
                        ['text' => "تنظیم هاست ده گیگ 💧", 'callback_data' => "setten"]
                    ],
                ]
            ])
        ]);


    } elseif ($data == "am") {
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
		 @$don = file_get_contents("data/done.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "بابای 🙂 خوش اومدی 😉
تعداد کاربرای توی ربات پسرت :$member_count
تعداد هاست های که ازمون گرفتن : $don",

            'show_alert' => true
        ]);
    }
	elseif ($data == "send") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "send");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برا  کاربرا  . بدو وقت ندارم😑",
        ]);
    } elseif ($saeed == "send") {
        file_put_contents("data/$chat_id/saeed.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    } elseif ($data == "fwd") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "fwd");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب پیام خودتون را فروارد کنید فقط زود که حوصله ندارم😤",
        ]);
    } elseif ($saeed == 'fwd') {
        file_put_contents("data/$chat_id/saeed.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    } elseif ($data == "pen") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "pen");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات😡",
        ]);
    } elseif ($saeed == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم😤
 ایدیش هم 
 $text ",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    } elseif ($data == "pasokh") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "pasokh1");
        bot('sendMessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
        ]);
    } elseif ($saeed == 'pasokh1') {
        file_put_contents("data/pasokh.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "pasokh2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "متن پیام خود را وارد کنید",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($saeed == 'pasokh2') {

        $pasokh = file_get_contents("data/pasokh.txt");
        file_put_contents("data/$pasokh/pasokh1.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "");
        bot('sendMessage', [
            'chat_id' => $pasokh,
            'text' => "کاربر گرامی شما یک پیام از طرف پشتیبانی دارید
            جهت مشاهده پیام به صندوق دریافت پیام مراجعه کنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "صندوق دریافت پیام", 'callback_data' => "daryaftpayam"]
                    ],
                ]
            ])
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
        ]);
    } elseif ($data == "unpen") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "unpen");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب ی بخشیدی حالا . ایدی عددیشو بدع تا انبلاکش کنم😕",
        ]);
    } elseif ($saeed == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }
	elseif ($data == "setone") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "setone1");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "اطلاعات هاست رو ارسال کن ‼️",
        ]);
    } elseif ($saeed == 'setone1') {
        file_put_contents("data/hostone.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "تنظیم شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }
	elseif ($data == "setthree") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "setthree1");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "اطلاعات هاست رو ارسال کن ‼️",
        ]);
    } elseif ($saeed == 'setthree1') {
        file_put_contents("data/hostfive.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "تنظیم شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }
	elseif ($data == "setten") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "setten1");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "اطلاعات هاست رو ارسال کن ‼️",
        ]);
    } elseif ($saeed == 'setten1') {
        file_put_contents("data/hostten.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "تنظیم شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"]
                ],
                ]
            ])
        ]);
    }
	elseif ($data == "kan"){
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "kamk");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب ایدی عددی کاربر را بفرست️",
        ]);
    }    elseif ($saeed == 'kamk') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "kamk2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خب چقدر ازش سکه کم کنم ؟",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($saeed == 'kamk2') {
        $buy = file_get_contents("data/buy.txt");
        $fle = file_get_contents("data/$buy/shoklat.txt");
        $getshe = $fle - $text;
        file_put_contents("data/$buy/shoklat.txt", $getshe);
        file_put_contents("data/$chat_id/saeed.txt", "");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت سکه های کابر کم شد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"], ['text' => "گرفتن امتیاز از کاربر  🌸", 'callback_data' => "kan"]
                ],
                ]
            ])
        ]);
    } 
    elseif ($data == "buy") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "♻️ Please wait ...",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/saeed.txt", "buy");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
        ]);
    } elseif ($saeed == 'buy') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/saeed.txt", "buy2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد سکه ها چقدر باشه",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($saeed == 'buy2') {
        $buy = file_get_contents("data/buy.txt");
        $fle = file_get_contents("data/$buy/shoklat.txt");
        $getshe = $fle + $text;
        file_put_contents("data/$buy/shoklat.txt", $getshe);
        file_put_contents("data/$chat_id/saeed.txt", "");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                    ['text' => "بازگشت ⌛️", 'callback_data' => "home"],['text' => "امتیاز به کاربر  🌸", 'callback_data' => "buy"]
                ],
                ]
            ])
        ]);
    }

}
		?>/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
