/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/<?php
$token = $_GET['token'];
$id = $_GET['id'];
$type = $_GET['type'];
$channel = $_GET['channel'];
$WEBADRESS = "http://Crystal.megaranhost.ir/Altos";
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 //--------------
if($token !== null && $id !== null && $type !== null){
	if($type == "create"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/MegaCreate/$un/index.php"))){
mkdir("Bots/MegaCreate/$un");
mkdir("Bots/MegaCreate/$un/data");
$index = file_get_contents("BotsSource/MegaBot/index.php");
  $index = str_replace("[(*TOKEN*)]",$token,$index);
  $index = str_replace("[(*ADMIN*)]",$id,$index);
  $index = str_replace("[(*CHANNEL*)]",$channel,$index);
  $index = str_replace("[*[BOT]*]",$un,$index);
  save("Bots/MegaCreate/$un/index.php",$index);	
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/MegaCreate/$un/index.php");
	}}
	if($type == "delete"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/MegaCreate/$un/index.php"))){
deletefolder("Bots/MegaCreate/$un");
rmdir("Bots/MegaCreate/$un");
	}}}
unlink('error_log');
 ?>/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
*/
