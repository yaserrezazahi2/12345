/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/<?php
$token = $_GET['token'];
$id = $_GET['id'];
$type = $_GET['type'];
$channel = $_GET['channel'];
$WEBADRESS = "https://wolfis.adrinaserver.site/Altos";
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 //--------------
if($token !== null && $id !== null && $type !== null){
	if($type == "create"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
mkdir("Bots/BotSazSazSazSazSazSaz/$un");
mkdir("Bots/BotSazSazSazSazSazSaz/$un/data");
mkdir("Bots/BotSazSazSazSazSazSaz/$un/bot");
mkdir("Bots/BotSazSazSazSazSazSaz/$un/bots");
  $logo = file_get_contents("BotsSource/BotSazSazSazSazSazSazSazSource/bot/index.php");
  save("Bots/BotSazSazSazSazSazSaz/$un/bot/index.php",$logo);
  $mega = file_get_contents("BotsSource/BotSazSazSazSazSazSazSazSource/bot/jdf.php");
  save("Bots/BotSazSazSazSazSazSaz/$un/bot/jdf.php",$mega);
  $alpha = file_get_contents("BotsSource/BotSazSazSazSazSazSazSazSource/bot/Buuton.php");
  save("Bots/BotSazSazSazSazSazSaz/$un/bot/Buuton.php",$alpha);
$index = file_get_contents("BotsSource/BotSazSazSazSazSazSazSazSource/index.php");
  $index = str_replace("[(*TOKEN*)]",$token,$index);
  $index = str_replace("[(*ADMIN*)]",$id,$index);
 $index = str_replace("[*[BOT]*]",$un,$index);
  $index = str_replace("[(*CHANNEL*)]",$channel,$index);
  save("Bots/BotSazSazSazSazSazSaz/$un/index.php",$index);	 file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazSazSazSazSazSaz/$un/index.php");
	}}
	if($type == "delete"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
deletefolder("Bots/BotSazSazSazSazSazSaz/$un");
rmdir("Bots/BotSazSazSazSazSazSaz/$un");
	}}}
unlink('error_log');
 ?>/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
