<?php
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("sik golam :)");
//
define('API_KEY','[(*TOKEN*)]');
//-------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactnum = $contact->phone_number;
$c_id2 = $message->forward_from_chat->id;
$admin = "[(*ADMIN*)]";
$channel = "[(*CHANNEL*)]";
$rpto = $update->message->reply_to_message->forward_from->id;
$URL = "http://Crystal.megaranhost.ir/Altos";
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$invite = $user["invite"];
$createbot = $user["createbot"];
$createbotsaz = $user["createbotsaz"];
$createbotbnz = $user["createbotbnz"];
$type = $user["type"];
$Stoken = $user["Stoken"];
$typegold = $user["typegold"];
$typebnz = $user["typebnz"];
$yourbotsaz = $user["yourbotsaz"];
$settings = json_decode(file_get_contents("data/settings.json"),true);
$code_silver = $settings["code_silver"];
$code_gold = $settings["code_gold"];
$code_bnz = $settings["code_bnz"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
//------
if($URL == "https://wolfis.adrinaserver.site/Altos"){
if(strpos($textmessage=="/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "none";
$user["type"] = "free";
$user["invite"] = "0";
$user["createbot"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$id.json"),true);
          $invite = $user1["invite"];
          settype($invite,"integer");
                      $newinvite = $invite + 1;
                      $user1["invite"] = $newinvite;
                       $outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$id,
                    'text'=>"یک نفر از طریق لینک شما به ربات اضافه شد✅
شما تا الان $newinvite نفر به ربات آورده اید و برای ویژه شدن برای ربات ساز نقره ای نیاز به 80 نفر دارید و طلایی 110 نفر
اگر به تعداد مورد نظر رسیده اید برای ویژه شدن در پنل نقره ای دستور /vip_silver و برای پنل طلایی از /vip_gold و برای پنل برنزی از /vip_bnz  استفاده کنید🍂",
                   'parse_mode'=>"HTML",
	                      ]);
						
					}
					}
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($textmessage == "/start" or $textmessage == "🔙"){
	$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به ربات ساز خوشومدی دوست من🤠
با استفاده از من میتونی برای خودت یک ربات ساز کامل داشته باشی 🎉
البته این ربات ساز رایگان نیست🔴


جهت خرید حساب ویژه هم میتونی از دکمه های زیر استفاده بکنی⬇️
به پشتیبانی تماس بگیرید 🌐",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"💎ربات سازنقره ای💎"],['text'=>"🔥ربات ساز طلایی🔥"]],
[['text'=>"💥ربات سازبرنزی💥"]],
[['text'=>"💢حذف ربات ساز💢"]],
[['text'=>"🔸کد هدیه نقره ای🔸"],['text'=>"🔻کد هدیه طلایی🔻"]],
[['text'=>"💥کد هدیه برنزی💥"]],
[['text'=>"➰پشتیبانی➰"],['text'=>"🔘خرید حساب ویژه🔘"]],
[['text'=>"⚡️زیرمجموعه گیری⚡️"]],
[['text'=>"اسپانسر ما✈️"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	elseif($textmessage == "💢حذف ربات ساز💢"){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"یکی از گزینه های زیر را انتخاب کنید❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"➰حذف ربات سازنقره ای➰"],['text'=>"🔥حذف ربات ساز طلایی🔥"]],[['text'=>"💥حذف ربات ساز برنزی💥"]],
[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	elseif($textmessage == "اسپانسر ما✈️"){	
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اسپانسر ما",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [['text'=>"اسپانسر", 'url'=>"https://AdrinaServerIr"]],
              ]
        ])
	 ]); 
	}
	 //---
	 	 elseif($textmessage == "💥کد هدیه برنزی💥"){	
	$user["step"] = "free-code-bnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ویژه شدن با استفاده از کد هدیه لطفا کد مورد نظر را ارسال نمایید:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🔙" and $step == "free-code-bnz"){	
	if($code_silver != null){
	if($code_silver == $textmessage){
	$user["step"] = "none";
	$user["typebnz"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_bnz"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تبریک کد هدیه به شما تعلق گرفت😊
حساب شما با موفقیت در ربات ساز ویژه شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"کد هدیه  برنزی با موفقیت استفاده شد😅❗️
ایدی عددی شخص: ⇦ <code>$from_id</code> ⇨
ایدی شخص: ⇦ @$username ⇨
کد وارد شده: ⇦ $textmessage ⇨
فرد با موفقیت ویژه شد🔥
Bot @[*[BOT]*]",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد ارسال شده نادرست است❗️
دوباره تلاش کنید😃",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شرمنده دوست عزیز😁
یک نفر قبل از شما کد رو زده و کد منقضی شده📛",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	 	 elseif($textmessage == "🔸کد هدیه نقره ای🔸"){	
	$user["step"] = "free-code-silver";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ویژه شدن با استفاده از کد هدیه لطفا کد مورد نظر را ارسال نمایید:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🔙" and $step == "free-code-silver"){	
	if($code_silver != null){
	if($code_silver == $textmessage){
	$user["step"] = "none";
	$user["type"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_silver"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تبریک کد هدیه به شما تعلق گرفت😊
حساب شما با موفقیت در ربات ساز ویژه شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"کد هدیه  نقره ای با موفقیت استفاده شد😅❗️
ایدی عددی شخص: ⇦ <code>$from_id</code> ⇨
ایدی شخص: ⇦ @$username ⇨
کد وارد شده: ⇦ $textmessage ⇨
فرد با موفقیت ویژه شد🔥
Bot @[*[BOT]*]",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد ارسال شده نادرست است❗️
دوباره تلاش کنید😃",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شرمنده دوست عزیز😁
یک نفر قبل از شما کد رو زده و کد منقضی شده📛",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	 elseif($textmessage == "🔻کد هدیه طلایی🔻"){	
	$user["step"] = "free-code_gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ویژه شدن با استفاده از کد هدیه لطفا کد مورد نظر را ارسال نمایید:",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	elseif($textmessage != "🔙" and $step == "free-code_gold"){	
	if($code_gold != null){
	if($code_gold == $textmessage){
	$user["step"] = "none";
	$user["typegold"] = "vip";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_gold"] = "";
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تبریک کد هدیه به شما تعلق گرفت😊
حساب شما با موفقیت در ربات ساز ویژه شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	  bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"کد هدیه  طلایی با موفقیت استفاده شد😅❗️
ایدی عددی شخص: ⇦ <code>$from_id</code> ⇨
ایدی شخص: ⇦ @$username ⇨
کد وارد شده: ⇦ $textmessage ⇨
فرد با موفقیت ویژه شد🔥
Bot @[*[BOT]*]",
 'parse_mode'=>"HTML",
	 ]); 
	}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد ارسال شده نادرست است❗️
دوباره تلاش کنید😃",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}else{
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شرمنده دوست عزیز😁
یک نفر قبل از شما کد رو زده و کد منقضی شده📛",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 	
	}
	}
	 //---
elseif($textmessage == "⚡️زیرمجموعه گیری⚡️"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ساخت ربات ساز نقره ای به 80 زیرمجموعه نیاز داری و تا حالا $invite نفر دعوت کردی😊
برای ساخت ربات ساز طلایی به 110 زیرمجموعه نیاز داری و تا حالا $invite نفر دعوت کردی😁
برای ساخت ربات ساز برنزی به 40 زیرمجموعه نیاز داری و تا حالا $invite نفر دعوت کردی😁
با لینک زیر دوستات رو دعوت کن :
https://telegram.me/[*[BOT]*]?start=$from_id",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
	  }
	  elseif($textmessage == "➰پشتیبانی➰"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به پشتیبانی آنلاین ربات ساز خوش اومدی😊
از الان هر پیامی بفرستی به مدیران ربات ارسال میشه😊
برای قطع مکالمه از دکمه زیر استفاده کن👇🏻",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
	   elseif($step == "support" and $textmessage != "🔙"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"پیام شما به پشتیبانی ارسال شد منتظر جواب بمانید😃
برای لغو گفتگو از دکمه زیر استفاده کنید👇🏻",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"دوست عزیز شما یک پیام از طرف پشتیبانی ربات دریافت کردید✔️
------------------------------
$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما به فرد ارسال شد✔️",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	 //---
	 	 	elseif($textmessage == "/vip_gold"){
	    if($typegold !== "vip"){
	        if($invite >= 110){
	            $user["typegold"] = "vip";
	            $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 

	    }else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیرمجموعه های شما کافی نمیباشد❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 		
		}
	}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه است🌟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	    }}
	 	elseif($textmessage == "/vip_silver"){
	    if($type !== "vip"){
	        if($invite >= 80){
	            $user["type"] = "vip";
	            $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 

	    }else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیرمجموعه های شما کافی نمیباشد❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 		
		}
	}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه است🌟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	    }}
	 	elseif($textmessage == "/vip_bnz"){
	    if($type !== "vip"){
	        if($invite >= 40){
	            $user["typebnz"] = "vip";
	            $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 

	    }else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد زیرمجموعه های شما کافی نمیباشد❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 		
		}
	}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه است🌟",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	    }}
	 //---
	 elseif($textmessage == "🔘خرید حساب ویژه🔘"){
		 if($type == "vip"){
			 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ما ویژه است🌹
با تشکر از خرید شما😃",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }else{
			 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام دوست عزیز😉
‼️حساب شما ویژه نمی باشد‼️
برای خرید حساب ویژه درهریک از سه پنل به قسمت➰پشتیبانی➰تماس بگیرید ✈️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
			 
		 }
	 }

	 //---
	 	 elseif($textmessage == "💥حذف ربات ساز برنزی💥"){
		 if($typebnz == "vip"){
			  $user["step"] = "deletebotsazbnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش حذف ربات ساز خوش اومدی دوست من🌹
توجه داشته باش که با حذف ربات ساز همه اعضای ربات سازت پاک میشن و ربات ساز تو از سیستم ما حذف میشه و در عوض میتونی یک ربات ساز دیگه بسازی !😄
▪️اگه قصد ادامه داری توکن ربات سازت رو برای از @BotFather ارسال کن :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	 }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه نمیباشد و هنوز در سیستم ما ربات سازی ثبت نکرده اید❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);   
	 }
	 }
		 elseif($step == "deletebotsazbnz" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("Bots/BotSazSazSazSaz/$un/index.php"))){
	file_get_contents("$URL/BotSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=delete");
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپسس ...
ربات ساز شما با آیدی @$un با موفقیت از سیستم ما حذف شد❌
جهت ساخت ربات ساز میتوانید از طریق همین ربات اقدام کنید ...",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز حذف شد❗️
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots - 1;
                       file_put_contents("data/vipbots.txt",$newbots);
	 $user["step"] = "none";
	 $user["createbotbnz"] = "none";
	 $user["yourbotsaz"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"خطایی رخ داد❌
ممکن است :
1️⃣توکن شما نادرست باشد(چک کنید).
2️⃣توکن شما مربوط به @$yourbotsaz نباشد (توکن همین ربات را ارسال نمایید).
حال دوباره توکن را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
}
}
	 	 elseif($textmessage == "🔥حذف ربات ساز طلایی🔥"){
		 if($typegold == "vip"){
			  $user["step"] = "deletebotsazsaz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش حذف ربات ساز خوش اومدی دوست من🌹
توجه داشته باش که با حذف ربات ساز همه اعضای ربات سازت پاک میشن و ربات ساز تو از سیستم ما حذف میشه و در عوض میتونی یک ربات ساز دیگه بسازی !😄
▪️اگه قصد ادامه داری توکن ربات سازت رو برای از @BotFather ارسال کن :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	 }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه نمیباشد و هنوز در سیستم ما ربات سازی ثبت نکرده اید❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);   
	 }
	 }
		 elseif($step == "deletebotsazsaz" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=delete");
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپسس ...
ربات ساز شما با آیدی @$un با موفقیت از سیستم ما حذف شد❌
جهت ساخت ربات ساز میتوانید از طریق همین ربات اقدام کنید ...",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز حذف شد❗️
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots - 1;
                       file_put_contents("data/vipbots.txt",$newbots);
	 $user["step"] = "none";
	 $user["createbotsaz"] = "none";
	 $user["yourbotsaz"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"خطایی رخ داد❌
ممکن است :
1️⃣توکن شما نادرست باشد(چک کنید).
2️⃣توکن شما مربوط به @$yourbotsaz نباشد (توکن همین ربات را ارسال نمایید).
حال دوباره توکن را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
}
}
	 elseif($textmessage == "➰حذف ربات سازنقره ای➰"){
		 if($type == "vip"){
			  $user["step"] = "deletebotsaz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به بخش حذف ربات ساز خوش اومدی دوست من🌹
توجه داشته باش که با حذف ربات ساز همه اعضای ربات سازت پاک میشن و ربات ساز تو از سیستم ما حذف میشه و در عوض میتونی یک ربات ساز دیگه بسازی !😄
▪️اگه قصد ادامه داری توکن ربات سازت رو برای از @BotFather ارسال کن :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	 }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حساب شما در ربات ساز ویژه نمیباشد و هنوز در سیستم ما ربات سازی ثبت نکرده اید❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);   
	 }
	 }
		 elseif($step == "deletebotsaz" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (file_exists("Bots/BotSazSazSazSazSaz/$un/index.php"))){
	file_get_contents("$URL/BotSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=delete");
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپسس ...
ربات ساز شما با آیدی @$un با موفقیت از سیستم ما حذف شد❌
جهت ساخت ربات ساز میتوانید از طریق همین ربات اقدام کنید ...",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"ربات ساز حذف شد❗️
آیدی ربات ساز :
@$un
ادمین ربات ساز :
[$first_name](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
	 ]);  
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots - 1;
                       file_put_contents("data/vipbots.txt",$newbots);
	 $user["step"] = "none";
	 $user["createbot"] = "none";
	 $user["yourbotsaz"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
}else{
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"خطایی رخ داد❌
ممکن است :
1️⃣توکن شما نادرست باشد(چک کنید).
2️⃣توکن شما مربوط به @$yourbotsaz نباشد (توکن همین ربات را ارسال نمایید).
حال دوباره توکن را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
}
}
//---
 elseif($textmessage == "💥ربات سازبرنزی💥"){
		 if($typebnz == "vip" and $createbotbnz == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر گرامی😃
حتی اعضای ویژه نیز نمیتوانند بیشتر از یک ربات ساز بسازند😁
شما از قبل یک ربات ساز با آیدی @$yourbotsaz ساخته اید🙂
همچنین میتوانید از بخش (حذف ربات ساز) این ربات ساز رو حذف کنید و یکی دیگه بسازید😄",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typebnz == "vip"){
			if($createbotbnz != "true"){
			$user["step"] = "createbotbnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با تشکر از خرید شما🌹
حساب شما ویژه است و میتوانید ربات ساز شخصی خود را داشته باشید✔️
🔸جهت ساخت ربات ساز شخصی خود در مرحله اول میبایست از @BotFather توکن خود را گرفته و اینجا ارسال نمایید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دوست من !
حساب شما در ربات ساز ویژه نمیباشد😅

جهت خرید اشتراک با استفاده از دکمه (پشتیبانی)  اقدام به خرید نمایید😄
قیمت خرید اشتراک 8 هزار تومان بوده ➰
با تشکر🌟
نمونه ربات سازی که با پنل برنزی ساخته میشه👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotbnz" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotbnz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپس !
مشکلی پیش اومد😢
احتمالا توکن خرابه یا این ربات با این آیدی قبلا ثبت شده😊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
 elseif($textmessage == "🔥ربات ساز طلایی🔥"){
		 if($typegold == "vip" and $createbotsaz == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر گرامی😃
حتی اعضای ویژه نیز نمیتوانند بیشتر از یک ربات ساز بسازند😁
شما از قبل یک ربات ساز با آیدی @$yourbotsaz ساخته اید🙂
همچنین میتوانید از بخش (حذف ربات ساز) این ربات ساز رو حذف کنید و یکی دیگه بسازید😄",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($typegold == "vip"){
			if($createbotsaz != "true"){
			$user["step"] = "createbotgold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با تشکر از خرید شما🌹
حساب شما ویژه است و میتوانید ربات ساز شخصی خود را داشته باشید✔️
🔸جهت ساخت ربات ساز شخصی خود در مرحله اول میبایست از @BotFather توکن خود را گرفته و اینجا ارسال نمایید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{

			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دوست من !
حساب شما در ربات ساز ویژه نمیباشد😅

جهت خرید اشتراک با استفاده از دکمه (پشتیبانی)  اقدام به خرید نمایید😄
قیمت خرید اشتراک 8 هزار تومان بوده ➰
با تشکر🌟
نمونه ربات سازی که با پنل طلایی ساخته میشه👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbotgold" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "none";
		$user["createbotsaz"] = "true";
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazSazApi.php?token=$textmessage&id=$from_id&type=create");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما ساخته شد",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپس !
مشکلی پیش اومد😢
احتمالا توکن خرابه یا این ربات با این آیدی قبلا ثبت شده😊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
}
	 //---
	 elseif($textmessage == "💎ربات سازنقره ای💎"){
		 if($type == "vip" and $createbot == "true"){
			 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر گرامی😃
حتی اعضای ویژه نیز نمیتوانند بیشتر از یک ربات ساز بسازند😁
شما از قبل یک ربات ساز با آیدی @$yourbotsaz ساخته اید🙂
همچنین میتوانید از بخش (حذف ربات ساز) این ربات ساز رو حذف کنید و یکی دیگه بسازید😄",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		 }
		if($type == "vip"){
			if($createbot != "true"){
			$user["step"] = "createbot";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);

	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با تشکر از خرید شما🌹
حساب شما ویژه است و میتوانید ربات ساز شخصی خود را داشته باشید✔️
🔸جهت ساخت ربات ساز شخصی خود در مرحله اول میبایست از @BotFather توکن خود را گرفته و اینجا ارسال نمایید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		}
	}else{
			bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دوست من !
حساب شما در ربات ساز ویژه نمیباشد😅

جهت خرید اشتراک با استفاده از دکمه (پشتیبانی)  اقدام به خرید نمایید😄
قیمت خرید اشتراک 6 هزار تومان بوده ➰
با تشکر🌟
نمونه ربات سازی که با پنل نقره ای درست میشود👇
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
		}
	}
	elseif($step == "createbot" and $textmessage != "🔙"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$textmessage .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSazSazSaz/$un/index.php"))){
	 $vipbots = file_get_contents("data/vipbots.txt");
                    settype($vipbots,"integer");
                      $newbots = $vipbots + 1;
                       file_put_contents("data/vipbots.txt",$newbots);
		$user["step"] = "createbot1";
		$user["createbot"] = "true";
		$user["Stoken"] = $textmessage;
		$user["yourbotsaz"] = $un;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تایید شد جالا یک پیام از چنلی که میخواهید برای ارسال اطلاع رسانی تنظیم شود فروارد کنید",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]);  
}else{
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اوپس !
مشکلی پیش اومد😢
احتمالا توکن خرابه یا این ربات با این آیدی قبلا ثبت شده😊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
}
	}
	elseif(isset($message->forward_from_chat) ){
if($step == "createbot1" and $textmessage != "🔙"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
file_get_contents("$URL/BotSazSazSazSazSazSazApi.php?token=$Stoken&id=$from_id&type=create&channel=$c_id2");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات ساز شما با موفقیت فعال شد✅",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
}
	
	//---
	
//-----admin-panel-----
if($textmessage == "مدیریت" or $textmessage == "پنل" or $textmessage == "/panel"){
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"مدیر گرامی به پنل مدیریت ربات ساز خوش آمدید😊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"➰آمار کلی➰"],['text'=>"➰ساخت کد برنزی➰"]],
	[['text'=>"🔸ویژه کردن نقره ای🔸"],['text'=>"🔸رایگان کردن نقره ای🔸"]],
	[['text'=>"🔸ویژه کردن برنزی🔸"],['text'=>"🔸رایگان کردن برنزی🔸"]],
	[['text'=>"🔸ویژه کردن طلایی🔸"],['text'=>"🔸رایگان کردن طلایی🔸"]],
	[['text'=>"➰ساخت کد نقره ای➰"],['text'=>"▫️ساخت کد طلایی▫️"]],
	[['text'=>"➰ارسال همگانی➰"],['text'=>"➰فروارد همگانی➰"]],
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما دسترسی به بخش مدیریت را ندارید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
elseif($chat_id == $admin and $textmessage == "▫️ساخت کد طلایی▫️"){	
$user["step"] = "create-code_gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ساخت کد هدیه لطفا کد مورد نظر را ارسال نمایید🍂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "create-code_gold"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_gold"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"کد هدیه جدیدی برای بخش طلایی ساخته شد😅❗️
کد: ⇦ $textmessage ⇨
Bot: @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage == "➰ساخت کد نقره ای➰"){	
$user["step"] = "create-code-silver";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ساخت کد هدیه لطفا کد مورد نظر را ارسال نمایید🍂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "create-code-silver"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code-silver"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"کد هدیه جدیدی برای بخش نقره ای ساخته شد😅❗️
کد: ⇦ $textmessage ⇨
Bot: @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage == "➰ساخت کد برنزی➰"){	
$user["step"] = "create-code-bnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ساخت کد هدیه لطفا کد مورد نظر را ارسال نمایید🍂",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "create-code-bnz"){	
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$settings["code_bnz"] = $textmessage;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
	 bot('sendMessage',[
 'chat_id'=>$channel,
 'text'=>"کد هدیه جدیدی برای بخش برنزی ساخته شد😅❗️
کد: ⇦ $textmessage ⇨
Bot: @[*[BOT]*]
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
elseif($chat_id == $admin and $textmessage == "🔸رایگان کردن طلایی🔸"){	
$user["step"] = "off-vip-user-gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "off-vip-user-gold"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typegold"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما توسط مدیران ربات ساز رایگان شد😄",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
elseif($chat_id == $admin and $textmessage == "🔸رایگان کردن برنزی🔸"){	
$user["step"] = "off-vip-user-bnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "off-vip-user-bnz"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typebnz"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما توسط مدیران ربات ساز رایگان شد😄",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
elseif($chat_id == $admin and $textmessage == "🔸ویژه کردن برنزی🔸"){	
$user["step"] = "set-vip-user-bnz";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "set-vip-user-bnz"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typebnz"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما با موفقیت توسط مدیران ربات ویژه شد🌹
ازین پس میتوانید ربات ساز شخصی خود را داشته باشید😃
با تشکر از خرید شما😊",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "➰آمار کلی➰"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers
🔸تعداد ربات های ویژه : $vipbots
🔹تعداد ربات های رایگان : $freebots",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "🔸ویژه کردن طلایی🔸"){	
$user["step"] = "set-vip-user-gold";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "set-vip-user-gold"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["typegold"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما با موفقیت توسط مدیران ربات ویژه شد🌹
ازین پس میتوانید ربات ساز شخصی خود را داشته باشید😃
با تشکر از خرید شما😊",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔸ویژه کردن نقره ای🔸"){	
$user["step"] = "set-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"آیدی عددی فرد رو برای ویژه کردن ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "set-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "vip";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت ویژه شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما با موفقیت توسط مدیران ربات ویژه شد🌹
ازین پس میتوانید ربات ساز شخصی خود را داشته باشید😃
با تشکر از خرید شما😊",
 'parse_mode'=>"HTML",
]); 
	 	 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب ویژه شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "🔸رایگان کردن نقره ای🔸"){	
$user["step"] = "off-vip-user";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"برای رایگان کردن حساب فرد آیدی عددی فرد مورد نظر را ارسال کنید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
      'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin and $textmessage != "🔙" and $step == "off-vip-user"){
	if(file_exists("data/$textmessage.json")) {
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$textmessage.json"),true);
$user1["type"] = "none";
$outjson1 = json_encode($user1,true);
file_put_contents("data/$textmessage.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر با موفقیت رایگان شد✔️
پروفایل فرد :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
bot('sendMessage',[
 'chat_id'=>$textmessage,
 'text'=>"حساب شما توسط مدیران ربات ساز رایگان شد😄",
 'parse_mode'=>"HTML",
]); 
 bot('sendMessage',[
 'chat_id'=>$channel_logs,
 'text'=>"حساب رایگان شد❗️
آیدی عددی :
$textmessage
ادمین ربات ساز :
[$textmessage](tg://user?id=$textmessage)",
 'parse_mode'=>"MarkDown",
	 ]);
}else{
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"کاربر مورد نظر در ربات وجود ندارد!❌",
 'parse_mode'=>"HTML",
]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "➰ارسال همگانی➰"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال همگانی ارسال نمایید➰",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "🔙"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"MarkDown",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"MarkDown",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "➰فروارد همگانی➰"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "🔙" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
]); 
}
}
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
unlink('error_log');
?>
?>
