<?php
// @GoldDev
ob_start();
define('API_KEY','[*[TOKEN]*]');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
}}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$chatid = $update->callback_query->message->chat->id;
$from_id = $message->from->id;
$message_id = $message->message_id;
$messageid = $update->callback_query->message->message_id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$admin = [*[ADMIN]*];
$tc = $update->message->chat->type;
$reply = $update->message->reply_to_message;
$data = $update->callback_query->data;
$reply_id = $update->message->reply_to_message->from->id;
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function ForwardMessage($chatid,$from_chat,$message_id){
	bot('ForwardMessage',[
	'chat_id'=>$chatid,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
	}
	//-------
	if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "none";
		 $user["Questions"]["1"] = "اطلاعات تکمیل نشده";
   $user["Questions"]["2"] = "اطلاعات تکمیل نشده";
   $user["Questions"]["3"] = "اطلاعات تکمیل نشده";
   $user["Questions"]["4"] = "اطلاعات تکمیل نشده";
   $user["Questions"]["5"] = " اطلاعات تکمیل نشده";
   $user["Questions"]["6"] = "اطلاعات تکمیل نشده";
   $user["Questions"]["7"] = "";
   $user["Questions"]["8"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	//-----------// @GoldDev
		if(strpos($textmessage,'/start') !== false && $textmessage != "/start") {
					$id=str_replace("/start ","",$textmessage);
					if($id != $from_id){
					   $user["soalha"] = "$id";
					   $user["step"] = "soalha";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
					 bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"سلام به ربات پروفایل مجازی خوش آمدید😃
تاحالا شده توی یه گروه هی بهت بگن اصل بده با این ربات میتونی اطلاعات خودتو تکمیل کنی و لینکتو بفرستی واسه کسایی که بهت میگن اصل بده و خودتو بهشون معرفی کنی🤩
🌐کانال ما
@[*[CHANNEL]*]",
                   'parse_mode'=>"HTML",
                   				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🤩start🤩"]],
	],
		"resize_keyboard"=>true,
	 ])
	                      ]);
						   bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"برای دیدن اطلاعات پروفایل فرد مورد نظر بر روی start بزنید بزنید😃",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🤩start🤩"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	 		bot('sendMessage',[
             'chat_id'=>$id,
            'text'=>"کاربر :  <a href='tg://user?id=$from_id'>$first_name</a> 😄
توسط لینک شما به ربات امد و اطلاعات شما | اصل شما، را که تنظیم کرده بودید را دریافت کرد🙂🤘🏿",
         'parse_mode'=>"HTML",
	 ]);
	}}
elseif($textmessage == "🤩start🤩" and $step == "soalha"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["1"];
$user["step"] = "soal-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"💥نام: $soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"⚡️شهر فرد"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	elseif($textmessage != "/start" and $step == "soal-1"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["2"];
$user["javabha"]["1"] = "$textmessage";
$user["step"] = "soal-2";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"⚡️شهر: $soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"✨سن فرد"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	elseif($textmessage != "/start" and $step == "soal-2"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["3"];
$user["javabha"]["2"] = "$textmessage";
$user["step"] = "soal-3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"✨سن: $soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔥توانایی های فرد"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
		elseif($textmessage!= "/start" and $step == "soal-3"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["4"];
$user["javabha"]["3"] = "$textmessage";
$user["step"] = "soal-4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"🔥توانایی های من: $soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔰بیوگرافی فرد"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	elseif($textmessage != "/start"and $step == "soal-4"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["5"];
$user["javabha"]["4"] = "$textmessage";
$user["step"] = "soal-5";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"🔰بیوگرافی من: $soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🌐کانال فرد"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	elseif($textmessage != "/start"and $step == "soal-5"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["6"];
$user["javabha"]["5"] = "$textmessage";
$user["step"] = "soal-6";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"🌐کانال من: @$soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"/start"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	elseif($textmessage != "/start"and $step == "soal-6"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["7"];
$user["step"] = "soal-7";
$user["javabha"]["6"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"$soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	elseif($textmessage != "/start"and $step == "soal-7"){
		$id = $user["soalha"];
		$user1 = json_decode(file_get_contents("data/$id.json"),true);
$soal = $user1["Questions"]["8"];
$user["javabha"]["7"] = "$textmessage";
$user["step"] = "soal-8";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"$soal",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);}
	 elseif($textmessage != "/start"and $step == "soal-8"){
		$id = $user["soalha"];
$user["step"] = "none";
$user["javabha"]["8"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
        $num1 = $user["javabha"]["1"];
		$num2 = $user["javabha"]["2"];
		$num3 = $user["javabha"]["3"];
		$num4 = $user["javabha"]["4"];
		$num5 = $user["javabha"]["5"];
		$num6 = $user["javabha"]["6"];
		$num7 = $user["javabha"]["7"];
		$num8 = $user["javabha"]["8"];
	  bot('sendMessage',[
                    'chat_id'=>$id,
                    'text'=>"",
                   'parse_mode'=>"HTML",
	 ]);
				bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	 bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"سلام به ربات پروفایل مجازی خوش آمدید😃
تاحالا شده توی یه گروه هی بهت بگن اصل بده با این ربات میتونی اطلاعات خودتو تکمیل کنی و لینکتو بفرستی واسه کسایی که بهت میگن اصل بده و خودتو بهشون معرفی کنی🤩
🌐کانال ما
@Megateam97",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	  bot('sendMessage',[
                    'chat_id'=>$from_id,
                    'text'=>"اطلاعات پروفایل خودتو تکمیل کن و لینکتو برای کسایی که ازت اصل میخوان بفرست😃",
                   'parse_mode'=>"HTML",
				    'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}

	elseif($textmessage == "/start" or $textmessage == "🔙 برگشت"){
		 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام به ربات پروفایل مجازی خوش آمدید😃
تاحالا شده توی یه گروه هی بهت بگن اصل بده با این ربات میتونی اطلاعات خودتو تکمیل کنی و لینکتو بفرستی واسه کسایی که بهت میگن اصل بده و خودتو بهشون معرفی کنی🤩
🌐کانال ما
@[*[CHANNEL]*]",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"اشتراک گذاشتن اطلاعات💻"],['text'=>"تنظیم اطلاعات پروفایل📑"]],[['text'=>"کانال ما🎈"],['text'=>"ارسال نظر🚦"]],
 ],
  "resize_keyboard"=>true,
  ])
  ]); 
 }
	//--------
elseif($textmessage == "ارسال نظر🚦"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"هرگونه انتقاد و پیشنهاد برای اپدیت های بعدی دارید ارسال کنید😄",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
	   elseif($step == "support" and $textmessage != "🔙"){
		    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ممنون بابت اینکه نظر دادید😃🤘🏾",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
		   bot('ForwardMessage',[
	'chat_id'=>$admin,
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
	   }
	   elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"دوست عزیز شما یک پیام از طرف پشتیبانی ربات دریافت کردید✔️
------------------------------
$textmessage",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام شما به فرد ارسال شد✔️",
 'parse_mode'=>"HTML",
	 ]);
       
    }
	if($textmessage == "تنظیم اطلاعات پروفایل📑"){
		 $user["step"] = "set-Questions";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"در این قسمت میتونی اطلاعات پروفایل تو تکمیل کنی😄یکی از گزینه هارو انتخاب کن و اطلاعات رو تکمیل کن🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);	
	}
	if($textmessage == "تنظیم نام📝" && $step == "set-Questions"){
		 $user["step"] = "set-1";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اسمت رو ارسال کن😄",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	if($textmessage && $step == "set-1"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["1"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اسمت تنظیم شد🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage == "تنظیم نام شهر📝" && $step == "set-Questions"){
		 $user["step"] = "set-2";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام شهرتو ارسال کن😄",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text' => 'تهران'], ['text' => 'البرز'], ['text' => 'اردبیل'], ['text' => 'کیش']],
    [['text' => 'آذربایجان شرقی'], ['text' => 'آذربایجان غربی'], ['text' => 'خوزستان']],
    [['text' => 'خراسان شمالی'], ['text' => 'خراسان جنوبی'], ['text' => 'خراسان رضوی']],
    [['text' => 'چهارمحال'], ['text' => 'کرمان'], ['text' => 'کردستان'], ['text' => 'کرمانشاه']],
    [['text' => 'لرستان'], ['text' => 'مازندران'], ['text' => 'هرمزگان']],
    [['text' => 'سیستان و بلوچستان'], ['text' => 'همدان'], ['text' => 'اصفهان'], ['text' => 'سمنان']],
    [['text' => 'زنجان'], ['text' => 'ایلام'], ['text' => 'قزوین'], ['text' => 'یزد']],
    [['text' => 'گیلان'], ['text' => 'بوشهر'], ['text' => 'فارس'], ['text' => 'قم'], ['text' => 'گلستان'], ['text' => '🔙 برگشت']],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-2"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["2"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام شهرت تنظیم شد🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	if($textmessage == "تنظیم سن📝" && $step == "set-Questions"){
		 $user["step"] = "set-3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سنت رو ارسال کن😄",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text' => '12'], ['text' => '13'], ['text' => '14'], ['text' => '15'], ['text' => '16']],
    [['text' => '17'], ['text' => '18'], ['text' => '19'], ['text' => '20'], ['text' => '21']],
    [['text' => '22'], ['text' => '23'], ['text' => '24'], ['text' => '25'], ['text' => '🔙 برگشت']],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-3"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["3"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سنت تنظیم شد🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage == "" && $step == "set-Questions"){
		 $user["step"] = "set-3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-3"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["3"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	if($textmessage == "تنظیم توانایی📝" && $step == "set-Questions"){
		 $user["step"] = "set-4";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توانایی هاتو ارسال کن😄",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-4"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["4"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"توانایی هات تنظیم شد🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage == "تنظیم بیوگرافی📝" && $step == "set-Questions"){
		 $user["step"] = "set-5";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"بیوگرافی تو ارسال کن😄",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-5"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["5"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"بیوگرافیت تنظیم شد🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	if($textmessage == "تنظیم چنل📝" && $step == "set-Questions"){
		 $user["step"] = "set-6";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ایدی چنلت رو بدون @ ارسال کن😄",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-6"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["6"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ایدی چنلت تنظیم شد🤘🏾",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage == "" && $step == "set-Questions"){
		 $user["step"] = "set-7";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-7"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["7"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}// @GoldDev
	if($textmessage == "" && $step == "set-Questions"){
		 $user["step"] = "set-8";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"🔙 برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage && $step == "set-8"){
		 $user["step"] = "set-Questions";
		 $user["Questions"]["8"] = "$textmessage";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
	}
	if($textmessage == "مشاهده پروفایل📑" && $step == "set-Questions"){
		$num1 = $user["Questions"]["1"];
		$num2 = $user["Questions"]["2"];
		$num3 = $user["Questions"]["3"];
		$num4 = $user["Questions"]["4"];
		$num5 = $user["Questions"]["5"];
		$num6 = $user["Questions"]["6"];
		$num7 = $user["Questions"]["7"];
		$num8 = $user["Questions"]["8"];
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اطلاعات پروفایل شما😃:

  💥نام: $num1
 ⚡️شهر: $num2
✨سن: $num3
🔥توانایی من: $num4
🔰بیوگرافی من: $num5
🌐کانال من: @$num6

اگه اطلاعاتت تکمیل نکردی روی تنظیم اطلاعات پروفایل بزن و تکمیل کن❗️
لینکتو بگیر و برای کسایی که ازت اصل میخوان بفرست🤩😃",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"تنظیم نام📝"],['text'=>"تنظیم نام شهر📝"]],
 [['text'=>"تنظیم سن📝"],['text'=>"تنظیم توانایی📝"]],
 [['text'=>"تنظیم بیوگرافی📝"],['text'=>"تنظیم چنل📝"]],
 [['text'=>"مشاهده پروفایل📑"],['text'=>""]],
    [['text'=>"🔙 برگشت"],['text'=>""]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);	
	}// @GoldDev
	//---------
	if($textmessage == "اشتراک گذاشتن اطلاعات💻"){
		 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام دوست عزیزم من $first_name هستم💋😃
میخوای اطلاعات کاملی از من داشته باشی؟!
روی لینک زیر بزن☺️
https://telegram.me/[*[BOT]*]?start=$from_id",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	 [['text'=>"اشتراک گذاشتن اطلاعات💻"],['text'=>"تنظیم اطلاعات پروفایل📑"]],[['text'=>"کانال ما😌"],['text'=>"ارسال نظر🚦"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);	
	  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"بنر بالا رو پخش کن کسی اگه با لینکت وارد ربات بشه میتونه اطلاعات پروفایل تو بخونه😃💋",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
           'keyboard'=>[
	 [['text'=>"اشتراک گذاشتن اطلاعات💻"],['text'=>"تنظیم اطلاعات پروفایل📑"]],[['text'=>"کانال ما🎈"],['text'=>"ارسال نظر🚦"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);	
	}
	if($textmessage == "کانال ما🎈"){
		 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای حمایت از ربات تیم ما عضو کانال ما شوید تا از اخبار و اپدیت های ربات ها باخبر شوید😃🤘🏾
@[*[CHANNEL]*]",
 'parse_mode'=>"HTML",
   'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"اشتراک گذاشتن اطلاعات💻"],['text'=>"تنظیم اطلاعات پروفایل📑"]],[['text'=>"کانال ما🎈"],['text'=>"ارسال نظر🚦"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);	
	  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
    'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
   'keyboard'=>[
	[['text'=>"اشتراک گذاشتن اطلاعات💻"],['text'=>"تنظیم اطلاعات پروفایل📑"]],[['text'=>"کانال ما🎈"],['text'=>"ارسال نظر🚦"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);	
	}
		unlink("error_log");
	?>
