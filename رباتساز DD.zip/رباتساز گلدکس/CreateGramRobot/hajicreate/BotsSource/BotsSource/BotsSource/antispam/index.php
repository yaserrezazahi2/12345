<?php
/*
این سورس توسط @GoldSudo نوشته شده است
جان هرکی دوست داری بدون منبع کپی و فروش نکنید که حرام است
*/
$API_KEY = '[*[TOKEN]*]'; //token
$admin = '[*[ADMIN]*]'; // id admin
$bot_id = '[*[BOT]*]'; // id robot bedon @
$channel = '[*[CHENNEL]*]'; // id kanal bedon @
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
function SendMessage($chat_id, $text, $key){
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
		'parse_mode' => 'MarkDown',
		'disable_web_page_preview' => true,
        'reply_markup' => $key
    ]);
}
function Forward($chat_id,$from_id,$massege_id){
    bot('ForwardMessage',[
    'chat_id'=>$chat_id,
    'from_chat_id'=>$from_id,
    'message_id'=>$massege_id
    ]);
}
function SendPhoto($chat_id, $photo, $action,$keyboard){
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'caption' => $action,
    ]);
}
//------[ @G o l d S u d o ]---------
$button_official = json_encode(['keyboard' => [
[['text' => 'دریافت لینک']],[['text' => 'تغییر علایق']]],'resize_keyboard' => true]);
$a = json_encode(['keyboard' => [
[['text' => 'قرمه سبزی'],['text' => 'تخم مرغ']],
[['text' => 'کله پاچه'],['text' => 'ماکارونی']],
[['text' => 'سیب زمینی'],['text' => 'ماهی']],
[['text' => 'ساندویچ'],['text' => 'اب گوشت']],
[['text' => 'پیتزا'],['text' => 'دیزی']]],'resize_keyboard' => true]);
$b = json_encode(['keyboard' => [
[['text' => 'نارنجی'],['text' => 'خاکستری']],
[['text' => 'ابی'],['text' => 'سبز']],
[['text' => 'قرمز'],['text' => 'سیاه']],
[['text' => 'صورتی'],['text' => 'زرد']]],'resize_keyboard' => true]);
$c = json_encode(['keyboard' => [
[['text' => 'لاله'],['text' => 'شمعدونی']],
[['text' => 'ارکیده'],['text' => 'الاله']],
[['text' => 'سوسن'],['text' => 'رز']],
[['text' => 'لادن'],['text' => 'بنفشه']],
[['text' => 'میخک'],['text' => 'اشرفی']],
[['text' => 'افتابگردان'],['text' => 'مریم']],
[['text' => 'شقایق'],['text' => 'پیچک']]],'resize_keyboard' => true]);
$d = json_encode(['keyboard' => [
[['text' => 'فوتبال'],['text' => 'کاراته']],
[['text' => 'کشتی'],['text' => 'بکس']],
[['text' => 'شنا'],['text' => 'دوچرخه سواری']],
[['text' => 'دومیدانی'],['text' => 'تنیس']],
[['text' => 'تکواندو'],['text' => 'والیبال']]],'resize_keyboard' => true]);
$f = json_encode(['keyboard' => [
[['text' => 'رمانتیک'],['text' => 'سنتی']],
[['text' => 'راک'],['text' => 'هیپ هاپ']],
[['text' => 'پاپ'],['text' => 'الکترونیک']],
[['text' => 'رپ'],['text' => 'بلوز']],
[['text' => 'جاز'],['text' => 'متال']]],'resize_keyboard' => true]);
//------[ @G o l d S u d o ]---------
$e = json_encode(['keyboard' => [
[['text' => 'خانگی'],['text' => 'کلاسیک']],
[['text' => 'ساده'],['text' => 'رسمی']],
[['text' => 'خیابانی'],['text' => 'لش']],
[['text' => 'شخصیتی'],['text' => 'پلنگی']],
[['text' => 'ارتشی'],['text' => 'شلوغ']]],'resize_keyboard' => true]);
$g = json_encode(['keyboard' => [
[['text' => 'اب'],['text' => 'اتش']],
[['text' => 'ارتفاع'],['text' => 'دندان پزشک']],
[['text' => 'مار'],['text' => 'پرواز']],
[['text' => 'سوسک'],['text' => 'سگ']]],'resize_keyboard' => true]);
//------[ @G o l d S u d o ]---------
$h = json_encode(['keyboard' => [
[['text' => 'اجتماعی'],['text' => 'خانوادگی']],
[['text' => 'تخیلی'],['text' => 'فانتزی']],
[['text' => 'کمدی'],['text' => 'اکشن']],
[['text' => 'وسترن'],['text' => 'درام']],
[['text' => 'بیوگرافی'],['text' => 'موزیکال']],
[['text' => 'انیمیشن'],['text' => 'علمی']],
[['text' => 'ماجراجویی'],['text' => 'عاشقانه']],
[['text' => 'ورزشی'],['text' => 'ترسناک']]],'resize_keyboard' => true]);
$button_sabt = json_encode(['keyboard' => [
[['text' => 'ثبت علایق']]],'resize_keyboard' => true]);
$button_ozv = json_encode(['keyboard' => [
[['text' => 'عضو شدم']]],'resize_keyboard' => true]);
$button_admin = json_encode(['keyboard' => [[['text' => 'امار']],[['text' => 'پیام همگانی'],['text' => 'فروارد همگانی']]],'resize_keyboard' => true]);
$button_back = json_encode(['keyboard' => [[['text' => 'بازگشت']]],'resize_keyboard' => true]);
//------[ @G o l d S u d o ]----------
$update = json_decode(file_get_contents('php://input'));
$text = $update->message->text;
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$message_id = $update->message->message_id;
$first_name = $update->message->from->first_name;
$command = file_get_contents('data/'.$chat_id.'/command.txt');
$members = file_get_contents('member.txt');
$memlist = explode("\n",$members);
$truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=@$channel&user_id=".$chat_id));
$tch = $truechannel->result->status;
//------[ @G o l d S u d o ]---------
if (strpos($text,'/start') !== false){
	if (!in_array($from_id,$memlist)){
		mkdir("data/$from_id");
		$members .= $chat_id."\n";
        file_put_contents("member.txt","$members"); 
		file_put_contents('data/'.$from_id.'/name.txt',$first_name);
	}
	$id = str_replace("/start ","",$text);
	if ($id != "" && $text != "/start"){
		if($id != $from_id){
			file_put_contents('data/'.$from_id.'/id.txt',$id);
			if($tch != 'left'){
				SendMessage($chat_id,"سلام $first_name عزیز 🌸

 به ربات 'تفاهم' خوش اومدی 😄

با این ربات میتونی بفهمی با دوستات و اطرافیانت چقدر تفاهم دارید و چقدر بهم شبیه هستین 😉

برای این کار فقط لازمه به سوالای ربات جواب بدی و بعدش لینک خودتو بگیری و برای دوستات بفرستی 👌

برای شروع روی دکمه تنظیم علایق کلیک کن👇",$button_sabt);
			}else{
				SendMessage($chat_id,"سلام $first_name  🌸
به ربات تفاهم خوش اومدی 😄

تو با لینکِ $id_name  وارد این ربات شدی و بعد از پرسیدن چند تا سوال ، من بهت میگم چقدر تفاهم دارین

فقط قبلش باید عضو کانال بشی :

🔅 @$channel
🔅 @$channel",$button_ozv);
			}//------[ @G o l d S u d o ]---------
		}else{
			SendMessage($chat_id,"😄 میخوای ببینی با خودت چند درصد تفاهم داری ؟
    
لینکو که گرفتی باید برای بقیه ارسالش کنی دوست عزیز",$button_official);
		}
	}else{
			if(file_exists('data/'.$from_id.'/soal8.txt')){
			SendMessage($chat_id,"سلام $first_name عزیز 🌸

 به ربات 'تفاهم' خوش اومدی 😄

با این ربات میتونی بفهمی با دوستات و اطرافیانت چقدر تفاهم دارید و چقدر بهم شبیه هستین 😉

برای این کار فقط لازمه به سوالای ربات جواب بدی و بعدش لینک خودتو بگیری و برای دوستات بفرستی 👌

برای شروع روی دکمه تنظیم علایق کلیک کن👇",$button_official);
			}else{//------[ @G o l d S u d o ]---------
				SendMessage($chat_id,"سلام $first_name عزیز 🌸

 به ربات 'تفاهم' خوش اومدی 😄

با این ربات میتونی بفهمی با دوستات و اطرافیانت چقدر تفاهم دارید و چقدر بهم شبیه هستین 😉

برای این کار فقط لازمه به سوالای ربات جواب بدی و بعدش لینک خودتو بگیری و برای دوستات بفرستی 👌

برای شروع روی دکمه تنظیم علایق کلیک کن👇",$button_sabt);
			}
			file_put_contents('data/'.$from_id.'/command.txt','none');
	}
}
elseif($tch == 'left'){
	SendMessage($chat_id,"برای استفاده از این ربات که کاملا هم رایگانه ، شما فقط باید عضو کانال بشین :

🔅@$channel
🔅@$channel",$button_ozv);
}
elseif($text == 'عضو شدم'){
	if($tch != 'left'){
		if(file_exists('data/'.$from_id.'/soal8.txt')){
			SendMessage($chat_id,"سلام $first_name عزیز 🌸

 به ربات 'تفاهم' خوش اومدی 😄

با این ربات میتونی بفهمی با دوستات و اطرافیانت چقدر تفاهم دارید و چقدر بهم شبیه هستین 😉

برای این کار فقط لازمه به سوالای ربات جواب بدی و بعدش لینک خودتو بگیری و برای دوستات بفرستی 👌

برای شروع روی دکمه تنظیم علایق کلیک کن👇",$button_official);
			}else{
				SendMessage($chat_id,"سلام $first_name عزیز 🌸

 به ربات 'تفاهم' خوش اومدی 😄

با این ربات میتونی بفهمی با دوستات و اطرافیانت چقدر تفاهم دارید و چقدر بهم شبیه هستین 😉

برای این کار فقط لازمه به سوالای ربات جواب بدی و بعدش لینک خودتو بگیری و برای دوستات بفرستی 👌

برای شروع روی دکمه تنظیم علایق کلیک کن👇",$button_sabt);
			}
			file_put_contents('data/'.$from_id.'/command.txt','none');
	}else{
		SendMessage($chat_id,"برای استفاده از این ربات که کاملا هم رایگانه ، شما فقط باید عضو کانال بشین :

🔅@$channel
🔅@$channel",$button_ozv);
	}
}
elseif($text == 'ثبت علایق' or $text == 'تغییر علایق'){
	SendMessage($chat_id,"رای تنظیم علایق شما ، لطفا به سوالات زیر جواب بدین

🍔 غذای مورد علاقه شما چیه ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`",$a);
file_put_contents('data/'.$from_id.'/command.txt','10');
}
elseif($command == '10' or $command == '11' or $command == '12' or $command == '13' or $command == '14' or $command == '15' or $command == '16'){
	if(strlen($text) != mb_strlen($text, 'utf-8')){
	$az = array('10','11','12','13','14','15','16');
	$be_s = array("🎨 رنگ مورد علاقه شما چه رنگیه ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`","🌸  گل مورد علاقه شما چه گلیه ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`","🏃🏻 ورزش مورد علاقه شما چیه ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`","🎵 کدوم سبک موسیقی رو بیشتر میپسندی ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`","👔 چه تیبی رو دوست داری ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`","😱 از چی بیشتر میترسی ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`","📽 چه نوع فیلمی رو بیشتر دوست داری ؟

`• اگر جواب شما بین گزینه ها نیست میتونید به صورت 'فارسی' اون رو ارسال کنید`");
    $button_be = array($b,$c,$d,$f,$e,$g,$h);
	$soal = str_replace($az,$be_s,$command);
	$button = str_replace($az,$button_be,$command);
	SendMessage($chat_id,$soal,$button);
	$id = file_get_contents('data/'.$from_id.'/id.txt');
	$be = array('soal1','soal2','soal3','soal4','soal5','soal6','soal7');
	$be = str_replace($az,$be,$command);
	file_put_contents('data/'.$from_id.'/'.$be.'.txt',$text);
	if($id != null){
	if($text == file_get_contents('data/'.$id.'/'.$be.'.txt')){
		file_put_contents('data/'.$from_id.'/darsad.txt',file_get_contents('data/'.$from_id.'/darsad.txt') +1);
	}}
	file_put_contents('data/'.$from_id.'/command.txt',$command + 1);
}else{
SendMessage($chat_id,"♨️ لطفا از حروف انگلیسی ، اعداد و شکلک ها استفاده نکنید ( به علت متمایز نشدن گزینه ها از هم )");
}}//------[ @G o l d S u d o ]---------
elseif($command == '17'){
    if(strlen($text) != mb_strlen($text, 'utf-8')){
	file_put_contents('data/'.$from_id.'/command.txt','none');
	file_put_contents('data/'.$from_id.'/soal8.txt',$text);
	$id = file_get_contents('data/'.$from_id.'/id.txt');
	if($id != null){
	if($text == file_get_contents('data/'.$id.'/soal8.txt')){
		file_put_contents('data/'.$from_id.'/darsad.txt',file_get_contents('data/'.$from_id.'/darsad.txt') +1);
	}
	$darsad = file_get_contents('data/'.$from_id.'/darsad.txt');
	$id_name = file_get_contents('data/'.$id.'/name.txt');
	$s1 = file_get_contents('data/'.$id.'/soal1.txt');
	$s2 = file_get_contents('data/'.$id.'/soal2.txt');
	$s3 = file_get_contents('data/'.$id.'/soal3.txt');
	$s4 = file_get_contents('data/'.$id.'/soal4.txt');
	$s5 = file_get_contents('data/'.$id.'/soal5.txt');
	$s6 = file_get_contents('data/'.$id.'/soal6.txt');
	$s7 = file_get_contents('data/'.$id.'/soal7.txt');
	$s8 = file_get_contents('data/'.$id.'/soal8.txt');
	$a1 = file_get_contents('data/'.$from_id.'/soal1.txt');
	$a2 = file_get_contents('data/'.$from_id.'/soal2.txt');
	$a3 = file_get_contents('data/'.$from_id.'/soal3.txt');
	$a4 = file_get_contents('data/'.$from_id.'/soal4.txt');
	$a5 = file_get_contents('data/'.$from_id.'/soal5.txt');
	$a6 = file_get_contents('data/'.$from_id.'/soal6.txt');
	$a7 = file_get_contents('data/'.$from_id.'/soal7.txt');
	$a8 = file_get_contents('data/'.$from_id.'/soal8.txt');
	$darsad = ($darsad/8) * 100;
	if($darsad > 50){
		$txt = '✋🏻 خیلی خوب تفاهم دارین';
	}else{
		$txt = '😕✋🏻 ببین اینو هیچ جا نشون ندین';
	}
	SendMessage($chat_id,"🔅 مقایسه علایق شما :

🍔 غذا :
$first_name: $a1
$id_name: $s1

🎨 رنگ :
$first_name: $a2
$id_name: $s2

🌸 گل :
$first_name: $a3
$id_name: $s3

🏃 ورزش :

$first_name: $a4
$id_name: $s4

🎵 موسیقی :
$first_name: $a5
$id_name: $s5

👔 تیپ :

$first_name: $a6
$id_name: $s6

😱 ترس : 
$first_name: $a7
$id_name: $s7

📽 فیلم :
$first_name: $a8
$id_name: $s8

$first_name و $id_name

🔹 درصد تفاهم شما : $darsad%

$txt

~~~~~~~~~~~
🔹 [ ربات تفاهم | @$bot_id ]
~~~~~~~~~~~
•",$button_official);
SendMessage($chat_id,"اگه تو هم میخوای ببینی با دوستات چقدر تفاهم داری روی دکمه دریافت لینک بزن و لینکتو برای دوستات بفرست😉👇",$button_official);
SendMessage($id,"🔅 مقایسه علایق شما :

🍔 غذا :
$first_name: $a1
$id_name: $s1

🎨 رنگ :
$first_name: $a2
$id_name: $s2

🌸 گل :
$first_name: $a3
$id_name: $s3

🏃 ورزش :

$first_name: $a4
$id_name: $s4

🎵 موسیقی :
$first_name: $a5
$id_name: $s5

👔 تیپ :

$first_name: $a6
$id_name: $s6

😱 ترس : 
$first_name: $a7
$id_name: $s7

📽 فیلم :
$first_name: $a8
$id_name: $s8

$first_name و $id_name

🔹 درصد تفاهم شما : $darsad%

$txt

~~~~~~~~~~~
🔹 [ ربات تفاهم | @$bot_id ]
~~~~~~~~~~~
•",$button_official);
unlink('data/'.$from_id.'/id.txt');
unlink('data/'.$from_id.'/darsad.txt');
	}else{
		SendMessage($chat_id,"✅ علایق شما با موفقیت ثبت شد
    
الان میتونی لینک مخصوص به خودت رو دریافت کنی",$button_official);
	}
}else{
    SendMessage($chat_id,"♨️ لطفا از حروف انگلیسی ، اعداد و شکلک ها استفاده نکنید ( به علت متمایز نشدن گزینه ها از هم )");
}}
elseif($text == 'دریافت لینک'){
	SendPhoto($chat_id,new CURLFile('baner.jpg')," 😁 $first_name هستم

با این ربات میشه فهمید ما چقدر تفاهم داریم 😛

روی لینک زیر کلیک کن 😁 وعلایقتو ثبت کن  تا معلوم شه چند درصد تفاهم داریم 😍👇

https://t.me/$bot_id?start=$chat_id");
}
# نوشته شده توسط: @G o l d s u d o
# channel: @F e e l p h p
if($chat_id == $admin){
	if($text == '/panel'){
	SendMessage($chat_id,"به پنل مدیریت خوش امدید",$button_admin);
	file_put_contents("data/$chat_id/command.txt","none");	
}
elseif($text == 'بازگشت'){
file_put_contents("data/$chat_id/command.txt","none");	
SendMessage($chat_id,"یک گزینه انتخاب کنید👇",$button_admin);
}
elseif($text == 'امار'){
    	$membersidd= explode("\n",$members);
		$mmemcount = count($membersidd) -1;
	SendMessage($chat_id,"👈 تعداد کل کاربران ربات: $mmemcount");
}
elseif($text == 'پیام همگانی'){
file_put_contents("data/$chat_id/command.txt","send");	
SendMessage($chat_id,"پیام خود را ارسال کنید",$button_back);
}
elseif($command == 'send'){
	file_put_contents("data/$chat_id/command.txt","none");
$forp = fopen( "member.txt", 'r'); 
while( !feof( $forp)) { 
$All = fgets( $forp); 
	SendMessage($All,$text,$button_official);
}
	SendMessage($chat_id,"ارسال شد",$button_admin);	
}
elseif($text == 'فروارد همگانی'){
	file_put_contents("data/$chat_id/command.txt","fwd");
SendMessage($chat_id,"پیام خود را ارسال کنید",$button_back);	
}
elseif($command == 'fwd'){
	file_put_contents("data/$chat_id/command.txt","none");
$forp = fopen("member.txt", 'r'); 
while( !feof( $forp)) { 
$fakar = fgets( $forp); 
	Forward($fakar,$chat_id,$message_id);
}
SendMessage($chat_id,"ارسال شد",$button_admin);	
}
}
/*
به نام خدا
این سورس توسط
@GoldSudo 
نوشته شده است
هرگونه کپی برداری و فروش  بدون رضایت ایشان حرام است
لطفا انسان باشید.
کانال ما:
@FeelPHP
*/
unlink('error_log');
?>
