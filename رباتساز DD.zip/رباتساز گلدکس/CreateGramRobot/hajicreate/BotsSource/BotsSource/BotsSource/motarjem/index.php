<?php
define('API_KEY','[*[TOKEN]*]');
//---------------------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function sendmessage($chat_id, $text, $parse, $msg_id, $buttens){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>$parse,
 'reply_to_message_id'=>$msg_id,
 'reply_markup'=>$buttens,
 ]);
 } 
function sendphoto($chat_id,$photo,$caption,$msg_id,$keyboard){
    bot('sendphoto' ,[
        'chat_id'=>$chat_id,
        'photo'=>$photo,
        'caption'=>$caption,
        'reply_to_message_id'=>$msg_id,
        'reply_markup'=>$keyboard,
        ]);
}
 function senddocument($chat_id, $document, $caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption,
 ]);
 }
	function objectToArrays( $object ) {
    if( !is_object( $object ) && !is_array( $object ) )
    {
    return $object;
    }
    if( is_object( $object ) )
    {
    $object = get_object_vars( $object );
    }
   return array_map( "objectToArrays", $object );
   }

function Forward($KojaShe,$AzKoja,$KodomMSG){
    bot('ForwardMessage',[
        'chat_id'=>$KojaShe,
        'from_chat_id'=>$AzKoja,
        'message_id'=>$KodomMSG
    ]);
}
function sendaction($chat_id, $action){
	bot('sendchataction',[
	'chat_id'=>$chat_id,
	'action'=>$action
	]);
}
function IranTime(){
        date_default_timezone_set("Asia/Tehran");
        return date('H:i:s');
    }
function IranDate(){
        date_default_timezone_set("Asia/Tehran");
       return date('Y/m/d');
 }
//----------------- <\n> ---------------------//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$name = $message->from->first_name;
$username = $message->from->username;
$from_id = $message->from->id;
$text = $message->text;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$admin = [*[ADMIN]*];
$message_id = $update->message->message_id;
$kanall = "[*[CHANNEL]*]";
$kanal = "@$kanall";
$step = file_get_contents("data/".$chat_id."/step.txt");
$coin = file_get_contents("data/".$chat_id."/coin.txt");
$mkd = file_get_contents("data/".$chat_id."/mkd.txt");
$start = file_get_contents("info/start.txt");
$txtback = file_get_contents("info/back.txt");
$error = file_get_contents("info/error.txt");
$help = file_get_contents("info/help.txt");
$Block = file_get_contents("info/block.txt");
$users = file_get_contents("users.txt");
$time = iranTime();
$date = iranDate();
mkdir("info");
mkdir("data");
//---------------------------
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=".$kanal."&user_id=".$from_id));
@$tch = $truechannel->result->status;
//----------------- Buttens -------------------//
$back = json_encode([
'keyboard'=>[
[['text'=>"/start"]],
],'resize_keyboard'=>true]);
$back2 = json_encode([
'keyboard'=>[
[['text'=>"🔙 مدیریت"]],
],'resize_keyboard'=>true]);
$panel = json_encode([
'keyboard'=>[
[['text'=>"📊 آمار ربات"]],
[['text'=>"📬 پیام همگانی"],['text'=>"📨 فروارد همگانی"]],
[['text'=>"📮 پیام به کاربر"],['text'=>"📦 اطلاعات کاربر"]],
[['text'=>"🔸 کم کردن سکه"],['text'=>"🔸 افزودن سکه"]],
[['text'=>"🚫 رفع بلاک"],['text'=>"🚫 بلاک کردن"]],
[['text'=>"👥 سکه همگانی"],['text'=>"📋 سایر دستورات"]],
[['text'=>"برگشت ➥"]],
],'resize_keyboard'=>true]);
$menu = json_encode([
'keyboard'=>[
[['text'=>"🏆 ساخت قرعه کشی"]],
[['text'=>"🏆 قرعه کشی چند نفره"]],
[['text'=>"👥 حساب کاربری"],['text'=>"🎭 قرعه کشی ها"]],
[['text'=>"💵 سکه روزانه"]],
],'resize_keyboard'=>true]);
$yon = json_encode([
'keyboard'=>[
[['text'=>"❌ خیر"],['text'=>"✅ بله"]],
],'resize_keyboard'=>true]);
$acc = json_encode([
'keyboard'=>[
[['text'=>"🗑 پاکسازی لیست"]],
[['text'=>"🎯 نسخه پشتیبان"]],
[['text'=>"/start"]],
],'resize_keyboard'=>false]);
//---------------------------
if(strpos ($Block, "$from_id")) {
        SendMessage($chat_id,"🚫 شما از ربات بن شدید ، دیگر پیام ندهید!","html",$message_id);
}
elseif($text == '/start'){
if(!file_exists("data/$from_id/step.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/step.txt","none");
        file_put_contents("data/$from_id/coin.txt","10");
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
}
SendMessage($from_id,"$start
به ربات قرعه کشی خوش آمدی🔥","html",$message_id,$menu);
}
elseif($text == "/start"){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"$txtback","html",$message_id,$menu);
}
//---------------------------
elseif($text == "🏆 ساخت قرعه کشی"){
if($coin > 0){
file_put_contents("data/$from_id/step.txt","crg");
SendMessage($from_id,"🎗 برای ساخت قرعه کشی هر ایدی یا ... را در یک خط قرار دهید!

مثال : بین افراد زیر میخاهیم قرعه کشی کنیم ، اینگونه قرار میدهیم!
<code>424708619
423805419
368289100
489015850
256725680</code>

☝️ مانند مثال بالا ارسال کنید :","html",$message_id,$back);
   } else {
SendMessage($from_id,"❌ به دلیل کمبود سکه انجام نپذیرفت!","html",$message_id,$menu);
    }
}
elseif($text == "🏆 قرعه کشی چند نفره"){
if($coin > 0){
file_put_contents("data/$from_id/step.txt","crg 2");
SendMessage($from_id,"🎗 برای ساخت قرعه کشی هر ایدی یا ... را در یک خط قرار دهید!

مثال : بین افراد زیر میخاهیم قرعه کشی کنیم ، اینگونه قرار میدهیم!
<code>424708619
423805419
368289100
489015850
256725680</code>

🥇 این نوع قرعه کشی 2 سکه از شما کسر میکند و دارای سه برنده میباشد!

☝️ مانند مثال بالا ارسال کنید :","html",$message_id,$back);
   } else {
SendMessage($from_id,"❌ به دلیل کمبود سکه انجام نپذیرفت!","html",$message_id,$menu);
    }
}
elseif($text == "👥 حساب کاربری"){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"♻️ اطلاعات شما در سیستم ما :

ℹ️ نام : $name
ℹ️ نام کاربری : $username
ℹ️ ایدی عددی : $from_id

💰 تعداد سکه : <b>$coin</b>️

🎯 مقدار سکه هر قرعه کشی : 
1⃣ - قرعه کشی ساده : 0.5 سکه
2⃣ - قرعه کشی چند نفره : 2.0 سکه
","html",$message_id,$menu);
}
elseif($text == "🎭 قرعه کشی ها"){
$sea = file_get_contents("data/$from_id/list.txt");
SendMessage($from_id,"$sea
➖➖➖➖➖➖➖
⏰ Time : $time
📅 Date : $date
➖➖➖➖➖➖➖
","html",$message_id,$acc);
}
elseif($text == "🗑 پاکسازی لیست"){
file_put_contents("data/$from_id/step.txt","unlinkL");
SendMessage($from_id,"🗑 آیا از این کار اطمینان دارید!؟","html",$message_id,$yon);
}
elseif($step == "unlinkL"){
file_put_contents("data/$from_id/step.txt","none");
if($text == "✅ بله"){
unlink("data/$from_id/list.txt");
SendMessage($from_id,"✅ با موفقیت حذف شد!","html",$message_id,$acc);
}
if($text == "❌ خیر"){
SendMessage($from_id,"❌ عملیات لغو شد!","html",$message_id,$acc);
   }
}
elseif($text == "🎯 نسخه پشتیبان"){
$ser = file_get_contents("data/$from_id/list.txt");
file_put_contents("data/$from_id/step.txt","none");
if($ser != "0"){
file_put_contents("data/$from_id/$kanal.txt","$ser
➖➖➖➖➖➖➖
⏰ Time : $time 
📅 Date : $date
➖➖➖➖➖➖➖
🆔 $kanal ");
SendDocument($from_id,new CURLFile("data/$from_id/$kanal.txt"),"🎯 نسخه پشتیبان از تمام قرعه کشی های انجام شده توسط شما در سرور ربات ما!

🆔 $kanal");
  } else {
SendMessage($from_id,"🎯 لیست قرعه کشی های شما خالی است!","html",$message_id);
   }
}
elseif($step == "crg"){
$fre = $coin - 0.5;
$ex = explode("\n",$text);
$count = count($ex);
$rand = rand(1,$count)-1;
$eszx = $ex[$rand];
$myfile2 = fopen("data/$from_id/list.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "➖➖➖➖➖➖➖
⏰ ساعت قرعه کشی : $time
📆 تاریخ قرعه کشی : $date
📊 تعداد نفرات : $count
🥇 برنده : $eszx\n");
        fclose($myfile2);
$myfile3 = fopen("Lotteries.txt", "a") or die("Unable to open file!");
      fwrite($myfile3,"$eszx\n");
      fclose($myfile3);

;file_put_contents("data/$from_id/step.txt","none");
file_put_contents("data/$from_id/coin.txt","$fre");
SendMessage($from_id,"🏆 برنده این قرعه کشی : <code> $eszx </code>","html",$message_id,$menu);
}
elseif($step == "crg 2"){
$fre = $coin - 2;
$ex = explode("\n",$text);
$count = count($ex);
$rand = rand(3,$count)-1;
$x1 = $ex[$rand];
$myfile2 = fopen("data/$from_id/list.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "➖➖➖➖➖➖➖
⏰ ساعت قرعه کشی : $time
📆 تاریخ قرعه کشی : $date
📊 تعداد نفرات : $count
🥇 برنده ها : 
🥇 نفر اول : $x1
🥈 نفر دوم : $x2
🥉 نفر سوم : $x3\n");
        fclose($myfile2);
$myfile3 = fopen("Lotteries.txt", "a") or die("Unable to open file!");
      fwrite($myfile3,"$x1\n");
      fclose($myfile3);

;file_put_contents("data/$from_id/step.txt","none");
file_put_contents("data/$from_id/coin.txt","$fre");
SendMessage($from_id,"🎭 قرعه کشی شما با موفقیت انجام شد!

🏆 برندگان با موفقیت مشخص شدند!","html",$message_id,$menu);
 }
elseif($text == "💵 سکه روزانه") {
 file_put_contents("data/$from_id/step.txt","none");
        date_default_timezone_set('Asia/Tehran');
        $date = IranDate();
        @$gettime = file_get_contents("data/$chat_id/date.txt");
        if ($gettime == $date) {
         SendMessage($from_id,"💰 قبلا سکه روزانه ات رو گرفتی!","html",$message_id);
        } else {
            file_put_contents("data/$chat_id/date.txt", $date);
            @$cun = file_get_contents("data/$chat_id/coin.txt");
            $ran = rand(15,30);
            $getcun = $cun + $ran;
            file_put_contents("data/$chat_id/coin.txt", $getcun);
            $sho2 = file_get_contents("data/$chat_id/coin.txt");
          SendMessage($chat_id,"💰 برای امروز شما $ran سکه گرفتید!","html",$message_id);
  }
 }
//---------------------------
elseif($text == "/panel" && $from_id == $admin || $text == "🔙 مدیریت" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"<b>Welcome To Your Panel!</b>☺️","html",$message_id,$panel);
}
elseif($text == "📊 آمار ربات" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","none");
$member = file_get_contents("users.txt");
$reqmem = explode("\n",$member);
$tedad = count($reqmem) -1;
$ghorek = file_get_contents("Lotteries.txt");
$reqgh = explode("\n",$ghorek);
$counts = count($reqgh) -1;
SendMessage($from_id,"📊 آخرین آمار ربات شما :

👥 اعضا : $tedad
🎊 تعداد قرعه کشی ها : $counts","html",$message_id,$panel);
}
elseif($text == "📮 پیام به کاربر" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","req ozv ci");
SendMessage($from_id,"♻️ لطفا ایدی عددی کاربر را ارسال کن :","html",$message_id,$back2);
}
elseif($step == "req ozv ci"){
file_put_contents("data/$from_id/step.txt","TxT 2 Ozv");
file_put_contents("info/member.txt",$text);
SendMessage($from_id,"♻️ متن پیام را ارسال کن :","html",$message_id,$back2);
}
elseif($step == "TxT 2 Ozv"){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($resm,"👀 پیام جدید از پشتیبانی :
〰〰〰〰〰
$text","html",$message_id,$menu);
SendMessage($from_id,"👀 ارسال شد!","html",$message_id,$panel);
}
elseif($text == "📨 فروارد همگانی" && $chat_id == $admin){
    file_put_contents("data/$from_id/step.txt","fwd");
	sendaction($chat_id,'typing');
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"پیام خودتون را فروراد کنید :",
    'parse_mode'=>'html',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back2
  ]);
}
elseif($step == "fwd"){
    file_put_contents("data/$from_id/step.txt","none");
	SendAction($chat_id,'typing');
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"☑️ در حال فروارد...",
    'parse_mode'=>'html',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=> $panel
  ]);
$forp = fopen( "users.txt", 'r'); 
while( !feof( $forp)) { 
$fakar = fgets( $forp); 
Forward($fakar, $chat_id,$message_id); 
  } 
   bot('sendMessage',[ 
   'chat_id'=>$chat_id, 
   'text'=>"با موفقیت فروارد شد.☑️", 
    'parse_mode'=>'html',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=> $panel
   ]);
}
elseif($text == "📬 پیام همگانی" && $from_id == $admin){
    file_put_contents("data/$from_id/step.txt","send");
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"📮 پیام خود را به صورت متن ارسال کنید.",
    'parse_mode'=>'html',
  'reply_to_message_id'=>$message_id,
    'reply_markup'=> $back2
  ]);
}
elseif($step == "send"){
    file_put_contents("data/$from_id/step.txt","none");
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"فرستاده شد!📮",
    'parse_mode'=>"html",
      'reply_to_message_id'=>$message_id,
    'reply_markup'=> $panel
  ]);
 $all_member = fopen( "users.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
   SendMessage($user,$text,"html");
  }
}
elseif($text == "🔸 افزودن سکه" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","addcoin 1");
SendMessage($from_id,"♻️ لطفا ایدی عددی کاربر رو ارسال کن :","html",$message_id,$back2);
}
elseif($step == "addcoin 1"){
file_put_contents("data/$from_id/step.txt","addcoin 2");
file_put_contents("info/member.txt",$text);
SendMessage($from_id,"♻️ لطفا تعداد سکه رو ارسال کن :","html",$message_id,$back2);
}
elseif($step == "addcoin 2"){
$xZ = file_get_contents("info/member.txt");
$null = file_get_contents("data/$xZ/coin.txt");
$addC = $null + $text;
file_put_contents("data/$from_id/step.txt","none");
file_put_contents("data/$xZ/coin.txt",$addC);
SendMessage($xZ,"💰 تعداد $text سکه به شما اضافه شد!
👀 کل سکه های شما $addC میباشد!","html");
SendMessage($from_id,"👀 مقدار $text سکه به کاربر $xZ اضافه شد!","html",$message_id,$panel);
}
elseif($text == "🔸 کم کردن سکه" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","delcoin 1");
SendMessage($from_id,"♻️ ایدی عددی کاربر رو ارسال کن :","html",$message_id,$back2);
}
elseif($step == "delcoin 1"){
file_put_contents("data/$from_id/step.txt","delcoin 2");
file_put_contents("info/member.txt",$text);
SendMessage($from_id,"♻️ لطفا تعداد سکه رو ارسال کن :","html",$message_id,$back2);
}
elseif($step == "delcoin 2"){
$mkr = file_get_contents("info/member.txt");
file_put_contents("data/$from_id/step.txt","none");
$per = file_get_contents("data/$mkr/coin.txt");
$newcoin = $per - $text;
file_put_contents("data/$mkr/coin.txt",$newcoin);
SendMessage($mkr,"💰 تعداد $text سکه از شما کم شد!
👀 کل سکه های شما $newcoin میباشد!","html");
SendMessage($from_id,"👀 مقدار $text سکه از کاربر $mkr کم شد!","html",$message_id,$panel);
}
elseif($text == "📦 اطلاعات کاربر" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","info");
SendMessage($from_id,"❓ ایدی عددی کاربر چیست :","html",$message_id,$back2);
}
elseif($step == "info"){
$co = file_get_contents("data/$text/coin.txt");
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"این کاربر <code> $co 💰</code> سکه دارد!","html",$message_id,$panel);
}
elseif ($text == "🚫 بلاک کردن") {
        file_put_contents("data/$chat_id/step.txt","ban");
        SendMessage($from_id,"🚫 ایدی عددی کاربر رو ارسال کن :","html",$message_id,$back2);
    } elseif ($step == "ban") {
        $myfile2 = fopen("info/block.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/step.txt","none");
        SendMessage($text,"🚫 شما از ربات بن شدید لطفا دیگر پیام ندهید!","html");
        SendMessage($from_id,"🚫 با موفقیت در لیست سیاه قرار گرفت!","html",$message_id,$panel);
    } 
elseif ($text == "🚫 رفع بلاک") {
        file_put_contents("data/$chat_id/step.txt", "unbaned");
        SendMessage($from_id,"🚫 ایدی عددی کاربر رو ارسال کن :","html",$message_id,$back2);
    } elseif ($step == "unbaned") {
        $newlist = str_replace($text, "", $Block);
        file_put_contents("info/block.txt", $newlist);
        file_put_contents("data/$chat_id/step.txt", "none");
        SendMessage($text,"🚫 شما از لیست سیاه خارج شدید!","html");
        SendMessage($from_id,"🚫 با موفقیت از لیست سیاه حذف شد!","html",$message_id,$panel);
    } 

elseif($text == "👥 سکه همگانی" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","coin to all");
SendMessage($from_id,"🔢 مقدار سکه جهت ارسال به همه را به صورت عدد ارسال کن :","html",$message_id,$back2);
}
elseif($step == "coin to all"){
if(preg_match('/^([0-9])/',$text)){
file_put_contents("data/$from_id/step.txt","cta 2");
file_put_contents("info/coin.txt","$text");
SendMessage($from_id,"📊 آیا از ارسال $text سکه به تمام کاربران اطمینان دارید؟","html",$message_id,$yon);
   }
}
elseif($step == "cta 2"){
if($text == "❌ خیر"){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"✅ عملیات با موفقیت لغو شد!","html",$message_id,$panel);
}
elseif($text == "✅ بله"){
$dew = explode("\n",$users);
$cout = count($dew)-1;
file_put_contents("data/$from_id/step.txt","none");
for($z = 0;$z <= $cout;$z++){
$mem = $dew[$z];
if($mem != "\n" && $mem != " "){
$acoiN = file_get_contents("data/$mem/coin.txt");
$hadie = file_get_contents("info/coin.txt");
file_put_contents("data/$mem/coin.txt",$acoiN + $hadie);
SendMessage($mem,"🎉 تبریک!

🎁 از طرف مدیریت $hadie سکه به شما تعلق گرفت!","html");
   }
}
SendMessage($from_id,"🎁 با موفقیت تعداد $hadie سکه به همه اعضا ارسال شد!","html",$message_id,$panel);
} else {
SendMessage($from_id,"🎈لطفا از کیبورد انتخاب کنید!","html",$message_id,$yon);
   }
}
elseif($text == "📋 سایر دستورات" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"➖➖➖➖➖➖➖
تنظیم متن شروع :
/setstart (text)
تنظیم متن خطا :
/error (text)
تنظیم متن برگشت :
/setback (text)
لیست اعضای مسدود شده : 
/blocklist
➖➖➖➖➖➖➖","html",$message_id,$panel);
}
elseif (strpos($text , "/error" ) !== false && $from_id == $admin){
$textmessage = str_replace("/error","",$text);
file_put_contents("data/$from_id/step.txt","none");
file_put_contents("info/error.txt",$textmessage);
SendMessage($from_id,"متن خطا به $textmessage تغییر کرد!😅","html",$message_id,$panel);
}
elseif (strpos($text , "/setback" ) !== false && $from_id == $admin){
$textmessage = str_replace("/setback","",$text);
file_put_contents("data/$from_id/step.txt","none");
file_put_contents("info/back.txt",$textmessage);
SendMessage($from_id,"متن برگشت به $textmessage تغییر کرد!😲","html",$message_id,$panel);
}
elseif($text == "/blocklist" && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","none");
SendMessage($from_id,"🚫 لیست کاربران مسدود :
$Block","html",$message_id,$panel);
}
elseif (strpos($text , "/setstart" ) !== false && $from_id == $admin){
$textmessage = str_replace("/setstart","",$text);
file_put_contents("data/$from_id/step.txt","none");
file_put_contents("info/start.txt",$textmessage);
SendMessage($from_id,"متن شروع به $textmessage تغییر کرد!😀","html",$message_id,$panel);
}
//---------------------------
else {
SendMessage($from_id,$error,"html",$message_id);
}
unlink('error_log');
?>
