<?php
/*
اپن شد توسط مگا تیم
نویسنده @saeedphp
@Megateam97
*/
define('API_KEY','[*[TOKEN]*]');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function sendmessage($chat_id, $text){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>"MarkDown"
 ]);
 }
function sendphoto($chat_id, $photo, $captionl){
 bot('sendphoto',[ 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$text = $message->text;
@$megateam = file_get_contents("data/$chat_id/mega.txt");
$admin = [*[ADMIN]*];
mkdir("data/$chat_id");
$from_id = $message->from->id;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id = $update->callback_query->message->message_id;
$name = $message->from->first_name;
//---------------//
if($text == '/start' || $text == "/mega"){
$user = file_get_contents('users.txt');
$members = explode("\n",$user);
if (!in_array($chat_id,$members)){
$add_user = file_get_contents('users.txt');
$add_user .= $chat_id."\n";
file_put_contents('users.txt',$add_user);
}
if(strpos($off_on,"false") !== false && $from_id != $Dev){
 return false;
}
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام $name عزیز به ربات پروکسی رایگان خوش آمدی❤️

💢با استفاده از این ربات میتونی پروکسی رایگان دریافت کنی و بدون فیلترشکن با سرعت بسیار بالا به تلگرام وصل شوید.

🔥امکانات این ربات نسبت به فیلترشکن(VPN)

🔸پرسرعت و سریع
🔹بدون قطعی
🔸بدون مصرف بسته اینترنتی شما",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
 ['text'=>"🚀پروکسی رایگان",'callback_data'=>"MegaProxy"]
],
[
['text' => "", 'url' => "https://t.me/megateam97"],['text'=>"🔘این ربات چگونه کار میکند",'callback_data'=>"aboutproxy"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "MegaProxy"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>" جهت دریافت پروکسی بر روی یکی از گزینه های زیر بزنید.
هر 24 ساعت پروکسی های جدید اضافه میشوند!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
['text' => "Proxy(1)", 'callback_data' => "viber"], ['text' => "Proxy(2)", 'callback_data' => "team"]
        ],
        [
            ['text' => "Proxy(3)", 'callback_data' => "max"], ['text' => "Proxy(4)", 'callback_data' => "mega"]
        ],
        [
            ['text' => "Proxy(5)", 'callback_data' => "osman"], ['text' => "Proxy(6)", 'callback_data' => "omg"]
        ],
        [
            ['text' => "Proxy(7)", 'callback_data' => "web"], ['text' => "Proxy(8)", 'callback_data' => "zarin"]
        ],
        [
            ['text' => "Proxy(9)", 'callback_data' => "saeed"], ['text' => "Proxy(10)", 'callback_data' => "mamad"]
        ],
        [
            ['text' => "Proxy(11)", 'callback_data' => "omid"], ['text' => "Proxy(12)", 'callback_data' => "onilne"]
        ],
        [
            ['text' => "Proxy(13)", 'callback_data' => "hoseini"], ['text' => "Proxy(14)", 'callback_data' => "piri"]
        ],
        [
            ['text' => "Proxy(15)", 'callback_data' => "alpha"], ['text' => "Proxy(16)", 'callback_data' => "create"]
        ],
        [
            ['text' => "Proxy(17)", 'callback_data' => "saz"], ['text' => "Proxy(18)", 'callback_data' => "member"]
        ],
        [
            ['text' => "Proxy(19)", 'callback_data' => "tele"], ['text' => "Proxy(20)", 'callback_data' => "gram"]              ],
              [
['text'=>"",'callback_data'=>"/start"]
              ]
              ]
        ])
 ]);
 }
 elseif($data == "omg"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?domain=socks&server=tg.seriyps.ru&port=1080&user=tg-enekas_majazi&pass=S0oByLMg"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "viber"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?domain=socks&server=tg.seriyps.ru&port=1080&user=tg-error_llog&pass=lxiqnr4B"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "max"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?domain=socks&server=tg.seriyps.ru&port=1080&user=tg-error_llog&pass=6YHuqrVy"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "team"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?domain=socks&server=tg.seriyps.ru&port=1080&user=tg-error_llog&pass=U13jf7gA"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "web"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=test.proxy.veesecurity.com&port=443&user=PROXY_5AE7A085DA7F5&pass=f8153932d81a0415"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "zarin"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=test.proxy.veesecurity.com&port=443&user=PROXY_5AE798A4336D9&pass=50c36ce515c6030c"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "saeed"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=test.proxy.veesecurity.com&port=443&user=PROXY_5AE7989516EC5&pass=a502ab753b73dbf0"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "mamad"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=test.proxy.veesecurity.com&port=443&user=PROXY_5AE791AA8B8C4&pass=9ee135c996776ee2"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "gram"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"http://telegram.dog/socks?server=tg.vbatuev.com&port=2388&user=tgproxy&pass=Ohqui1oomeim1eeDuJ1xaedeer4igaev"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "tele"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"http://telegram.dog/socks?server=zharov-pidor.vbatuev.com&port=2388&user=tgproxy&pass=vieCi4eish6ahph5mooxie5iethie4ah"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "member"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?domain=socks&server=tg.seriyps.ru&port=1080&user=tg-error_llog&pass=lxiqnr4B"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "saz"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"http://telegram.dog/socks?server=zharov-pidor.vbatuev.com&port=2388&user=tgproxy&pass=vieCi4eish6ahph5mooxie5iethie4ah"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "alpha"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"http://telegram.dog/socks?server=tg.vbatuev.com&port=2388&user=tgproxy&pass=Ohqui1oomeim1eeDuJ1xaedeer4igaev"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "create"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"http://telegram.dog/socks?server=tgproxy1.vbatuev.com&port=2388&user=tgproxy&pass=Ohqui1oomeim1eeDuJ1xaedeer4igaev"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "hoseini"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?domain=socks&server=socksy.seriyps.ru&port=1080&user=tg-s0lm0&pass=qhS3PBkx"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "piri"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=test.proxy.veesecurity.com&port=443&user=PROXY_5AE77B539F869&pass=c31e3452c5b33116"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "onilne"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=nl10.proxy.veesecurity.com&port=443&user=PROXY_5AE614ED69758&pass=1834f2a748a6619c"]
              ]
              ]
        ])
 ]);
  }
elseif($data == "omid"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=nl4.proxy.veesecurity.com&port=443&user=PROXY_5AE7373556EC1&pass=c85053067843cc07"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "osman"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=199.247.23.227&port=10080&usert=tgfree_user&pass=laip3Ez6"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "mega"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"جهت متصل شدن به پروکسی بر روی گزینه زیر بزنید!",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"متصل شدن☑️",'url'=>"https://t.me/socks?server=185.211.245.14&port=1090&usert=178309743&pass=D1Tt3RmU"]
              ]
              ]
        ])
 ]);
  }
 elseif($data == "aboutproxy"){
bot('sendMessage',[
 'chat_id' => $chatid,
 'text' =>"✔️این ربات با استفاده از پروکسی های مختلف شما را به پروکسی های اختصاصی متصل میکند سپس باعث میشود فیلترینگ تلگرام را دور زده و به تلگرام متصل شد.",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"",'callback_data'=>"back"]
              ]
              ]
        ])
 ]);
  }
/*
اپن شد توسط مگا تیم
نویسنده @saeedphp
@Megateam97
*/
?>









