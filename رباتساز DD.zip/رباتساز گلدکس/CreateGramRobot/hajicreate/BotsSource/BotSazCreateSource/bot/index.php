<?php
/**به نام تنها خالق هستی*/
$token = "[*BOTTOKEN*]";
$admin = "123";
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
define('API_KEY', $token);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function SendMessage($chatid,$text,$parsmde,$disable_web_page_preview,$keyboard){
 bot('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>$text,
 'parse_mode'=>$parsmde,
 'disable_web_page_preview'=>$disable_web_page_preview,
 'reply_markup'=>$keyboard
 ]);
 }
function Forward($chatid,$from_chat,$message_id){
  bot('ForwardMessage',[
  'chat_id'=>$chatid,
  'from_chat_id'=>$from_chat,
  'message_id'=>$message_id
  ]);
  }  
 function sendphoto($chat_id, $photo, $caption){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
 function save($filename,$TXTdata)
  {
  $myfile = fopen($filename, "w") or die("Unable to open file!");
  fwrite($myfile, "$TXTdata");
  fclose($myfile);
 }
 function senddocument($chat_id,$document,$caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption
 ]);
 }
 function sendvideo($chat_id, $video, $caption){
 bot('sendvideo',[
 'chat_id'=>$chat_id,
 'photo'=>$video,
 'caption'=>$caption,
 ]);
 }
 function sendaudio($chat_id, $audio, $caption){
 bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>$audio,
 'caption'=>$caption,
 ]);
 }
 
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$text = $message->text;
@mkdir("data/$chat_id");
//متغیر های کافی برای ساخت دکمه بصورت پیشرفته
$rezaq = file_get_contents("data/rezaq.txt");
$rezaqt = file_get_contents("data/rezaq.php");
$rezaw = file_get_contents("data/rezaw.txt");
$rezawt = file_get_contents("data/rezaw.php");
$rezae = file_get_contents("data/rezae.txt");
$rezaet = file_get_contents("data/rezae.php");
$ssstmman = file_get_contents("data/wwwsssir.txt");
$sssman = file_get_contents("data/wwwsssga.txt");
$sssfrombot = file_get_contents("data/combotsss.txt");
$rezar = file_get_contents("data/rezar.txt");
$rezart = file_get_contents("data/rezar.php");
//متغیر های موردنیاز برای تنظیم پیغام ها
$sssfrom = file_get_contents("data/sssbotcom.txt");
$setteam = file_get_contents("data/sos.txt");
$setstart = file_get_contents("data/setstart.txt");
$sssfromname = file_get_contents("data/setnamebot.txt");
$fareza = file_get_contents("http://goldbotsaz.tk/api.php");
$command = file_get_contents("data/$from_id/command.txt");
@$rezasss = file_get_contents("data/$chat_id/reza.txt");
$shasha = file_get_contents("shasha.txt");
$rezamgs = file_get_contents("data/rezassmss.txt");
$rezasgm = file_get_contents("data/rezasms.txt");
$shasha = file_get_contents("data/svanto.txt");
$botep = file_get_contents("data/user/$from_id/step.txt");
$panel = file_get_contents("mirtm.txt");
$daikmond = file_get_contents("http://goldbotsaz.tk/apidata.php");
$sssmusic = file_get_contents("data/music.txt");
$apijok = file_get_contents("goldbotsaz.tk/apijok.php");
$ilovebot = file_get_contents("goldbotsaz.tk//ilovetext.php");
$userslist = file_get_contents("users.txt");
$fatime = file_get_contents("https://provps.ir/td/?td=time");
$fadate = file_get_contents("https://provps.ir/td/?td=date");
$danloods = file_get_contents("filesaz.txt");
$name = $message->from->first_name;
$lastname = $message->from->last_name;
$username = $message->from->username;
$from_id = $message->from->id;
$_start = file_get_contents("data/sos.txt");
$_start = str_replace("FIRSTNAME",$name,$_start);
$_start = str_replace("LASTNAME",$lastname,$_start);
$_start = str_replace("USERID",$from_id,$_start);
$_start = str_replace("USERNAME",$username,$_start);
$_start = str_replace("DATE",$fadate,$_start); 
$_start = str_replace("TIME",$fatime,$_start);
$_rezapt = file_get_contents("data/rezapt.php");
$_rezapt = str_replace("FIRSTNAME",$name,$_rezapt);
$_rezapt = str_replace("LASTNAME",$lastname,$_rezapt);
$_rezapt = str_replace("USERID",$from_id,$_rezapt);
$_rezapt = str_replace("USERNAME",$username,$_rezapt);
$_rezapt = str_replace("DATE",$fadate,$_rezapt); 
$_rezapt = str_replace("TIME",$fatime,$_rezapt);
$_rezapt = str_replace("TEXTJOK",$apijok,$_rezapt);
$_rezapt = str_replace("TEXTLOVE",$ilovebot,$_rezapt);
$_rezapt = str_replace("LISTUSER",$userslist,$_rezapt);
//=========ŝšş™=========//
if($text == '/start'){
$user = file_get_contents('users.txt');
$members = explode("\n",$user);
if (!in_array($chat_id,$members)){
$add_user = file_get_contents('users.txt');
$add_user .= $chat_id."\n";
file_put_contents('users.txt',$add_user);
//متغیر های کافی ثبت اطلاعات کاربر بصورت پیشرفته برای دریافت اطلاعات کاربر و فهمیدن فعالیت ان
file_put_contents("data/$chat_id/asm.txt", $name);
file_put_contents("data/$chat_id/mam.txt", $username);
file_put_contents("data/$chat_id/svd.txt", $fatime);
file_put_contents("data/$chat_id/tvd.txt", $fadate);
file_put_contents("data/$chat_id/yyyoo.txt", $lastname);
}
bot('sendMessage', [
'chat_id' => $chat_id,
'text'=>"
$setteam",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"$sssmusic"],['text'=>"$ssstmman"]
],
[
['text'=>"$rezaq"],['text'=>"$rezaw"]
],
[
['text'=>"$sssfromname"],['text'=>"$shasha"]
],
[
['text'=>"$rezae"],['text'=>"$rezar"]
],
[
['text'=>"$sssman"]
],
]
])
]);
//کد برای رفع خطا و هشدار به ادمین
}
if($test_code->error){
send('sendMessage',[
'chat_id'=>$msg->chat->id,
'text'=>'ادمین عزیز متاسفانه ربات ارور داد به هاست رفته و برسی کنید
Error Message :
'.$test_code->message.'
Error Line : '.$test_code->line.'
Error code :
'.$test_code->code]);
}
if($text == "$shasha"){
file_put_contents("data/$chat_id/reza.txt","377373");
bot('sendMessage', [
'chat_id' => $chat_id,
'text'=>"سلام اسم شما : $name
نام خانوادگی شما : $lastname
یوزنیم شما : @$username
ایدی عددی شما : $chat_id",
'parse_mode'=>'html',
]);
}
if($text == '$sssman'){
file_put_contents("data/$from_id/reza.txt","🚀");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "لینک فایل را ارسال فایل توجه نباید حجم فایل بیشتر از 50مگابایت باشد",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "🚀"){
file_put_contents("data/$chat_id/$fatime.txt", $text);
file_put_contents("data/$chat_id/reza.txt","🔙🔙🔙🔙🔙");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"بفرمایید اینم از فایلتون",
'parse_mode' => 'html'
]);
}
if($text == "$ssstmman"){
file_put_contents("data/$from_id/reza.txt","danloodfile");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "اسم فایل همراه با فرمت فایل را ارسال نمایید برای مثال
file.txt file.zip٬file.php",
'parse_mode'=>'html',
]);
}
elseif($rezasss == "danloodfile"){
file_put_contents("data/$chat_id/$text", $text);
file_put_contents("filesaz.txt", $text);
file_put_contents("data/$chat_id/reza.txt", "filesazsss");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حالا متنی که میخوای تو فایل قرار بدی بفرست گلم",
'parse_mode'=>"markdown",
]);
}
elseif($rezasss == "filesazsss"){
file_put_contents("data/$chat_id/$danloods", $text);
file_put_contents("data/$chat_id/reza.txt","4737djekp");;
bot('sendDocument',[
    'chat_id'=>$chat_id,
    'document'=>new CURLFILE("data/$chat_id/$danloods")

  ]);
}
if($text == "$sssmusic"){
file_put_contents("data/$from_id/reza.txt","mmusic");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "اسم خواننده یا ترانه را بفرستید",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "mmusic"){
$datamusic = file_get_contents("data/datamusic.txt");
file_put_contents("data/$chat_id/reza.txt","mmmusic");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"نتیجه پیدا شده برای $text
$daikmond",
'parse_mode' => 'html'
]);
}
if($text == "$rezaq"){
file_put_contents("data/$from_id/reza.txt","sdhdhbdhsga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
$rezaqt",
'parse_mode'=>'html',
]);
}
if($text == "$rezaw"){
file_put_contents("data/$from_id/reza.txt","sdhdhdnhsga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
$rezawt",
'parse_mode'=>'html',
]);
}
if($text == "$rezae"){
file_put_contents("data/$from_id/reza.txt","sdhdhmdhsga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
$rezaet",
'parse_mode'=>'html',
]);
}
if($text == "$rezar"){
file_put_contents("data/$from_id/reza.txt","sdhdhdfhsga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "
$rezart",
'parse_mode'=>'html',
]);
}
if($text == "$sssfromname"){
file_put_contents("data/$from_id/reza.txt","sssok");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "$sssfrom",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "sssok"){
file_put_contents("data/$chat_id/reza.txt","novvgggne");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$sssfrombot",
'parse_mode' => 'html'
]);
}
elseif($rezasss == "ssoook"){
file_put_contents("data/$chat_id/kkkaaamm.txt", $text);
file_put_contents("data/$chat_id/reza.txt","sksjhsbsos");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$text",
'parse_mode'=>'html'
]);
}
if($text == "$rezamgs"){
file_put_contents("data/$from_id/reza.txt","sssbbga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "$rezasgm",
'parse_mode'=>'html',
]);
}
if($text == '🔙برگشت🔙'){
file_get_contents("data/$from_id/reza", "back");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام دوست عزیز بی منوی اصلی برگشتی↪
 لطفا یک گزینه رو انتخاب کن✅",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"$sssmusic"],['text'=>"$ssstmman"]
],
[
['text'=>"$rezaq"],['text'=>"$rezaw"]
],
[
['text'=>"$sssfromname"],['text'=>"$shasha"]
],
[
['text'=>"$rezae"],['text'=>"$rezar"]
],
[
['text'=>"$sssman"]
],
]
])
]);
}
elseif($text == '/creator'){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام این ربات ساخته شده توسط ربات ساز پرقدرت sss
 
 @I_robot_bot
 @chphp_tm
",
]);
}
elseif($text == '/on_spam_admin' && $from_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "حالت ضد لینک فعال شد✅",
]);
}
//-------
if($text == '/panel' && $from_id == $admin){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"وارد پنل مدیریت شدید",
 'parse_mode'=>"markdown",
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"📊آمار ربات📊"],['text'=>"✉پیام همگانی✉"]
],
[
['text'=>"📮فوروارد همگانی"],['text'=>"👥اطلاعات کاربران👥"]
],
[
['text'=>"💢ریست کردن💢"],['text'=>"📡تنظیم متن استارت📡"]
],
[
['text'=>"ساخت دکمه"],['text'=>"پاسخ سریع"]
],
[
['text'=>"👥لیست کاربران👥"],['text'=>"❌حذف دکمه❌"]
],
[
['text' => "مدیریت گروه💢"]
],
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($text == 'مدیریت گروه💢' && $from_id == $admin){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "ادمین عزیز میتوانید با اضافه کردن رباتتون به گروه و ارسال دستور
/on_spam_admin
حالت مدیریت گروه را فعال نمایید و گروهی ایمن داشته باشید 

به یاد داشته باشید فقط شما قادر به ارسال دستور و استفاده از ربات هستید و کاربر دیگری توانایی این کار را ندارد.

بخاطر بالا بودن حجم سرور و مخارج نگهداری از سرور تصمیم گرفتیم 10%سرعت را کاهش دهیم به این دلیل امکان تشخیص و حساسیت نسبت به لینک کمی دیرتشخیص داده شود اما بزودی سرور را تقویت خواهیم کرد

اطلاعات بیشتر :
    @chphp_tm",
]);
}
if($text == '/setdanfile' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","oooqqqppp");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "گلم من اسم دکمه رو بفرست🌈",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "oooqqqppp"){
file_put_contents("data/wwwsssga.txt", $text);
file_put_contents("data/$chat_id/reza.txt","widhdhbdodjsjdjdj");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"حالا متن پاسخ رو بفرست",
'parse_mode' => 'html'
]);
}
if($text == '/setfilesaz' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","rezakkkiii");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "خوب عزیزم اسم دکمه رو بفرست",
'parse_mode'=>'html',
]);
}
elseif($rezasss == "rezakkkiii"){
file_put_contents("data/wwwsssir.txt", $text);
file_put_contents("data/$chat_id/reza.txt", "dhsjisjshshs");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"دکمه با موفقیت ساخته شد",
'parse_mode'=>"markdown",
]);
}
if($text == "❌حذف دکمه❌" && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","sdhdhdnhsga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "دستورات حذف دکمه❌👇👇
/deletbotsaz 👈برای حذف دکمه بات ساز
/deletname 👈حذف دکمه نمایش اطلاعات👥
/deletfilesaz 👈برای پاک کردن دکمه فایل ساز
/deletmusic 👈برای حذف دکمه جستوجو موزیک
/deletdanfile 👈پاک کردن دکمه دانلود فایل",
'parse_mode'=>'html',
]);
}
if($text == "/deletdanfile" && $from_id == $admin){
file_put_contents("data/wwwsssga.txt","");
file_put_contents("data/$from_id/reza","48483872");
bot('sendMessage',[
'chat_id' => $chat_id,
'text'=>"دکمه حذف شد",
'parse_mode'=>'html',
]);
}
if($text == "/deletfilesaz" && $from_id == $admin){
file_put_contents("data/wwwsssir.txt","");
file_put_contents("data/$from_id/reza.txt","373782736356");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت پاک شد",
'parse_mode'=>'html',
]);
}
if($text == "/deletbotsaz" && $from_id == $admin){
file_put_contents("data/setnamebot.txt","");
file_put_contents("data/$from_id/reza.txt","sdhdhdsjdnhsga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "با موفقیت دکمه پاک شد✅",
'parse_mode'=>'html',
]);
}
if($text == "/deletname" && $from_id == $admin){
file_put_contents("data/svanto.txt","");
file_put_contents("data/$from_id/reza.txt","sdhdhdqpdjdbbd");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "با موفقیت پاک شد✅",
'parse_mode'=>'html',
]);
}
if($text == "/deletfont" && $from_id == $admin){
file_get_contents("data/fontm.txt","");
file_put_contents("data/$from_id/reza.txt","qpdmfnjxjdvv");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "با موفقیت پاک شد✅",
'parse_mode'=>'html',
]);
}
if($text == "/deletmusic" && $from_id == $admin){
file_put_contents("data/music.txt","");
file_put_contents("data/$from_id/reza.txt","cmoozksnnn");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "با موفقیت پاک شد✅",
'parse_mode'=>'html',
]);
}
if($text == '/setmusic' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","musiccom");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "اسم دکمه را ارسال نمایید",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "musiccom"){
file_put_contents("data/music.txt", $text);
file_put_contents("data/$chat_id/reza.txt","vggrkdkdje");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"اسم دکمه با موفقیت تنظیم شد✅",
'parse_mode' => 'html'
]);
}
if($text == "ساخت دکمه"){
bot('sendMessage',[
 'chat_id' => $chat_id,
 'text' => "سلام خوش امدید راهنما و دستورات ساخت دکمه های ربات
 /setmusic 👈برای ساخت دکمه جستوجو موزیک
 
 /setbotsaz 👈برای ساخت دکمه رباتساز
 
 /setsssbots 👈برای ساخت دکمه دلخواه
 
 /setfilesaz 👈برای دکمه ساخت فایل ساز
 
 /setsssname 👈برای ساخت دکمه نمایش پروفایل و مشخصات
 
 /setdanfile 👈برای ساخت دکمه دانلود فایل",
 'parse_mode'=>"html",
]);
}
if($text == 'پاسخ سریع' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","pasochsariaa");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "لطفا کلمه ای که قراره ربات پاسخش بده بفرست!.",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "pasochsariaa"){
file_put_contents("data/rezassmss.txt", $text);
file_put_contents("data/$chat_id/reza.txt","pasochsariaato");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"حالا متن پاسخ رو بفرست",
'parse_mode' => 'html'
]);
}
elseif($rezasss == "pasochsariaato"){
file_put_contents("data/rezasms.txt", $text);
file_put_contents("data/$chat_id/reza.txt","dokwjsjdjdbeb");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پاسخ سریع تنظیم شد✅",
'parse_mode' => 'html'
]);
}
if($text == '/setbotsaz' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","djdjdjdjdj");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "اسم دکمه را ارسال نمایید",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "djdjdjdjdj"){
file_put_contents("data/setnamebot.txt", $text);
file_put_contents("data/$chat_id/reza.txt","vggrkdkdje");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"اسم دکمه با موفقیت تنظیم شد✅",
'parse_mode' => 'html'
]);
}
if($text == '📊آمار ربات📊' && $from_id == $admin){
$user = file_get_contents("users.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
$listmember = file_get_contents("users.txt");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد اعضای ربات : $member_count
 لیست اعضا👇👇👇
 
 $listmember",
 'parse_mode'=>"markdown",
 ]);
}
elseif($text == '👥لیست کاربران👥' && $from_id == $admin){
bot('sendDocument',[
    'chat_id'=>$chat_id,
    'document'=>new CURLFILE("users.txt")

  ]);
 }
if($text == '/setsssbots' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","ssttttsok");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "اسم دکمه رو ارسال نمایید✅",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "ssttttsok"){
file_put_contents("data/mmggfor.txt", $fareza);
$mmjjo = file_get_contents("data/mmggfor.txt");
file_put_contents("data/$mmjjo.txt", $text);
file_put_contents("data/$chat_id/reza.txt","vggrkdkdjem");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"حله خوب✅
حالا!!متن داخل دکمه رو بفرست.✅",
'parse_mode' => 'html'
]);
}
elseif($rezasss == "vggrkdkdjem"){
$wwwqqqqm = file_get_contents("data/mmggfor.txt");
file_put_contents("data/$wwwqqqqm.php", $text);
file_put_contents("data/$chat_id/reza.txt","vggrkdkdjeggl");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت تنظیم شد✅",
'parse_mode' => 'html'
]);
}
if($text == '/setsssname' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","shadmhreaghili");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "اسم دکمه را ارسال نمایید",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($rezasss == "shadmhreaghili"){
file_put_contents("data/svanto.txt", $text);
file_put_contents("data/$chat_id/reza.txt","qpxndbxjnnvf");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"اسم دکمه با موفقیت تنظیم شد✅",
'parse_mode' => 'html'
]);
}
if($text == '💢ریست کردن💢' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","sssooioo");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "از انجام کار مطمئن هستید با انجام این کار تمامی متن ها،اطلاعات،دکمه های سیستمی و دستی همه پاک میشود فقط امار ربات باقی می ماند از انجام این کار مطمئن هستید اگر تمایل دارید دکمه بله را ارسال نمایید",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"بله"]
],
]
])
]);
}
elseif($rezasss == "sssooioo"){
file_put_contents("data/svanto.txt","");
file_put_contents("data/rezaq.txt","");
file_put_contents("data/rezaq.php","");
file_put_contents("data/rezaw.txt","");
file_put_contents("data/rezaw.php","");
file_put_contents("data/rezae.txt","");
file_put_contents("data/rezae.php","");
file_put_contents("data/rezar.txt","");
file_put_contents("data/rezar.php","");
file_put_contents("data/sos.txt","");
file_put_contents("data/$chat_id/reza.txt", "kdjsdjdjdjsj");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"داده پاک شد
 $faaa",
'parse_mode' => 'html'
]);
}
if($text == '👥اطلاعات کاربران👥' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","sssga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "سلام ادمین عزیز برای بدست اوردن اطلاعات یک کاربر کافیست ایدی عددی کاربر را ارسال نمایید",
'parse_mode'=>'html',
]);
}
elseif($rezasss == "sssga"){
$faaa = file_get_contents("data/$text/asm.txt");
$qaaa = file_get_contents("data/$text/yyyoo.txt");
$taaa = file_get_contents("data/$text/svd.txt");
$daaa = file_get_contents("data/$text/tvd.txt");
$ggpp = file_get_contents("data/$text/mam.txt");
file_put_contents("data/$chat_id/reza.txt", "dkdjsjsj");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام اطلاعات کاربر👇👇
اسم کاربر👤 : $faaa
نام خانوادگی کاربر👥 : $qaaa
ساعت ورود کاربر⏰ : $taaa
تاریخ ورود کاربر📆 : $daaa
یوزنیم کاربر : 🆔 @$ggpp",
'parse_mode' => 'html'
]);
}
if($text == '📡تنظیم متن استارت📡' && $from_id == $admin){
file_put_contents("data/$from_id/reza.txt","ssgfuusga");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "متن استارت را ارسال نمایید",
'parse_mode'=>'html',
]);
}
elseif($rezasss == "ssgfuusga"){
file_put_contents("data/sos.txt", $text);
file_put_contents("data/$chat_id/reza.txt", "dkdjshshpoijsj");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"با موفقیت تنظیم شد✅",
'parse_mode' => 'html'
]);
}
if($text == '✉پیام همگانی✉' && $from_id == $admin){
file_put_contents("mirtm.txt","Send");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "پیام مورد نظرتونو بفرستید تا برای همه ی کاربرا ارسالش کنم",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙برگشت🔙"]
],
]
])
]);
}
elseif($panel == "Send" && $from_id == $admin){
file_put_contents("mirtm.txt","none");
Bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>" پیام همگانی فرستاده شد.",
'parse_mode' => 'html'
]);
$all_member = fopen( "users.txt", "r");
while( !feof( $all_member)) {
$user = fgets( $all_member);
SendMessage($user,$text,'html');
}
}
?>
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/