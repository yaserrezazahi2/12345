<?php
/*
به نام خداوند بخشنده ی مهربان
*/
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
define('API_KEY','[TOKEN]');
//----######------
function makereq($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//##############=--API_REQ
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}
//----######------
//---------
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
//=========
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
 $type = $update->message->chat->type;
$textmessage = isset($update->message->text)?$update->message->text:'';
$userlist = file_get_contents("users.txt");
$grouplist = file_get_contents("groups.txt");
$supergrouplist = file_get_contents("supergroups.txt");
$step = file_get_contents("data/admin/step.txt");
$sudo = [ADMIN];
$admin = file_get_contents("data/admins.txt");
//-------
function SendMessage($ChatId, $TextMsg)
{
 makereq('sendMessage',[
'chat_id'=>$ChatId,
'text'=>$TextMsg,
'parse_mode'=>"MarkDown"
]);
}
function Forward($KojaShe,$AzKoja,$KodomMSG)
{
makereq('ForwardMessage',[
'chat_id'=>$KojaShe,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
function save($filename,$TXTdata)
	{
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
		if ($textmessage == "/start" && strpos($admin , "$from_id") !== false || $textmessage == "/start" && $from_id == $sudo) {
		SendMessage($chat_id,"سلام ادمین !\nدستور\n/help\nرا برای دیدن راهنما ارسال کنید!");
	}
			elseif ($textmessage == "/help" && strpos($admin , "$from_id") !== false || $textmessage == "/help" && $from_id == $sudo ) {
		SendMessage($chat_id,"راهنمای ربات تبلیغ گر شما:

💗 /fwd all
💗 فوروارد متن به همه گروه ها،سوپر گروه ها‌،کاربران
😊 /fwd users
😊 فوروارد کردن متن به تمامی کاربران
😅 /fwd gps
😅 فوروارد کردن متن به تمامی گروه ها
😉 /fwd sgps
😉 فوروارد کردن متن به تمامی سوپر گروه ها

😝 /bc
😝 ارسال متن به تمامی کاربران،گروه ها،سوپر گروه ها

😃 /stats
😄 امار ربات شما 

😶 راهنمای افزودن و حذف ادمین(فقط ادمین اصلی)

😜 /addadmin
😜 افزودن ادمین با استپ
👌 /demadmin
👌 حذف ادمین با استپ");
	}
	elseif ($textmessage == "/addadmin" && $from_id == $sudo ) {
			save("data/admin/step.txt","add admin");
		SendMessage($chat_id,"ایدی عددی فردی که میخواهید در ربات ادمین شود را ارسال کنید");
		}
				if ($step == 'add admin') {
		save("data/admin/step.txt","none");
$myfile2 = fopen("data/admins.txt", "a") or die("Unable to open file!");	
fwrite($myfile2, "$textmessage\n");
fclose($myfile2);
		SendMessage($chat_id,"شخص مورد نظر ادمین شد.");
	}
		elseif ($textmessage == "/demadmin" && $from_id == $sudo ) {
			save("data/admin/step.txt","dem admin");
		SendMessage($chat_id,"کر");
		}
			if ($step == 'dem admin') {
			    save("data/admin/step.txt","none");
			$newlist = str_replace("$textmessage","",$admin);
			save("data/admins.txt",$newlist);
			SendMessage($chat_id,"فرد مورد نظر از ادمینی کنار گذاشته شد!");
		}
		if ($type == "group") {
	 if (strpos($grouplist , "$chat_id") == false){
 $txxt = file_get_contents('groups.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('groups.txt');
      $aaddd .= $chat_id."\n";
  save('groups.txt',$aaddd);
    }
	}
}
		if ($type == "private") {
	 if (strpos($users , "$chat_id") == false){
 $txxt = file_get_contents('users.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('users.txt');
      $aaddd .= $chat_id."\n";
  save('users.txt',$aaddd);
    }
	}
}
		if ($type == "supergroup") {
	 if (strpos($supergrouplist , "$chat_id") == false){
 $txxt = file_get_contents('supergroups.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('supergroups.txt');
      $aaddd .= $chat_id."\n";
  save('supergroups.txt',$aaddd);
    }
	}
}
		if ($step == 'Send To All' && strpos($admin , "$from_id") !== false || $step == 'Send To All' && $from_id == $sudo ) {
		SendMessage($chat_id,"پیام در حال `ارسال` میباشد");
		save("data/admin/step.txt","none");
		$fp = fopen( "users.txt", 'r');
		while( !feof( $fp)) {
 			$users = fgets( $fp);
			SendMessage($users,$textmessage);
		}
			$fp2 = fopen( "groups.txt", 'r');
		while( !feof( $fp2)) {
 			$groups = fgets( $fp2);
			SendMessage($groups,$textmessage);
		}
		$fp3 = fopen( "supergroups.txt", 'r');
		while( !feof( $fp3)) {
 			$supergroups = fgets( $fp3);
			SendMessage($supergroups,$textmessage);
		}
		SendMessage($chat_id,"✅ پیام شما به تمامی `کاربران رباتتان`ارسال شد.");
		
	}

	if ($textmessage == "/bc" && strpos($admin , "$from_id") !== false || $textmessage == "/bc" && $from_id == $sudo ) {
			save("data/admin/step.txt","Send To All");
		SendMessage($chat_id,"پیام خود را ارسال کنید.
		جهت کنسل کردن بفرستید /cancel");
	}

		if ($step == 'fwd To ALL' && strpos($admin , "$from_id") !== false || $step == 'fwd To ALL' && $from_id == $sudo ) {
		SendMessage($chat_id,"پیام در حال `فوروارد` میباشد");
		save("data/admin/step.txt","none");
		$fp = fopen( "users.txt", 'r');
		while( !feof( $fp)) {
 			$users = fgets( $fp);
			Forward($users,$chat_id,$message_id);
		}
		$fp2 = fopen( "groups.txt", 'r');
		while( !feof( $fp2)) {
 			$groups = fgets( $fp2);
			Forward($groups,$chat_id,$message_id);
		}
		$fp3 = fopen( "supergroups.txt", 'r');
		while( !feof( $fp3)) {
 			$supergroups = fgets( $fp3);
			Forward($supergroups,$chat_id,$message_id);
		}
		SendMessage($chat_id,"پیام شما به تمامی گروه ها و کاربران و سوپر گروه های رباتتان ارسال شد!");
	}

	if ($textmessage == "/fwd all" && strpos($admin , "$from_id") !== false || $textmessage == "/fwd all" && $from_id == $sudo ) {
			save("data/admin/step.txt","fwd To ALL");
		SendMessage($chat_id,"پیام خود را فوروارد کنید.
		جهت کنسل کردن بفرستید /cancel");
		}
		if ($step == 'fwd To users' && strpos($admin , "$from_id") !== false || $step == 'fwd To users' && $from_id == $sudo ) {
		SendMessage($chat_id,"پیام در حال `فوروارد` میباشد");
		save("data/admin/step.txt","none");
		$fp = fopen( "users.txt", 'r');
		while( !feof( $fp)) {
 			$users = fgets( $fp);
			Forward($users,$chat_id,$message_id);
		}
		SendMessage($chat_id,"پیام شما به تمامی `کاربران رباتتان`ارسال شد!");
	}


	if ($textmessage == "/fwd users" && strpos($admin , "$from_id") !== false || $textmessage == "/fwd users" && $from_id == $sudo ) {
			save("data/admin/step.txt","fwd To users");
		SendMessage($chat_id,"پیام خود را فوروارد کنید.
		جهت کنسل کردن بفرستید /cancel");
		}
		if ($step == 'fwd To gps' && strpos($admin , "$from_id") !== false || $step == 'fwd To gps' && $from_id == $sudo ) {
		SendMessage($chat_id,"پیام در حال `فوروارد` میباشد");
		save("data/admin/step.txt","none");
		$fp2 = fopen( "groups.txt", 'r');
		while( !feof( $fp2)) {
 			$groups = fgets( $fp2);
			Forward($groups,$chat_id,$message_id);
		}
		SendMessage($chat_id,"پیام شما به تمامی گروه های رباتتان ارسال شد!");
	}


	if ($textmessage == "/fwd gps" && strpos($admin , "$from_id") !== false || $textmessage == "/fwd gps" && $from_id == $sudo ) {
			save("data/admin/step.txt","fwd To gps");
		SendMessage($chat_id,"پیام خود را فوروارد کنید.
		جهت کنسل کردن بفرستید /cancel");
		}
		
		if ($step == 'fwd To sgps' && strpos($admin , "$from_id") !== false || $step == 'fwd To sgps' && $from_id == $sudo ) {
		SendMessage($chat_id,"پیام در حال `فوروارد` میباشد");
		save("data/admin/step.txt","none");
		$fp2 = fopen( "groups.txt", 'r');
		while( !feof( $fp2)) {
 			$groups = fgets( $fp2);
			Forward($groups,$chat_id,$message_id);
		}
		SendMessage($chat_id,"پیام شما به تمامی سوپر گروه های رباتتان ارسال شد!");
	}


	if ($textmessage == "/fwd sgps" && strpos($admin , "$from_id") !== false || $textmessage == "/fwd sgps" && $from_id == $sudo ) {
			save("data/admin/step.txt","fwd To sgps");
		SendMessage($chat_id,"پیام خود را فوروارد کنید.
		جهت کنسل کردن بفرستید /cancel");
		}

		if ($textmessage == "/cancel" && strpos($admin , "$from_id") !== false || $textmessage == "/cancel" && $from_id == $sudo ) {
			save("data/admin/step.txt","none");
		SendMessage($chat_id,"کنسل شد");
		}
	
if ($textmessage == "/stats" && strpos($admin , "$from_id") !== false || $textmessage == "/stats" && $from_id == $sudo ) {
		$all = 0;
	$fp = fopen( "users.txt", 'r');
	while( !feof( $fp)) {
    		fgets( $fp);
    		$all ++;
	}
	fclose( $fp);
		$all2 = 0;
	$fp = fopen( "groups.txt", 'r');
	while( !feof( $fp)) {
    		fgets( $fp);
    		$all2 ++;
	}
	fclose( $fp);
		$all3 = 0;
	$fp = fopen( "supergroups.txt", 'r');
	while( !feof( $fp)) {
    		fgets( $fp);
    		$all3 ++;
	}
	fclose( $fp);
	
	$all4 = $all + $all2 + $all3;
var_dump(makereq('sendmessage',[
            'chat_id'=>$chat_id,
  "text" => 'امار تبچی شما',
'reply_markup' =>json_encode([
'inline_keyboard'=>[
	                [
                    ['text' => "آمار اعضا👤", 'callback_data'=>'nolock'],['text' => "$all", 'callback_data'=>'nolock']
                ],
		                [
                    ['text' => "آمار گروه ها👥", 'callback_data'=>'nolock'],['text' => "$all2", 'callback_data'=>'nolock']
                ],
			                [
                    ['text' => "آمار سوپر گروه ها👥", 'callback_data'=>'nolock'],['text' => "$all3", 'callback_data'=>'nolock']
                ],
				                [
                    ['text' => "جمع کل👥", 'callback_data'=>'nolock'],['text' => "$all4", 'callback_data'=>'nolock']
                ]
]
			])
		]));
}unlink("error_log");

	/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
?>
