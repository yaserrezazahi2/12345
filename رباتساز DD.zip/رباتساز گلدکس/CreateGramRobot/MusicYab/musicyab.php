/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/<?php
ob_start();
ini_set('max_execution_time', 99999999);

set_time_limit(99999999);

$channel = '[*[CHANNEL]*]';

define('API_KEY','[*[TOKEN]*]');
//---------------ch_robotsazi-----------------//
function robot($method,$datas=[]){
	$url = "https://api.telegram.org/bot".API_KEY."/".$method;
	$ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function SendMessage($chat_id, $text){
robot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
 function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function sendphoto($chat_id, $photo, $caption){
 robot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
function Forward($kojashe, $azkoja, $kodommsg){
	robot('forwardmessage',[
	'chat_id'=>$kojashe,
	'from_chat_id'=>$azkoja,
	'message_id'=>$kodommsg
	]);
}
function sendaudio($chatid,$audio,$caption){
    robot('sendaudio',[
        'chat_id'=>$chatid,
        'audio'=>$audio,
        'caption'=>$caption
    ]);
}
function Sendaction($chat_id,$action){
robot('Sendchataction',[
'chat_id'=>$chat_id,
'action'=>$action,
]);
}
function IranTime(){
        date_default_timezone_set("Asia/Tehran");
        return date('H:i:s');
    }
//--------ch_robotsazi---------//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
mkdir("data/$from_id");
mkdir("data/$chat_id");
mkdir("data");
$message_id = $message->message_id;
$from_id = $message->from->id;
$first_name = $message->from->first_name;
$username = $message->from->username;
$textmassage = $message->text;
$message_id = $update->message->message_id;
$data = $update->callback_query->data;
$message_id2 = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$firstname = $update->callback_query->from->first_name;
$inline = $update->inline_query->query;
$inline_id=$update->callback_query->inline_message_id;
$forward_chat = $update->message->forward_from_chat->username;
$zaman = IranTime();
$ADMINS = array(244939302,546600456);
$userbot = "@[*[BOT]*]";
$ADMIN = [*[ADMIN]*];
$ali = file_get_contents("data/$from_id/ali.txt");
$mention = "<a href='tg://user?id=$from_id'>$first_name</a>";
$left = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$channel&user_id=$from_id"));
$tch = $left->result->status;
$forchannelq = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$channel&user_id=$fromid"));
$tchq = $forchannelq->result->status;
//--------------mac_team-------------//
if($left == "left"){
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ شما عضو کانال ما نیستید ⛔

💠 برای ادامه کار با ربات باید عضو کانال 
نیو ربات بشوید .

🚫 جهت عضویت روی دکمه بررسی عضویت کلیک کنید
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"📢 عضویت در کانال",'url'=>"https://t.me/$channel"],['text'=>"بررسی عضویت",'callback_data'=>'lockch']
],
]
])
]);
}
elseif($textmassage == "/start"){
$user = file_get_contents('Member.txt');
    $members = explode("\n",$user);
    if (!in_array($from_id,$members)){
      $add_user = file_get_contents('Member.txt');
      $add_user .= $from_id."\n";
     file_put_contents('Member.txt',$add_user);
    }
robot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"  سلام $mention به ربات ترانه یاب خوش آمدی
 این بات میتواند آهنگ خواننده موردنظرت رو در دوکیفیت دانلود کنه
<a href='tg://user?id=$ADMIN'>|MusicYab|</a>",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"موزیک های جدید"],['text'=>"جستجو در رادیو جوان"]
],
[
['text'=>"جستجو در نکس وان"]
],
]
])
]);
}
elseif($data == "lockch"){
$mentionn = "<a href='tg://user?id=$fromid'>$firstname</a>";
if($tchq == 'member' or $tchq == 'creator' or $tchq == 'administrator'){
robot('sendmessage',[
	'chat_id'=>$chatid,
'text'=>"  سلام $mention به ربات ترانه یاب خوش آمدی
 این بات میتواند آهنگ خواننده موردنظرت رو در دوکیفیت دانلود کنه
<a href='tg://user?id=$ADMIN'>|MusicYab|</a>",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"موزیک های جدید"],['text'=>"جستجو در رادیو جوان"]
],
[
['text'=>"جستجو در نکس وان"]
],
]
])
]);
}else{
        robot('answercallbackquery',[
            'callback_query_id' => $update->callback_query->id,
            'text' => "❌ هنوز داخل کانال عضو نیستید",
            'show_alert' =>true
        ]);
}
}
elseif(strpos($textmassage, '/start') !== false){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
    $id31 = str_replace("/start ", "",$textmassage);
    $smn1 = json_decode(file_get_contents("http://webservice.lorddeveloper.ir/nex1music?id=$id31"));
$cov = $smn1->cover;
$dl128 = $smn1->dl128;
$dl320 = $smn1->dl320;
robot('Sendphoto',[
'chat_id'=>$chat_id,
'photo'=>"$cov",
'caption'=>"
🆔 $userbot",
]);
$rand = rand(1,99999);
file_put_contents("data/$rand.mp3",file_get_contents("$dl320"));
sendAction($chat_id,'upload_audio');
robot('Sendaudio',[
'chat_id'=>$chat_id,
'audio'=>new CURLFile("data/$rand.mp3"),
'caption'=>"
📥 download 320p
🆔 $userbot",
]);
$rand1 = rand(1,99999);
file_put_contents("data/$rand1.mp3",file_get_contents("$dl128"));
sendAction($chat_id,'upload_audio');
robot('Sendaudio',[
'chat_id'=>$chat_id,
'audio'=>new CURLFile("data/$rand1.mp3"),
'caption'=>"
📥 download 128p
🆔 $userbot",
]);
unlink("data/$rand.mp3");
unlink("data/$rand1.mp3");
}else{
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"شما هنوز در کانال ما عضو نشدید 😶

لطفا روی دکمه عضویت در کانال کلیک کنید و بعد روی بررسی عضویت 😸",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"📢 عضویت در کانال",'url'=>"https://t.me/$channel"],['text'=>"بررسی عضویت",'callback_data'=>'lockch']
],
]
])
]);
}
}
elseif($textmassage == "جستجو در نکس وان"){
file_put_contents("data/$from_id/ali.txt","searchn");
robot('sendmessage',[
	'chat_id'=>$chat_id,
		'text'=>" 📍 لطفا نام خواننده موردنظر خود را ارسال کنید 

🇺🇸 به صورت انگلیسی: mehdi jahani
🇮🇷 به صورت فارسی: مهدی جهانی",
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
])
]);
}
elseif($ali == "searchn"){
$text1 = str_replace(" ","+",$textmassage);
$smn = json_decode(file_get_contents("http://webservice.lorddeveloper.ir/nex1music?q=$text1"));
for($i=0;$i<=$count;$i++){
$title2[$i] = $smn->results[$i]->title;
$id3[$i] = $smn->results[$i]->id;
$count = $smn->count;
$key[] = [['text'=>"🎤 $title2[$i]",'callback_data'=>"dlm|$from_id|$id3[$i]"]];
}
}
if($title2[0] != ''){
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"تعداد $count موزیک پیدا شد 🎤",
'reply_markup'=>json_encode([
'inline_keyboard'=>$key
])
]);
}
if(strpos($data,"dlm|") !== false){
$ex = explode("|",$data);
$key = $ex[1];
$id4 = $ex[2];
robot('answercallbackquery',[
            'callback_query_id' => $update->callback_query->id,
            'text' =>"درخواست شما ثبت شد ✅ در حال ارسال ...",
            'show_alert' => false
]);
robot('editmessagetext',[
'chat_id'=>$chatid,
'message_id'=>$message_id2,
'text'=>"بزودی موزیک مورد نظر ارسال میشود",
]);
$smn1 = json_decode(file_get_contents("http://webservice.lorddeveloper.ir/nex1music?id=$id4"));
$cov = $smn1->cover;
$dl128 = $smn1->dl128;
$dl320 = $smn1->dl320;
robot('Sendphoto',[
'chat_id'=>$chatid,
'photo'=>"$cov",
'caption'=>"
🆔 $userbot",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
        [
            ['text'=>"اشتراک گذاری",'switch_inline_query'=>"send|$id4"
                ]]]
    
    ])
]);
$rand = rand(1,99999);
file_put_contents("data/$rand.mp3",file_get_contents("$dl320"));
sendAction($chatid,'upload_audio');
robot('Sendaudio',[
'chat_id'=>$chatid,
'audio'=>new CURLFile("data/$rand.mp3"),
'caption'=>"
📥 download 320p
🆔 $userbot",
]);
$rand1 = rand(1,99999);
file_put_contents("data/$rand1.mp3",file_get_contents("$dl128"));
sendAction($chatid,'upload_audio');
robot('Sendaudio',[
'chat_id'=>$chatid,
'audio'=>new CURLFile("data/$rand1.mp3"),
'caption'=>"
📥 download 128p
🆔 $userbot",
]);
unlink("data/$rand.mp3");
unlink("data/$rand1.mp3");
robot('sendmessage',[
	'chat_id'=>$chatid,
		'text'=>"

📎 این بات میتونه آهنگ خواننده موردنظر رو در دوکیفیت دانلود کنه

لطفا انتخاب کنید ⏳",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"موزیک های جدید"],['text'=>"جستجو در رادیو جوان"]
],
[
['text'=>"جستجو در نکس وان"]
],
]
])
]);
}
elseif($textmassage  == "موزیک های جدید"){
$nmusic = json_decode(file_get_contents("https://Api.MahdiElvis.ir/music"));
for($i=0;$i<=14;$i++){
$title1[$i] = $nmusic->result[$i]->title;
$art[$i] = $nmusic->result[$i]->artist;
$url[$i] = $nmusic->result[$i]->url;
$keyn[] = [['text'=>"🎤 $art[$i] - $title1[$i]",'url'=>"$url[$i]"]];
}
}
if($title1[0] != ''){
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"موزیک های جدید در لیست زیر میباشد 📻",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'inline_keyboard'=>$keyn
])
]);
}
elseif($textmassage == "جستجو در رادیو جوان"){
file_put_contents("data/$from_id/ali.txt","searchmr");
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا نام خواننده موردنظر خود را ارسال کنید 😎
مثال:
1- 🇺🇸 به زبان انگلیسی: Mehdi jahani",
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
])
]);
}
elseif($ali == "searchmr"){
file_put_contents("data/$from_id/ali.txt","no");
$text2 = str_replace(" ","+",$textmassage);
$smo = json_decode(file_get_contents("https://apprdjvn.com/api2/search?query=$text2"));
for($i=0;$i<=14;$i++){
$title[$i] = $smo->mp3s[$i]->title;
$id2[$i] = $smo->mp3s[$i]->id;
$dls[$i] = $smo->mp3s[$i]->downloads;
$key[] = [['text'=>"$title[$i]",'callback_data'=>"dlm1|$from_id|$id2[$i]"]];
}
}
if($title[0] != ''){
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🎈 لیست موزیک های جستجو شده
",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>$key
])
]);
}
if(strpos($data,"dlm1|" ) !== false ) {
$ex = explode("|",$data);
$key = $ex[1];
$id3 = $ex[2];
robot('editmessagetext',[
'chat_id'=>$chatid,
'message_id'=>$message_id2,
'text'=>"بزودی موزیک مورد نظر ارسال میشود",
]);
$smo1 = json_decode(file_get_contents("https://apprdjvn.com/api2/mp3?id=$id3"));
$title = $smo1->title;
$link = $smo1->link;
$photo = $smo1->photo;
$plays = $smo1->plays;
$like = $smo1->likes;
$dislike = $smo1->dislikes;
robot('Sendphoto',[
'chat_id'=>$chatid,
'photo'=>"$photo",
'caption'=>"🎼 *$title*\n🎧 *$plays*\n❤ *$like*\n👎 *$dislike*",
'parse_mode'=>"markdown",
]);
robot('Senddocument',[
'chat_id'=>$chatid,
'document'=>"$link",
'caption'=>"🎼 *$title*\n🎧 *$plays*\n❤ *$like*\n👎 *$dislike*",
'parse_mode'=>"markdown",
]);
robot('sendmessage',[
	'chat_id'=>$chatid,
		'text'=>"

📎 این بات میتونه آهنگ خواننده موردنظر رو در دوکیفیت دانلود کنه

لطفا انتخاب کنید ⏳",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"موزیک های جدید"],['text'=>"جستجو در رادیو جوان"]
],
[
['text'=>"جستجو در نکس وان"]
],
]
])
]);
}
//-------------Phpmans--------------//
elseif($textmassage == "/panel" && in_array($from_id,$ADMINS)){
robot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
مدیر گرامی به پنل مدیریتی خود خوش آمدی 💞",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"📊 آمار",'callback_data'=>'amar'],['text'=>"📨 فروارد همگانی",'callback_data'=>'forw']
],
]
])
]); 
}
if($data == "amar"){
$user = file_get_contents("Member.txt");
    $member_id = explode("\n",$user);
    $countm = count($member_id) -1;
robot('editmessagetext',[
'chat_id'=>$chatid,
'message_id'=>$message_id2,
'text'=>"
📍 آمار کاربران تا ساعت $zaman

$countm ممبر میباشد",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"برگشت↪",'callback_data'=>'bk3']
],
]
])
]);
}
elseif($data == "bk3"){
file_put_contents("data/$chatid/ali.txt","no");
robot('editmessagetext',[
'chat_id'=>$chatid,
'message_id'=>$message_id2,
'text'=>"
برگشتیم مدیر جان چکار کنیم انتخاب کن 😎",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"📊 آمار",'callback_data'=>'amar'],['text'=>"📨 فروارد همگانی",'callback_data'=>'forw']
],
]
])
]);
}
if($data == "forw"){
    file_put_contents("data/$chatid/ali.txt","fc");
 robot('editmessagetext',[
    'chat_id'=>$chatid,
'message_id'=>$message_id2,
    'text'=>"📍 پیام مورد خود را فوروارد کنید",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"برگشت↪",'callback_data'=>'bk3']
],
]
])
]);
}
elseif($ali == "fc"){
    file_put_contents("data/$chat_id/ali.txt","no");
robot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" پیام همگانی فرستاده شد.",
  ]);
 $all_member = fopen( "Member.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
Forward($user, $chat_id,$message_id);
    }
}
elseif(strpos($inline,"send|")!== false){
    $ex = explode("|",$inline);
    $id22 = $ex[1];
    $smn1 = json_decode(file_get_contents("http://webservice.lorddeveloper.ir/nex1music?id=$id22"));
$cov = $smn1->cover;
robot('answerInlineQuery', [
        'inline_query_id' => $update->inline_query->id,
        'results'=>json_encode([[
            'type' => 'photo',
             'thumb_url'=>"$cov",
            'id' => base64_encode(rand(5,555)),
            'title' =>"لینک دانلود",
            'description' =>"برای ارسال کلیک کنید",
            'photo_url' =>"$cov",
            'caption'=>"$userbot
            ",
'parse_mode'=>'Markdown',
            'reply_markup' => [
                'inline_keyboard' => [
                    [
                        ['text' => "دانلود موزیک", 'url'=>"https://t.me/taranahyabrobot?start=$id22"]
            ],
            [
                ['text'=>"اشتراک گذاری",'switch_inline_query'=>"send|$id22"
                    ]]
                    ]
                    ]
                    ]
                
        ])
    ]);
}
unlink("error_log");
?>/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/