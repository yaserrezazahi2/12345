﻿/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/<?php

$lange = file_get_contents("data/$chat_id/lang.txt");
$tabli = "_________________ \n🎭channel: @$channel \n 💳shop: @$channel";
$tablig = "_________________ \n🎭کانال ما: @$channel \n 💳فروشگاه: @$channel";
//###########################english###########################//
if($lange == "en")
{
	$poster = "^$text^ Done. \n $tabli";
	//#######status#########//
	$posterr = "^$text^ it was already done. \n $tabli";
}
//###########################persian###########################//
//if($lange == "fa")
else
{
	$poster = "^$text^ انجام شد. \n $tablig";
	//#######status#########//
	$posterr = "^$text^ از قبل انجام شده بود. \n $tablig";
}
//###############set lang###############//
if(strpos($text,'/setlang') !==false && $type == "supergroup")
{
	if($rank == "creator" or $rank == "administrator")
	{	
		$langesets = str_replace("/setlang ","",$text);

		if($langesets == "fa")
		{
			sendmessage($chat_id,"زبان به فارسی تغیر یافت. \n $tablig");
			file_put_contents("data/$chat_id/lang.txt","fa");
		}
		elseif($langesets == "en")
		{
			sendmessage($chat_id,"languge set to english. \n $tabli");
			file_put_contents("data/$chat_id/lang.txt","en");
		}
		else
		{
			sendmessage($chat_id,"please select en or fa.\n لطفا یکی از کلمات en یا fa را انتخاب کنید.");
		}
	}
}

?>/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/