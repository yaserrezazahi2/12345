<?php
/*
AftabDeveloper | SudoMojtaba
*/
set_time_limit(0);
ob_start();
include("jdf.php");
$API_KEY = '[*[TOKEN]*]';
$admin = "[*[ADMIN]*]";
$sup = "[*[SUP]*]";
$BOT_ID = "[*[BOT]*]";
define('API_KEY',$API_KEY);
// === Functions === //
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_POSTFIELDS, $datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}}
function SendMessage($chat_id,$text,$mode,$keyboard,$reply,$disable='true'){
return bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>$mode,
'reply_to_message_id'=>$reply,
'disable_web_page_preview'=>$disable,
'reply_markup'=>$keyboard
]);
}
function EditMessage($chat_id,$message_id,$text,$mode,$keyboard){
return bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>$text,
'parse_mode'=>$mode,
'reply_markup'=>$keyboard
]);    
}
function DeleteMessage($chat_id,$message_id){
return bot('deletemessage', [
'chat_id'=>$chat_id,
'message_id'=>$message_id,
]);
}
function SendAction($chat_id,$action){
return bot('SendChatAction',[
'chat_id'=>$chat_id,
'action'=>$action
]);
}
function Forward($KojaShe,$AzKoja,$KodomMSG){
return bot('ForwardMessage',[
'chat_id'=>$KojaShe,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
function SendPhoto($chat_id,$photo,$keyboard,$caption,$reply){
return bot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption
]);
}
function SendAudio($chatid,$audio,$keyboard,$caption,$reply,$title,$sazande){
return bot('SendAudio',[
'chat_id'=>$chatid,
'audio'=>$audio,
'caption'=>$caption,
'performer'=>$sazande,
'title'=>$title,
'reply_to_message_id'=>$reply,
'reply_markup'=>$keyboard
]);
}
function SendDocument($chatid,$document,$keyboard,$caption,$reply){
return bot('SendDocument',[
'chat_id'=>$chatid,
'document'=>$document,
'caption'=>$caption,
'reply_to_message_id'=>$reply,
'reply_markup'=>$keyboard
]);
}
function SendSticker($chatid,$sticker,$keyboard,$reply){
return bot('SendSticker',[
'chat_id'=>$chatid,
'sticker'=>$sticker,
'reply_to_message_id'=>$reply,
'reply_markup'=>$keyboard
]);
}
function SendVideo($chatid,$video,$keyboard,$caption,$reply,$duration){
return bot('SendVideo',[
'chat_id'=>$chatid,
'video'=>$video,
'caption'=>$caption,
'reply_to_message_id'=>$reply,
'duration'=>$duration,
'reply_markup'=>$keyboard
]);
}
function SendVideoNote($chat_id,$videonote,$keyboard,$reply){
return bot('SendVideoNote',[
'chat_id'=>$chat_id,
'video_note'=>$videonote,
'reply_to_message_id'=>$reply,
'reply_markup'=>$keyboard
]);    
}
function SendVoice($chatid,$voice,$keyboard,$caption,$reply){
return bot('SendVoice',[
'chat_id'=>$chatid,
'voice'=>$voice,
'caption'=>$caption,
'reply_to_message_id'=>$reply,
'reply_markup'=>$keyboard
]);
}
function AnswerCallbackQuery($callback_id,$text,$show_alert){
return bot('AnswerCallbackQuery',[
'callback_query_id'=>$callback_id,
'text'=>$text,
'show_alert'=>$show_alert
]);    
}
function EditReplyMarkup($chat_id,$message_id){
bot('editMessageReplyMarkup',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'reply_markup'=>''
]);
}
function getChat($chat_id){
return bot('getChat',[
'chat_id'=>$chat_id    
]);    
}
function getChatMember($chat_id,$user_id){
return bot('getChatMember',[
'chat_id'=>$chat_id,
'user_id'=>$user_id
])->result->status;
}
function objectToArrays($object){
if(!is_object($object) && !is_array($object)){
return $object;
}
if(is_object($object)){
$object = get_object_vars($object);
}
return array_map("objectToArrays",$object);
}
function save($filename,$TXTdata){
$myfile = fopen($filename,"w") or die("Unable to open file!");
fwrite($myfile,"$TXTdata");
fclose($myfile);
}
function add_txt($filename,$TXTdata){
$myfile = fopen($filename,"a") or die("Unable to open file!");
fwrite($myfile,"$TXTdata");
fclose($myfile);
}
function top($number,$file){ 
$saveusers = array(); 
$usersscan = scandir("user"); 
unset($usersscan[0]); 
unset($usersscan[1]); 
foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("user/$savetojs/$file.txt"); 
$saveusers[$savetojs] = $savedis; 
} 
$rating = $saveusers; 
arsort($rating,SORT_NUMERIC);  
$rate = array();  
foreach($rating as $key=>$value){  
$rate[] = $key;  
}  
return $rate[$number];  
}
function GetRank($fadmin,$file){  
$saveusers = array(); 
$usersscan = scandir("user"); 
unset($usersscan[0]); 
unset($usersscan[1]); 
foreach($usersscan as $savetojs){ 
$savedis = file_get_contents("user/$savetojs/$file.txt"); 
$saveusers[$savetojs] = $savedis; 
} 
$rating = $saveusers; 
if(isset($rating[$fadmin])){  
arsort($rating,SORT_NUMERIC);  
$rate = array();  
foreach($rating as $key=>$value){  
$rate[] = $key;  
}  
$flipped = array_flip($rate);  
return $flipped[$fadmin]+1;  
}else{  
return false;  
}}
function Random($lenght){
$small = 'abcdefghijklmnopqrstuvwxyz'; 
$caps  = strtoupper($small);
$numerics   = '1234567890';
$container = $small.$caps.$numerics;
$password = '';
for($i = 0;$i < $lenght;$i++){
$_rand = rand(0,strlen($container)-1);
$password .= substr($container, $_rand, 1);
}
return $password;
}
// === Variables === //
// Keyboards
$keyboard = json_encode([
'keyboard'=>[
     [
    ['text' => "🌟دریافت بازدید رایگان"],['text' =>"ثبت سفارش📝"]
    ],
        [
    ['text' => "فروشگاه🛍"],['text' =>"بهترین اعضا💯"],['text' => "پشتیبانی☎️"]
    ],
        [
    ['text' => "زیرمجموعه گیری👥"],['text' => "پروفایل من🔻"],['text' => "📊 پیگیری سفارشات"]
    ],
        [
    ['text' => "عابر بــانڪ🏦"], ['text' => "قوانین ثبت🚫"], ['text' => "⏰بازدید فوری"]
    ],
       ]
     ]);
$admin_keyboard = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📊 آمار کلی ربات"]],
[['text'=>"پیام همگانی 📩"],['text'=>"📌 فوروارد همگانی"]],
[['text'=>"بن کردن کاربر 🚫"],['text'=>"✅ آنبن کردن کاربر"]],
[['text'=>"تنظیم کانال جوین اجباری 🔊"],['text'=>"📢 تنظیم کانال تبلیغات"]],
[['text'=>"سکه همگانی 👥"],['text'=>"💰 سکه به کاربر"]],
[['text'=>"🔝 برترین کاربران"]],
[['text'=>"بازگشت"],['text'=>"تنظیم ایدی پشتیبانی😎"]]
]
]);

$freecoin_keyboard = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"مشاهده تبلیغ درون کانال"]],
[['text'=>"بازگشت"],['text'=>"سکه روزانه"]]
]
]);
$submit_ad_keyboard = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"خیر"],['text'=>"بله"]]    
]
]);
$back = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"انصراف"]]]
]);
$back_admin = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"برگشت به منوی مدیریت"]]]
]);
// Input
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_from = $message->forward_from;
$forward_from_chat = $message->forward_from_chat;
$forward_id = $forward_from->id;
$forward_name = $forward_from->first_name;
$text = $message->text;
$reply_message_id = $update->callback_query->message->reply_to_message->message_id;
$reply = $update->message->reply_to_message;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$fromid = $update->callback_query->from->id;
$callback_id = $update->callback_query->id;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
$caption = $message->caption;
// File IDs
$stickerid = $message->sticker->file_id;
$videoid = $message->video->file_id;
$voiceid = $message->voice->file_id;
$fileid = $message->document->file_id;
$photo = $message->photo;
$photoid = $photo[count($photo)-1]->file_id;
$musicid = $message->audio->file_id;
$music_name = $message->audio->title;
$videonoteid = $message->video_note->file_id;
// User Variables
@$command = file_get_contents("user/$from_id/command.txt");
@$wait = file_get_contents("user/$from_id/wait.txt");
@$adminidd = file_get_contents("data/poshtibani.txt");
@$coin = file_get_contents("user/$from_id/coin.txt");
@$coin_call = file_get_contents("user/$fromid/coin.txt");
@$user_members = file_get_contents("user/$from_id/members.txt");
@$date_user = explode("\n",file_get_contents("user/$from_id/date.txt"));
@$user_date = $date_user[0];
@$date_coin = $date_user[1];
@$day_post = file_get_contents("user/$from_id/day post.txt");
@$day_members = file_get_contents("user/$from_id/day members.txt");
@$members_coin = file_get_contents("user/$from_id/members coin.txt");
@$user_ads = file_get_contents("user/$from_id/ads.txt");
@$received = file_get_contents("user/$from_id/received.txt");
@$sended = file_get_contents("user/$from_id/sended.txt");
@$send_users = file_get_contents("user/$from_id/send users.txt");
// Other Variables
$bot_username = bot('getMe')->result->username;
@$list = file_get_contents("Member.txt");
@$submit_post = file_get_contents("data/submit posts.txt");
@$end_post = file_get_contents("data/end posts.txt");
@$channel = file_get_contents("data/channel.txt");
@$channel = str_replace('@','',$channel);
@$channel_join = file_get_contents("data/join channel.txt");
@$ban = file_get_contents("data/ban.txt");
$mch = file_get_contents("data/mch.txt");
$time = jdate("h : i : s");
$date = jdate("Y F d");
$bot_date = date('Ymd');
$code = Random(rand(8,12));
$variable_text = "<i>📌 میتوانید از متغیر های زیر استفاده کنید 👇🏻</i>
- <code>FIRSTNAME</code> » نام کاربر
- <code>LASTNAME</code> » نام آخر کاربر
- <code>USERNAME</code> » نام کاربری کاربر
- <code>USERID</code> » شناسه عددی کاربر
- <code>DATE</code> » تاریخ درخواست
- <code>TIME</code> » زمان درخواست";
// === Start Source === //
if(!file_exists("ads")){
mkdir("ads");
mkdir("ads/admin");
mkdir("ads/msg id");
mkdir("ads/count");
mkdir("ads/seen");
mkdir("ads/user");
}
if($message != null){
mkdir("user/$from_id");
mkdir("user/$from_id/transfers");
}
if(strpos($ban,$from_id) !== false or strpos($ban,$fromid) !== false){
return false;
}
elseif(getChatMember($channel_join,$from_id) == 'left'){
SendAction($chat_id,typing);
SendMessage($chat_id,"️کاربر عزیز شما برای استفاده از بهترین امکانات  سین باید در کانال اطلاع رسانی عضو شوید تا از اخبار،چالشات،پورسانت و تخفیفات باخبر شوید.👇
- - - - - - - - - - - - - - - - - - - - - - - - -
🆔 $channel_join
- - - - - - - - - - - - - - - - - - - - - - - - -
⁉️لطفا پس از عضویت /start را فشار دهید تا دکمه های ربات برای شما نمایان شود",'HTML',json_encode(['inline_keyboard'=>[[['text'=>" برای عضویت در کانال کلیک کنید🌐",'url'=>"https://telegram.me/$channel"]]]]));
}
elseif($text == "/start"){
SendAction($chat_id,typing);
$members = explode("\n",$list);
if(!in_array($from_id,$members)){
add_txt('Member.txt',"$from_id\n");
save("user/$from_id/members.txt",0);
save("user/$from_id/coin.txt","20");
save("user/$from_id/date.txt","$bot_date\nnone");
save("user/$from_id/day post.txt",0);
save("user/$from_id/day members.txt",0);
save("user/$from_id/members coin.txt",0);
}
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅سلام به ربات تخصصی  ای بازدید سین خوش امدید
🔆 شما در  سین میتوانید:

✅ تا حالا شده بخواید تو یه چالش برنده بشید؟ یا این که بازدید پست های کانالتون رو بالا ببرین ؟!

💯 بازدیدها با این موضوع به شما کمک میکند تا به راحتی چالش هایتان را برنده شوید؛ و بازدید پست های کانالتان را بالا ببرید. کانال تبلیغات و دریافت سکه @$channel است با عضویت و ثبت بازدید سکه بگیرید و با کمترین زمان ممکن سفارشات خود را بازدید بزنید.

♻️ شما در  سین تبلیغات دیگران را دیده و ثبت بازدید میکنید و به میزان تأیین شده سکه دریافت میکنید و تبلیغات خودتان را ثبت مینمایید; سین رباتی برنامه نویسی شده میباشد که الگوریتم این ربات مبنی بر گسترده بودن  شما در کانال تبلیغاتی که تأیین شده میتوانید عضو شده و از جدید ترین تبلیغات پورسانت بگیرید.

⁉️ اگه به توضیحات بیشتری نیاز دارید دستور /help را به ربات بفرستید.
همچنین برای اطلاع از جدیدترین اخبار و بروزرسانی ها حتما عضو کانال ما @$channel_join بشید!
ض
⚠️ در ضمن اگر سوال،انتقاد یا پیشنهادی جهت آپدیت سین داشتید میتوانید /support را فشار دهید و به صورت مستقیم با مدیریت  در میان بگذارید.

🚨 توجه: تمامی بازدید های دریافت شده توسط تبلیغات شما در کانال تبلیغات  قرار گرفته و توسط کاربرانی کاملا واقعی بازدید",'HTML',$keyboard,$message_id);
return;
}
elseif(strpos($text,'/start ref-') !== false && $forward_chat_username == null){
SendAction($chat_id,typing);
SendMessage($chat_id,"✅سلام به ربات تخصصی  سین خوش امدید.
🔆 شما در  سین میتوانید:

✅ تا حالا شده بخواید تو یه چالش برنده بشید؟ یا این که بازدید پست های کانالتون رو بالا ببرین ؟!

💯 بازدیدها با این موضوع به شما کمک میکند تا به راحتی چالش هایتان را برنده شوید؛ و بازدید پست های کانالتان را بالا ببرید. کانال تبلیغات و دریافت سکه @$channel است با عضویت و ثبت بازدید سکه بگیرید و با کمترین زمان ممکن سفارشات خود را بازدید بزنید.

♻️ شما در  سین تبلیغات دیگران را دیده و ثبت بازدید میکنید و به میزان تأیین شده سکه دریافت میکنید و تبلیغات خودتان را ثبت مینمایید; سین رباتی برنامه نویسی شده میباشد که الگوریتم این ربات مبنی بر گسترده بودن  شما در کانال تبلیغاتی که تأیین شده میتوانید عضو شده و از جدید ترین تبلیغات پورسانت بگیرید.

⁉️ اگه به توضیحات بیشتری نیاز دارید دستور /help را به ربات بفرستید.
همچنین برای اطلاع از جدیدترین اخبار و بروزرسانی ها حتما عضو کانال ما @$channel_join بشید!

⚠️ در ضمن اگر سوال،انتقاد یا پیشنهادی جهت آپدیت سین داشتید میتوانید /support را فشار دهید و به صورت مستقیم با مدیریت  در میان بگذارید.

🚨 توجه: تمامی بازدید های دریافت شده توسط تبلیغات شما در کانال تبلیغات  قرار گرفته و توسط کاربرانی کاملا واقعی بازدی",'HTML',$keyboard,$message_id);
$newid = str_replace("/start ref-","",$text);
if(!in_array($from_id,explode("\n",$list))){
$newid_coin = file_get_contents("user/$newid/coin.txt");
$newid_members = file_get_contents("user/$newid/members.txt");
save("user/$newid/coin.txt",$newid_coin + 15);
save("user/$newid/members.txt",$newid_members + 1);
save("user/$from_id/inviter.txt",$newid);
$members = explode("\n",$list);
if(!in_array($from_id,$members)){
add_txt('Member.txt',"$from_id\n");
save("user/$from_id/members.txt",0);
save("user/$from_id/coin.txt",20);
save("user/$from_id/day post.txt",0);
save("user/$from_id/members coin.txt",30);
save("user/$from_id/day members.txt",0);
save("user/$from_id/date.txt","$bot_date\nnone");
}
save("user/$from_id/command.txt",'none');
SendMessage($newid,"💰تــــبریک یک زیرمجموعه کسب شد!!

♦️یک کاربر با لینک فعالسازی زیرمجموعه شما وارد ربات  سین شد و 30 بازدید ارزشمند دریافت کردید. و از این پس 20 درصد فعالیت ایشون به شما داده میشه");
return;
}}
if(file_exists("user/$from_id/date.txt") && $user_date != $bot_date && $message != null){
save("user/$from_id/date.txt",str_replace($user_date,$bot_date,$user_date)."\n".$date_coin);
save("user/$from_id/day post.txt",0);
save("user/$from_id/day members.txt",0);
}
// === Submit Seen ( Channel ) === //
elseif(strpos($data,"submit seen") !== false && file_exists("user/$fromid")){
$ad = str_replace("submit seen-",'',$data);
$count = file_get_contents("ads/count/$ad.txt");
$seen = file_get_contents("ads/seen/$ad.txt");
$user = explode("\n",file_get_contents("ads/user/$ad.txt"));
$admin = file_get_contents("ads/admin/$ad.txt");
$msg_id = file_get_contents("ads/mag id/$ad.txt");
if(in_array($fromid,$user)){
AnswerCallbackQuery($callback_id,"🚫 شما قبلا از این تبلیغ سکه گرفته اید!");    
}else{
add_txt("ads/user/$ad.txt","$fromid\n");
save("ads/seen/$ad.txt",$seen + 1);
save("user/$fromid/coin.txt",$coin_call + 0.9);
$coin_call = file_get_contents("user/$fromid/coin.txt");
$day_post = file_get_contents("user/$fromid/day post.txt");
save("user/$fromid/day post.txt",$day_post + 1);
if(file_exists("user/$fromid/inviter.txt")){
$newid = file_get_contents("user/$fromid/inviter.txt");
$coin = file_get_contents("user/$newid/coin.txt");
$member_coin = file_get_contents("user/$newid/members coin.txt");
save("user/$newid/coin.txt",$coin + 0.1);
save("user/$newid/members coin.txt",$member_coin + 0.1);
}
AnswerCallbackQuery($callback_id,"✅ موفقیت آمیز | موجودی شما : $coin_call سکه");
$seen = file_get_contents("ads/seen/$ad.txt");
}
if($seen >= $count){
DeleteMessage("@$channel",$reply_message_id);
DeleteMessage("@$channel",$messageid);
save("ads/seen/$ad.txt",$count);
save("data/submit posts.txt",$submit_post - 1);
save("data/end posts.txt",$end_post + 1);
$msg_id = Forward($admin,$msg_id,$admin)->result->message_id;
SendMessage($admin,"✅ تکمیل بازدید درخواستی!!

⁉️تبلیغ شما با تعداد بازدید $seen/$coin با کد پیگیری /ord$code با موفقیت به پایان رسید جهت ثبت دوباره سفارشات خود اقدام کنید.",'HTML','',$msg_id);
save("ads/all ads.txt",str_replace("$ad\n",'',file_get_contents("ads/all ads.txt")));
unlink("ads/admin/$ad.txt");
unlink("ads/user/$ad.txt");
}}
elseif(strpos($data,"report post") !== false && file_exists("user$fromid")){
$ad = str_replace("report post-",'',$data);
$block_reports = explode("\n",file_get_contents("data/block reports.txt"));
if(in_array($fromid,$block_reports)){
AnswerCallbackQuery($callback_id,"شما نمیتوانید گزارش کنید!",'false');    
}else{
AnswerCallbackQuery($callback_id,"گزارش شما با موفقیت ثبت شد!",'false');
$msg_id = Forward($admin,"@$channel",$reply_message_id)->result->message_id;
SendMessage($admin,"🚫 پست جدیدی گزارش شد!

👆🏻 پست را میتوانید در بالا ببینید ...

➖ یک گزینه را انتخاب کنید :",'HTMl',json_encode(['inline_keyboard'=>[[['text'=>"حذف پست",'callback_data'=>"delete post $ad $messageid $reply_message_id"]],[['text'=>"بلاک گزارش دهنده",'callback_data'=>"block report-$fromid"]]]]),$msg_id);
}}
elseif(strpos($data,"delete post") !== false){
$data = explode(" ",$data);
$ad = $data[2];
$msgid = $data[3];
$msg_id = $data[4];
$admin = file_get_contents("ads/admin/$ad.txt");
DeleteMessage("@$channel",$msg_id);
DeleteMessage("@$channel",$msgid);
AnswerCallbackQuery($callback_id,"پست مورد نظر با موفقیت حذف شد!");
EditMessage($chatid,$messageid,"پست مورد نظر حذف شد!");
SendMessage($admin,"🚫 پشت شماره $ad از کانال تبلیغات حذف شد!");
}
elseif(strpos($data,"block report") !== false){
$user = str_replace("block report-",'',$data);
add_txt("data/block reports.txt","$user\n");
AnswerCallbackQuery($callback_id,"کاربر مورد نظر دیگر نمیتواند گزارش کند!");
EditMessage($chatid,$messageid,"کاربر مورد نظر دیگر نمیتوانید گزارش کند!");
}
elseif($text == "بازگشت" or $text == "انصراف"){
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"⁉️به منوی اصلی بازگشتید...",'HTML',$keyboard,$message_id);
}
elseif($text == "برگشت به منوی مدیریت" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ به منوی مدیریت بازگشتید !
👈🏻 یک گزینه را انتخاب کنید :",'HTML',$admin_keyboard,$message_id);
}
elseif($text == "🌟دریافت بازدید رایگان"){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","free coin");
SendMessage($chat_id,"🌐به بخش دریافت سکه رایگان خوش آمدید...
⚠️ در این جا به ازای هر تبلیغی که مشاهده میکنید 0.9 سکه دریافت میکنید، سپس میتونید با استفاده از سکه هایی که دارید از بخش ثبت سفارش در ربات تبلیغ خودتون که میتونه شامل پست کانال یا چالش و یا هر چیز دیگه ای باشه رو اضافه کنید.و منتظر تکمیل سفارش باشید.

⁉️ مشاهده تبلیغ درون کانال:
 در این روش شما جهت جمع آوری سکه میتوانید در کانال تبلیغات  سین عضو شده و از جدیدترین تبلیغات مطلع شوید و پورسانت آن هارا به میزان تأیین شده کسب کنید.

⁉️چگونه میتوانیم در کانال تبلیغات سکه جمع کنیم؟
شما جهت جمع اوری سکه با توجه به الگوریتم ربات پیشرفته  سین شما در کانالی با نشانی @$channel به عنوان کانال تبلیغات مشاهده میکنید و اگر دقت کنید تبلیغاتی بسیار در این کانال وجود دارد که هرکدام با یک ریپلای مخصوص که نشان میدهد چه مقدار بازدید درخواست این سفارش است مشخص شده؛اما زیر ریپلای دکمه هایی شیشه ای وجود دارد که ثبت بازدید به شما به میزان تأیین شده برای دیدن هر تبلیغ سکه اضافه میکند.

⁉️اکسیژن چیست؟
اکسیژن یک هدیه جهت پاسداری از فعالیت شما در  سین است شما به میزان تأیین شده و با توجه به برنامه نویسی  سین میتوانید تبلیغات را مشاهده و از سین هدیه کسب کنید.

🌐اگر هنوز سوالی دارید پشتیبانی  سین در خدمت شماست با دستور /support میتوانید به مدیریت اصلی  سین پیغام،انتقاد،سوال و یا هرگونه مشکل را اطلاع دهید.

♻️ یک روش را انتخاب کنید",'HTML',$freecoin_keyboard,$message_id);
}
elseif($text == "مشاهده تبلیغ درون کانال" && $command = "free coin"){
SendAction($chat_id,typing);    
SendMessage($chat_id,"💰در این بخش شما میتوانید:

⚜️با توجه به الگوریتم ربات  سین شما میتوانید با زدم بر روی دکمه ی شیشه ای [ثبت بازدید] به مقدار تأیین شده بازدید دریافت کرده و تبلیغات خود را ثبت کنید.
⁉️اکسیژن یک هدیه میباشد که شما هر مقدار تبلیغ دیده و ثبت بازدید را لمس کنید به شما بازدید هدیه میدهد.

🛡برای ورود به کانال تبلیغات
@$channel
کلیک کن",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"بازگشت به منوی قبل"]]]]));
}
elseif($text == "سکه روزانه" && $command = "free coin"){
SendAction($chat_id,typing);
date_default_timezone_set('Asia/Tehran');
if($bot_date == $date_coin){
SendMessage($chat_id,"⚠️ هدیه خود را دریافت کردید!
👈 شما امروز هدیه روزانه خود را دریافت کردید، جهت دریافت دوباره هدیه لطفا 24 ساعت دیگر امتحان کنید.",'HTML','',$message_id);
}else{
save("user/$from_id/command.txt","date coin");
SendMessage($chat_id,"حالا یه بسته رو به دلخواه از بین بسته های زیر (6 بسته) انتخاب کنید.
بسته به شانستون بین 10 تا 20 سکه دریافت میکنید!
 با دقت انتخاب کنید 🙂",'HTML',json_encode(['keyboard'=>[[['text'=>"1️⃣"],['text'=>"2️⃣"],['text'=>"3️⃣"]],[['text'=>"4️⃣"],['text'=>"5️⃣"],['text'=>"6️⃣"]],[['text'=>"انصراف"]]]]));
}}
elseif($command == "date coin"){
SendAction($chat_id,typing);
if($text == "1️⃣" or $text == "2️⃣" or $text == "3️⃣" or $text == "4️⃣" or $text == "5️⃣" or $text == "6️⃣"){
save("user/$from_id/command.txt",'none');
$rand = rand(10,20);
save("user/$from_id/date.txt",$user_date."\n".str_replace($date_coin,$bot_date,$date_coin));
save("user/$from_id/coin.txt",$coin + $rand);
SendMessage($chat_id,"✅ تبریک!
👈 $rand سکه هدیه روزانه از بسته شماره $text به حسابتان افزوده شد ☺️",'HTML',$keyboard,$message_id);
}else{
SendMessage($chat_id,"⚠️ یک بسته معتبر را انتخاب کنید!
👈 بسته مورد نظر خود را از روی کیبورد انتخاب کنید
 ",'HTML','',$message_id);
}}
elseif($text == "پروفایل من🔻"){
SendAction($chat_id,typing);
$members_count = count(explode("\n",$user_members))-1;
SendMessage($chat_id,"⁉️وضعیت حساب کاربری شما در  سین به صورت آنلاین👇

🆔 شناسه کاربری: $from_id
💸 مشاهده تبلیغات امروز: $day_post
👤زیرمجموعه های شما: $members_count
🗣20% پورسانت زیرمجموعه: $members_coin

✅موجودی بازدید: $coin",'HTML',json_encode(['inline_keyboard'=>[[['text'=>"به اشتراک گذاشتن کد کاربری",'url'=>"https://Telegram.me/share/url?url=$from_id&text=کد کاربری من در ربات @$bot_username"]]]]));
}
if($text=="⏰بازدید فوری"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🍃 کاربر گرامی لطفا تعداد بازدید خواسته شده را انتخواب نمایید 
♦️توجه: تمامی پرداخت ها زیر نظر بانک تأیین شده میباشد و هیچگونه اختلافی نمیتواند موجب ناراحتی پیش اید و به صورت مستقیم تحت نظارت بانک میباشد.
💎بازدید فوری در کمترین زمان ممکن پست شما با هزینه بسیار کم
 ✅لطفا یک گزینه را انتخواب نمایید👇",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=> [
[['text' => "1000 بازدید🛍 | 2000 تومان💰", 'url' => "https://t.me/$sup"]],
[['text' => "2000 بازدید🛍 | 5.500 تومان💰", 'url' => "https://t.me/$sup"]],
[['text' => "3000 بازدید🛍 | 7.000 تومان💰", 'url' => "https://t.me/$sup"]],
]
])
]);
}
if ($text == "زیرمجموعه گیری👥") {
	bot('sendMessage', [
        'chat_id'=>$update->message->chat->id,
        'text'=>"♦️در سیستم زیرمجموعه گیری جدید  سین شما با هر نفر عضو کردن با لینک مخصوص خودتون میتوانید:

1⃣- از 20 درصد پورسانت زیرمجموعه خود استفاده کنید.
2⃣- 30 بازدید به عنوان هدیه دریافت کنید.

⁉️پورسانت
پورسانتی که شما از زیرمجموعه خود میگیرید همان درصدی است که زیرمجموعه شما دکمه ثبت تبلیغ را لنس کرده و دریافت بازدید میکند شما هج درصدی از این بازدید را کسب میکنید.
اما بازدیدی از زیرمجموعه شما کسر نمیشود.!!

♦️لینک مخصوص
شما برای دریافت زیرمجموعه باید دریافت بنر را فشار دهید تا بنر شما اماده و با لینک مخصوص خودتون به دست شما برسد. و هر یک نفر با لینک مخصوص شما عضو ربات  شود از پورسانت و هدیه ی عضویت زیرمجموعه برخوردار خواهید شد.

دریافت بنر با لینک اختصاصی👇💯",
'reply_to_message_id'=>$message_id,
'reply_markup' => json_encode([
                'inline_keyboard' => [
                [
 ['text' => "💯دریافت بنر", 'callback_data' => "ba"]
                    ],
                ]
            ])
        ]);
}
 elseif ($data == "ba") {
       sendAction($chatid, 'typing');
      bot('sendphoto', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'photo'=>"ادرس عکس زیرمجموعه",
        'caption'=>"⁉️ افزایش بازدید پست های تلگرام📊
✅ زیرمجموعه گیری با 20 درصد پورسانت👥
✅ پرسرعت در تکمیلی سفارش💯
✅بهترین پروژ برنامه نویسی شده🌀
✅ همراه با هدیه عضویت 🔆
telegram.me/$BOT_ID?start=ref-$chatid",
        ]);
bot('sendmessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "
✅کاربر گرامی بنر بالا با لینک فعال سازی شماست. شما میتوانید کاربران دیگر را عضو ربات ما کنید و به میزان 30 بازدید دریافت کنید.  
🔆باتشکر تیم تخصصی !!",
]);

}
elseif($text == "ثبت سفارش📝"){
SendAction($chat_id,typing);
if($coin < 20){
SendMessage($chat_id,"موجودی شما کمتر از حد مجاز است! 
حداقل مقدار سکه مورد نیاز برای ثبت سفارش، 20 سکه میباشد.",'HTML',$keyboard,$message_id);
return;
}
save("user/$from_id/command.txt","set ad");
$btn = [];
$btn[] = [['text'=>"انصراف"]];
$btn[] = [['text'=>"ثبت بازدید دلخواه"]];
if($coin >= 20){ $btn[] = [['text'=>'درخواست 20 بازدید | 20 سکه']]; }
if($coin >= 50){ $btn[] = [['text'=>'درخواست 50 بازدید | 50 سکه']]; }
if($coin >= 100){ $btn[] = [['text'=>'درخواست 100 بازدید | 100 سکه']]; }
if($coin >= 200){ $btn[] = [['text'=>'درخواست 200 بازدید | 200 سکه']]; }
if($coin >= 500){ $btn[] = [['text'=>'درخواست 500 بازدید | 500 سکه']]; }
if($coin >= 1000){ $btn[] = [['text'=>'درخواست 1000 بازدید | 1000 سکه']]; }
if($coin >= 2000){ $btn[] = [['text'=>'درخواست 2000 بازدید | 2000 سکه']]; }
if($coin >= 5000){ $btn[] = [['text'=>'درخواست 5000 بازدید | 5000 سکه']]; }
SendMessage($chat_id,"👁‍🗨 چه تعداد بازدید میخواهید ثبت کنید؟
👈 بسته های نمایش داده شده با توجه به موجودی شما ($coin سکه) هستند.

⭕️ مهم: توجه داشته باشید ثبت چند سفارش برای یک پست بیهوده بوده و باید در یک سفارش به تعداد مورد نیازتان بازدید دریافت کنید. برای مثال برای افزایش 100 بازدید برای یک پست، لطفا 100 بازدید را در یک سفارش ثبت کنید و از ثبت 5 سفارش 20 بازدیدی خودداری کنید.",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>$btn]),$message_id);
}
elseif($command == "set ad"){
$btn = [];
$btn[] = [['text'=>"انصراف"]];
$btn[] = [['text'=>"ثبت بازدید دلخواه"]];
if($coin >= 20){ $btn[] = [['text'=>'درخواست 20 بازدید | 20 سکه']]; }
if($coin >= 50){ $btn[] = [['text'=>'درخواست 50 بازدید | 50 سکه']]; }
if($coin >= 100){ $btn[] = [['text'=>'درخواست 100 بازدید | 100 سکه']]; }
if($coin >= 200){ $btn[] = [['text'=>'درخواست 200 بازدید | 200 سکه']]; }
if($coin >= 500){ $btn[] = [['text'=>'درخواست 500 بازدید | 500 سکه']]; }
if($coin >= 1000){ $btn[] = [['text'=>'درخواست 1000 بازدید | 1000 سکه']]; }
if($coin >= 2000){ $btn[] = [['text'=>'درخواست 2000 بازدید | 2000 سکه']]; }
if($coin >= 5000){ $btn[] = [['text'=>'درخواست 5000 بازدید | 5000 سکه']]; }
SendAction($chat_id,typing);
if($text == "ثبت بازدید دلخواه"){
save("user/$from_id/command.txt","set ad favourite");
SendMessage($chat_id,"👁‍🗨 چه تعداد بازدید دلخواه میخواهید؟
👈 شما میتوانید بین 20 الی 5000 بازدید (با توجه به موجودی سکه شما) را به دلخواه انتخاب کنید.",'HTML',$back,$message_id);
return;
}
switch($text){
case 'درخواست 20 بازدید | 20 سکه':$count = 20;break;
case 'درخواست 50 بازدید | 50 سکه':$count = 50;break;
case 'درخواست 100 بازدید | 100 سکه':$count = 100;break;
case 'درخواست 200 بازدید | 200 سکه':$count = 200;break;
case 'درخواست 500 بازدید | 500 سکه':$count = 500;break;
case 'درخواست 1000 بازدید | 1000 سکه':$count = 1000;break;
case 'درخواست 2000 بازدید | 2000 سکه':$count = 2000;break;
case 'درخواست 5000 بازدید | 5000 سکه':$count = 5000;break;
}
if($coin >= $count && preg_match('/^([0-9])/',$count)){
save("user/$from_id/wait.txt",$count);
save("user/$from_id/command.txt","set ad 2");
SendMessage($chat_id,"💎 تبلیغ، متن، تصویر و یا پست خود را فوروارد نمایید تا در معرض دید کاربران  قرار بگیرد.
 
⁉️ توجه داشته باشید ثبت تبلیغ دارای محتوا های خلاف قوانین ایران اسلامی، کلاهبرداری، توهین و فحاشی، تبلیغ ربات های مشابه، پخش شماره سایر افراد و... غیر مجاز میباشد. در صورت ثبت چنین پست هایی حساب کاربر بدون اطلاع قبلی بسته خواهد شد.خواهشمندیم قبل از تبلیغ تمام قوانین  سین را چک کنید.",'HTML',$back,$message_id);
}else{
SendMessage($chat_id,"‼️ لطفا گزینه مورد نظر را از روی کیبورد انتخاب کنید و یا برای لغو عملیات، روی کلید انصراف کلیک کنید.",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>$btn]),$message_id);
if($coin >= $count && preg_match('/^([0-9])/',$count)){
save("user/$from_id/wait.txt",$count);
save("user/$from_id/command.txt","set ad 2");
SendMessage($chat_id,"💎 تبلیغ، متن، تصویر و یا پست خود را فوروارد نمایید تا در معرض دید کاربران  قرار بگیرد.
 
⁉️ توجه داشته باشید ثبت تبلیغ دارای محتوا های خلاف قوانین ایران اسلامی، کلاهبرداری، توهین و فحاشی، تبلیغ ربات های مشابه، پخش شماره سایر افراد و... غیر مجاز میباشد. در صورت ثبت چنین پست هایی حساب کاربر بدون اطلاع قبلی بسته خواهد شد.خواهشمندیم قبل از تبلیغ تمام قوانین  سین را چک کنید.",'HTML',$back,$message_id);
}else{
SendMessage($chat_id,"‼️ لطفا گزینه مورد نظر را از روی کیبورد انتخاب کنید و یا برای لغو عملیات، روی کلید انصراف کلیک کنید.",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>$btn]),$message_id);
}}}
elseif($command == "set ad favourite"){
SendAction($chat_id,typing);
if($text >= 20 && 200 >= $text){
if($coin >= $text){
save("user/$from_id/wait.txt",$text);
save("user/$from_id/command.txt","set ad 2");
SendMessage($chat_id,"💎 تبلیغ، متن، تصویر و یا پست خود را فوروارد نمایید تا در معرض دید کاربران  قرار بگیرد.
 
⁉️ توجه داشته باشید ثبت تبلیغ دارای محتوا های خلاف قوانین ایران اسلامی، کلاهبرداری، توهین و فحاشی، تبلیغ ربات های مشابه، پخش شماره سایر افراد و... غیر مجاز میباشد. در صورت ثبت چنین پست هایی حساب کاربر بدون اطلاع قبلی بسته خواهد شد.خواهشمندیم قبل از تبلیغ تمام قوانین  سین را چک کنید.",'HTML',$back,$message_id);    
}else{
SendMessage($chat_id,"⚠️ برای ثبت $text بازدید به $text سکه نیاز دارید!
 👈 لطفا یک مقدار دیگر وارد کنید ",'HTML',$back,$message_id);
}    
}else{
SendMessage($chat_id,"‼️ مقدار ورودی معتبر نیست ",'HTML',$back,$message_id);    
}}
elseif($command == "set ad 2"){
SendAction($chat_id,typing);
SendMessage($chat_id,"⁉️آیا با ثبت سفارش بازدید به میزان $wait بازدید هستید؟",'HTML',$submit_ad_keyboard,$message_id);
save("user/$from_id/wait.txt","$chat_id\n$message_id\n$wait");
save("user/$from_id/command.txt","set ad 3");
}
if($data == "goldr"){$bazdidday = file_get_contents("user/$fromid/bish.txt");$shoklt = file_get_contents("user/$fromid/coin.txt");if ($bazdidday > "30") {bot('answercallbackquery',['callback_query_id' => $update->callback_query->id,'text'=>"✅ شما 30 تبلیغ دیدید و 15 سین دریافت کردید !!",]);$mojodi = file_get_contents("user/$fromid/coin.txt");  $sek = $mojodi + "15";file_put_contents("user/$fromid/coin.txt" , $sek); $kasrbazdid = $bazdidday - "30";file_put_contents("user/$fromid/bish.txt" , $kasrbazdid); bot('SendMessage',['chat_id'=>$fromid,'text'=>"✅تــــــبریک!!؟
شما یک بسته اکـــسیژن را مصرف کردید👍
از این به بعد وقت داری بسته بعدیو مال خودت کنی🔥",]);}else{$bazdidday = file_get_contents("user/$fromid/bish.txt");$rrr1 = "30";$eee1 = $rrr1 - $bazdidday;bot('answercallbackquery', ['callback_query_id' => $update->callback_query->id,'text' => "فقط به میزان  $eee1 بازدید مانده تا دریافت اکسیژن!!",'show_alert' => false]);}}

elseif($command == "set ad 3"){
SendAction($chat_id,typing);
if($text == "بله"){
$ad = fopen("user/$from_id/wait.txt",'r');
$from_chat_id = str_replace("\n",'',fgets($ad));
$msg_id = str_replace("\n",'',fgets($ad));
$count = str_replace("\n",'',fgets($ad));
$messageid = Forward("@$channel",$from_chat_id,$msg_id)->result->message_id;
SendMessage("@$channel","| - - - - 👆👇 - $count - 👆👇 - - - - |",'HTML',json_encode(['inline_keyboard'=>[[['text'=>"ثبت بازدید👁‍🗨",'callback_data'=>"submit seen-$code"],['text'=>"اڪسیژن💯",'callback_data'=>"goldr"],['text'=>" سین↪",'url'=>"https://Telegram.me/$BOT_ID"]]]]),$messageid);
save("user/$from_id/coin.txt",$coin - $count);
add_txt("user/$from_id/ads.txt","$code\n");
save("user/$from_id/command.txt",'none');
save("data/submit posts.txt",$submit_post + 1);
save("ads/count/$code.txt",$count);
save("ads/admin/$code.txt",$from_id);
save("ads/msg id/$code.txt",$msg_id);
save("ads/user/$code.txt",'');
save("ads/seen/$code.txt",0);
add_txt("ads/all ads.txt","$code\n");
SendMessage($chat_id,"✅ تبلیغ شما با موفقیت ثبت شد!!

⁉️سفارش بازدید شما با کد پیگیری /ord_$code و به میزان $count بازدید درحال پردازش میباشد.پس از پایان بازدید سفارش پیغامی جهت اطلاع رسانی برای شما ارسال خواهد شد.",'HTML',$keyboard);
}
elseif($text == "خیر"){
unlink("user/$from_id/wait.txt");
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ درخواست شما برای این تبلیغ لغو شد.
◀️لطفا یکی از قسمت های زیر را جهت ورود اتخاب نمایید",'HTML',$keyboard);
}else{
SendMessage($chat_id,"‼️ لطفا بدرستی انتخاب کنید :",'HTML',$submit_ad_keyboard,$message_id);
}}
elseif($text == "📊 پیگیری سفارشات"){
SendAction($chat_id,typing);
$all_ads = explode("\n",$user_ads);
$ads_count = count($all_ads)-1;
if($all_ads == null){
$user_ads = "❗️ شما تاکنون تبلیغی ثبت نکرده اید!";
}else{
$user_ads = "";
for($z = 0;$z <= $ads_count;$z++){
if($all_ads[$z] != null){
$ad = $all_ads[$z];
$count = file_get_contents("ads/count/$ad.txt");
$seen = file_get_contents("ads/seen/$ad.txt");
if($count == $seen){$status = "تکمیل شده";}else{$status = "در حال انجام ♻️";}
$user_ads = "$user_ads\n👈 سفارش شماره /ord_$ad
🔍 $seen/$count بازدید ارسال شده ($status)\n";
}}
SendMessage($chat_id,"⁉️پیگیری سفارشات!!
برای مشاهده امار دقیق هرکدام از سفارشات روی کد انها کلیک کنید!!
\n$user_ads",'HTML',$keyboard,$message_id);
}}
elseif(strpos($text,"/ord_") !== false){
$ad = str_replace("/ord_",'',$text);
$ads = explode("\n",$user_ads);
if(in_array($ad,$ads) && strpos($user_ads,$ad) !== false){
SendAction($chat_id,typing);
$msg_id = file_get_contents("ads/msg id/$ad.txt");
$count = file_get_contents("ads/count/$ad.txt");
$seen = file_get_contents("ads/seen/$ad.txt");
$messageid = Forward($chat_id,$chat_id,$msg_id)->result->message_id;
if($count == $seen){$status = "تکمیل شده!!";}else{$status = "در حال انجام!! ♻️";}
SendMessage($chat_id,"⁉️پیگیری سفارش با کد $ad
⁉️تعداد بازدید ارسال شده  ( $status )👁‍🗨
تعداد بازدید ارسال شده: $seen/$count میباشد!!
💯پیام سفارش خود را میتوانید در بالای این پیام ببینید و از آخرین وضعیت آن سفارش با خبر شوید.

⁉️توجه داشته باشید شمارنده پست بالا تعداد بازدید،شمارنده پست شما نیست و در صورتی که تعداد آن کمتر از بازدید سفارش شماست اصلا جای نگرانی نیست.
⁉️شمارنده یا بازدید های بالا نشاندهنده وضعیت سفارش تبلیغ شما در  سین است.",'HTML',$keyboard,$messageid);
}}
elseif($text == "عابر بــانڪ🏦"){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","transfer");
$send_users = fopen("user/$from_id/send users.txt",'r');
$one = str_replace("\n",'',fgets($send_users));
$two = str_replace("\n",'',fgets($send_users));
$three = str_replace("\n",'',fgets($send_users));
$four = str_replace("\n",'',fgets($send_users));
$five = str_replace("\n",'',fgets($send_users));
SendMessage($chat_id,"⁉️شماره کاربری کاربر مورد نظر را ارسال نمایید.
💎شماره کاربری هر فرد در قسمت پروفایل من قابل مشاهده میباشد.

🌟جهت سهولت بیشتر شما میتوانید با ارسال دستور /transfers از انتقالات اخیر خود مطلع شوید.",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"انصراف"]],[['text'=>$one]],[['text'=>$two]],[['text'=>$three]],[['text'=>$four]],[['text'=>$five]]]]),$message_id);
}
elseif($text == "قوانین ثبت🚫"){
save("user/$from_id/command.txt","none");
SendMessage($chat_id,"⚖️صفحه قوانین و مقررات⚖️


⛔️ تبلیغات شما نباید شامل موارد زیر باشد:
1⃣ - خلاف قوانین جمهوری اسلامی ایران
2⃣ - فحاشی و توهین
3⃣ - محتوای جنسی و بزرگسالان
4⃣ - مزاحمت و پخش اطلاعات افراد
5⃣ - کلاهبرداری و پخش موارد جعلی
6⃣ -سایتها و رباتها و کانالهای شرط بندی 
7⃣ - تبلیغ ربات های مشابه، ربات های غیرواقعی
8⃣ - فریب افراد و کاربران
9⃣ - هک و نفوذ، پخش برنامه های پولی و موارد علیه کپی رایت
🔟 - و ... (موارد غیرمجاز)

⚠️ توجه داشته باشید در صورت گزارش هر پست و حذف پست شما 1 اخطار میگیرید؛ در صورتی که 3 اخطار دریافت کنید در ربات مسدود خواهید شد!

⚠️ قوانین و مقررات دائما در حال به روز شدن می باشند و کلیه کاربران موظف به مطالعه این صفحه به صورت مکرر می باشند.

❗️پست های غیرمجاز را به ما گزارش کنید تا ما سریعا برخوردهای قانونی را با عوامل آن انجام دهیم. برای گزارش پست های غیر مجاز می توانید هنگام مشاهده بنرها بر روی دکمه گزارش تخلف کلیک کنید.

⚠️ در صورت ثبت گزارش های غیرواقعی و دروغین، اخطار خواهید گرفت و در صورت تکرار این گزارشات به صورت عمدی، اکانت شما غیر فعال خواهد شد");
}
elseif($text == "پشتیبانی☎️"){
save("user/$from_id/command.txt","none");
SendMessage($chat_id," جهت پشتیبانی🕹👇
$adminidd
در هر ساعت از شبانه روز حاضر به پشتیبانی هستیم⚡️");
}
elseif($text == "/transfers" or $text == "تاریخچه انتقالات!!"){
SendAction($chat_id,typing);
$send = explode("\n",$sended);
$send_count = count($send)-1;
$receive = explode("\n",$received);
$receive_count = count($receive)-1;
if($send[0] == null){
$last_send = "‼️ ارسالی صورت نگرفته است";    
}else{
$last_send = "";
for($z = $send_count-5;$z <= $send_count;$z++){
if($send[$z] != null && $send[$z] != "\n"){
$ref = $send[$z];
$status = fopen("user/$from_id/transfers/$ref.txt",'r');
$count = str_replace("\n",'',fgets($status));
$to = str_replace("\n",'',fgets($status));
$last_send = "$last_send ↗️ $count سکه به $to | شناسه تراکنش: $ref\n";
}}}
if($receive[0] == null){
$last_receive = "‼️ دریافتی صورت نگرفته است";    
}else{
$last_receive = "";
for($z = $receive_count-5;$z <= $receive_count;$z++){
if($receive[$z] != null && $receive[$z] != "\n"){
$ref = $receive[$z];
$status = fopen("user/$from_id/transfers/$ref.txt",'r');
$count = str_replace("\n",'',fgets($status));
$from = str_replace("\n",'',fgets($status));
$last_receive = "$last_receive ↙️ $count سکه از $from | شناسه تراکنش: $ref\n";
}}}
SendMessage($chat_id,"👈 تاریخچه 5 دریافتی و 5 ارسال اخیر خود را میتوانید در اینجا مشاهده کنید.

🔺تاریخچه ارسالی ها:
$last_send
🔻تاریخچه دریافتی ها:
$last_receive",'HTML','',$message_id);
}
elseif($command == "transfer"){
SendAction($chat_id,typing);
if(strpos($list,$text) !== false){
save("user/$from_id/wait.txt",$text);
save("user/$from_id/command.txt","transfer 2");
SendMessage($chat_id,"💸 مقدار سکه را برای انتقال وارد کنید:

👈 حداقل مقدار انتقال 20 سکه و حداکثر مقدار انتقال $coin سکه (برای شما) میباشد.
👈 انتقال بدون هیچ کارمزدی میباشد.",'HTML',$back,$message_id);
}else{
SendMessage($chat_id,"⚠️ شناسه کاربری نامعتبر میباشد!
👈 لطفا شناسه ورودی را برسی کنید و از صحت آن مطمئن شوید",'HTML','',$message_id);    
}}
elseif($command == "transfer 2"){
SendAction($chat_id,typing);
if(preg_match('/^([0-9])/',$text)){
if($text >= 20 && $text <= 5000){
if($coin >= $text){
$user = explode("\n",$send_users);
save("user/$from_id/coin.txt",$coin-$text);
save("user/$wait/coin.txt",file_get_contents("user/$wait/coin.txt") + $text);
add_txt("user/$from_id/sended.txt","$code\n");
add_txt("user/$wait/received.txt","$code\n");
save("user/$from_id/transfers/$code.txt","$text\n$wait");
save("user/$wait/transfers/$code.txt","$text\n$from_id");
save("user/$from_id/send users.txt","$wait\n".str_replace($user[5],'',$send_users));
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ مقدار $text سکه با موفقیت از حساب شما به $wait ارسال شد.
👈 کد پیگیری انتقال: $code",'HTML',$keyboard,$message_id);
SendMessage($wait,"✅ مقدار $text سکه از کاربر $from_id به حساب شما ارسال شد.
👈 کد پیگیری انتقال: $code",'HTML');
unlink("user/$from_id/wait.txt");
}else{
SendMessage($chat_id,"⚠️ این مقدار قابل انتقال نیست!
👈 شما در حساب خود $coin سکه دارید و انتقال بیش از $coin سکه ممکن نیست.",'HTML',$back,$message_id);    
}
}else{
SendMessage($chat_id,"⚠️ حداقل مبلغ قابل انتقال 20 سکه میباشد!
👈 لطفا مقداری بیشتر از 20 سکه وارد نمایید.",'HTML',$back,$message_id);
}    
}else{
SendMessage($chat_id,"⚠️ مقدار ورودی صحیح نیست
👈 لطفا به صورت عددی معتبر وارد کنید.",'HTML',$back,$message_id);    
}}
if($text=="فروشگاه🛍"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🍃 کاربر گرامی لطفا تعداد بازدید خواسته شده را انتخواب نمایید 
♦️توجه: تمامی پرداخت ها زیر نظر بانک تأیین شده میباشد و هیچگونه اختلافی نمیتواند موجب ناراحتی پیش اید و به صورت مستقیم تحت نظارت بانک میباشد.

✅لطفا یک گزینه را انتخواب نمایید👇",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=> [
[['text' => "🛍1000بازدید | 1000تومان💸", 'url' => "https://t.me/[*[ADMINID]*]"]],
[['text' => "🛍2000بازدید | 2000 تومان💸", 'url' => "https://t.me/[*[ADMINID]*]"]],
[['text' => "🛍4000 بازدید | 3500 تومان💸", 'url' => "https://t.me/[*[ADMINID]*]"]],
[['text' => "🛍6000بازدید | 5000تومان💸", 'url' => "https://t.me/[*[ADMINID]*]"]],
[['text' => "🛍10.000بازدید | 8.000تومان💸", 'url' => "https://t.me/[*[ADMINID]*]"]],
[['text' => "🛍20000بازدید | 17.000تومان💸", 'url' => "https://t.me/[*[ADMINID]*]"]],

]
])
]);
}
elseif($text == "بهترین اعضا💯"){ 
SendAction($chat_id,typing);
$top_coin = "";
for($z = 0;$z <= 10;$z++){
$top = top($z,'coin');
if($top != null){
$name = getChat($top)->result->first_name;
$coin = file_get_contents("user/$top/coin.txt");
$top_coin = "$top_coin ➖ <a href='tg://user?id=$top'>$name</a> با $coin سکه\n";
}}
$top_members = "";
for($z = 0;$z <= 10;$z++){
$top = top($z,'members');
if($top != null){
$name = getChat($top)->result->first_name;
$member = file_get_contents("user/$top/members.txt");
$top_members = "$top_members ➖ <a href='tg://user?id=$top'>$name</a> با $member زیرمجموعه\n";
}}  
SendMessage($chat_id,"👈🏻 برترین کاربران ( از نظر سکه ) :

$top_coin
...............................................
👈🏻 برترین کاربران ( از نظر زیرمجموعه ) :

$top_members
این ها برترین کاربران سین هستند که فعالیت های آنها در ربات  سین بسیار بالا و پیشرفته میباشد!!",'HTML',$back,$message_id);
}
elseif($text =="/help"){
SendAction($chat_id,typing);
SendMessage($chat_id,"⚠️به بخش راهنمای  خوش آمدید...

♻️و سین یک ربات قدرتمند و گسترده نویسی شده میباشد که به شما کمک میکند بازدید پست های تلگرامی خود را بالا ببرید. 

⁉️اما چطور ممکن است؟
پاسخ به این سوال خیلی ساده میباشد؛شما جهت جمع اوری سکه برای ثبت تبلیغات میتوانید از دو روش استفاده نمایید.1-زیرمجموعه گیری و دریافت 20 درصد پورسانت ویژه.2-جمع اوری سکه در کانال تبلیغات  سین.

⁉️پورسانت چیست؟
پورسانتی که شما از زیرمجموعه خود میگیرید همان درصدی است که زیرمجموعه شما دکمه ثبت تبلیغ را لنس کرده و دریافت بازدید میکند شما هج درصدی از این بازدید را کسب میکنید.اما بازدیدی از زیرمجموعه شما کسر نمیشود.!!

⁉️چگونه میتوانیم در کانال تبلیغات سکه جمع کنیم؟
شما جهت جمع اوری سکه با توجه به الگوریتم ربات پیشرفته  سین شما در کانالی با نشانی @$channel به عنوان کانال تبلیغات مشاهده میکنید و اگر دقت کنید تبلیغاتی بسیار در این کانال وجود دارد که هرکدام با یک ریپلای مخصوص که نشان میدهد چه مقدار بازدید درخواست این سفارش است مشخص شده؛اما زیر ریپلای دکمه هایی شیشه ای وجود دارد که ثبت بازدید به شما به میزان تأیین شده برای دیدن هر تبلیغ سکه اضافه میکند.

⁉️اکسیژن چیست؟
اکسیژن یک هدیه جهت پاسداری از فعالیت شما در  سین است شما به میزان تأیین شده و با توجه به برنامه نویسی  سین میتوانید تبلیغات را مشاهده و از سین هدیه کسب کنید.

🌐اگر هنوز سوالی دارید پشتیبانی  سین در خدمت شماست با دستور /support میتوانید به مدیریت اصلی  سین پیغام،انتقاد،سوال و یا هرگونه مشکل را اطلاع ده",'HTML','',$message_id);
}
elseif($data == "member info"){
EditMessage($chatid,$messageid,"👈 شما میتوانید با انتشار پست بالا و دعوت دوستان خود به ویوبگیر، 10 سکه رایگان بگیرید.
👈 همچنین در صورت فعالیت دوستان زیرمجموعه شما، 10 درصد سکه های آن ها به شما افزوده خواهد شد.

🔺برای مثال اگر شما 500 زیر مجموعه داشته باشید که به طور میانگین روزانه 200 تبلیغ ببینند، شما روزانه 1000 سکه به صورت رایگان بدست می آورید!
همین حالا شروع کنید...");    
}
// === Manage Panel === //
elseif($text =="مدیریت" && $from_id == $admin){
SendAction($chat_id,typing);
SendMessage($chat_id,"به منوی مدیریت خوش امدید!",'HTML',$admin_keyboard,$message_id);
}
elseif($text == "📊 آمار کلی ربات" && $from_id == $admin){
SendAction($chat_id,typing);
$Member = explode("\n",$list);
$member_count = count($Member)-1;
$last_users = "";
for($z = $member_count-10;$z <= $member_count;$z++){
if($Member[$z] != null){
$name = getChat($Member[$z])->result->first_name;
$last_users = "$last_users 〰 <a href='tg://user?id=$Member[$z]'>$name</a>\n";
}}
$submit_post_count = count(explode("\n",$submit_post))-1;
$end_post_count = count(explode("\n",$end_post))-1;
SendMessage($chat_id,"📊 آمار کلی ربات شما :

👥 تعداد کاربران » <b>$member_count</b>
🔖 تعداد پست های باقی مانده » <b>$submit_post_count</b>
📌 تعداد پست های تکمیل شده » <b>$end_post_count</b>

➖ آخرین کاربران : 👇🏻
$last_users",'HTML',$admin_keyboard,$message_id);
}
elseif ($text == "تنظیم مسابقه" && $chat_id ==$admin) { file_put_contents("data/$chat_id/ali.txt", "setmch"); bot('sendmessage', [ 'chat_id' => $chat_id, 'text' => "متن خود را ارسال کنید", 'reply_to_message_id'=>$message_id, 'reply_markup'=>$back_keyboard ]);
 }
 elseif ($ali == 'setmch') { file_put_contents("data/mch.txt", $text); file_put_contents("data/$chat_id/ali.txt", "No"); bot('sendMessage', [ 'chat_id' => $chat_id, 'text' => "تنظیم شد", 'reply_to_message_id'=>$message_id, 'reply_markup' => $admin_keyboard ]);
 }
elseif($text == "پیام همگانی 📩" && $from_id == $admin){ 
SendAction($chat_id,typing);
save("user/$from_id/command.txt","send to all");
SendMessage($chat_id,"👈🏻 لطفا پیام خود را در هر قالبی ارسال کنید :\n\n$variable_text",'HTML',$back_admin,$message_id);
}
elseif($command == "send to all"){
SendAction($chat_id,typing);
save("user/$from_id/command.txt",'none');
$Member = fopen('Member.txt','r');
while(!feof($Member)){
$user = fgets($Member); $user = str_replace("\n",'',$user);
$get = getChat($user)->result;
$first_name = $get->first_name;
$last_name = $get->last_name;
$username = $get->username;
if($caption != null){
$_caption = str_replace("FIRSTNAME",$first_name,$caption);
$_caption = str_replace("LASTNAME",$last_name,$_caption);
$_caption = str_replace("USERID","$user\n",$_caption);
$_caption = str_replace("USERNAME",$username,$_caption);
$_caption = str_replace("DATE",$date,$_caption);
$_caption = str_replace("TIME",$time,$_caption);     
}
if($text != null){
$_text = str_replace("FIRSTNAME",$first_name,$text);
$_text = str_replace("LASTNAME",$last_name,$_text);
$_text = str_replace("USERID","$user\n",$_text);
$_text = str_replace("USERNAME",$username,$_text);
$_text = str_replace("DATE",$date,$_text);
$_text = str_replace("TIME",$time,$_text);    
}
if($stickerid != null){SendSticker($user,$stickerid);}
elseif($videoid != null){SendVideo($user,$videoid,$_caption);}
elseif($voiceid != null){SendVoice($user,$voiceid,'',$_caption);}
elseif($fileid != null){SendDocument($user,$fileid,'',$_caption);}
elseif($musicid != null){SendAudio($user,$musicid,'',$_caption);}
elseif($photoid != null){SendPhoto($user,$photoid,'',$_caption);}
elseif($text != null){SendMessage($user,$_text,"html");}
}
SendMessage($chat_id,"📩 پیام شما با موفقیت با تمام کاربران ارسال شد !!",'html',$admin_keyboard,$message_id);
}
elseif($text == "📌 فوروارد همگانی" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","fwd to all");
SendMessage($chat_id,"👈🏻 پیام مورد نظر را فوروارد کنید :",'HTML',$back_admin,$message_id);
}
elseif($command == "fwd to all"){
SendAction($chat_id,typing);
save("user/$from_id/command.txt",'none');
$Member = fopen('Member.txt','r');
while(!feof($Member)){
$user = fgets($Member);
Forward($user,$chat_id,$message_id);
}
SendMessage($chat_id,"📩 پیام شما با موفقیت با تمام کاربران فوروارد شد !!",'HTML',$admin_keyboard,$message_id);
}
elseif($text == "بن کردن کاربر 🚫" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","ban user");
SendMessage($chat_id,"〰 لطفا شناسه عددی یا یک پیام از کاربر مورد نظر را فوروارد کنید :",'HTML',$back_admin,$message_id);
}
elseif($command == "ban user"){
SendAction($chat_id,typing);
if($forward_from != null){
$id = $forward_id;
$name = $forward_name;
}else{
$get = getChat($text)->result;
$id = $get->id;
$name = $get->first_name;
}
if($id != null){
save("user/$from_id/command.txt",'none');
if(strpos($ban,$id) == false){add_txt("data/ban.txt","$id\n");}
SendMessage($chat_id,"🚫 کاربر <a href='tg://user?id=$id'>$name</a> از ربات بن شد !!",'HTML',$admin_keyboard,$message_id);
SendMessage($id,"💢 شما از ربات بن شدید ؛ لطفا دیگر پیام ندید!",'HTML');
}else{
SendMessage($chat_id,"🚫 کاربر مورد نظر در ربات عضو نمیباشد !!",'HTML',$back_admin,$message_id);
}}
elseif($text == "✅ آنبن کردن کاربر" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","unban user");
SendMessage($chat_id,"〰 لطفا شناسه عددی یا یک پیام از کاربر مورد نظر را فوروارد کنید :",'HTML',$back_admin,$message_id);
}
elseif($command == "unban user"){
SendAction($chat_id,typing);
if($forward_from != null){
$id = $forward_id;
$name = $forward_name;
}else{
$get = getChat($text)->result;
$id = $get->id;
$name = $get->first_name;
}
if($id != null){
if(strpos($ban,$id) !== false){
save("data/ban.txt",str_replace("$id\n",'',$ban));
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ کاربر <a href='tg://user?id=$id'>$name</a> از ربات آنبن شد !!",'HTML',$admin_keyboard,$message_id);
SendMessage($id,"✅ شما از ربات آنبن شدید!",'html',$keyboard);
}else{
SendMessage($chat_id,"💢 کاربر مورد نظر در لیست افراد بن شده نمیباشد !!",'html',$back_admin,$message_id);      
}}else{
SendMessage($chat_id,"🚫 کاربر مورد نظر در ربات عضو نمیباشد !!",'HTML',$back_admin,$message_id);    
}}
elseif($text == "تنظیم ایدی پشتیبانی😎" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","setposhti");
SendMessage($chat_id,"ایدی بدون @ ارسال کن",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"انصراف"]]]]),$message_id);
}
elseif($text == "تنظیم کانال جوین اجباری 🔊" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","set join channel");
SendMessage($chat_id,"💠 لطفا آیدی کانال مورد نظر را ارسال کنید یا یک پست از کانال فوروارد کنید :

👈🏻 توجه : ربات باید مدیر کانال مورد نظر باشد!",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"انصراف"]],[['text'=>"❌ حذف کانال جوین اجباری"]]]]),$message_id);
}
elseif($command == "setposhti"){
SendAction($chat_id,typing);
save("data/poshtibani.txt",$text);
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"تنظیم شد ",'HTML',$admin_keyboard);
}
elseif($command == "set join channel"){
SendAction($chat_id,typing);
if($text == "❌ حذف کانال جوین اجباری"){
save("user/$from_id/command.txt",'none');
unlink("data/join channel.txt");
SendMessage($chat_id," ☢️ با موفقیت حذف  شد !!",'HTML',$admin_keyboard,$message_id);
return;    
}
if($forward_chat_username != null){
$channel = '@'.$forward_chat_username;    
}else{
$channel = $text;    
}
$get = getChatMember($channel,$from_id);
if($get != null){
save("data/join channel.txt",$channel);
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ کانال $channel با موفقیت بعنوان چنل جوین اجباری تنظیم شد !!",'HTML',$admin_keyboard,$message_id);
}else{
    save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"🚫 ربات ادمین کانال مورد نظر نمیباشد !!",'HTML',$back_admin,$message_id);
}}
elseif($text == "📢 تنظیم کانال تبلیغات" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","set ads channel");
SendMessage($chat_id,"💠 لطفا آیدی کانال مورد نظر را ارسال کنید یا یک پست از کانال فوروارد کنید :

👈🏻 توجه : ربات باید مدیر کانال مورد نظر باشد!",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"انصراف"]],[['text'=>"❌ حذف کانال تبلیغات"]]]]),$message_id);
}
elseif($command == "set ads channel"){
SendAction($chat_id,typing);
if($text == "❌ حذف کانال تبلیغات"){
save("user/$from_id/command.txt",'none');
unlink("data/channel.txt");
SendMessage($chat_id," ☢️ با موفقیت حذف  شد !!",'HTML',$admin_keyboard,$message_id);
return;    
}
if($forward_chat_username != null){
$channel = '@'.$forward_chat_username;    
}else{
$channel = $text;    
}
$get = getChatMember($channel,$from_id);
if($get != null){
save("data/channel.txt",$channel);
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ کانال $channel با موفقیت بعنوان چنل تبلیغات تنظیم شد !!",'HTML',$admin_keyboard,$message_id);
}else{
SendMessage($chat_id,"🚫 ربات ادمین کانال مورد نظر نمیباشد !!",'HTML',$back_admin,$message_id);
}}
elseif($text == "سکه همگانی 👥" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","coin to all");
SendMessage($chat_id,"🔢 لطفا تعداد سکه را بصورت عدد وارد کنید :",'HTML',$back_admin,$message_id);
}
elseif($command == "coin to all"){
SendAction($chat_id,typing);
if(preg_match('/^([0-9])/',$text)){
save("user/$from_id/wait.txt",$text);
save("user/$from_id/command.txt","coin to all 2");
SendMessage($chat_id,"⁉️ آیا ارسال $text سکه به تمام کاربران ربات را تایید میکنید ؟",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"برگشت به منوی مدیریت"]],[['text'=>"خیر"],['text'=>"بله"]]]]),$message_id);
}else{
SendMessage($chat_id,"⚠️ ورودی نامعتبر است !
👈🏻 لطفا فقط عدد ارسال کنید :",'HTML',$back_admin,$message_id);
}}
elseif($command == "coin to all 2"){
SendAction($chat_id,typing);
if($text == "خیر"){
unlink("user/$from_id/wait.txt");
save("user/$from_id/command.txt",'none');
SendMessage($chat_id,"✅ با موفقیت لغو شد !
👈🏻 یک گزینه را انتخاب کنید :",'HTML',$admin_keyboard,$message_id);
}
elseif($text == "بله"){
$Member = explode("\n",$list);
$count = count($Member)-2;
save("user/$from_id/command.txt",'none');
for($z = 0;$z <= $count;$z++){
$user = $Member[$z];
if($user != "\n" && $user != " "){
$coin = file_get_contents("user/$user/coin.txt");
save("user/$user/coin.txt",$coin + $wait);
SendMessage($user,"⁉️کاربر گرامی به پاس حضور شما در  سین شما از طرف مدیریت ربات  سین به میزان $wait بازدید به حسابتان واریز شد.
",'HTML');
}}
unlink("user/$from_id/wait.txt");
SendMessage($chat_id,"✅ با موفقیت به تمام اعضا مقدار $wait سکه ارسال شد !
👈🏻 یک گزینه را انتخاب کنید :",'HTML',$admin_keyboard,$message_id);
}else{
SendMessage($chat_id,"💢 لطفا فقط از کیبورد زیر انتخاب کنید :",'HTML',json_encode(['resize_keyboard'=>true,'keyboard'=>[[['text'=>"برگشت به منوی مدیریت"]],[['text'=>"خیر"],['text'=>"بله"]]]]),$message_id);    
}}
elseif($text == "💰 سکه به کاربر" && $from_id == $admin){
SendAction($chat_id,typing);
save("user/$from_id/command.txt","coin to user");
SendMessage($chat_id,"〰 لطفا شناسه عددی یا یک پیام از کاربر مورد نظر را فوروارد کنید :",'HTML',$back_admin,$message_id);
}
elseif($command == "coin to user"){
SendAction($chat_id,typing);
if($forward_from != null){
$id = $forward_id;
$name = $forward_name;
}else{
$get = getChat($text)->result;
$id = $get->id;
$name = $get->first_name;
}
if($id != null && file_exists("user/$id")){
save("user/$from_id/wait.txt",$id);
save("user/$from_id/command.txt","coin to user 2");
SendMessage($chat_id,"💰 حال تعداد سکه را وارد کنید :",'HTML',$back_admin,$message_id);
}else{
SendMessage($chat_id,"🚫 کاربر مورد نظر در ربات عضو نمیباشد !!",'HTML',$back_admin,$message_id);    
}}
elseif($command == "coin to user 2"){
SendAction($chat_id,typing);
if(preg_match('/^([0-9])/',$text)){
$coin = file_get_contents("user/$wait/coin.txt");
$name = getChat($wait)->result->first_name;
save("user/$wait/coin.txt",$coin + $text);
save("user/$from_id/command.txt",'none');
SendMessage($wait,"🎉تبریک !!
🎁 از طرف مدیریت $text سکه به شما داده شده است ...",'HTML');
SendMessage($chat_id,"✅ با موفقیت $text سکه به کاربر <a href='tg://user?id=$wait'>$name</a> ارسال شد !!
👈🏻یک گزینه را انتخاب کنید :",'HTML',$admin_keyboard,$message_id);
unlink("user/$from_id/wait.txt");
}else{
SendMessage($chat_id,"⚠️ ورودی نامعتبر است !
👈🏻 لطفا فقط عدد ارسال کنید :",'HTML',$back_admin,$message_id);    
}}
elseif($text == "🔝 برترین کاربران" && $from_id == $admin){ 
SendAction($chat_id,typing);
$top_coin = "";
for($z = 0;$z <= 10;$z++){
$top = top($z,'coin');
if($top != null){
$name = getChat($top)->result->first_name;
$coin = file_get_contents("user/$top/coin.txt");
$top_coin = "$top_coin ➖ <a href='tg://user?id=$top'>$name</a> ( <code>$top</code> ) با $coin سکه\n";
}}
$top_members = "";
for($z = 0;$z <= 10;$z++){
$top = top($z,'members');
if($top != null){
$name = getChat($top)->result->first_name;
$member = file_get_contents("user/$top/members.txt");
$top_members = "$top_members ➖ <a href='tg://user?id=$top'>$name</a> ( <code>$top</code> ) با $member زیرمجموعه\n";
}}  
SendMessage($chat_id,"👈🏻 برترین کاربران ( از نظر سکه ) :

$top_coin

...............................................

👈🏻 برترین کاربران ( از نظر زیرمجموعه ) :

$top_members",'HTML',$admin_keyboard,$message_id);
}
/*
AftabGroup
*/
unlink("error_log");
?>
