
<?php 
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
ob_start();

$API_KEY = '[*[TOKEN]*]';
##------------------------------##
define('API_KEY',$API_KEY);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
 function sendmessage($chat_id, $text, $model){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 ]);
 }
 function sendphoto($chat_id, $photo, $captionl){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
 function sendaudio($chat_id, $audio, $caption, $title ,$performer){
 bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>$audio,
 'caption'=>$caption,
 'title'=>$title,
 'performer'=>$performer
 ]);
 }
 function senddocument($chat_id, $document, $caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption
 ]);
 }
 function sendsticker($chat_id, $sticker){
 bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>$sticker
 ]);
 }
 function sendvideo($chat_id, $video, $caption){
 bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>$video,
 'caption'=>$caption
 ]);
 }
 function sendvoice($chat_id, $voice, $caption){
 bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>$voice,
 'caption'=>$caption
 ]);
 }
 function sendaction($chat_id, $action){
 bot('sendchataction',[
 'chat_id'=>$chat_id,
 'action'=>$action
 ]);
 }
 function objectToArrays($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        if (is_object($object)) {
            $object = get_object_vars($object);
        }
        return array_map("objectToArrays", $object);
    }
//====================Tikapp======================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$first_name = $message->from->first_name;
$text = $message->text;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id = $update->callback_query->message->message_id;
$reply = $update->message->reply_to_message;
$ali = file_get_contents("ali.txt");
$ADMIN = [*[ADMIN]*];
//====================Tikapp======================//
if($text == "/start" ){
$user = file_get_contents('Member.txt');
    $members = explode("\n",$user);
    if (!in_array($chat_id,$members)){
      $add_user = file_get_contents('Member.txt');
      $add_user .= $chat_id."\n";
     file_put_contents('Member.txt',$add_user);
    }
        bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"سلام😉
به ربات ادیت پیکسل خوش آمدید 🌺
به وسیله من میتونی لوگو های مختلف😍
و جالب درست کنی یا حتی میتونی عکسات رو به استیکر تبدیل کنی 😊
با کلی امکانات جالب دیگه ...😝
⚙️برای استفاده از این ربات از دکمه های ارایه شده استفاده کنید",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
[
['text'=>"🌠 ساخت لوگو"]
],
[
['text'=>"🌈 ساخت استیکر"],['text'=>"🏖 ساخت عکس"]
],
[
['text'=>"📽 تبدیلگر فیلم"],['text'=>"📝تبدیل متن به ویس"]
],
[
['text'=>"🎧 تبدیلگر اهنگ"]
]
],
'resize_keyboard'=>true
])
]);
}

////
//====================Tikapp======================//
 elseif($text == "/panel" && $from_id == $ADMIN){
sendaction($chat_id, typing);
        bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"ادمین عزیز به پنل مدیریتی ربات خودش امدید",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            'keyboard'=>[
              [
              ['text'=>"آمار"],['text'=>"پیام همگانی"]
              ],
              ],'resize_keyboard'=>true
        ])
            ]);
        }
elseif($text == "آمار" && $from_id == $ADMIN){
 sendaction($chat_id,'typing');
    $user = file_get_contents("Member.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
 sendmessage($chat_id , " آمار کاربران : $member_count" , "html");
}
elseif($text == "پیام همگانی" && $from_id == $ADMIN){
    file_put_contents("ali.txt","bc");
 sendaction($chat_id,'typing');
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" پیام مورد نظر رو در قالب متن بفرستید:",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
   [['text'=>'/panel']],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($ali == "bc" && $from_id == $ADMIN){
    file_put_contents("ali.txt","none");
 SendAction($chat_id,'typing');
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" پیام همگانی فرستاده شد.",
  ]);
 $all_member = fopen( "Member.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
   SendMessage($user,$text,"html");
  }
}
//====================Tikapp======================//
elseif($text == "🌠 ساخت لوگو" ){
	bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"به بخش ساخت لوگو خوش اومدی❤️
➖➖➖➖➖
🔹 تو این بخس میتونی لوگو های فوق العاده درست کنی فقط کافیه طرح لوگوت رو انتخاب کنی

🔸بعدش متن لوگو خودت رو ارسال کنی😜
➖➖➖➖
طرح لوگوت رو انتخاب کن🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
              [
                   ['text'=>"🔹رنگی"],['text'=>"🔸ساده"],['text'=>"🔹قلبی"]
                ],
				[
				['text'=>"🔸بچه کجایی"],['text'=>"🔹زندگی بدون من[پسرانه]"],['text'=>"🔸شاخ"]
				],
				[
				['text'=>"🔹مهر"],['text'=>"🔸فونت زیبا"],['text'=>"🔹زندگی بدون من[دخترانه]"]
				],
				[
				['text'=>"🔸ماه و ستاره"],['text'=>"🔹طرح دریا"],['text'=>"🔸کلاسیک"]
				],
			[
			['text'=>"برگشت"]
                ]
           ],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($text == "برگشت" ){
        bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"به منوی اصلی بازگشتید✔️
➖➖➖➖
از دکمه های زیر استفاده کنید🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
[
['text'=>"🌠 ساخت لوگو"]
],
[
['text'=>"🌈 ساخت استیکر"],['text'=>"🏖 ساخت عکس"]
],
[
['text'=>"📽 تبدیلگر فیلم"],['text'=>"📝تبدیل متن به ویس"]
],
[
['text'=>"🎧 تبدیلگر اهنگ"]
]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($text == "🔸ساده"){
  file_put_contents("ali.txt","photos");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photos"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://www.iloveheartstudio.com/-/p.php?t=$text&bc=FFCBDB&tc=000000&hc=ff0000&f=c&uc=true&ts=true&ff=PNG&w=500&ps=sq",
 'caption'=>"Edit Bot",
 ]);}
elseif($text == "🔹رنگی"){
  file_put_contents("ali.txt","photo");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photo"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&color=white&font=trashco",
 'caption'=>"Edit Bot",
 ]);}
 elseif($text == "🔸بچه کجایی"){
  file_put_contents("ali.txt","photoa");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photoa"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&y=-10&x=20&color=black&font=fa&fsize=100&bg=esm4",
 'caption'=>"Edit Bot",
 ]);}
  elseif($text == "🔹زندگی بدون من[پسرانه]"){
  file_put_contents("ali.txt","photob");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photob"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&y=-100&x=-80&color=black&font=fa&fsize=100&bg=esm2",
 'caption'=>"Edit Bot",
 ]);}
   elseif($text == "🔹زندگی بدون من[دخترانه]"){
  file_put_contents("ali.txt","photoc");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photoc"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&y=-90&x=-80&color=black&font=fa&fsize=100&bg=esm",
 'caption'=>"Edit Bot",
 ]);}
   elseif($text == "🔹قلبی"){
  file_put_contents("ali.txt","photod");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photod"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&color=red&font=ANGEL&fsize=200&bg=logo34&angel=0&y=0&x=-20",
 'caption'=>"Edit Bot",
 ]);}
    elseif($text == "🔸فونت زیبا"){
  file_put_contents("ali.txt","photoe");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به فارسی وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photoe"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?color=white&font=AGhasem&text=$text",
 'caption'=>"Edit Bot",
 ]);}

     elseif($text == "🔹مهر"){
  file_put_contents("ali.txt","photof");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photof"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&color=black&font=28&fsize=50&angel=-0&y=140&bg=mk&x=130&angel=-11",
 'caption'=>"Edit Bot",
 ]);}
      elseif($text == "🔸شاخ"){
  file_put_contents("ali.txt","photog");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photog"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&color=white&font=28&fsize=50&bg=logo31&angel=-0&y=245",
 'caption'=>"Edit Bot",
 ]);}
       elseif($text == "🔸ماه و ستاره"){
  file_put_contents("ali.txt","photoh");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به فارسی وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photoh"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&y=-30&x=20&color=Burly+Wood&font=Holool&fsize=120&bg=logo16",
 'caption'=>"Edit Bot",
 ]);}
       elseif($text == "🔹طرح دریا"){
  file_put_contents("ali.txt","photoi");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photoi"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&color=black&y=0&x=10&font=28&fsize=60&bg=logo11",
 'caption'=>"Edit Bot",
 ]);}
        elseif($text == "🔸کلاسیک"){
  file_put_contents("ali.txt","photoj");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"متن خودتون رو به لاتین وارد کنید✨🚀",
        'reply_markup'=>json_encode([
              'keyboard'=>[
      [
        ['text'=>"🔚 برگشت"]
                ]
           ],
              'resize_keyboard'=>true
           ])
  ]);   
}
elseif($ali == "photoj"){
file_put_contents("ali.txt","none");
  bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"http://api.monsterbot.ir/pic/?text=$text&y=15&font=Steamy&fsize=90&bg=logo8",
 'caption'=>"Edit Bot",
 ]);}
 elseif($text == "🔚 برگشت" ){
	bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"به منوی لوگو برگشتید✔️
➖➖➖➖
از دکمه های زیر استفاده کنید🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
              [
                   ['text'=>"🔹رنگی"],['text'=>"🔸ساده"],['text'=>"🔹قلبی"]
                ],
				[
				['text'=>"🔸بچه کجایی"],['text'=>"🔹زندگی بدون من[پسرانه]"],['text'=>"🔸شاخ"]
				],
				[
				['text'=>"🔹مهر"],['text'=>"🔸فونت زیبا"],['text'=>"🔹زندگی بدون من[دخترانه]"]
				],
				[
				['text'=>"🔸ماه و ستاره"],['text'=>"🔹طرح دریا"],['text'=>"🔸کلاسیک"]
				],
			[
			['text'=>"برگشت"]
                ]
           ],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($text == "🌈 ساخت استیکر" ){
	bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"به بخش ساخت استیکر خوش اومدی❤️
➖➖➖➖➖
🔹 تو این بخش میتونی هر عکسیو به استیکر تبدیل کنیی

🔸 یا میتونی با ارسال عکس اون رو به فایل برای ربات ساخت استیکر استفاده کنی
➖➖➖➖
فقط کافیه از دکمه های زیر استفاده کنی🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
              [
                   ['text'=>"🏖تبدیل عکس به استیکر"],['text'=>"📂تبدیل فایل به استیکر"]
                ],
			[  
				['text'=>"💾تبدیل استیکر به فایل"]
			],
			[
				['text'=>"برگشت"]
                ]
           ],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($text == "🏖 ساخت عکس" ){
	bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"به بخش ساخت استیکر خوش اومدی❤️
➖➖➖➖➖
🔹 تو این بخش میتونی هر عکسیو به استیکر تبدیل کنیی

🔸 یا میتونی با ارسال عکس اون رو به فایل برای ربات ساخت استیکر استفاده کنی
➖➖➖➖
فقط کافیه از دکمه های زیر استفاده کنی🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
              [
                   ['text'=>"🌠 تبدیل‌استیکر ‌به ‌عکس"],['text'=>"💾تبدیل عکس‌به ‌فایل"]
                ],
			[  
				['text'=>"🖼تبدیل‌ فایل‌ به‌ عکس"]
			],
			[
				['text'=>"برگشت"]
                ]
           ],
            	'resize_keyboard'=>true
       		])
    		]);
}

//====================Photo======================//
elseif($text == "🏖تبدیل عکس به استیکر" ){               
file_put_contents("ali.txt","c4");    
SendMessage($chat_id, "خوب حالا کافیه عکس خودتون را بفرستید تا تبدیل به استیکر کنم😉✨");
}
elseif($text == "📂تبدیل فایل به استیکر" ){               
file_put_contents("ali.txt","c6");    
SendMessage($chat_id, "خوب حالا کافیه فایل خودتون را بفرستید تا تبدیل به استیکر کنم😉✨");
}
elseif($text == "💾تبدیل استیکر به فایل" ){               
file_put_contents("ali.txt","c5");    
SendMessage($chat_id, "خوب حالا کافیه استیکر خودتون را بفرستید تا تبدیل به فایل کنم😉✨");
}
elseif($text == "🌠 تبدیل‌استیکر ‌به ‌عکس" ){               
file_put_contents("ali.txt","c3");    
SendMessage($chat_id, "خوب حالا کافیه استیکر خودتون را بفرستید تا تبدیل به عکس کنم😉✨");
}
elseif($text == "💾تبدیل عکس‌به ‌فایل" ){               
file_put_contents("ali.txt","c1");    
SendMessage($chat_id, "خوب حالا کافیه عکس خودتون را بفرستید تا تبدیل به فایل کنم😉✨");
}
elseif($text == "🖼تبدیل‌ فایل‌ به‌ عکس" ){               
file_put_contents("ali.txt","c1");    
SendMessage($chat_id, "خوب حالا کافیه  فایل خودتون را بفرستید تا تبدیل به عکس کنم😉✨");
}
elseif($ali == "c1"){
file_put_contents("ali.txt","none");
$photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('tikapp.png'),
 'Caption' => 'hi'
 ]);
unlink('tikapp.png');
}
elseif($ali == "c2"){
$document = $message->document;
$file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>new CURLFile('tikapp.png'),
 ]);
unlink('tikapp.png');
 }
elseif($ali == "c3"){
file_put_contents("ali.txt","none");
$sticker = $message->sticker;
$file = $sticker->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>new CURLFile('tikapp.png'),
 'Caption' => 'hi'
 ]);
unlink('tikapp.png');
 }
elseif($ali == "c4"){
file_put_contents("ali.txt","none");
$photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>new CURLFile('tikapp.png'),
 ]);
unlink('tikapp.png');
}
elseif($ali == "c5"){
file_put_contents("ali.txt","none");
$sticker = $message->sticker;
$file = $sticker->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('tikapp.png'),
 ]);
unlink('tikapp.png');
 }
 elseif($ali == "c6"){
 file_put_contents("ali.txt","none");
$document = $message->document;
$file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>new CURLFile('tikapp.png'),
 ]);
unlink('tikapp.png');
 }
//====================video======================//
elseif($text == "📽 تبدیلگر فیلم" ){
	bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"ه بخش تبدیلگر فیلم خوش امدید❤️
➖➖➖➖➖
🔹در این بخش میتونید فیلم های خودتون رو تبدیل کنید
➖➖➖
فقط کافیه از دکمه های زیر استفاده کنید🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
              [
                   ['text'=>"🎤تبدیل فیلم به اهنگ"],['text'=>"🏜تبدیل فیلم به گیف"]
                ],
			[
				['text'=>"برگشت"]
                ]
           ],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($text == "🎤تبدیل فیلم به اهنگ" ){               
file_put_contents("ali.txt","d1");    
SendMessage($chat_id, "خوب حالا کافیه فیلم خودتون را بفرستید تا تبدیل به  اهنگ کنم😉✨");
}
elseif($text == "🏜تبدیل فیلم به گیف" ){               
file_put_contents("ali.txt","d3");    
SendMessage($chat_id, "خوب حالا کافیه فیلم خودتون را بفرستید تا تبدیل به  گیف کنم😉✨");
}
elseif($ali == "d1"){
 file_put_contents("ali.txt","none");
$video = $message->video;
$file = $video->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.mp3',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>new CURLFile('tikapp.mp3'),
 ]);
 }
 elseif($ali == "d2"){
 file_put_contents("ali.txt","none");
$video = $message->video;
$file = $video->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.gif',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('tikapp.gif'),
 ]);
unlink('tikapp.gif');
 }
//====================audio======================//
elseif($text == "🎧 تبدیلگر اهنگ" ){
	bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"به بخش تبدیلگر آهنگ خوش امدید❤️
➖➖➖➖➖
🔹در این بخش میتونید آهنگ های خودتون رو تبدیل کنید
➖➖➖
فقط کافیه از دکمه های زیر استفاده کنید🔻",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            	'keyboard'=>[
              [
                   ['text'=>"🎹تبدیل ‌ویس ‌به ‌آهنگ"],['text'=>"🎻تبدیل ‌آهنگ ‌به ‌ویس"]
                ],
			[
				['text'=>"برگشت"]
                ]
           ],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($text == "🎹تبدیل ‌ویس ‌به ‌آهنگ" ){               
file_put_contents("ali.txt","e1");    
SendMessage($chat_id, "خوب حالا کافیه ویس خودتون را بفرستید تا تبدیل به  اهنگ کنم😉✨");
}
elseif($text == "🎻تبدیل ‌آهنگ ‌به ‌ویس" ){               
file_put_contents("ali.txt","e2");    
SendMessage($chat_id, "خوب حالا کافیه اهنگ خودتون را بفرستید تا تبدیل به  ویس کنم😉✨");
}
elseif($ali == "e1"){
 file_put_contents("ali.txt","none");
$voice = $message->voice;
$file = $voice->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.mp3',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>new CURLFile('tikapp.mp3'),
 ]);
unlink('tikapp.mp3');
 }
elseif($ali == "e2"){
 file_put_contents("ali.txt","none");
$audio = $message->audio;
$file = $audio->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('tikapp.ogg',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>new CURLFile('tikapp.ogg'),
 ]);
unlink('tikapp.ogg');
 }
//====================text======================//
elseif($text == "📝تبدیل متن به ویس" ){               
file_put_contents("ali.txt","g3");    
SendMessage($chat_id, "به بخش تبدیل متن به ویس خوش امدید❤️
➖➖➖➖➖
🔹در این بخش میتونید متن خود را به ویس تبدیل کنید

⚠️توجه داشته باشید فقط باید متن خود را به صورت لاتین [فینگلیش] وارد کنید
➖➖➖");
}
elseif($ali == "g3"){
 file_put_contents("ali.txt","none");
	$vo = file_get_contents('http://tts.baidu.com/text2audio?lan=en&ie=UTF-8&text='.urlencode($text));
 file_put_contents('vo.ogg',$vo);
 bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>new CURLFile('vo.ogg'),
 ]);
unlink('vo.ogg');
 }

 elseif($text == "✅ ارسال نظر" ){                 
SendMessage($chat_id, "نظرات شما باعث دلگرمی ماست❤️
➖➖➖➖➖
انتفادات پیشنهادات و نظرات خود را برای ما ارسال کنید
برای ارسال کافیست به ربات زیر پیام دهید✔️
➖➖➖
@bat_saz_everet_bot
");
}
 elseif($text == "🔖راهنما" ){                 
SendMessage($chat_id, "به بخش راهنما خوش امدید
➖➖➖➖
در این بخش میتوانید توضیحات در مورد دکمه ها بخوانید☺️
1⃣ساخت لوگو :

🔹با استفاده از این دکمه میتونی لوگو طراحی کنی برای خودت بدون نیاز به دانش گرافیکی خاصی😊
کافیه پس از انتخاب دکمه طراحی لوگو 
از دکمه های طرح لوگو استفاده کنی و بعد از اون باتوجه به دستوری که ربات میده
مثلا متن خود را به لاتین وارد کنید
متن مورد نظر رو ارسال کنید و لوگو خودتون رو دریافت و لذت ببرید😍
➖➖➖➖
2⃣ساخت عکس :
در این بخش میتونی عکسات رو به استیکر و چیزاری دیگه تبدیل کنی یا میتونی فایل اون رو دریافت و در ربات تلگرامی
@stickers
که برای ساخت استیکر هست استفاده کنی😉
➖➖➖➖
3⃣ساخت استیکر :
این بخش جذاب میتونه برای شما عکس هارو به استیکر تبدیل کنه فقط کافیه عکس رو بفرستی تا فایل یا استیکر اون رو دریافت کنی🎈
➖➖➖➖➖
3⃣تبدیل گر ها :
هر کودوم از تبدیل گر ها میتونن فایل های شما مثل اهنگ یا فیلم و حتی متن رو به چیزای دیگه مثل گیف ویس یا اهنگ تبدیل کنن😍
این بخش واقعا عالیه😜
➖➖➖
4⃣پشتبانی و ارسال نظر
تو این بخش هم میتونی با ما در ارتباط باشید و نظرات پیشنهاداتتون رو برای ما ارسال کنید
پشتیبانی ربات اماده دریافت نظرات شمات❤️
➖➖➖
با احترام
ربات پیکاسو");
}
//====================Tikapp======================//
unlink("error_log");
/*
این پیام را به هیچ عنوان پاک نکنید
 کانال نویسنده این سورس
@CadoCreate
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
   ?>
