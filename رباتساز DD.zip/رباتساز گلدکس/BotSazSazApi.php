<?php
/*
این پیام را به هیچ عنوان پاک نکنید
نویسنده این سورس
@GoldDev
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
$token = $_GET['token'];
$id = $_GET['id'];
$type = $_GET['type'];
$WEBADRESS = "https://Crystal.megaranhost.ir/Altos";
$j = date('j');
$maintime = $j+1;
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 //--------------
if($token !== null && $id !== null && $type !== null){
	if($type == "create"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazGold/$un/index.php"))){
mkdir("Sites/$un");
mkdir("Sites/$un/index_files");
$site = file_get_contents("BotsSource/WebSite/index.html");
$site = str_replace("[(*ID*)]",$un,$site);
 save("Sites/$un/index.html",$site);
 $api = file_get_contents("BotsSource/WebSite/api.php");
 $api = str_replace("[(*ID*)]",$un,$api);
 save("Sites/$un/api.php",$api);
 //-
 $test1 = file_get_contents("BotsSource/WebSite/index_files/all.js.download");
 save("Sites/$un/index_files/all.js.download",$test1);
 $test2 = file_get_contents("BotsSource/WebSite/index_files/beacon.js.download");
 save("Sites/$un/index_files/beacon.js.download",$test2);
  $test3 = file_get_contents("BotsSource/WebSite/index_files/cb=gapi(1).loaded_0");
 save("Sites/$un/index_files/cb=gapi(1).loaded_0",$test3);
 $test4 = file_get_contents("BotsSource/WebSite/index_files/core.css");
 save("Sites/$un/index_files/core.css",$test4);
 $test5 = file_get_contents("BotsSource/WebSite/index_files/core.js.download");
 save("Sites/$un/index_files/core.js.download",$test5);
 $test6 = file_get_contents("BotsSource/WebSite/index_files/css");
 save("Sites/$un/index_files/css",$test6);
 $test7 = file_get_contents("BotsSource/WebSite/index_files/dc.js.download");
 save("Sites/$un/index_files/dc.js.download",$test7);
 $test8 = file_get_contents("BotsSource/WebSite/index_files/detector.js.download");
 save("Sites/$un/index_files/detector.js.download",$test8);
 $test9 = file_get_contents("BotsSource/WebSite/index_files/geekaphone.com.js.download");
 save("Sites/$un/index_files/geekaphone.com.js.download",$test9);
 $test10 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-core.css");
 save("Sites/$un/index_files/geekaphone-core.css",$test10);
 $test11 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-core.js.download");
 save("Sites/$un/index_files/geekaphone-core.js.download",$test11);
 $test12 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-index.css");
 save("Sites/$un/index_files/geekaphone-index.css",$test12);
 $test13 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-index.js.download");
 save("Sites/$un/index_files/geekaphone-index.js.download",$test13);
 $test14 = file_get_contents("BotsSource/WebSite/index_files/getuid");
 save("Sites/$un/index_files/getuid",$test14);
 $test15 = file_get_contents("BotsSource/WebSite/index_files/getuid(1)");
 save("Sites/$un/index_files/getuid(1)",$test15);
 $test16 = file_get_contents("BotsSource/WebSite/index_files/gpt.js.download");
 save("Sites/$un/index_files/gpt.js.download",$test16);
 $test17 = file_get_contents("BotsSource/WebSite/index_files/jquery.min.js.download");
 save("Sites/$un/index_files/jquery.min.js.download",$test17);
 $test18 = file_get_contents("BotsSource/WebSite/index_files/lib.js.download");
 save("Sites/$un/index_files/lib.js.download",$test18);
 $test19 = file_get_contents("BotsSource/WebSite/index_files/pixelSync");
 save("Sites/$un/index_files/pixelSync",$test19);
 $test20 = file_get_contents("BotsSource/WebSite/index_files/plusone.js.download");
 save("Sites/$un/index_files/plusone.js.download",$test20);
 $test21 = file_get_contents("BotsSource/WebSite/index_files/quant.js.download");
 save("Sites/$un/index_files/quant.js.download",$test21);
 $test22 = file_get_contents("BotsSource/WebSite/index_files/rpc-shindig_random.js.download");
 save("Sites/$un/index_files/rpc-shindig_random.js.download",$test22);
 $test23 = file_get_contents("BotsSource/WebSite/index_files/rs=AGLTcCN-9gVorbD2Az76744xqpQBLERe4Q");
 save("Sites/$un/index_files/rs=AGLTcCN-9gVorbD2Az76744xqpQBLERe4Q",$test23);
 $test24 = file_get_contents("BotsSource/WebSite/index_files/rtset");
 save("Sites/$un/index_files/rtset",$test24);
 $test25 = file_get_contents("BotsSource/WebSite/index_files/rules-p-N04C2m09Yy8f8.js.download");
 save("Sites/$un/index_files/rules-p-N04C2m09Yy8f8.js.download",$test25);
 $test26 = file_get_contents("BotsSource/WebSite/index_files/sovrn_standalone_beacon.js.download");
 save("Sites/$un/index_files/sovrn_standalone_beacon.js.download",$test26);
 $test27 = file_get_contents("BotsSource/WebSite/index_files/widgets.js.download");
 save("Sites/$un/index_files/widgets.js.download",$test27);
//---
mkdir("Bots/BotSazGold/$un");
mkdir("Bots/BotSazGold/$un/data");
$index = file_get_contents("BotsSource/BotSazSazSource/index.php");
  $index = str_replace("[(*TOKEN*)]",$token,$index);
  $index = str_replace("[(*BotSazGoldWEB*)]","$WEBADRESS/Sites/$un",$index);
  $index = str_replace("[(*ADMIN*)]",$id,$index);
  $index = str_replace("[(*TIME*)]","99999",$index);
  $index = str_replace("[(*BOT*)]",$un,$index);
  save("Bots/BotSazGold/$un/index.php",$index);	
  $settings = json_decode(file_get_contents("Bots/BotSazGold/$un/data/settings.json"),true);
  $settings["mode"] = "on";
  $settings["selledBotSazGold"] = "0";
  $settings["maxcreate"] = "2";
  $settings["freeallbots"] = "0";
  $settings["vipaccs"] = "0";
  $settings["cinvite"] = "15";
$settings["starttext"] = "سلام 😉♥️
به ربات ساز هوشمند گلد خوش آمدی
💠برای کار با ربات از دکمه های زیراستفاده کنید";
  $settings["buttons"]["btn1"] = "ساخت ربات";
  $settings["buttons"]["btn2"] = "ساخت ربات ساز";
  $settings["buttons"]["btn3"] = "ویژه کردن حساب";
  $settings["buttons"]["btn4"] = "پروفایل من";
  $settings["buttons"]["btn5"] = "سایت ربات ساز ما";
  $settings["buttons"]["btn6"] = "حذف ربات";
  $settings["buttons"]["btn7"] = "کد رایگان";
  $settings["buttons"]["btn8"] = "زیرمجموعه گیری";
  $settings["buttons"]["btn9"] = "قوانین";
  $settings["buttons"]["btn10"] = "کانال ما";
  $settings["buttons"]["btn11"] = "رزرو تبلیغات";
  $settings["buttons"]["btn12"] = "راهنما";
  $settings["buttons"]["btn13"] = "پشتیبانی آنلاین";
$settings["text"]["text1"] = "
🔻یک ربات را برای ساخت انتخاب کنید";
$settings["text"]["text2"] = "
❌حساب شما ویژه نمی باشد 
جهت ویژه کردن حساب خود به پشتیبانی مراجعه نمایید";
$settings["text"]["text3"] = "
حساب شما رایگان می باشد ❗️
برای ویژه کردن حساب خود از طریق دکمه زیرمجموعه گیری برن خود را دریافت کنید و طبق تعداد معین شدع زیرمجموعه جمع آوری کنید و سپس حساب خود را ویژه کنید";
$settings["text"]["text4"] = "
🔸تعداد افراد دعوت شده : INVITE
🔹آیدی عددی شما : ID
🔸تعداد ربات های شما : BOTS
🔹نوع حساب شما : TYPE
";
 $settings["text"]["text5"] = "
🔻برای ساخت ربات میتوانید همچنان در سایت هم به همان شیوه ربات خود را بسازید 

";
$settings["text"]["text6"] = "
🛡برای حذف ربات ; توکن آن ارسال کنید !";
$settings["text"]["text7"] = "
🎉لطفا کدی که در کانال قرار گرفته را وارد نمایید";
  $settings["text"]["text8"] = "متن نمایه برای زیر مجموعه گیری";
$settings["text"]["text9"] = "
ℹ️ قوانین ساخت و استفاده از ربات:

📕 تمامی مطلب ها باید تابع قوانین جمهوری اسلامی ایران باشد.

📔 ساخت هرگونه ربات +18 که خلاف قوانین ربات میباشد و در صورت مشاهده ربات مورد نظر مسدود و همچنین صاحب ربات از تمامی ربات ها بلاک میشود.

📙 مسئولیت پیام های رد و بدل شده در هر ربات با صاحب آن میباشد و ما هیچگونه مسئولیتی نداریم.

📘 در صورت مشاهده استفاده از قابلیت های ربات در چیز های منفی به شدت برخورد میشود.

📚 اگر به هر دلیلی درخواست های ربات شما به سرور ما بیش از حد معمول باشد (و اشتراک ربات ویژه نباشد) چند باری به شما اخطار داده میشود، اگر این اخطار ها نادیده گرفته شوند ربات شما مسدود و به هیچ عنوان از محدودیت خارج نمیشود.";
  $settings["text"]["text10"] = "متن نمایه برای کانال ما";
$settings["text"]["text11"] = "
🏷جهت تبلیغ در این ربات به پشتیبانی مراجعه نمایید";
$settings["text"]["text12"] = "
1️⃣ ابتدا به ربات ( @BotFather ) مراجعه کنید
2️⃣ دستور /newbot رو ارسال کنید
3️⃣ یک نام برای ربات ارسال کنید
4️⃣ پس از ارسال نام،یک یوزرنیم ارسال کنید
❌ توجه کنین حتما باید در آخر یوزرنیم ارسالی کلمه bot با حروف کوچیک یا بزرگ (فرقی نداره) وجود داشته باشه
5️⃣ اگر با پیغام زیر برخورد کردید
Sorry, this username is already taken. Please try something different.
یعنی قبلا یکی این یوزرنیم رو ثبت کرده یوزرنیم دیگری وارد کنید. اگر این پیغام رو دریافت نکردید یعنی کار حل است
6️⃣ حالا به این ربات مراجعه کنید و دکمه (☢️ساخت ربات) رو بزنید
7️⃣ سپس پیام آخری که از ربات ( @BotFather ) دریافت کردید رو اون جایی که مثل این یه متن نوشته👇

369762599:AAFeMVVjM8KSYz_-1f-6nowsl22-0gGAr36
کپی کن و بفرست به همین ربات😁
8️⃣ ربات شما با موفقیت ثبت شد";
$settings["text"]["text13"] = "
📫لطفا پیام خود را ارسال نمایید !";
$outjson = json_encode($settings,true);
file_put_contents("Bots/BotSazGold/$un/data/settings.json",$outjson);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazGold/$un/index.php");
	}}
	if($type == "delete"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/BotSazGold/$un/index.php"))){
deletefolder("Bots/BotSazGold/$un");
rmdir("Bots/BotSazGold/$un");
deletefolder("Sites/$un");
rmdir("Sites/$un");
	}}
	if($type == "update"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/BotSazGold/$un/index.php"))){
unlink("Bots/BotSazGold/$un/index.php");
unlink("Sites/$un/api.php");
unlink("Sites/$un/index.html");
$index = file_get_contents("BotsSource/BotSazSazSource/index.php");
  $index = str_replace("[(*TOKEN*)]",$token,$index);
  $index = str_replace("[(*BotSazGoldWEB*)]","$WEBADRESS/Sites/$un",$index);
  $index = str_replace("[(*ADMIN*)]",$id,$index);
  $index = str_replace("[(*TIME*)]","99999",$index);
  $index = str_replace("[(*BOT*)]",$un,$index);
  save("Bots/BotSazGold/$un/index.php",$index);	
  $site = file_get_contents("BotsSource/WebSite/index.html");
$site = str_replace("[(*ID*)]",$un,$site);
 save("Sites/$un/index.html",$site);
 $api = file_get_contents("BotsSource/WebSite/api.php");
 $api = str_replace("[(*ID*)]",$un,$api);
 save("Sites/$un/api.php",$api);
	}}
    if($type == "free"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (!file_exists("Bots/BotSazGold/$un/index.php"))){
mkdir("Sites/$un");
mkdir("Sites/$un/index_files");
$site = file_get_contents("BotsSource/WebSite/index.html");
$site = str_replace("[(*ID*)]",$un,$site);
 save("Sites/$un/index.html",$site);
 $api = file_get_contents("BotsSource/WebSite/api.php");
 save("Sites/$un/api.php",$api);
 //-
 $test1 = file_get_contents("BotsSource/WebSite/index_files/all.js.download");
 save("Sites/$un/index_files/all.js.download",$test1);
 $test2 = file_get_contents("BotsSource/WebSite/index_files/beacon.js.download");
 save("Sites/$un/index_files/beacon.js.download",$test2);
  $test3 = file_get_contents("BotsSource/WebSite/index_files/cb=gapi(1).loaded_0");
 save("Sites/$un/index_files/cb=gapi(1).loaded_0",$test3);
 $test4 = file_get_contents("BotsSource/WebSite/index_files/core.css");
 save("Sites/$un/index_files/core.css",$test4);
 $test5 = file_get_contents("BotsSource/WebSite/index_files/core.js.download");
 save("Sites/$un/index_files/core.js.download",$test5);
 $test6 = file_get_contents("BotsSource/WebSite/index_files/css");
 save("Sites/$un/index_files/css",$test6);
 $test7 = file_get_contents("BotsSource/WebSite/index_files/dc.js.download");
 save("Sites/$un/index_files/dc.js.download",$test7);
 $test8 = file_get_contents("BotsSource/WebSite/index_files/detector.js.download");
 save("Sites/$un/index_files/detector.js.download",$test8);
 $test9 = file_get_contents("BotsSource/WebSite/index_files/geekaphone.com.js.download");
 save("Sites/$un/index_files/geekaphone.com.js.download",$test9);
 $test10 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-core.css");
 save("Sites/$un/index_files/geekaphone-core.css",$test10);
 $test11 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-core.js.download");
 save("Sites/$un/index_files/geekaphone-core.js.download",$test11);
 $test12 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-index.css");
 save("Sites/$un/index_files/geekaphone-index.css",$test12);
 $test13 = file_get_contents("BotsSource/WebSite/index_files/geekaphone-index.js.download");
 save("Sites/$un/index_files/geekaphone-index.js.download",$test13);
 $test14 = file_get_contents("BotsSource/WebSite/index_files/getuid");
 save("Sites/$un/index_files/getuid",$test14);
 $test15 = file_get_contents("BotsSource/WebSite/index_files/getuid(1)");
 save("Sites/$un/index_files/getuid(1)",$test15);
 $test16 = file_get_contents("BotsSource/WebSite/index_files/gpt.js.download");
 save("Sites/$un/index_files/gpt.js.download",$test16);
 $test17 = file_get_contents("BotsSource/WebSite/index_files/jquery.min.js.download");
 save("Sites/$un/index_files/jquery.min.js.download",$test17);
 $test18 = file_get_contents("BotsSource/WebSite/index_files/lib.js.download");
 save("Sites/$un/index_files/lib.js.download",$test18);
 $test19 = file_get_contents("BotsSource/WebSite/index_files/pixelSync");
 save("Sites/$un/index_files/pixelSync",$test19);
 $test20 = file_get_contents("BotsSource/WebSite/index_files/plusone.js.download");
 save("Sites/$un/index_files/plusone.js.download",$test20);
 $test21 = file_get_contents("BotsSource/WebSite/index_files/quant.js.download");
 save("Sites/$un/index_files/quant.js.download",$test21);
 $test22 = file_get_contents("BotsSource/WebSite/index_files/rpc-shindig_random.js.download");
 save("Sites/$un/index_files/rpc-shindig_random.js.download",$test22);
 $test23 = file_get_contents("BotsSource/WebSite/index_files/rs=AGLTcCN-9gVorbD2Az76744xqpQBLERe4Q");
 save("Sites/$un/index_files/rs=AGLTcCN-9gVorbD2Az76744xqpQBLERe4Q",$test23);
 $test24 = file_get_contents("BotsSource/WebSite/index_files/rtset");
 save("Sites/$un/index_files/rtset",$test24);
 $test25 = file_get_contents("BotsSource/WebSite/index_files/rules-p-N04C2m09Yy8f8.js.download");
 save("Sites/$un/index_files/rules-p-N04C2m09Yy8f8.js.download",$test25);
 $test26 = file_get_contents("BotsSource/WebSite/index_files/sovrn_standalone_beacon.js.download");
 save("Sites/$un/index_files/sovrn_standalone_beacon.js.download",$test26);
 $test27 = file_get_contents("BotsSource/WebSite/index_files/widgets.js.download");
 save("Sites/$un/index_files/widgets.js.download",$test27);
//---
mkdir("Bots/BotSazGold/$un");
mkdir("Bots/BotSazGold/$un/data");
$index = file_get_contents("BotsSource/BotSazSazSource/index.php");
  $index = str_replace("[(*TOKEN*)]",$token,$index);
  $index = str_replace("[(*BotSazGoldWEB*)]","$WEBADRESS/Sites/$un",$index);
  $index = str_replace("[(*ADMIN*)]",$id,$index);
  $index = str_replace("[(*TIME*)]",$maintime,$index);
  $index = str_replace("[(*BOT*)]",$un,$index);
  save("Bots/BotSazGold/$un/index.php",$index);	
  $settings = json_decode(file_get_contents("Bots/BotSazGold/$un/data/settings.json"),true);
  $settings["mode"] = "on";
   $settings["maxcreate"] = "2";
   $settings["selledBotSazGold"] = "0";
   $settings["cinvite"] = "15";
     $settings["freeallbots"] = "0";
  $settings["vipaccs"] = "0";
  $settings["starttext"] = "این متن بصورت نمایه روی ربات ساز شما تنظیم شده😊
از مدیریت میتوانید این متن را تغییر دهید😃";
  $settings["buttons"]["btn1"] = "ساخت ربات";
  $settings["buttons"]["btn2"] = "ساخت ربات ساز";
  $settings["buttons"]["btn3"] = "ویژه کردن حساب";
  $settings["buttons"]["btn4"] = "پروفایل من";
  $settings["buttons"]["btn5"] = "سایت ربات ساز ما";
  $settings["buttons"]["btn6"] = "حذف ربات";
  $settings["buttons"]["btn7"] = "کد رایگان";
  $settings["buttons"]["btn8"] = "زیرمجموعه گیری";
  $settings["buttons"]["btn9"] = "قوانین";
  $settings["buttons"]["btn10"] = "کانال ما";
  $settings["buttons"]["btn11"] = "رزرو تبلیغات";
  $settings["buttons"]["btn12"] = "راهنما";
  $settings["buttons"]["btn13"] = "پشتیبانی آنلاین";
  $settings["text"]["text1"] = "متن نمایه برای ساخت ربات";
  $settings["text"]["text2"] = "متن نمایه برای ساخت ربات ساز";
  $settings["text"]["text3"] = "متن نمایه برای ویژه کردن حساب";
  $settings["text"]["text4"] = "متن نمایه پروفایل کاربر";
  $settings["text"]["text5"] = "متن نمایه سایت ربات ساز ما";
  $settings["text"]["text6"] = "متن نمایه برای حذف ربات";
  $settings["text"]["text7"] = "متن نمایه برای وارد کردن کد رایگان";
  $settings["text"]["text8"] = "متن نمایه برای زیر مجموعه گیری";
  $settings["text"]["text9"] = "متن نمایه برای قوانین";
  $settings["text"]["text10"] = "متن نمایه برای کانال ما";
  $settings["text"]["text11"] = "متن نمایه برای تبلیغات";
  $settings["text"]["text12"] = "متن نمایه برای راهنمای ربات";
  $settings["text"]["text13"] = "متن نمایه برای پشتیبانی آنلاین";
$outjson = json_encode($settings,true);
file_put_contents("Bots/BotSazGold/$un/data/settings.json",$outjson);
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazGold/$un/index.php");
  
	}}
	
}
/*
این پیام را به هیچ عنوان پاک نکنید
نویسنده این سورس
@GoldDev
است و کپی بدون ذکر منبع شرعا از نظر نویسنده حرام است
پاک کردن این پیام نیز از نظر نویسنده ممنوع است
*/
unlink('error_log');
 ?>
