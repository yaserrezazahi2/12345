<?php
$token = $_GET['token'];
$id = $_GET['id'];
$type = $_GET['type'];
$channel = $_GET['channel'];
$WEBADRESS = "https://Crystal.megaranhost.ir/Altos";
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
 //--------------
if($token !== null && $id !== null && $type !== null){
	if($type == "create"){
	$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
if($ok == "1" && (!file_exists("Bots/BotSazSazSaz/$un/index.php"))){
mkdir("Bots/BotSazSaz/$un");
mkdir("Bots/BotSazSaz/$un/data");
$index = file_get_contents("BotsSource/BotSazSazSazSource/index.php");
  $index = str_replace("[(*TOKEN*)]",$token,$index);
  $index = str_replace("[(*ADMIN*)]",$id,$index);
  $index = str_replace("[(*CHANNEL*)]",$channel,$index);
  save("Bots/BotSazSaz/$un/index.php",$index);	
  file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=$WEBADRESS/Bots/BotSazSaz/$un/index.php");
	}}
	if($type == "delete"){
		$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
	if($ok == "1" && (file_exists("Bots/BotSazSaz/$un/index.php"))){
deletefolder("Bots/BotSazSaz/$un");
rmdir("Bots/BotSazSaz/$un");
	}}}
unlink('error_log');
 ?>

