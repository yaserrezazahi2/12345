<?php
ob_start();

define('API_KEY','[*[TOKEN]*]');
//-------------------------------function-bot---------------------------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//----------------------------Variable-----------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$chatid = $update->callback_query->message->chat->id;
$from_id = $message->from->id;
mkdir("data/$from_id");
$message_id = $message->message_id;
$messageid = $update->callback_query->message->message_id;
$text1 = $message->text;
$inline = $update->inline_query->query;
$data = $update->callback_query->data;
$step = file_get_contents("data/$from_id/step.txt");
$bot_type = file_get_contents("data/bottype.txt");
$adstext = file_get_contents("data/adstext.txt");
$creator_cmd = file_get_contents("data/creator-cmd.txt");
//----------------------------------------------------------------------------
function SendMessage($chat_id, $text , $reply_id){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$text,
        'reply_to_message_id'=>$message_id,
        'parse_mode'=>"MarkDown"
    ]);
}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}

function objectToArrays($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        if (is_object($object)) {
            $object = get_object_vars($object);
        }
        return array_map("objectToArrays", $object);
    }
//---------
if($text1 == "/start"){
    if (!file_exists("data/$from_id/step.txt")) {
		 mkdir("data/$from_id");
        file_put_contents("data/$from_id/step.txt","none");
	}
if($bot_type != 'gold'){
		bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>$adstext,
		]);
	}
	file_put_contents("data/$from_id/step.txt","none");
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به ربات زیبا کننده متن خوشامدید🌹
لطفا متن خود را ارسال کنید تا نتیجه را مشاهده کنید💁🏻‍♂️
همچنین میتوانید از ربات به صورت inline نیز استفاده کنید
@[*[BOT]*] TEXT
برای این کار متن بالا را در کیبورد خود تایپ و منتظر نمایش نتیجه باشد💎",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"info"]]
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}  
if($text1 == "info"){
     bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ربات هوشمند ساخت اسم پروفایل با فنت های انگلیسی🍂",
 'parse_mode'=>"HTML",
	 ]);
}
if($text1 == "Create Again" or $text1 == "/again"){
    file_put_contents("data/$from_id/step.txt","none"); 
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به ربات زیبا کننده متن خوشامدید🌹
لطفا متن خود را ارسال کنید تا نتیجه را مشاهده کنید💁🏻‍♂️
همچنین میتوانید از ربات به صورت inline نیز استفاده کنید
@[*[BOT]*] TEXT
برای این کار متن بالا را در کیبورد خود تایپ و منتظر نمایش نتیجه باشد💎",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"info"]]
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
elseif($step == "none" && $text1 != "/start" && $text1 != "info" && $text1 != "Create Again" && $text1 != "/again"){
    $edited = str_replace(" ","+",$text1);
	file_put_contents("data/$from_id/step.txt","font"); 
   $url2 = "http://api.mostafa-am.ir/painting-name/$edited";
   $jsurl=json_decode(file_get_contents($url2),true);
   
   for ($i=0; $i <= 99; $i++){
	   $d3=$jsurl["result"]["$i"]["name"];
        $d4[] = [ 	['text'=>"$d3"]];
        }
	    $d4[] = [ 	['text'=>"Create Again"]];
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لیست فنت های ایجاد شده :
جهت ایجاد دوباره فنت از دستور 
/again 
استفاده کنید🤠",
     'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>$d4
	])
]); 
}
elseif(preg_match('/^\/([Cc][Rr][Ee][Aa][Tt][Oo][Rr])/',$text1)){
	bot ('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$creator_cmd,
		]);
}
elseif($inline){
    $edited = str_replace(" ","+",$inline);
    $url2 = "http://api.mostafa-am.ir/painting-name/$edited";
   $jsurl=json_decode(file_get_contents($url2),true);
   $ra1 = rand(0,99);
	$golddev0=$jsurl["result"]["$ra1"]["name"];
	$ra2 = rand(0,99);
	$golddev1=$jsurl["result"]["$ra2"]["name"];
	$ra3 = rand(0,99);
	$golddev2=$jsurl["result"]["$ra3"]["name"];
	$ra4 = rand(0,99);
	$golddev3=$jsurl["result"]["$ra4"]["name"];
	$ra5 = rand(0,99);
	$golddev4=$jsurl["result"]["$ra5"]["name"];
	$ra6 = rand(0,99);
	$golddev5=$jsurl["result"]["$ra6"]["name"];
	$ra7 = rand(0,99);
	$golddev6=$jsurl["result"]["$ra7"]["name"];
	$ra8 = rand(0,99);
	$golddev7=$jsurl["result"]["$ra8"]["name"];
	$ra9 = rand(0,99);
	$golddev8=$jsurl["result"]["$ra9"]["name"];
	$ra10 = rand(0,99);
	$golddev9=$jsurl["result"]["$ra10"]["name"];
	$ra11 = rand(0,99);
	$golddev10=$jsurl["result"]["$ra11"]["name"];
	$ra12 = rand(0,99);
	$golddev11=$jsurl["result"]["$ra12"]["name"];
	$ra13 = rand(0,99);
	$golddev12=$jsurl["result"]["$ra13"]["name"];
	$ra14 = rand(0,99);
	$golddev13=$jsurl["result"]["$ra14"]["name"];
	$ra15 = rand(0,99);
	$golddev14=$jsurl["result"]["$ra15"]["name"];

	 bot('answerInlineQuery', [
        'inline_query_id' => $update->inline_query->id,
        'results' => json_encode([[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev0",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev0"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev1",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev1"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' =>"$golddev2",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev2"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev3",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev3"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev4",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev4"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev5",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev5"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' =>"$golddev6",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev6"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' =>"$golddev7",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev7"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' =>"$golddev8",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev8"],
        ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev9",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev9"],
             ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev10",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev10"],
             ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev11",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev11"],
             ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev12",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev12"],
             ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev13",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev13"],
             ],[
            'type' => 'article',
            'thumb_url'=>"http://uupload.ir/files/nih7_1421856945_ifont-logo.png",
            'id' => base64_encode(rand(5,555)),
            'title' => "$golddev14",
            'input_message_content' => ['parse_mode' => 'HTML', 'message_text' => "$golddev14"],

            
        ]])
    ]);
}
	
	
	
unlink('error_log');
?>